extends Node
var checks:=0
var failures:=0
const Jobs=preload("res://scripts/FleetJobs.gd")
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:failures+=1;print("JOB FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate();add_child(main)
 for i in 12:await get_tree().process_frame
 get_tree().paused=true
 var ship=PlayerState.fleet_ships[0]
 var ai=ship.get_node("AIShipController")
 var stations=get_tree().get_nodes_in_group("stations")
 var source=stations[0]
 var dest=stations[1]
 source.faction_id=&"player";dest.faction_id=&"player"
 source.position=Vector2(60000,60000);dest.position=Vector2(65000,60000)
 ship.position=source.position
 ship.inventory.clear();source.inventory.clear();dest.inventory.clear()
 source.inventory.add_item(&"iron",40,GameData.items)
 ai.cancel_all_commands()
 ai.fleet_job={"kind":"trade","source":source,"destination":dest,"item":&"iron","amount":10,"repeat":true,"phase":"collect"}
 Jobs.tick(ai,.3)
 check(ship.inventory.get_amount(&"iron")==10 and source.inventory.get_amount(&"iron")==30,"load conserves cargo")
 Jobs.tick(ai,.3)
 check(dest.inventory.get_amount(&"iron")==0,"cannot deliver remotely")
 ship.position=dest.position
 Jobs.tick(ai,.3)
 check(dest.inventory.get_amount(&"iron")==10 and ship.inventory.get_amount(&"iron")==0,"delivery conserves cargo")
 check(ai.fleet_job.phase=="collect","repeat starts next trip")
 ai.set_command_queue([{"type":GlobalEnums.FleetCommand.GO_WAIT,"position":ship.position}])
 check(ai.fleet_job.is_empty(),"manual command interrupts job")
 ai.default_behavior="patrol"
 ai._command_queue.clear();ai._execute_next_command()
 check(ai._state==AIShipController.State.PATROL_AREA,"queue completion uses default")
 ai.cancel_all_commands();ai._think()
 check(ai._state==AIShipController.State.IDLE,"stop holds instead of restarting default")
 var recipient=PlayerState.fleet_ships[1]
 recipient.position=source.position;recipient.inventory.clear()
 ship.position=source.position
 ai.fleet_job={"kind":"resupply","source":source,"destination":recipient,"item":&"iron","amount":5,"repeat":true,"phase":"collect"}
 Jobs.tick(ai,.3);Jobs.tick(ai,.3)
 check(recipient.inventory.get_amount(&"iron")==5,"resupply reaches requested stock")
 var stock=source.inventory.get_amount(&"iron")
 Jobs.tick(ai,.3)
 check(source.inventory.get_amount(&"iron")==stock,"resupply does not overstock")
 ai.cancel_all_commands()
 var miner:ShipInstance
 for candidate in PlayerState.fleet_ships:
  if "miner" in str(candidate.ship_data.id):miner=candidate;break
 var mine_ai=miner.get_node("AIShipController")
 miner.position=Vector2(70000,70000);miner.inventory.clear()
 var rock=SectorManager.current_sector.get_node("Asteroids").get_child(0)
 rock.position=miner.position+Vector2(100,0)
 rock.hull=1;rock._remaining_yield=3
 var material=AsteroidInstance.MATERIAL_IDS[rock.material_type]
 mine_ai.cancel_all_commands()
 mine_ai.fleet_job={"kind":"mine","destination":dest,"item":material,"amount":3,"repeat":false,"phase":"collect"}
 Jobs.tick(mine_ai,.3)
 check(miner.inventory.get_amount(material)==3,"mining yields real cargo")
 Jobs.tick(mine_ai,.3)
 miner.position=dest.position
 var deposited=dest.inventory.get_amount(material)
 Jobs.tick(mine_ai,.3)
 check(dest.inventory.get_amount(material)==deposited+3 and mine_ai.fleet_job.is_empty(),"mining delivery completes one-shot job")
 source.faction_id=&"terran_republic"
 PlayerState.set_reputation(source.faction_id,1000)
 source.inventory.add_item(&"ballistic_ammo",20,GameData.items)
 ship.position=source.position;ship.inventory.clear()
 PlayerState.credits=100000
 ai.fleet_job={"kind":"trade","source":source,"destination":dest,"item":&"ballistic_ammo","amount":2,"repeat":false,"phase":"collect"}
 var credits=PlayerState.credits
 Jobs.tick(ai,.3)
 check(ship.inventory.get_amount(&"ballistic_ammo")==2 and PlayerState.credits==credits-2*source.get_sell_price(&"ballistic_ammo"),"external purchases spend real credits")
 var editor=preload("res://scripts/FleetJobEditor.gd").new();editor.ai=ai;add_child(editor)
 check(editor.source.item_count>0 and editor.destination.item_count>0,"job editor lists stations")
 var logic=preload("res://scripts/ShipLogicPanel.gd").new();add_child(logic);logic._process(0)
 check(logic.ships.item_count>0,"ship logic lists owned ships")
 print("FLEET_JOBS: ",checks," checks, ",failures," failures")
 get_tree().quit(failures)
