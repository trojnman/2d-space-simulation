extends Node
var failures := 0
func check(ok: bool, msg: String) -> void:
	if not ok:
		failures += 1
		push_error(msg)
func mouse(button: int, pressed: bool = true) -> InputEventMouseButton:
	var event := InputEventMouseButton.new()
	event.button_index = button
	event.pressed = pressed
	return event
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var player: Player = main.get_node("Player")
	var ms: MissileSystem = player.get_node("MissileSystem")
	player.inventory.clear()
	player.inventory.add_item(&"missile_s1",100)
	ms._input(mouse(MOUSE_BUTTON_RIGHT))
	var zoom: Vector2 = player.camera._target_zoom
	ms._input(mouse(MOUSE_BUTTON_WHEEL_UP))
	player.camera._unhandled_input(mouse(MOUSE_BUTTON_WHEEL_UP))
	check(ms.get_selected_count() == 2, "Scroll increases salvo")
	check(player.camera._target_zoom == zoom, "Zoom blocked while arming held")
	ms._input(mouse(MOUSE_BUTTON_WHEEL_DOWN))
	check(ms.get_selected_count() == 1, "Scroll decreases salvo")
	ms._input(mouse(MOUSE_BUTTON_RIGHT,false))
	check(ms.get_state() == MissileSystem.State.ARMING and not ms.is_arm_button_held(), "Release begins arming")
	player.camera._unhandled_input(mouse(MOUSE_BUTTON_WHEEL_UP))
	check(player.camera._target_zoom.x > zoom.x, "Zoom resumes after release")
	ms.cancel()
	for id in [&"missile_boat", &"medium_missile_boat", &"heavy_missile_boat"]:
		player.initialize(GameData.ships[id])
		check(ms._get_max_missiles() == [6,12,18][int(player.ship_data.ship_class)], "Boat capacity " + str(id))
	player.inventory.clear()
	player.inventory.add_item(&"missile_s1",3)
	check(ms._get_max_missiles() == 3, "Salvo limited by ammo")
	player.inventory.clear()
	ms._input(mouse(MOUSE_BUTTON_RIGHT))
	check(ms.get_state() == MissileSystem.State.IDLE, "No ammo cannot arm")
	ms.cancel()
	print("MISSILE CONTROLS: %d failures" % failures)
	get_tree().quit(1 if failures else 0)
