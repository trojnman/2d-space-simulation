extends Node
var failures := 0
var checks := 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(message)
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var home: StationInstance
	var yard: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_military": home = station
		if station.station_data.id == &"sol_prime_shipyard": yard = station
	var spawner: StationSpawner
	for child in home.get_children():
		if child is StationSpawner: spawner = child
	spawner._try_spawn()
	var original: ShipInstance = spawner._spawned_ships[0]
	var id: StringName = original.ship_data.id
	original.ship_destroyed.emit(original,null)
	original.free()
	check(spawner._replacement_requests.size() == 1, "Loss creates one replacement request")
	var combat := ShipInstance.new()
	combat.ship_data = GameData.ships[&"fighter"]
	var miner := ShipInstance.new()
	miner.ship_data = GameData.ships[&"miner"]
	var hauler := ShipInstance.new()
	hauler.ship_data = GameData.ships[&"hauler"]
	FactionManager._faction_build_ships(home.faction_id, [home,yard], [combat,combat,combat,combat,miner,miner,miner,hauler,hauler])
	check(yard.get_manufacture_queue().is_empty(), "Pending replacement counts toward strategic fleet goal")
	yard.requested_supply_ship = &"fighter"
	FactionManager._faction_build_ships(home.faction_id, [yard], [])
	check(yard.get_manufacture_queue().is_empty(), "Strategic builder respects player supply priority")
	yard.requested_supply_ship = &""
	combat.free()
	miner.free()
	hauler.free()
	yard.station_credits = 0
	check(not spawner._request_replacement(), "No funds blocks replacement")
	check(yard.get_manufacture_queue().is_empty(), "Unfunded request creates no ship job")
	yard.station_credits = 100000
	yard.inventory.clear()
	check(not spawner._request_replacement(), "Missing materials block replacement")
	check(yard.replacement_supply_ship == id, "Shortage requests physical resupply")
	var recipe := yard.get_ship_recipe(id)
	for item_id in recipe["inputs"]: yard.inventory.add_item(item_id,recipe["inputs"][item_id])
	yard.requested_supply_ship = &"heavy_fighter"
	check(not spawner._request_replacement(), "Player supply request has priority")
	yard.requested_supply_ship = &""
	var before: int = yard.station_credits
	check(spawner._request_replacement(), "Funded replacement queues")
	check(yard.station_credits == before-yard.get_production_cost(recipe), "Replacement pays worker cost")
	check(yard.inventory.get_all_items().is_empty(), "Replacement consumes all recipe inputs")
	check(not spawner._request_replacement() and yard.get_manufacture_queue().size() == 1, "No duplicate replacement while building")
	check(spawner.get_ship_count() == 0, "No ship before build timer completes")
	yard._process_manufacturing(3.1)
	check(spawner.get_ship_count() == 1 and spawner._replacement_requests.is_empty(), "Finished ship delivered to original fleet")
	var ship: ShipInstance = spawner._spawned_ships[0]
	check(ship.ship_data.id == id and ship.faction_id == home.faction_id, "Replacement preserves type and faction")
	check(not ship.equipped_weapons.is_empty(), "Prepaid equipment installed")
	check(not spawner._request_replacement(), "Fulfilled request does not build again")
	print("FLEET REPLACEMENT: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
