extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:failures+=1;print("TRADE FAIL: ",label)
func _ready()->void:
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 12:await get_tree().process_frame
 get_tree().paused=true
 var source:StationInstance
 var buyer:StationInstance
 for station in get_tree().get_nodes_in_group("stations"):
  if station.station_data.station_type==StationData.TYPE_MANUFACTURING:source=station
  if station.station_data.station_type==StationData.TYPE_SHIPYARD:buyer=station
 var ship=PlayerState.fleet_ships[0]
 var ai=ship.get_node("AIShipController")
 ai.cancel_all_commands();ai.default_suspended=false
 ai.default_behavior="auto_trade";ai.automation_home=SectorManager.current_sector_id;ai.automation_hops=0;ai.automation_item=&"hull_parts";ai.automation_amount=2
 source.faction_id=&"terran_republic";buyer.faction_id=&"terran_republic"
 PlayerState.set_reputation(&"terran_republic",1000)
 source.position=Vector2(60000,60000);buyer.position=Vector2(64000,60000)
 source.inventory.add_item(&"hull_parts",10000,GameData.items)
 buyer.inventory.remove_item(&"hull_parts",buyer.inventory.get_amount(&"hull_parts"))
 ship.inventory.clear();ship.position=source.position
 PlayerState.credits=100000
 var faction_before=FactionManager.get_faction_credits(&"terran_republic")
 var player_before=PlayerState.credits
 check(buyer.get_buy_price(&"hull_parts")>source.get_sell_price(&"hull_parts"),"manufacturer-to-consumer route has margin")
 preload("res://scripts/FleetAutomation.gd").plan(ai)
 check(not ai.fleet_job.is_empty(),"auto trade selects profitable route")
 if not ai.fleet_job.is_empty():
  var selected_source=ai.fleet_job.source
  var selected_buyer=ai.fleet_job.destination
  var quantity=int(ai.fleet_job.amount)
  var expected_profit=quantity*(selected_buyer.get_buy_price(&"hull_parts")-selected_source.get_sell_price(&"hull_parts"))
  ship.position=selected_source.position
  preload("res://scripts/FleetJobs.gd").tick(ai,.3)
  check(ship.inventory.get_amount(&"hull_parts")==quantity,"auto trader purchases cargo")
  ship.position=selected_buyer.position
  preload("res://scripts/FleetJobs.gd").tick(ai,.3)
  check(ship.inventory.get_amount(&"hull_parts")==0,"auto trader delivers cargo")
  check(PlayerState.credits==player_before+expected_profit,"completed trade earns real profit")
  check(FactionManager.get_faction_credits(&"terran_republic")+PlayerState.credits==faction_before+player_before,"credits conserved between player and faction")
 check(source.get_sell_price(&"laser_autocannon_s1")==StationData.calc_sell_price(GameData.items[&"laser_autocannon_s1"].base_price),"equipment pricing preserved")
 print("AUTO_TRADE: ",checks," checks, ",failures," failures")
 get_tree().quit(failures)
