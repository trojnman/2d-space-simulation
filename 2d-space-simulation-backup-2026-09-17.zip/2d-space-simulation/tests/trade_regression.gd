extends Node
var failures: int = 0
var checks: int = 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(message)
	else: print("PASS: " + message)
func _ready() -> void:
	call_deferred("run")
func run() -> void:
	await get_tree().process_frame
	var station := StationInstance.new()
	station.station_data = StationData.new()
	station.station_data.station_type = StationData.TYPE_TRADE
	var cargo := InventoryData.new()
	var item := GameData.get_item(&"hull_parts")
	cargo.capacity = item.volume * 2
	station.inventory.add_item(&"hull_parts", 10)
	PlayerState.credits = 100000
	station.station_credits = 20000
	var total: int = PlayerState.credits + station.station_credits
	var price: int = station.get_sell_price(&"hull_parts")
	check(station.player_buy_item(&"hull_parts", 2, cargo), "Buy succeeds within hold capacity")
	check(cargo.get_amount(&"hull_parts") == 2 and station.inventory.get_amount(&"hull_parts") == 8, "Purchase conserves goods")
	check(PlayerState.credits == 100000 - price * 2 and station.station_credits == 20000 + price * 2, "Purchase credits seller exactly")
	check(not station.player_buy_item(&"hull_parts", 1, cargo), "Full cargo rejects purchase")
	check(PlayerState.credits + station.station_credits == total and station.inventory.get_amount(&"hull_parts") == 8, "Rejected purchase changes neither money nor stock")
	var sell_price: int = station.get_buy_price(&"hull_parts")
	check(station.player_sell_item(&"hull_parts", 1, cargo, 0) == sell_price, "Sale settles at quoted price")
	check(cargo.get_amount(&"hull_parts") == 1 and station.inventory.get_amount(&"hull_parts") == 9 and PlayerState.credits + station.station_credits == total, "Sale conserves goods and credits")
	for amount in [0, -1, -100]:
		check(not station.player_buy_item(&"hull_parts", amount, cargo) and station.player_sell_item(&"hull_parts", amount, cargo, 0) == 0, "Invalid quantity rejected: %d" % amount)
	check(not cargo.remove_item(&"hull_parts", -2) and cargo.get_amount(&"hull_parts") == 1, "Negative removal cannot create goods")
	check(not PlayerState.spend_credits(-100), "Negative spending cannot create credits")
	var before: int = PlayerState.credits
	PlayerState.add_credits(-100)
	check(PlayerState.credits == before, "Negative credit grant rejected")
	PlayerState.credits = 0
	check(not station.player_buy_item(&"hull_parts", 1, cargo), "Poor buyer rejected")
	station.station_credits = 0
	check(station.player_sell_item(&"hull_parts", 1, cargo, 0) == 0 and cargo.get_amount(&"hull_parts") == 1, "Poor station cannot buy goods")
	station.station_credits = 20000
	station.inventory.capacity = station.inventory.get_used_capacity(GameData.items)
	check(station.player_sell_item(&"hull_parts", 1, cargo, 0) == 0, "Full station rejects sale")
	station.inventory.capacity = 0
	check(not station.player_buy_item(&"hull_parts", 1, station.inventory), "Same-inventory trade rejected")
	station._is_destroyed = true
	check(station.player_sell_item(&"hull_parts", 1, cargo, 0) == 0, "Destroyed station rejects trade")
	station.free()
	print("TRADE REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
