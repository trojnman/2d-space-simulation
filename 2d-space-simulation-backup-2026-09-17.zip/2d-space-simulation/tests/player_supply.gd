extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("TRADE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var destination: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		candidate.inventory.clear()
		if candidate.station_data.id == &"sol_prime_manufacturing": destination = candidate
	var seller: StationInstance = load("res://scenes/Station.tscn").instantiate()
	seller.station_data = GameData.stations[&"sol_prime_trade"]
	seller.faction_id = &"free_traders_guild"
	seller.position = Vector2(15000, 0)
	SectorManager.current_sector.add_child(seller)
	for i in 4: await get_tree().process_frame
	seller.inventory.clear()
	seller.inventory.add_item(&"hull_parts", 300)
	FactionManager.set_relation(destination.faction_id,seller.faction_id,0)
	var ship: ShipInstance = load("res://scenes/Hauler.tscn").instantiate()
	ship.faction_id = destination.faction_id
	SectorManager.add_sector_entity(ship)
	ship.initialize(GameData.ships[&"hauler"])
	var ai := AIShipController.new()
	ship.add_child(ai)
	for i in 2: await get_tree().process_frame
	destination.faction_id = &"player"
	ship.add_to_group("player_fleet")
	ai._is_fleet_ship = true
	check(ai.assign_station_supply(destination), "assign player station")
	check(ai._haul_source == seller and ai._haul_destination == destination, "plans station input purchase")
	var before := PlayerState.credits
	var treasury := FactionManager.get_faction_credits(seller.faction_id)
	ship.global_position = seller.global_position
	ai._think_haul()
	var amount := ship.inventory.get_amount(&"hull_parts")
	var cost := amount * seller.get_sell_price(&"hull_parts")
	check(amount > 0 and ai._haul_loaded, "collect supplies physically")
	check(PlayerState.credits == before-cost and FactionManager.get_faction_credits(seller.faction_id)==treasury+cost, "purchase conserves funds")
	ship.global_position = destination.global_position
	ai._think_haul()
	check(destination.inventory.get_amount(&"hull_parts")==amount, "deliver supplies to player station")
	check(PlayerState.credits == before-cost, "delivery has no second payment")
	destination.inventory.clear()
	ship.inventory.clear()
	PlayerState.credits = 0
	ai._pick_haul_destination()
	check(ai._haul_source == null, "unaffordable imports not planned")
	seller.faction_id = &"player"
	seller.visiting_traders_enabled = false
	ai._pick_haul_destination()
	check(ai._haul_source == seller, "private owned surplus can supply station")
	ship.global_position = seller.global_position
	ai._think_haul()
	check(ai._haul_loaded and PlayerState.credits == 0, "internal transfer needs no payment")
	var carried := ship.inventory.get_amount(&"hull_parts")
	ai.cancel_all_commands()
	check(ship.inventory.get_amount(&"hull_parts") == carried, "cancel retains cargo")
	check(ai.assign_station_supply(destination), "resume assignment with cargo")
	destination.set_stock_target(&"ballistic_ammo", 500)
	check(destination.get_supply_target(&"ballistic_ammo") == 500, "explicit ammunition target")
	check(ai._station_shortage(destination,&"ballistic_ammo") == 500, "hauler sees custom demand")
	check(destination.get_export_reserve(&"ballistic_ammo") == 500, "custom stock protected from exports")
	var path := "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/supply-save.dat"
	check(SaveManager.save_game(path), "save assignment")
	check(await SaveManager.load_game(path), "load assignment")
	var restored: AIShipController
	for fleet in get_tree().get_nodes_in_group("player_fleet"):
		var controller = fleet.get_node_or_null("AIShipController")
		if controller and is_instance_valid(controller.supply_station): restored = controller
	check(restored != null, "assignment target restored")
	if restored:
		check(restored.supply_station.stock_targets.get(&"ballistic_ammo") == 500, "stock target restored")
		restored.supply_station.set_stock_target(&"ballistic_ammo", 0)
		check(not restored.supply_station.stock_targets.has(&"ballistic_ammo"), "clear target")
		restored.cancel_all_commands()
		check(restored.supply_station == null and restored._state == AIShipController.State.IDLE, "cancel stops supply")
	print("SUPPLY: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
