extends Node
var checks: int = 0
func verify(ok: bool, message: String) -> void:
 checks += 1
 if not ok:
  push_error(message)
  get_tree().quit(1)
func _ready() -> void:
 var main = load("res://scenes/Main.tscn").instantiate()
 main.process_mode = Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10: await get_tree().process_frame
 get_tree().paused = true
 var factory: StationInstance
 for candidate in SectorManager.get_sector_stations(SectorManager.current_sector):
  if candidate.station_data.id == &"sol_prime_manufacturing": factory = candidate
 factory._manufacture_queue.clear()
 factory.inventory.clear()
 factory.production_enabled = true
 factory.faction_id = &"player"
 PlayerState.credits = 1000000
 factory.requested_station_blueprint = GameData.stations.keys()[0]
 var demand = factory.get_faction_supply_request()
 var recipes = factory.station_data.get_recipes()
 for recipe in recipes:
  for item in recipe["inputs"]: factory.inventory.add_item(item, 10000)
 # Make every output need production, retaining raw material inputs.
 for recipe in recipes: factory.inventory.remove_item(recipe["output_id"], factory.inventory.get_amount(recipe["output_id"]))
 factory._recipe_cursor = 2
 factory._auto_queue_recipes()
 verify(factory._manufacture_queue.size() > 0, "Factory must start requested production")
 verify(demand.has(factory._manufacture_queue[0]["recipe"]["output_id"]), "Requested material should take priority")
 factory._manufacture_queue.clear()
 factory.inventory.clear()
 factory._auto_queue_recipes()
 verify(factory._manufacture_queue.is_empty(), "No production without materials")
 print("PRODUCTION_PRIORITY: ", checks, " checks completed")
 get_tree().quit()
