extends Node

var failures: int = 0

func check(condition: bool, message: String) -> void:
	if condition:
		print("PASS: " + message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func _ready() -> void:
	call_deferred("run")

func run() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	FactionManager.set_process(false)
	var factory: StationInstance
	var yard: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_manufacturing": factory = station
		if station.station_data.id == &"sol_prime_shipyard": yard = station
	check(factory != null and yard != null, "Starting sector has factory and shipyard")
	if not factory or not yard:
		get_tree().quit(1)
		return
	factory.inventory.clear()
	yard.inventory.clear()
	var hull_recipe: Dictionary = {}
	for recipe in factory.station_data.get_recipes():
		if recipe["output_id"] == &"hull_parts": hull_recipe = recipe
	check(not factory.queue_manufacture(hull_recipe), "Insufficient resources cannot start manufacturing")
	check(factory.get_manufacture_queue().is_empty(), "Rejected job leaves no queue entry")
	factory.inventory.add_item(&"iron", 5)
	factory.inventory.add_item(&"carbon", 5)
	check(factory.queue_manufacture(hull_recipe), "Factory accepts funded recipe")
	check(factory.inventory.get_amount(&"iron") == 0 and factory.inventory.get_amount(&"carbon") == 0, "Factory consumes exact ingredients")
	check(not factory.queue_manufacture(hull_recipe), "Duplicate output cannot create concurrent unpaid work")
	factory._process_manufacturing(60.0)
	check(factory.inventory.get_amount(&"hull_parts") == 10, "Factory produces components")
	var spawner: StationSpawner
	for child in yard.get_children():
		if child is StationSpawner: spawner = child
	var hauler: ShipInstance = spawner.build_completed_ship(&"hauler")
	await get_tree().process_frame
	var ai: AIShipController
	for child in hauler.get_children():
		if child is AIShipController: ai = child
	hauler.inventory.clear()
	hauler.inventory.capacity = 12.0
	ai._haul_source = factory
	ai._haul_destination = yard
	ai._haul_item = &"hull_parts"
	ai._haul_loaded = false
	ai._waypoint = factory.global_position
	hauler.global_position = factory.global_position
	ai._think_haul()
	check(hauler.inventory.get_amount(&"hull_parts") == 6 and factory.inventory.get_amount(&"hull_parts") == 4, "Pickup respects capacity and conserves cargo")
	hauler.global_position = yard.global_position
	ai._think_haul()
	check(yard.inventory.get_amount(&"hull_parts") == 6 and hauler.inventory.get_amount(&"hull_parts") == 0, "Delivery transfers cargo into shipyard")
	var fighter_recipe: Dictionary = {}
	for recipe in yard.station_data.get_recipes():
		if recipe["output_id"] == &"fighter": fighter_recipe = recipe
	yard.inventory.clear()
	check(not yard.queue_manufacture(fighter_recipe), "Shipyard rejects unfunded ship")
	for item in fighter_recipe["inputs"]:
		yard.inventory.add_item(item, fighter_recipe["inputs"][item])
	check(yard.queue_manufacture(fighter_recipe), "Shipyard accepts funded ship")
	check(yard.inventory.get_all_items().is_empty(), "Ship materials deducted exactly once")
	check(not yard.queue_manufacture(fighter_recipe), "Busy shipyard rejects second order")
	var before: int = get_tree().get_nodes_in_group("ships").size()
	yard._process_manufacturing(59.0)
	check(get_tree().get_nodes_in_group("ships").size() == before, "No ship before build timer expires")
	yard._process_manufacturing(1.0)
	check(get_tree().get_nodes_in_group("ships").size() == before + 1, "Completed production creates a real ship")
	check(yard.inventory.get_amount(&"fighter") == 0, "Ship output is not a warehouse item")
	check(yard.get_manufacture_queue().is_empty(), "Completed job removed from queue")
	var built: ShipInstance = spawner._spawned_ships.back()
	check(built.faction_id == yard.faction_id and FactionManager.get_faction_ships(yard.faction_id).has(built), "Built ship registered to owning faction")
	check(SectorManager.current_sector.is_ancestor_of(built), "Built ship belongs to its sector")
	spawner.max_ships = 1
	spawner._initial_ships_spawned = 0
	spawner._try_spawn()
	var starter: ShipInstance = spawner._spawned_ships.back()
	starter.queue_free()
	await get_tree().process_frame
	before = get_tree().get_nodes_in_group("ships").size()
	spawner._try_spawn()
	check(get_tree().get_nodes_in_group("ships").size() == before, "Destroyed starter ship does not respawn for free")
	var miner: ShipInstance = spawner.build_completed_ship(&"miner")
	miner.inventory.capacity = 2.0
	var asteroid := AsteroidInstance.new()
	asteroid.setup(GlobalEnums.AsteroidMaterial.IRON, GlobalEnums.AsteroidSize.LARGE, 42)
	add_child(asteroid)
	asteroid.take_mining_damage(100000.0, miner)
	check(miner.inventory.get_amount(&"iron") == 2, "Mining respects available cargo space")
	check(not asteroid._is_destroyed and asteroid._remaining_yield > 0, "Overflow ore remains available in asteroid")
	var ore_left: int = asteroid._remaining_yield
	asteroid.take_mining_damage(100000.0, miner)
	check(asteroid._remaining_yield == ore_left, "Full hold cannot destroy or duplicate ore")
	print("ECONOMY REGRESSION: %d failures" % failures)
	get_tree().quit(1 if failures else 0)
