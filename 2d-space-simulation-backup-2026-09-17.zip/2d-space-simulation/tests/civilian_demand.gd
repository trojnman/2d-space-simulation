extends Node
func _ready() -> void:
 var main = load("res://scenes/Main.tscn").instantiate()
 main.process_mode = Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10: await get_tree().process_frame
 get_tree().paused = true
 var station: StationInstance
 for c in SectorManager.get_sector_stations(SectorManager.current_sector):
  if c.station_data.station_type == StationData.TYPE_TRADE: station = c; break
 station.inventory.clear()
 station.inventory.add_item(&"water", 10)
 station._civilian_timer = 0
 FactionManager.civilian_credits = 10000
 var money = station.station_credits + FactionManager.civilian_credits
 station._process_civilian_demand(59)
 assert(station.inventory.get_amount(&"water") == 10)
 station._process_civilian_demand(1)
 assert(station.inventory.get_amount(&"water") == 8)
 assert(station.station_credits + FactionManager.civilian_credits == money)
 FactionManager.civilian_credits = 0
 station._process_civilian_demand(60)
 assert(station.inventory.get_amount(&"water") == 8)
 assert(station.get_supply_target(&"water") == 20)
 station._civilian_timer = 37.0
 var station_id = station.station_data.id
 var path = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/civilian-demand-test.dat"
 assert(SaveManager.save_game(path), SaveManager.last_error)
 assert(await SaveManager.load_game(path))
 get_tree().paused = true
 for c in SectorManager.get_sector_stations(SectorManager.current_sector):
  if c.station_data.id == station_id: station = c; break
 assert(absf(station._civilian_timer - 37.0) < 1.0, "Consumption countdown persists")
 print("CIVILIAN_DEMAND: 8 checks passed")
 get_tree().quit()
