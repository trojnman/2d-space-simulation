extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("TURN FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player = get_tree().get_first_node_in_group("player")
	for id in GameData.ships:
		var data: ShipData = GameData.ships[id]
		player.initialize(data)
		player.rotation = 0
		player._mouse_world_pos = player.global_position + Vector2.DOWN * 1000
		player._aim_at_mouse(0.1)
		check(is_equal_approx(absf(player.rotation), data.rotation_speed * 0.1), str(id) + " capped player turn")
		player.rotation = PI - 0.01
		player._mouse_world_pos = player.global_position + Vector2.from_angle(0.01) * 1000
		player._aim_at_mouse(1.0)
		check(absf(angle_difference(player.rotation, -PI + 0.01)) < 0.0001, str(id) + " wrap and no overshoot")
		var ship: ShipInstance = load(StationSpawner.SHIP_SCENES[id]).instantiate()
		SectorManager.add_sector_entity(ship)
		ship.initialize(data)
		var ai := AIShipController.new()
		ship.add_child(ai)
		ship.rotation = 0
		ai._move_toward(ship.global_position + Vector2.DOWN * 1000, 0.1)
		check(is_equal_approx(ship.rotation, data.rotation_speed * 0.1), str(id) + " capped AI turn")
		ship.queue_free()
	for prefix in ["", "medium_", "heavy_"]:
		var previous := INF
		for role in ["fighter", "missile_boat", "miner", "hauler"]:
			var rate: float = GameData.ships[StringName(prefix + role)].rotation_speed
			check(rate < previous, prefix + role + " role order")
			previous = rate
	check(GameData.ships[&"hauler"].rotation_speed > GameData.ships[&"medium_fighter"].rotation_speed, "all small faster than medium")
	check(GameData.ships[&"medium_hauler"].rotation_speed > GameData.ships[&"heavy_fighter"].rotation_speed, "all medium faster than large")
	await get_tree().process_frame
	print("TURN_RATES: %d checks, %d failures" % [checks, failures])
	get_tree().quit(failures)
