extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var sector = SectorManager.current_sector
	var owner = sector.sector_data.controlling_faction_id
	var standard = GameData.stations[&"sol_prime_shipyard"]
	var capital = GameData.stations[&"sol_prime_capital_shipyard"]
	var trade = GameData.stations[&"sol_prime_trade"]
	var factory = GameData.stations[&"sol_prime_manufacturing"]
	var military = GameData.stations[&"sol_prime_military"]
	check(BUILD.limit_problem(sector,standard,&"player").contains("owner"),"foreign shipyard denied")
	check(BUILD.limit_problem(sector,military,&"player").contains("owner"),"foreign military denied")
	check(BUILD.limit_problem(sector,standard,owner).contains("limit"),"existing standard yard counts")
	check(BUILD.limit_problem(sector,capital,owner).contains("limit"),"existing capital yard counts")
	check(BUILD.limit_problem(sector,trade,&"player")=="","foreign trade permitted")
	check(BUILD.limit_problem(sector,factory,&"player")=="","foreign factory permitted")
	var yard: StationInstance
	for st in SectorManager.get_sector_stations(sector):
		if st.station_data.id == standard.id: yard=st
	yard._station_build_queue.append({"owner": &"player", "blueprint": trade.id})
	check(BUILD.limit_problem(sector,trade,&"player").contains("limit"),"queued trade reserves faction slot")
	yard._station_build_queue.clear()
	for i in 3: yard._station_build_queue.append({"owner": &"player", "blueprint": factory.id})
	check(BUILD.limit_problem(sector,factory,&"player").contains("limit"),"three queued factories fill cap")
	check(BUILD.limit_problem(sector,factory,&"another_faction")=="","factory caps independent")
	yard._station_build_queue.clear()
	check(StationData.SECTOR_CAPS[&"defense_platform"]==4,"defense cap four")
	check(StationData.SECTOR_CAPS[&"military"]==2,"military cap two")
	PlayerState.joined_faction = owner
	check(BUILD.limit_problem(sector,military,&"player") != "", "membership grants no military rights")
	check(BUILD.limit_problem(sector,trade,&"player") == "", "member retains civilian construction")
	sector.sector_data.controlling_faction_id = &"player"
	PlayerState.joined_faction = &""
	PlayerState.founded_faction = false
	check(BUILD.limit_problem(sector,military,&"player").contains("headquarters"), "own faction must be founded")
	PlayerState.founded_faction = true
	check(BUILD.limit_problem(sector,military,&"player") == "", "founder may build in owned sector within cap")
	PlayerState.joined_faction = owner
	check(BUILD.limit_problem(sector,military,&"player") != "", "joined member cannot use former faction military rights")
	sector.sector_data.controlling_faction_id = owner
	var defense := StationData.new()
	defense.station_type = StationData.TYPE_DEFENSE_PLATFORM
	check(BUILD.limit_problem(sector,defense,&"player") == "","member can build defense platform")
	PlayerState.joined_faction = &""
	check(BUILD.limit_problem(sector,defense,&"player") != "","nonmember cannot build foreign defenses")
	print("LIMITS: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
