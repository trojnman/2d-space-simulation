extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:failures+=1;print("FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10:await get_tree().process_frame
 get_tree().paused=true
 var sector:SectorInstance=SectorManager.current_sector
 var player:Player=PlayerState.current_ship
 var rock:AsteroidInstance=sector.get_node("Asteroids").get_child(0)
 var location:=rock.position
 var material:=rock.material_type
 var supply:=rock._remaining_yield
 var item:StringName=AsteroidInstance.MATERIAL_IDS[material]
 check(supply>0,"deposit finite from spawn")
 player.inventory.clear()
 player.inventory.capacity=0
 rock.take_mining_damage(10000,player)
 check(player.inventory.get_amount(item)==supply,"exact finite yield collected")
 check(sector.asteroid_respawns.size()==1,"one respawn scheduled")
 rock.take_mining_damage(10000,player)
 check(player.inventory.get_amount(item)==supply and sector.asteroid_respawns.size()==1,"no duplicate ore or respawn")
 await get_tree().process_frame
 sector.advance_asteroid_respawns(100)
 check(sector.asteroid_respawns.size()==1,"no early respawn")
 var path="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/asteroid-save.dat"
 check(SaveManager.save_game(path),"save cooldown")
 check(await SaveManager.load_game(path),"restore cooldown")
 get_tree().paused=true
 sector=SectorManager.current_sector
 check(is_equal_approx(sector.asteroid_respawns[0].remaining,500),"remaining delay restored")
 player.position=location
 sector.advance_asteroid_respawns(501)
 check(sector.asteroid_respawns.size()==1,"occupied spawn delayed")
 player.position=location+Vector2(2000,0)
 var count:=sector.get_node("Asteroids").get_child_count()
 sector.advance_asteroid_respawns(5)
 check(sector.asteroid_respawns.is_empty(),"clear position respawns")
 check(sector.get_node("Asteroids").get_child_count()==count+1,"one replacement")
 var replacement:AsteroidInstance=sector.get_node("Asteroids").get_child(count)
 check(replacement.material_type==material and replacement._remaining_yield>0,"replacement has finite deposit")
 print("ASTEROID_CYCLE: %d checks, %d failures" % [checks,failures])
 get_tree().quit(failures)
