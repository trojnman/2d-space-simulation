extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var sector = SectorManager.current_sector
	var yard: StationInstance
	for st in SectorManager.get_sector_stations(sector):
		if st.station_data.id == &"sol_prime_shipyard": yard=st
		if st.station_data.station_type == StationData.TYPE_MANUFACTURING:
			st.get_parent().remove_child(st)
			st.queue_free()
	yard.inventory.clear()
	FactionManager._plan_owned_expansion()
	check(yard.requested_station_blueprint == &"sol_prime_manufacturing", "missing factory gets material request")
	check(yard._station_build_queue.is_empty(), "no free construction without materials")
	for id in StationData.BUILD_COSTS[&"manufacturing"]: yard.inventory.add_item(id,StationData.BUILD_COSTS[&"manufacturing"][id])
	yard.station_credits=1000000
	var before := yard.station_credits
	FactionManager._plan_owned_expansion()
	check(yard._station_build_queue.size()==1,"funded project queued")
	check(yard.station_credits<before,"wages paid")
	FactionManager._plan_owned_expansion()
	check(yard._station_build_queue.size()==1,"no duplicate active project")
	BUILD.tick(yard,4)
	for i in 3: await get_tree().process_frame
	FactionManager._plan_owned_expansion()
	check(yard._station_build_queue.is_empty(),"existing facilities not duplicated")
	print("EXPANSION: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
