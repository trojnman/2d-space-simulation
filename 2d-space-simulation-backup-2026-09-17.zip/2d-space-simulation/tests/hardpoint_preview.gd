extends Node2D
func _ready() -> void:
 SensorSystem.set_physics_process(false)
 SensorSystem.set_process(false)
 RenderingServer.set_default_clear_color(Color("0a1422"))
 var index: int = 0
 for id in StationSpawner.SHIP_SCENES:
  if not GameData.ships.has(id): continue
  var sd: ShipData = GameData.ships[id]
  var ship: ShipInstance = load(StationSpawner.SHIP_SCENES[id]).instantiate()
  add_child(ship)
  ship.initialize(sd)
  ship.position = Vector2(150+(index%4)*310,115+(index/4)*205)
  var extent: Vector2 = Vector2(30,20)
  for c in ship.get_children():
   if c is ShipVisualController: extent = c.get_meta("hull_half_size", extent)
  ship.scale = Vector2.ONE * minf(130.0/extent.x,70.0/extent.y)
  for slot in sd.weapon_slots:
   var wid = ("mining_laser_s" if sd.mount_kind(slot)=="Mining" else "laser_autocannon_s")+str(sd.mount_size(slot))
   ship.equip_weapon(GameData.weapons[StringName(wid)],slot)
  for slot in sd.missile_slots: ship.equip_missile(GameData.missiles[StringName("missile_s"+str(sd.rack_sizes[slot]))],slot)
  var label = Label.new()
  label.position = Vector2((index%4)*310+20,(index/4)*205+180)
  label.text = sd.display_name + " | " + str(sd.weapon_slots) + " mounts"
  add_child(label)
  index+=1
 for i in 12: await get_tree().process_frame
 await RenderingServer.frame_post_draw
 get_viewport().get_texture().get_image().save_png("C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/hardpoint-preview.png")
 get_tree().quit()
