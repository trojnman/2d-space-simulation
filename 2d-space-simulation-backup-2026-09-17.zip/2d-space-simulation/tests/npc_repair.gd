extends Node
func _ready() -> void:
 var main = load("res://scenes/Main.tscn").instantiate()
 main.process_mode = Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10: await get_tree().process_frame
 get_tree().paused = true
 var station: StationInstance
 for c in SectorManager.get_sector_stations(SectorManager.current_sector):
  if c.station_data.offers_repairs: station = c; break
 var ship: ShipInstance = load("res://scenes/Fighter.tscn").instantiate()
 ship.faction_id = station.faction_id
 SectorManager.current_sector.add_child(ship)
 ship.initialize(GameData.ships[&"fighter"])
 var ai = AIShipController.new()
 ai._background_initialized = true
 ship.add_child(ai)
 ai._is_combat_ship = true
 ship.global_position = station.global_position
 ship.hull = ship.max_hull - 20
 station.inventory.add_item(&"hull_parts", 10)
 var parts = station.inventory.get_amount(&"hull_parts")
 var money = FactionManager.get_faction_credits(ship.faction_id)
 var civilian = FactionManager.civilian_credits
 ai._repair_at_station(0.3)
 assert(ship.hull == ship.max_hull, "Repairs restore hull")
 assert(station.inventory.get_amount(&"hull_parts") == parts - 2, "Repairs consume parts")
 assert(FactionManager.get_faction_credits(ship.faction_id) == money - 10, "Repairs pay real wages")
 assert(FactionManager.civilian_credits == civilian + 10, "Money conserved")
 ship.hull -= 10
 ship.global_position += Vector2(20000, 0)
 ai._repair_at_station(0.3)
 assert(ship.hull == ship.max_hull - 10, "No remote repairs")
 print("NPC_REPAIR: 5 checks passed")
 get_tree().quit()
