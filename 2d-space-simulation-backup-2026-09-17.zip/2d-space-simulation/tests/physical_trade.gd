extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("TRADE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var destination: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		candidate.inventory.clear()
		if candidate.station_data.id == &"sol_prime_manufacturing": destination = candidate
	var seller: StationInstance = load("res://scenes/Station.tscn").instantiate()
	seller.station_data = GameData.stations[&"sol_prime_trade"]
	seller.faction_id = &"free_traders_guild"
	seller.position = Vector2(15000, 0)
	SectorManager.current_sector.add_child(seller)
	for i in 4: await get_tree().process_frame
	seller.inventory.clear()
	seller.inventory.add_item(&"hull_parts", 300)
	FactionManager.set_relation(destination.faction_id,seller.faction_id,0)
	var ship: ShipInstance = load("res://scenes/Hauler.tscn").instantiate()
	ship.faction_id = destination.faction_id
	SectorManager.add_sector_entity(ship)
	ship.initialize(GameData.ships[&"hauler"])
	var ai := AIShipController.new()
	ship.add_child(ai)
	for i in 2: await get_tree().process_frame
	var buyer_before := FactionManager.get_faction_credits(ship.faction_id)
	var seller_before := FactionManager.get_faction_credits(seller.faction_id)
	ai._pick_haul_destination()
	check(ai._haul_source == seller, "plans foreign purchase when internal stock absent")
	check(FactionManager.get_faction_credits(ship.faction_id)==buyer_before and seller.inventory.get_amount(&"hull_parts")==300, "planning does not teleport goods or pay")
	ship.global_position = seller.global_position + Vector2(seller.get_docking_range()+1,0)
	check(not FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "requires physical docking range")
	ship.global_position = seller.global_position
	ai._think_haul()
	var amount := ship.inventory.get_amount(&"hull_parts")
	check(amount>0 and ai._haul_loaded, "pickup loads physical cargo")
	var price: int = amount*seller.get_sell_price(&"hull_parts")
	check(FactionManager.get_faction_credits(ship.faction_id)==buyer_before-price, "buyer debited at pickup")
	check(FactionManager.get_faction_credits(seller.faction_id)==seller_before+price, "seller credited once")
	check(seller.inventory.get_amount(&"hull_parts")+amount==300, "stock conserved")
	var target: StationInstance = ai._haul_destination
	var stock_before := target.inventory.get_amount(&"hull_parts")
	ship.global_position = target.global_position
	ai._think_haul()
	check(target.inventory.get_amount(&"hull_parts")==stock_before+amount and ship.inventory.get_amount(&"hull_parts")==0, "physical delivery")
	check(FactionManager.get_faction_credits(ship.faction_id)==buyer_before-price, "delivery does not pay twice")
	ship.global_position = seller.global_position
	FactionManager.set_relation(ship.faction_id,seller.faction_id,-1)
	check(not FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "enemy trade refused")
	FactionManager.set_relation(ship.faction_id,seller.faction_id,0)
	FactionManager._faction_state[ship.faction_id].credits=0
	var remaining := seller.inventory.get_amount(&"hull_parts")
	check(not FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "unfunded trade refused")
	check(seller.inventory.get_amount(&"hull_parts")==remaining, "failed trade leaves stock")
	check(not FactionManager.purchase_cargo(ship,seller,&"hull_parts",-1), "negative quantity refused")
	seller.faction_id = &"player"
	FactionManager._faction_state[ship.faction_id].credits=1000000
	PlayerState.set_reputation(ship.faction_id,0)
	check(not FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "private warehouse refuses visitors")
	seller.visiting_traders_enabled=true
	var wallet := PlayerState.credits
	var treasury := FactionManager.get_faction_credits(ship.faction_id)
	var stock := seller.inventory.get_amount(&"hull_parts")
	var unit := seller.get_sell_price(&"hull_parts")
	check(FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "visitors buy owned station surplus")
	check(PlayerState.credits == wallet+unit and FactionManager.get_faction_credits(ship.faction_id)==treasury-unit, "player trade conserves money")
	check(seller.inventory.get_amount(&"hull_parts")==stock-1 and ship.inventory.get_amount(&"hull_parts")==1, "player trade conserves cargo")
	check(not FactionManager.get_treasury_history(&"player").is_empty(), "player sale has ledger entry")
	PlayerState.set_reputation(ship.faction_id,-1000)
	check(not FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "hostile visitors refused")
	PlayerState.set_reputation(ship.faction_id,0)
	seller.station_data = GameData.stations[&"sol_prime_manufacturing"]
	var reserve := seller.get_input_reserve(&"hull_parts")
	seller.inventory.clear()
	seller.inventory.add_item(&"hull_parts",reserve)
	check(reserve>0 and not FactionManager.purchase_cargo(ship,seller,&"hull_parts",1), "production reserve protected at pickup")
	seller.visiting_traders_enabled=false
	check(not seller.can_export_to_traders(&"hull_parts"), "disabled station excluded from route planning")
	print("PHYSICAL_TRADE: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
