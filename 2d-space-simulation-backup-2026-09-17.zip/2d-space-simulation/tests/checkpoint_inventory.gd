extends SceneTree
func _initialize()->void:
 for path in ["user://quicksave.dat","user://quicksave.dat.bak"]:
  var file=FileAccess.open(path,FileAccess.READ)
  if not file:continue
  var envelope=file.get_var(false);file.close()
  var scenario="legacy"
  if envelope is Dictionary and envelope.get("payload") is PackedByteArray:
   var payload=bytes_to_var(envelope.payload)
   if payload is Dictionary:scenario=payload.get("scenario","legacy")
  print("CHECKPOINT ",ProjectSettings.globalize_path(path)," SCENARIO ",scenario)
 quit()
