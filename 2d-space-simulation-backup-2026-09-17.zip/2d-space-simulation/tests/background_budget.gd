extends Node
func _ready()->void:
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 45:await get_tree().process_frame
 get_tree().paused=true
 var actors:=0
 for sector in SectorManager._visited_sectors.values():
  for node in sector.find_children("*","",true,false):
   if node is StationSpawner:
    node._try_spawn();node._try_spawn()
 for i in 3:await get_tree().process_frame
 for sector in SectorManager._visited_sectors.values():
  for node in sector.find_children("*","",true,false):
   if node is AIShipController:actors+=1
 var started=Time.get_ticks_usec()
 for i in 8:SectorManager.advance_background_transport(.25)
 print("BUDGET background transport average ms: ",(Time.get_ticks_usec()-started)/8000.0,"; AI ships: ",actors)
 get_tree().quit()
