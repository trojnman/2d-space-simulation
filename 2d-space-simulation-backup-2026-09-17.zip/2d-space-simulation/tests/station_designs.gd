extends Node
var failures := 0
var artwork: Dictionary = {}
func check(ok: bool, message: String) -> void:
	if not ok:
		failures += 1
		push_error(message)
func gather(node: Node, result: Array) -> void:
	if node is Polygon2D:
		check(not Geometry2D.triangulate_polygon(node.polygon).is_empty(), "Station polygon triangulates")
		var points: Array = []
		for point in node.polygon:
			var p: Vector2 = node.to_global(point)
			points.append([p.x,p.y])
		result.append({"points":points,"color":node.color.to_html(false)})
	for child in node.get_children(): gather(child,result)
func _ready() -> void:
	for kind in ["headquarters","military","trade","mining","manufacturing","defense_platform","shipyard","capital"]:
		var station := StationInstance.new()
		station.station_data = StationData.new()
		station.station_data.station_type = &"shipyard" if kind == "capital" else StringName(kind)
		station.station_data.capital_yard = kind == "capital"
		station.faction_id = &"terran_republic"
		add_child(station)
		var art := StationVisuals.new()
		station.add_child(art)
		await get_tree().process_frame
		await get_tree().process_frame
		art.set_process(false)
		art.rotation = 0
		var layers: Array = []
		gather(art,layers)
		artwork[kind] = layers
		if kind in ["shipyard","capital"]:
			PlayerState.set_reputation(station.faction_id,0)
			var catalog := station.get_ship_sale_catalog()
			check(not catalog.is_empty(), "Neutral yard catalog available")
			for entry in catalog:
				var large: bool = GameData.ships[entry["id"]].ship_class == GlobalEnums.ShipClass.LARGE
				check(large == (kind == "capital"), "Yard size restriction")
			check(station.get_ship_recipe(&"fighter" if kind == "capital" else &"heavy_fighter").is_empty(), "Wrong yard rejects recipe")
			station.inventory.clear()
			check(not station.get_ship_sale_catalog()[0]["stocked"], "Catalog flags shortage")
			var recipe := station.get_ship_recipe(catalog[0]["id"])
			for id in recipe["inputs"]: station.inventory.add_item(id,recipe["inputs"][id])
			check(station.get_ship_sale_catalog()[0]["stocked"], "Catalog recognizes build stock")
		station.queue_free()
	var file := FileAccess.open("C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/station-art.json",FileAccess.WRITE)
	file.store_string(JSON.stringify(artwork))
	file.close()
	print("STATION DESIGNS: %d failures" % failures)
	get_tree().quit(1 if failures else 0)
