extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var a: StringName=GameData.factions.keys()[0]
	var b: StringName=GameData.factions.keys()[1]
	var hq=get_tree().get_first_node_in_group("stations")
	FactionManager._faction_state[a].hq_station=hq
	FactionManager._faction_state[b].hq_station=hq
	FactionManager._faction_state[a].owned_ships.clear()
	FactionManager._faction_state[b].owned_ships.clear()
	FactionManager._faction_state[a].credits=100000
	FactionManager._faction_state[b].credits=100000
	var sectors=GameData.sectors.values()
	sectors[0].controlling_faction_id=a
	sectors[1].controlling_faction_id=b
	sectors[0].connected_sectors.assign([sectors[1].id])
	for i in 6:
		var ship: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
		ship.faction_id=a
		SectorManager.add_sector_entity(ship)
		ship.initialize(GameData.ships[&"fighter"])
		FactionManager.register_ship(ship)
	FactionManager.set_relation(a,b,0)
	FactionManager.advance_diplomacy(0)
	FactionManager.advance_diplomacy(599)
	check(not FactionManager.are_at_war(a,b),"war waits for cooldown")
	FactionManager.advance_diplomacy(1)
	check(FactionManager.are_at_war(a,b),"funded stronger neighbor declares war")
	FactionManager.advance_diplomacy(299)
	check(FactionManager.are_at_war(a,b),"war does not reverse immediately")
	FactionManager.advance_diplomacy(1)
	check(not FactionManager.are_at_war(a,b),"exhausted weaker faction reaches peace")
	check(FactionManager.diplomacy_events.size()>=2,"decisions recorded")
	var clock:=FactionManager.diplomacy_time
	check(SaveManager.save_game(PATH),"save diplomacy")
	check(await SaveManager.load_game(PATH),"load diplomacy")
	check(FactionManager.diplomacy_time==clock,"cooldown time restored")
	print("DIPLOMACY: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
