extends Node
var failures:=0
var checks:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:
  failures+=1
  print("SHIELD FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 12:await get_tree().process_frame
 for weapon in GameData.weapons.values():
  if weapon.weapon_type==GlobalEnums.WeaponType.BALLISTIC:
   var split=weapon.calc_damage_split(100)
   check(is_equal_approx(split[0],75) and is_equal_approx(split[1],25),str(weapon.id)+" ballistic 75/25 split")
 for missile in GameData.missiles.values():
  var split=missile.calc_damage_split(100)
  check(is_equal_approx(split[0],50) and is_equal_approx(split[1],50),str(missile.id)+" missile 50/50 split")
 var owner=PlayerState.current_ship
 var target=load("res://scenes/Fighter.tscn").instantiate()
 SectorManager.current_sector.add_child(target)
 target.initialize(GameData.ships[&"fighter"])
 target.faction_id=&"rogue"
 target.position=Vector2(50000,50000)
 target.set_physics_process(false)
 target.equipped_shield=owner.equipped_shield
 target._apply_shield()
 owner.position=target.position-Vector2(300,0)
 owner.velocity=Vector2.ZERO
 for i in 3:await get_tree().physics_frame
 get_tree().paused=true
 var shield=target.get_node("ShieldHitbox")
 shield.collision_layer=128
 for kind in ["LaserBeam","Bullet","Missile"]:
  target.shield=10000
  target.hull=10000
  var shot=load("res://scenes/"+kind+".tscn").instantiate()
  shot.set_physics_process(false)
  add_child(shot)
  shot.global_position=target.global_position-Vector2(200,0)
  if kind=="Missile":shot.launch(Vector2.ZERO,owner,GameData.missiles.values()[0])
  else:shot.launch(Vector2(10000,0),owner,GameData.weapons[&"laser_autocannon_s1"])
  check(preload("res://scripts/ProjectileSweep.gd").move(shot,Vector2(400,0)),kind+" swept collision")
  check(absf(shot.global_position.distance_to(target.global_position)-shield.shape.radius)<1,kind+" stops at shield boundary")
  check(target.shield<10000,kind+" damages shield")
  var remaining=target.shield
  shot._on_body_entered(target)
  check(target.shield==remaining,kind+" no duplicate damage")
 target.shield=0
 var shot=load("res://scenes/LaserBeam.tscn").instantiate()
 shot.set_physics_process(false)
 add_child(shot)
 shot.global_position=owner.global_position
 shot.launch(Vector2(10000,0),owner,GameData.weapons[&"laser_autocannon_s1"])
 check(preload("res://scripts/ProjectileSweep.gd").move(shot,Vector2(500,0)),"own shield and depleted shield skipped")
 check(shot.global_position.distance_to(target.global_position)<shield.shape.radius,"depleted shield lets shot reach hull")
 var station=get_tree().get_first_node_in_group("stations")
 station.faction_id=&"rogue"
 var station_shield=station.get_node("ShieldHitbox")
 for kind in ["LaserBeam","Bullet","Missile"]:
  station.shield=10000
  station.hull=10000
  var projectile=load("res://scenes/"+kind+".tscn").instantiate()
  projectile.set_physics_process(false)
  add_child(projectile)
  projectile.global_position=station.global_position-Vector2(station_shield.shape.radius+100,0)
  var raw:float
  var penetration:float
  if kind=="Missile":
   var missile=GameData.missiles.values()[0]
   projectile.launch(Vector2.ZERO,owner,missile)
   raw=missile.damage
   penetration=.5
  else:
   var weapon=GameData.weapons[&"ballistic_autocannon_s1" if kind=="Bullet" else &"laser_autocannon_s1"]
   projectile.launch(Vector2(10000,0),owner,weapon)
   raw=weapon.damage
   penetration=.25 if kind=="Bullet" else 0.0
  check(preload("res://scripts/ProjectileSweep.gd").move(projectile,Vector2(station_shield.shape.radius*2+200,0)),kind+" station collision")
  check(absf(projectile.global_position.distance_to(station.global_position)-station_shield.shape.radius)<1,kind+" station boundary")
  check(is_equal_approx(station.shield,10000-raw*(1.0-penetration)),kind+" station shield damage")
  check(is_equal_approx(station.hull,10000-raw*penetration),kind+" station hull penetration")
 station.shield=0
 station.hull=10000
 station.take_damage_from_weapon(GameData.weapons[&"ballistic_autocannon_s1"],owner)
 check(is_equal_approx(station.hull,10000-GameData.weapons[&"ballistic_autocannon_s1"].damage),"station depleted shield passes full damage")
 station._regen_shield(1)
 check(station.shield==0,"station recharge delay")
 station._regen_shield(100)
 check(is_equal_approx(station.shield,station.max_shield),"station recharges")
 check("shield" in SaveManager.STATION_FIELDS and "_shield_delay_timer" in SaveManager.STATION_FIELDS,"station shield save fields")
 var blast=load("res://scenes/Missile.tscn").instantiate()
 blast.set_physics_process(false)
 add_child(blast)
 var payload=GameData.missiles.values()[0].duplicate()
 payload.damage=100
 payload.blast_radius=100
 blast.launch(Vector2.ZERO,owner,payload)
 blast.global_position=station.global_position+Vector2(station_shield.shape.radius+50,0)
 station.shield=10000
 station.hull=10000
 blast._detonate(null)
 check(is_equal_approx(station.shield,9975) and is_equal_approx(station.hull,9975),"station splash surface distance and 50/50 split")
 blast._detonate(null)
 check(is_equal_approx(station.hull,9975),"splash cannot repeat")
 var friendly_blast=load("res://scenes/Missile.tscn").instantiate()
 friendly_blast.set_physics_process(false)
 add_child(friendly_blast)
 friendly_blast.launch(Vector2.ZERO,owner,payload)
 friendly_blast.global_position=blast.global_position
 station.faction_id=&"player"
 PlayerState.friendly_fire_enabled=false
 friendly_blast._detonate(null)
 check(is_equal_approx(station.hull,9975) and is_equal_approx(station.shield,9975),"station splash respects friendly fire setting")
 print("SHIELD: ",checks," checks, ",failures," failures")
 get_tree().quit(1 if failures else 0)

