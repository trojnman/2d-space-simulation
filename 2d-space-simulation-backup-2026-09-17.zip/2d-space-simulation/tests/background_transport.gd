extends Node
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("TRANSPORT FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var home: SectorInstance = SectorManager.current_sector
	var source: StationInstance
	var destination: StationInstance
	for station in SectorManager.get_sector_stations(home):
		if station.station_data.id == &"sol_prime_trade": source=station
		if station.station_data.id == &"sol_prime_shipyard": destination=station
	destination.inventory.clear()
	var hauler: ShipInstance = load("res://scenes/Hauler.tscn").instantiate()
	hauler.faction_id=source.faction_id
	home.add_child(hauler)
	hauler.initialize(GameData.ships[&"hauler"])
	var haul := AIShipController.new()
	hauler.add_child(haul)
	var miner: ShipInstance = load("res://scenes/Miner.tscn").instantiate()
	miner.faction_id=source.faction_id
	home.add_child(miner)
	miner.initialize(GameData.ships[&"miner"])
	miner.equip_weapon(GameData.weapons[&"mining_laser_s1"],0)
	var mining := AIShipController.new()
	miner.add_child(mining)
	var rock := AsteroidInstance.new()
	rock.setup(GlobalEnums.AsteroidMaterial.IRON,GlobalEnums.AsteroidSize.SMALL,123)
	rock.position=Vector2(100000,100000)
	rock.hull=1
	rock._remaining_yield=2
	home.get_node("Asteroids").add_child(rock)
	for i in 3: await get_tree().process_frame
	haul._haul_source=source
	haul._haul_destination=destination
	haul._haul_item=&"hull_parts"
	haul._haul_loaded=false
	haul._state=AIShipController.State.HAUL
	hauler.position=source.position+Vector2(source.get_docking_range()-1,0)
	miner.position=rock.position+Vector2(50,0)
	mining._waypoint=rock.position
	mining._state=AIShipController.State.MINE
	mining._think_timer=0
	var stock := source.inventory.get_amount(&"hull_parts")
	SectorManager.load_sector(&"frontier_reach")
	for i in 4: await get_tree().process_frame
	SectorManager.advance_background_transport(0.25)
	check(hauler.inventory.get_amount(&"hull_parts")>0,"remote physical pickup")
	check(source.inventory.get_amount(&"hull_parts")+hauler.inventory.get_amount(&"hull_parts")==stock,"remote pickup conserves goods")
	check(miner.inventory.get_amount(&"iron")==2,"remote finite mining yield")
	check(rock._is_destroyed,"remote asteroid depleted")
	check(miner.get_child_count()<20,"no accumulating offscreen muzzle flashes")
	var amount := hauler.inventory.get_amount(&"hull_parts")
	var start := hauler.position
	SectorManager.advance_background_transport(0.25)
	check(hauler.position!=start,"remote hauler travels rather than teleporting")
	hauler.position=destination.position+Vector2(destination.get_docking_range()-1,0)
	haul._think_timer=0
	SectorManager.advance_background_transport(0.25)
	check(destination.inventory.get_amount(&"hull_parts")==amount,"remote delivery")
	check(hauler.inventory.get_amount(&"hull_parts")==0,"delivered cargo removed")
	var spawner:=StationSpawner.new()
	spawner._station=destination
	destination.add_child(spawner)
	var built: ShipInstance=spawner.build_completed_ship(&"hauler")
	var built_ai:=built.get_node_or_null("AIShipController") as AIShipController
	check(built_ai!=null and built_ai._ship==built,"new remote hauler AI initialized")
	check(built_ai._state==AIShipController.State.HAUL,"new remote hauler begins hauling")
	built.hull=25
	built.inventory.add_item(&"ballistic_ammo",11)
	SectorManager.load_sector(&"sol_prime")
	for i in 3: await get_tree().process_frame
	check(destination.inventory.get_amount(&"hull_parts")==amount,"return retains remote delivery")
	check(miner.inventory.get_amount(&"iron")==2,"return retains mined cargo")
	check(built.hull==25 and built.inventory.get_amount(&"ballistic_ammo")==11,"first sector entry preserves remote ship state")
	check(built_ai._state==AIShipController.State.HAUL,"first entry preserves AI state")
	print("BACKGROUND_TRANSPORT: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
