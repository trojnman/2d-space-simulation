extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:
  failures+=1
  print("FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10:await get_tree().process_frame
 get_tree().paused=true
 var remote:SectorInstance=SectorManager.current_sector
 var original:=SectorManager.current_sector_id
 SectorManager.load_sector(&"frontier_reach")
 var scaffold=load("res://scripts/ConstructionScaffold.gd").new()
 scaffold.blueprint=&"sol_prime_shipyard"
 scaffold.beneficiary=&"terran_republic"
 scaffold.position=Vector2(20000,20000)
 remote.add_child(scaffold)
 scaffold.finish()
 var yard:StationInstance
 for station in SectorManager.get_sector_stations(remote):
  if station.constructed:yard=station
 check(is_instance_valid(yard),"remote completed yard registered")
 check(yard.inventory.serialize().items.is_empty(),"no free starting inventory")
 var spawner:StationSpawner
 for child in yard.get_children():
  if child is StationSpawner:spawner=child
 check(is_instance_valid(spawner),"launch component present")
 spawner._try_spawn()
 check(spawner.get_ship_count()==0,"no free starting fleet")
 var recipe:Dictionary=yard.get_ship_recipe(&"fighter")
 yard._manufacture_queue.append({"recipe":recipe,"time_remaining":0.1})
 yard._process_manufacturing(1)
 check(yard._manufacture_queue.is_empty(),"completed job leaves queue")
 check(spawner.get_ship_count()==1,"completed ship launches remotely")
 yard.hull-=50
 var damaged:=yard.hull
 SectorManager.load_sector(original)
 for i in 4:await get_tree().process_frame
 check(yard.hull==damaged,"first visit preserves remote station damage")
 check(spawner.get_ship_count()==1,"first visit does not seed fleet again")
 var path="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/kit-yard-save.dat"
 check(SaveManager.save_game(path),"save newly built yard")
 check(await SaveManager.load_game(path),"load newly built yard")
 remote=SectorManager._visited_sectors[original]
 for station in SectorManager.get_sector_stations(remote):
  if station.constructed:yard=station
 spawner=null
 for child in yard.get_children():
  if child is StationSpawner:spawner=child
 check(is_instance_valid(spawner) and spawner.get_ship_count()==1,"launched fleet preserved")
 print("KIT_YARD: %d checks, %d failures" % [checks,failures])
 get_tree().quit(failures)
