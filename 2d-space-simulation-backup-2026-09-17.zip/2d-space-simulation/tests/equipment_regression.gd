extends Node
var failures: int = 0
var checks: int = 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(message)
	else: print("PASS: " + message)
func _ready() -> void: call_deferred("run")
func run() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	FactionManager.set_process(false)
	var yard: StationInstance
	var military: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_shipyard": yard = station
		if station.station_data.id == &"sol_prime_military": military = station
	var spawner: StationSpawner
	for child in yard.get_children():
		if child is StationSpawner: spawner = child
	for ship_id in GameData.ships:
		var loadout: Dictionary = StationData.get_ship_loadout(ship_id)
		var valid: bool = loadout.size() >= 2
		for item_id in loadout:
			valid = valid and GameData.items.has(item_id) and GameData.items[item_id].volume > 0
			if GameData.weapons.has(item_id): valid = valid and GameData.weapons[item_id].can_equip_on(GameData.ships[ship_id].ship_class)
			if GameData.shields.has(item_id): valid = valid and GameData.shields[item_id].can_equip_on(GameData.ships[ship_id].ship_class)
		check(valid, "Valid cargo-backed loadout for " + String(ship_id))
	var recipe: Dictionary
	for entry in yard.station_data.get_recipes():
		if entry["output_id"] == &"fighter": recipe = entry
	yard.inventory.clear()
	for item_id in recipe["inputs"]:
		if not GameData.weapons.has(item_id) and not GameData.shields.has(item_id): yard.inventory.add_item(item_id, recipe["inputs"][item_id])
	var before: Dictionary = yard.inventory.get_all_items()
	check(not yard.queue_manufacture(recipe) and yard.inventory.get_all_items() == before, "Hull-only order rejected without consuming materials")
	yard.inventory.add_item(&"ballistic_gatling_s1", 1)
	check(not yard.queue_manufacture(recipe) and yard.inventory.get_amount(&"ballistic_gatling_s1") == 1, "Missing shield does not consume reserved weapon")
	var hauler: ShipInstance = spawner.build_completed_ship(&"hauler")
	check(hauler.equipped_weapons.is_empty() and hauler.equipped_shield == null, "Bare launch grants no free equipment")
	await get_tree().process_frame
	var ai: AIShipController
	for child in hauler.get_children():
		if child is AIShipController: ai = child
	military.inventory.clear()
	military.inventory.add_item(&"shield_s1_average", 1)
	hauler.inventory.capacity = 5
	ai._haul_source = military
	ai._haul_destination = yard
	ai._haul_item = &"shield_s1_average"
	ai._haul_loaded = false
	ai._waypoint = military.global_position
	hauler.global_position = military.global_position + Vector2(260, 0)
	ai._think_haul()
	check(hauler.inventory.get_amount(&"shield_s1_average") == 1 and military.inventory.get_amount(&"shield_s1_average") == 0, "Hauler physically picks up shield within cargo capacity")
	hauler.global_position = yard.global_position
	ai._think_haul()
	check(yard.inventory.get_amount(&"shield_s1_average") == 1 and hauler.inventory.get_amount(&"shield_s1_average") == 0, "Hauler delivers shield to shipyard")
	check(yard.queue_manufacture(recipe) and yard.inventory.get_all_items().is_empty(), "Funded order consumes equipment and hull materials once")
	var count: int = spawner._spawned_ships.size()
	yard._process_manufacturing(60)
	var built: ShipInstance = spawner._spawned_ships.back()
	check(spawner._spawned_ships.size() == count + 1 and built.equipped_weapons[0].id == &"ballistic_gatling_s1" and built.equipped_shield.id == &"shield_s1_average", "Completed ship receives exact reserved equipment")
	yard._process_manufacturing(60)
	check(spawner._spawned_ships.size() == count + 1, "Completed order cannot grant equipment twice")
	print("EQUIPMENT REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
