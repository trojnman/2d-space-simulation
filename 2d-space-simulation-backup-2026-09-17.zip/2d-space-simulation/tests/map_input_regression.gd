extends Node
func _ready() -> void:
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 20:await get_tree().process_frame
 var camera=main.get_node("FreeCameraController")
 camera._enter_free_cam()
 var ship=PlayerState.fleet_ships[0]
 camera.global_position=ship.global_position
 camera.zoom=Vector2(.3,.3)
 camera._zoom_target=camera.zoom
 camera.force_update_scroll()
 for i in 3:await get_tree().process_frame
 var point:Vector2=camera.get_canvas_transform()*ship.global_position
 var motion:=InputEventMouseMotion.new()
 motion.position=point
 get_viewport().push_input(motion,true)
 await get_tree().process_frame
 print("HOVER ",get_viewport().gui_get_hovered_control(), " POINT ",point," SIZE ",get_viewport().get_visible_rect())
 var click:=InputEventMouseButton.new()
 click.button_index=MOUSE_BUTTON_LEFT
 click.position=point
 click.pressed=true
 get_viewport().push_input(click,true)
 await get_tree().process_frame
 click=click.duplicate()
 click.pressed=false
 get_viewport().push_input(click,true)
 await get_tree().process_frame
 assert(FleetCommandSystem.selected_ships.has(ship),"Viewport mouse click must select fleet ship")
 print("MAP INPUT: viewport click selected ship")
 FleetCommandSystem.deselect_all()
 var a:Vector2=point-Vector2(80,80)
 var b:Vector2=point+Vector2(80,80)
 click.position=a
 click.pressed=true
 get_viewport().push_input(click,true)
 motion.position=b
 motion.button_mask=MOUSE_BUTTON_MASK_LEFT
 get_viewport().push_input(motion,true)
 click=click.duplicate()
 click.position=b
 click.pressed=false
 get_viewport().push_input(click,true)
 await get_tree().process_frame
 assert(FleetCommandSystem.selected_ships.has(ship),"Box selection must select fleet ship")
 print("MAP INPUT: box selection passed")
 var sidebar=get_tree().get_first_node_in_group("fleet_sidebar")
 var selected_row=sidebar.tree.get_next_selected(null)
 assert(selected_row!=null and selected_row.get_metadata(0)==ship,"Map selection must highlight fleet row")
 sidebar.name_input.grab_focus()
 var old_position:Vector2=camera.global_position
 Input.action_press("thrust")
 camera._process(.1)
 Input.action_release("thrust")
 assert(camera.global_position==old_position,"Typing must block WASD map movement")
 sidebar.name_input.release_focus()
 print("MAP INPUT: typing blocks camera movement")
 sidebar.formation_editor.open_selection()
 sidebar.formation_editor.title_input.grab_focus()
 assert(preload("res://scripts/UIInput.gd").typing(get_viewport()))
 old_position=camera.global_position
 Input.action_press("thrust")
 camera._process(.1)
 Input.action_release("thrust")
 assert(camera.global_position==old_position,"Popup typing must block camera movement")
 var old_zoom:Vector2=camera._zoom_target
 var wheel:=InputEventMouseButton.new()
 wheel.button_index=MOUSE_BUTTON_WHEEL_UP
 wheel.pressed=true
 camera._unhandled_input(wheel)
 assert(camera._zoom_target==old_zoom,"Popup scrolling must block world zoom")
 sidebar.formation_editor.hide()
 sidebar.formation_editor.title_input.release_focus()
 Input.action_press("thrust")
 camera._process(.1)
 Input.action_release("thrust")
 assert(camera.global_position!=old_position,"Camera controls resume after closing popup")
 print("MAP INPUT: popup typing, wheel isolation, and control restoration passed")
 var start=Time.get_ticks_usec()
 for i in 120:await get_tree().process_frame
 print("MAP TIMING: mean frame ms ",float(Time.get_ticks_usec()-start)/120000.0)
 get_tree().quit()

