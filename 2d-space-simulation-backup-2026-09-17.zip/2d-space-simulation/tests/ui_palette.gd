extends Node
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 15:await get_tree().process_frame
 var original=HUDLayout.color_name
 var dock=load("res://scenes/StationUI.tscn").instantiate()
 add_child(dock)
 var station=get_tree().get_first_node_in_group("stations")
 dock.open(station,PlayerState.current_ship)
 for i in 2:await get_tree().process_frame
 var inspector=get_tree().get_first_node_in_group("station_inspection")
 for choice in HUDLayout.COLORS:
  HUDLayout.color_name=choice
  HUDLayout.repaint_ui()
  var expected=HUDLayout.palette_color(Color("56dfeb"))
  assert(dock.station_name_label.get_theme_color("font_color").is_equal_approx(expected))
  assert(inspector._title.get_theme_color("font_color").is_equal_approx(expected))
  var popup:=PopupMenu.new()
  popup.theme=preload("res://scripts/ConsoleTheme.gd").build()
  add_child(popup)
  await get_tree().process_frame
  assert(popup.get_theme_color("font_hover_color").is_equal_approx(expected))
  popup.queue_free()
 HUDLayout.color_name=original
 HUDLayout.repaint_ui()
 print("UI PALETTE: five palettes verified on docking, inspection, and new popups")
 get_tree().quit()
