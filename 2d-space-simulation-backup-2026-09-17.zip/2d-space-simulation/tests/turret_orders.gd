extends Node
const Orders = preload("res://scripts/TurretOrders.gd")
var checks: int = 0
var failures: int = 0
func check(ok: bool, label: String) -> void:
 checks+=1
 if not ok:
  failures+=1
  print("TURRET FAIL: ",label)
func _ready() -> void:
 var aim_point=Orders.intercept_point(Vector2.ZERO,Vector2.ZERO,Vector2(100,0),Vector2(0,30),100)
 var flight_time=aim_point.length()/100.0
 check(aim_point.distance_to(Vector2(100,0)+Vector2(0,30)*flight_time)<.01,"moving target intercept")
 aim_point=Orders.intercept_point(Vector2.ZERO,Vector2(0,30),Vector2(100,0),Vector2(0,30),100)
 check(aim_point.is_equal_approx(Vector2(100,0)),"inherited velocity cancels shared motion")
 aim_point=Orders.intercept_point(Vector2.ZERO,Vector2.ZERO,Vector2(100,0),Vector2(200,0),100)
 check(aim_point.is_equal_approx(Vector2(100,0)),"unreachable target has finite fallback")
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 12:await get_tree().process_frame
 get_tree().paused=true
 var player:Player=PlayerState.current_ship
 player.initialize(GameData.ships[&"medium_fighter"])
 player.rotation=PI
 player.equipped_weapons.clear()
 player.equip_weapon(GameData.weapons[&"laser_autocannon_s2"],3)
 player.energy=1000
 var target:ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
 SectorManager.current_sector.add_child(target)
 target.initialize(GameData.ships[&"fighter"])
 target.faction_id=&"rogue"
 var aim:float=player.ship_data.mount_arc_center(3)
 target.position=player.position+Vector2.from_angle(aim)*400
 SensorSystem._do_sweep()
 player.turret_angles[3]=aim
 player.set_turret_order(Orders.DEFEND)
 Orders.select_targets(player,0)
 check(player.turret_targets[3]==null,"Defend ignores unprovoked enemies")
 Orders.notify_shot(target,target.position,target.position.direction_to(player.position),1000)
 Orders.select_targets(player,0)
 check(player.turret_targets[3]==target,"Incoming shot activates Defend before impact")
 var energy:float=player.energy
 Orders.fire(player)
 check(player.energy<energy,"Defend fires on attacker")
 Orders.select_targets(player,31)
 check(player.turret_targets[3]==null,"Defend expires without further attacks")
 player._weapon_cooldowns.fill(0)
 player.set_turret_order(Orders.PASSIVE)
 Orders.record_attack(player,target)
 Orders.select_targets(player,0)
 energy=player.energy
 Orders.fire(player)
 check(player.energy==energy and player.turret_targets[3]==null,"Passive never retaliates")
 player.fire_group(1,Vector2.from_angle(aim))
 check(player.energy==energy,"Manual trigger cannot override Passive turrets")
 player.set_turret_order(Orders.ATTACK)
 player.turret_threats.clear()
 Orders.select_targets(player,0)
 check(player.turret_targets[3]==target,"Attack selects enemy without provocation")
 var hud=get_tree().get_first_node_in_group("targeting_hud")
 player.set_turret_order(Orders.CURRENT_TARGET)
 hud.target=null
 Orders.select_targets(player,0)
 check(player.turret_targets[3]==null,"Current target holds fire with no selection")
 hud.target=target
 Orders.select_targets(player,0)
 check(player.turret_targets[3]==target,"Current target selects selected enemy")
 target.position=player.position+Vector2(400,0)
 Orders.select_targets(player,0)
 check(player.turret_targets[3]==null,"Turret arc prevents frontal fire")
 target.position=player.position+Vector2.from_angle(aim)*400
 player.set_turret_order(Orders.ATTACK)
 player.turret_angles[3]=aim+0.5
 Orders.select_targets(player,0)
 energy=player.energy
 Orders.fire(player)
 check(player.energy==energy,"Turret waits to traverse before firing")
 player.set_turret_order(Orders.DEFEND)
 Orders.record_attack(player,target)
 var path="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/turret-orders-save.dat"
 check(SaveManager.save_game(path),"Save turret policy")
 check(await SaveManager.load_game(path),"Load turret policy")
 get_tree().paused=true
 player=PlayerState.current_ship
 check(player.turret_order==Orders.DEFEND and not player.turret_threats.is_empty(),"Policy and retaliation survive load")
 player.set_turret_order(Orders.PASSIVE)
 var entry=PlayerState._boarding_snapshot(player)
 player.set_turret_order(Orders.ATTACK)
 PlayerState.restore_ship_entry(player,entry)
 check(player.turret_order==Orders.PASSIVE,"Boarding entry preserves policy")
 var home=SectorManager.current_sector
 var defender:ShipInstance=load("res://scenes/MediumFighter.tscn").instantiate()
 home.add_child(defender)
 defender.initialize(GameData.ships[&"medium_fighter"])
 defender.faction_id=&"terran_republic"
 defender.position=Vector2(20000,20000)
 defender.equip_weapon(GameData.weapons[&"laser_autocannon_s2"],3)
 var aggressor:ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
 home.add_child(aggressor)
 aggressor.initialize(GameData.ships[&"fighter"])
 aggressor.faction_id=&"rogue"
 aggressor.position=defender.position+Vector2.from_angle(aim)*300
 defender.turret_angles[3]=aim
 defender.set_turret_order(Orders.DEFEND)
 Orders.record_attack(defender,aggressor)
 SectorManager.load_sector(&"frontier_reach")
 for i in 4:await get_tree().process_frame
 var hull:float=aggressor.hull
 defender.tick(0)
 check(aggressor.hull<hull,"Offscreen defending turret damages attacker")
 defender.set_turret_order(Orders.PASSIVE)
 defender._weapon_cooldowns.fill(0)
 hull=aggressor.hull
 defender.tick(0)
 check(aggressor.hull==hull,"Offscreen Passive holds fire")
 print("TURRET_ORDERS: ",checks," checks, ",failures," failures")
 get_tree().quit(failures)
