extends Node

var failures: int = 0
var checks: int = 0

func check(condition: bool, message: String) -> void:
	checks += 1
	if condition: print("PASS: " + message)
	else:
		failures += 1
		push_error("FAIL: " + message)

func _ready() -> void:
	call_deferred("run")

func settle() -> void:
	for i in 4: await get_tree().process_frame

func run() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	FactionManager.set_process(false)
	var sol: SectorInstance = SectorManager.current_sector
	var yard: StationInstance
	var factory: StationInstance
	var trade: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		match station.station_data.id:
			&"sol_prime_shipyard": yard = station
			&"sol_prime_manufacturing": factory = station
			&"sol_prime_trade": trade = station
	if not yard or not factory or not trade:
		check(false, "Fixture stations exist")
		get_tree().quit(1)
		return
	var player: Player = get_tree().get_first_node_in_group("player")
	var docking: DockingManager = get_tree().get_first_node_in_group("docking_manager")
	var spawner: StationSpawner
	for child in yard.get_children():
		if child is StationSpawner: spawner = child
	var ship: ShipInstance = spawner.build_completed_ship(&"hauler")
	await settle()
	ship.add_to_group("player_fleet")
	ship.hull = 17.0
	ship.energy = 23.0
	ship.shield = 11.0
	ship.inventory.add_item(&"iron", 7)
	ship.position = Vector2(9200, 8100)
	var ship_pos: Vector2 = ship.position
	var ai: AIShipController
	for child in ship.get_children():
		if child is AIShipController: ai = child
	ai._haul_source = factory
	ai._haul_destination = yard
	ai._haul_item = &"iron"
	ai._haul_loaded = true
	ai._command_queue = [{"type": GlobalEnums.FleetCommand.GO_WAIT, "position": Vector2(123,456)}]
	yard.inventory.clear()
	yard.station_credits = 731
	var recipe: Dictionary
	for item in yard.station_data.get_recipes():
		if item["output_id"] == &"fighter": recipe = item
	for item_id in recipe["inputs"]:
		yard.inventory.add_item(item_id, recipe["inputs"][item_id])
	check(yard.queue_manufacture(recipe), "Funded ship queued before travel")
	yard._process_manufacturing(19.0)
	var remaining: float = yard.get_manufacture_queue()[0]["time_remaining"]
	var stock_before: Dictionary = yard.inventory.serialize()
	var faction_money: int = FactionManager.get_faction_credits(yard.faction_id) + FactionManager.civilian_credits
	var player_money: int = PlayerState.credits
	spawner.max_ships = 1
	spawner._initial_ships_spawned = 0
	spawner._try_spawn()
	spawner._spawned_ships.back().queue_free()
	trade.take_damage(100000.0)
	var gone_asteroid: Node = get_tree().get_first_node_in_group("asteroids")
	var gone_id: int = gone_asteroid.get_instance_id()
	gone_asteroid.queue_free()
	await settle()
	var asteroid: AsteroidInstance = get_tree().get_first_node_in_group("asteroids")
	asteroid.hull = 9.0
	asteroid._remaining_yield = 3
	var ore_count: int = get_tree().get_nodes_in_group("asteroids").size()
	var ship_count: int = get_tree().get_nodes_in_group("ships").size()
	var station_count: int = get_tree().get_nodes_in_group("stations").size()
	var satellite: SatelliteInstance = load("res://scenes/Satellite.tscn").instantiate()
	satellite.position = Vector2(17000, 14000)
	SectorManager.add_sector_entity(satellite)
	var projectile: Node2D = load("res://scenes/Bullet.tscn").instantiate()
	SectorManager.add_sector_entity(projectile)
	var registrar: Node = load("res://scripts/ObserverRegistrar.gd").new()
	ship.add_child(registrar)
	await settle()
	check(_observes(satellite), "Satellite registers sensors before travel")
	SensorSystem.register_observer(ship, 1000.0)
	var baseline_circles: int = SensorSystem.get_sensor_circles().size()
	FleetCommandSystem.selected_ships.append(ship)
	docking._nearby_stations.append(yard)
	yard._player_in_range = true
	var outbound: JumpGate = sol.get_node("JumpGates").get_child(0)
	var destination: StringName = outbound.destination_sector_id
	outbound._player_in_range = true
	check(outbound.activated.get_connections().size() == 1, "Jump gate signal connected to sector")
	outbound._activate()
	await settle()
	var frontier: SectorInstance = SectorManager.current_sector
	check(frontier != sol and SectorManager.current_sector_id == destination, "Gate activation changes sector")
	check(is_instance_valid(sol) and not sol.is_inside_tree(), "Visited sector retained outside active tree")
	check(not ship.is_inside_tree() and not satellite.is_inside_tree() and not projectile.is_inside_tree(), "Ships, satellites and projectiles remain in original sector")
	check(not get_tree().get_nodes_in_group("stations").has(yard), "Inactive stations absent from local world queries")
	check(not _observes(satellite), "Inactive satellite cannot reveal another sector")
	check(SensorSystem.get_sensor_circles().size() < baseline_circles, "Inactive ship observers cannot reveal another sector")
	check(FleetCommandSystem.selected_ships.is_empty(), "Travel clears fleet selection without cancelling orders")
	check(docking._nearby_stations.is_empty() and not yard._player_in_range, "Travel clears stale docking state")
	var return_gate: JumpGate
	for gate in frontier.get_node("JumpGates").get_children():
		if gate.destination_sector_id == &"sol_prime": return_gate = gate
	check(return_gate != null, "Destination has return gate")
	if return_gate:
		check(player.global_position.distance_to(return_gate.global_position) > 300.0 and player.global_position.distance_to(return_gate.global_position) < 700.0, "Player arrives beside the correct return gate")
	FactionManager._run_faction_strategy()
	await settle()
	check(yard.get_manufacture_queue().size() == 1 and yard.get_manufacture_queue()[0]["time_remaining"] == remaining, "Inactive production is paused and untouched by active strategy")
	check(yard.inventory.serialize() == stock_before, "Inactive stock is not reseeded or consumed")
	SectorManager.load_sector(&"sol_prime", Vector2(1000,2000))
	await settle()
	check(SectorManager.current_sector == sol, "Return reuses exact sector state")
	check(get_tree().get_nodes_in_group("ships").size() == ship_count, "No duplicate or replenished ships after travel")
	check(get_tree().get_nodes_in_group("stations").size() == station_count and not is_instance_valid(trade), "Destroyed station stays destroyed")
	check(get_tree().get_nodes_in_group("asteroids").size() == ore_count and not is_instance_id_valid(gone_id), "Depleted asteroid stays removed")
	check(asteroid.hull == 9.0 and asteroid._remaining_yield == 3, "Partial asteroid depletion survives travel")
	check(ship.hull == 17.0 and ship.energy == 23.0 and ship.shield == 11.0, "Ship damage and energy survive travel")
	check(ship.position == ship_pos and ship.inventory.get_amount(&"iron") == 7, "Ship position and cargo survive travel")
	check(ai._haul_source == factory and ai._haul_destination == yard and ai._haul_loaded, "In-flight cargo route survives travel")
	check(ai._command_queue.size() == 1, "Queued fleet order survives travel")
	check(yard.station_credits == FactionManager.get_faction_credits(yard.faction_id) and FactionManager.get_faction_credits(yard.faction_id) + FactionManager.civilian_credits == faction_money and PlayerState.credits == player_money, "Station, faction and player credits survive travel")
	check(yard.inventory.serialize() == stock_before and yard.get_manufacture_queue()[0]["time_remaining"] == remaining, "Paid production resumes with original inputs and timer")
	check(_observes(satellite) and SensorSystem.get_sensor_circles().size() == baseline_circles, "Sensors restore once on return")
	spawner._try_spawn()
	check(get_tree().get_nodes_in_group("ships").size() == ship_count and spawner._initial_ships_spawned == 1, "Travel cannot reset starter allocation")
	var stock_after: Dictionary = yard.inventory.serialize()
	for i in 3:
		SectorManager.load_sector(destination)
		await settle()
		SectorManager.load_sector(&"sol_prime")
		await settle()
	check(SectorManager._visited_sectors.size() == 2, "Repeated travel does not accumulate duplicate sectors")
	check(yard.inventory.serialize() == stock_after, "Repeated travel conserves materials")
	check(get_tree().get_nodes_in_group("ships").size() == ship_count, "Repeated travel conserves ships")
	check(_observer_count(satellite) == 1, "Repeated travel does not duplicate satellite observers")
	check(outbound.activated.get_connections().size() == 1, "Repeated travel does not duplicate gate connections")
	SectorManager.load_sector(&"missing_sector")
	check(SectorManager.current_sector == sol, "Invalid destination leaves current sector intact")
	yard._process_manufacturing(remaining)
	check(yard.get_manufacture_queue().is_empty() and get_tree().get_nodes_in_group("ships").size() == ship_count + 1, "Preserved job finishes once after return")
	# Exercise real physics processing too, not only manually stepped production.
	for item_id in recipe["inputs"]:
		yard.inventory.add_item(item_id, recipe["inputs"][item_id])
	check(yard.queue_manufacture(recipe), "Live-processing fixture queues funded ship")
	main.process_mode = Node.PROCESS_MODE_INHERIT
	for i in 90: await get_tree().physics_frame
	await get_tree().process_frame
	var live_remaining: float = yard.get_manufacture_queue()[0]["time_remaining"]
	check(live_remaining < 60.0, "Production advances in the active sector under real physics")
	SectorManager.load_sector(destination)
	for i in 90: await get_tree().physics_frame
	await get_tree().process_frame
	check(yard.get_manufacture_queue()[0]["time_remaining"] == live_remaining, "Detached sector timers remain frozen during live simulation")
	SectorManager.load_sector(&"sol_prime")
	for i in 90: await get_tree().physics_frame
	await get_tree().process_frame
	check(yard.get_manufacture_queue()[0]["time_remaining"] < live_remaining, "Production resumes automatically when sector returns")
	print("PERSISTENCE REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)

func _observes(node: Node) -> bool:
	return _observer_count(node) > 0

func _observer_count(node: Node) -> int:
	var result: int = 0
	for observer in SensorSystem._observers:
		if observer["node"] == node: result += 1
	return result
