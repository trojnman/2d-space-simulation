extends Node
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("TRANSPORT FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var home=SectorManager.current_sector
	var attacker: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	var target: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	home.add_child(attacker)
	home.add_child(target)
	attacker.initialize(GameData.ships[&"fighter"])
	target.initialize(GameData.ships[&"fighter"])
	attacker.faction_id=&"rogue"
	target.faction_id=&"terran_republic"
	attacker.position=Vector2(20000,20000)
	target.position=attacker.position+Vector2(100,0)
	attacker.equip_weapon(GameData.weapons[&"ballistic_autocannon_s1"],0)
	attacker.inventory.add_item(&"ballistic_ammo",100)
	var ai:=AIShipController.new()
	attacker.add_child(ai)
	for i in 2:await get_tree().process_frame
	SectorManager.load_sector(&"frontier_reach")
	for i in 4:await get_tree().process_frame
	ai._target=target
	ai._state=AIShipController.State.ATTACK
	var before:=target.hull
	ai._fire_background()
	check(target.hull<before,"background weapon damage")
	check(attacker.inventory.get_amount(&"ballistic_ammo")==99,"background consumes ammo")
	before=target.hull
	ai._fire_background()
	check(target.hull==before,"cooldown prevents extra shot")
	attacker._weapon_cooldowns.fill(0)
	target.position=attacker.position+Vector2(100000,0)
	ai._fire_background()
	check(target.hull==before and attacker.inventory.get_amount(&"ballistic_ammo")==99,"range gate preserves ammo")
	check(home.find_children("*","Bullet",true,false).is_empty(),"no offscreen projectiles")
	attacker.add_to_group("player_fleet")
	target.position=attacker.position+Vector2(100,0)
	var remote:=SensorSystem.remote_sector_contacts(&"sol_prime")
	check(remote.circles.size()>0,"remote fleet provides sensor coverage")
	check(remote.contacts.any(func(contact):return contact.position==target.position),"in-range remote contact visible")
	target.position=attacker.position+Vector2(10000,0)
	remote=SensorSystem.remote_sector_contacts(&"sol_prime")
	check(not remote.contacts.any(func(contact):return contact.position==target.position),"out-of-range remote contact hidden")
	attacker.remove_from_group("player_fleet")
	attacker.faction_id=&"terran_republic"
	target.position=attacker.position+Vector2(100,0)
	PlayerState.joined_faction=&"terran_republic"
	remote=SensorSystem.remote_sector_contacts(&"sol_prime")
	check(remote.contacts.any(func(contact):return contact.position==target.position),"joined faction shares remote coverage")
	PlayerState.joined_faction=&""
	remote=SensorSystem.remote_sector_contacts(&"sol_prime")
	check(remote.circles.is_empty(),"leaving revokes shared coverage")
	SectorManager.load_sector(&"sol_prime")
	for i in 3:await get_tree().process_frame
	check(target.hull==before,"return preserves combat damage")
	PlayerState.joined_faction=&"terran_republic"
	check(SensorSystem.has_local_contact(attacker.position),"joined faction shares local coverage")
	print("BACKGROUND_COMBAT: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
