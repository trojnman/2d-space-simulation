extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var sector=SectorManager.current_sector
	var owner: StringName=sector.sector_data.controlling_faction_id
	var npc: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	npc.faction_id=owner
	sector.add_child(npc)
	npc.initialize(GameData.ships[&"fighter"])
	var ai:=AIShipController.new()
	npc.add_child(ai)
	for i in 3:await get_tree().process_frame
	PlayerState.joined_faction=owner
	FactionManager._on_faction_hq_destroyed(owner,null)
	check(npc.faction_id==&"rogue" and not npc.is_queued_for_deletion(),"NPC ship survives as rogue")
	check(ai._is_combat_ship,"rogue hauler or fighter enters combat behavior")
	check(PlayerState.joined_faction==&"","membership ends on collapse")
	check(not PlayerState.can_join_faction(owner),"cannot rejoin defeated faction")
	check(ai._is_enemy(PlayerState.current_ship),"rogue targets player")
	for i in 4:await get_tree().process_frame
	check(SaveManager.save_game(PATH),"save NPC collapse")
	check(await SaveManager.load_game(PATH),"load NPC collapse")
	check(FactionManager._defeated_factions.has(owner),"defeat flag persists")
	var late: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	late.faction_id=owner
	sector=SectorManager.current_sector
	sector.add_child(late)
	late.initialize(GameData.ships[&"fighter"])
	FactionManager.register_ship(late)
	check(late.faction_id==&"rogue","later sector ships inherit collapse")
	print("NPC_COLLAPSE: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
