extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("TRADE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var destination: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		candidate.inventory.clear()
		if candidate.station_data.id == &"sol_prime_manufacturing": destination = candidate
	var seller: StationInstance = load("res://scenes/Station.tscn").instantiate()
	seller.station_data = GameData.stations[&"sol_prime_trade"]
	seller.faction_id = &"free_traders_guild"
	seller.position = Vector2(15000, 0)
	SectorManager.current_sector.add_child(seller)
	for i in 4: await get_tree().process_frame
	seller.inventory.clear()
	seller.inventory.add_item(&"hull_parts", 300)
	FactionManager.set_relation(destination.faction_id,seller.faction_id,0)
	var ship: ShipInstance = load("res://scenes/Hauler.tscn").instantiate()
	ship.faction_id = destination.faction_id
	SectorManager.add_sector_entity(ship)
	ship.initialize(GameData.ships[&"hauler"])
	var ai := AIShipController.new()
	ship.add_child(ai)
	for i in 2: await get_tree().process_frame
	ship.add_to_group("player_fleet")
	ai._is_fleet_ship=true
	var scaffold=preload("res://scripts/ConstructionScaffold.gd").new()
	scaffold.blueprint=&"claim_beacon"
	scaffold.beneficiary=destination.faction_id
	scaffold.position=Vector2(20000,0)
	SectorManager.current_sector.add_child(scaffold)
	check(ai.assign_scaffold_supply(scaffold),"assign scaffold")
	ship.global_position=seller.global_position
	var money:=PlayerState.credits
	ai._think_haul()
	var carried:=ship.inventory.get_amount(&"hull_parts")
	check(carried>0 and PlayerState.credits<money,"buys construction supplies")
	ship.global_position=scaffold.global_position
	ai._think_haul()
	check(scaffold.cargo.get(&"hull_parts",0)==carried and ship.inventory.get_amount(&"hull_parts")==0,"delivers into temporary inventory")
	var path:="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/scaffold-haul.dat"
	check(SaveManager.save_game(path),"save supply target")
	check(await SaveManager.load_game(path),"load supply target")
	var restored: AIShipController
	for node in get_tree().get_nodes_in_group("player_fleet"):
		var controller=node.get_node_or_null("AIShipController")
		if controller and is_instance_valid(controller.supply_scaffold):restored=controller
	check(restored!=null,"scaffold reference restored")
	if restored:
		restored.supply_scaffold.remaining=3
		restored._think_haul()
		check(restored.supply_scaffold==null and restored._state==AIShipController.State.IDLE,"hauler stops when build begins")
	print("SCAFFOLD_SUPPLY: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
