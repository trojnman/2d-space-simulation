extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player=PlayerState.current_ship
	var target: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	SectorManager.add_sector_entity(target)
	target.initialize(GameData.ships[&"fighter"])
	target.add_to_group("player_fleet")
	target.hull=80
	PlayerState.friendly_fire_enabled=false
	target.take_damage(0,10,player)
	check(target.hull==80,"off protects owned ships")
	PlayerState.friendly_fire_enabled=true
	target.take_damage(0,10,player)
	check(target.hull==70,"on damages owned ships")
	PlayerState.friendly_fire_enabled=false
	var station: StationInstance=get_tree().get_first_node_in_group("stations")
	station.faction_id=&"player"
	var health:=station.hull
	station.take_damage(10,player)
	check(station.hull==health,"off protects owned stations")
	PlayerState.friendly_fire_enabled=true
	station.take_damage(10,player)
	check(station.hull==health-10,"on damages owned stations")
	target.remove_from_group("player_fleet")
	target.faction_id=GameData.factions.keys()[0]
	PlayerState.set_reputation(target.faction_id,-1000)
	PlayerState.friendly_fire_enabled=false
	target.take_damage(0,10,player)
	check(target.hull==60,"off still damages hostile ships")
	PlayerState.set_reputation(target.faction_id,0)
	target.take_damage(0,10,player)
	check(target.hull==60,"off protects neutrals")
	target.global_position=Vector2(100000,100000)
	for enabled in [false,true]:
		PlayerState.friendly_fire_enabled=enabled
		var missile=load("res://scenes/Missile.tscn").instantiate()
		var payload: MissileData=GameData.missiles[&"missile_s1"].duplicate(true)
		payload.damage=10
		payload.blast_radius=100
		missile.launch(Vector2.ZERO,player,payload)
		SectorManager.add_sector_entity(missile)
		missile.global_position=target.global_position+Vector2(10,0)
		var before:=target.hull
		missile._detonate(null)
		check(target.hull<before if enabled else target.hull==before,"missile splash respects toggle: "+str(enabled))
	PlayerState.friendly_fire_enabled=true
	check(SaveManager.save_game(PATH),"save toggle")
	PlayerState.friendly_fire_enabled=false
	check(await SaveManager.load_game(PATH),"load toggle")
	check(PlayerState.friendly_fire_enabled,"toggle restored")
	print("FRIENDLY_FIRE: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
