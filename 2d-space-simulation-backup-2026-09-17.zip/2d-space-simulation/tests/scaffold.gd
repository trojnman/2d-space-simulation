extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player=PlayerState.current_ship
	var sector=SectorManager.current_sector
	var yard: StationInstance
	for station in SectorManager.get_sector_stations(sector):
		if station.station_data.id==&"sol_prime_shipyard":yard=station
	player.global_position=yard.global_position
	player.inventory.clear()
	var credits=PlayerState.credits
	check(BUILD.buy_kit(yard,player),"buy kit")
	check(PlayerState.credits==credits-1000 and player.inventory.get_amount(&"construction_kit")==1,"kit costs credits and enters cargo")
	sector.sector_data.controlling_faction_id=&""
	FactionManager._sector_ownership[sector.sector_data.id]=&""
	var point:=Vector2.INF
	for x in range(-25000,25000,1500):
		var candidate:=Vector2(x,22000)
		if BUILD.site_clear(sector,candidate):point=candidate;break
	player.global_position=point
	check(BUILD.deploy_kit(player,&"player_headquarters",point),"deploy headquarters scaffold")
	check(player.inventory.get_amount(&"construction_kit")==0,"deployment consumes kit")
	var scaffold=get_tree().get_first_node_in_group("construction_scaffolds")
	scaffold.advance(10)
	check(scaffold.remaining<0,"missing materials block timer")
	for id in scaffold.requirements():player.inventory.add_item(id,scaffold.requirements()[id])
	check(scaffold.deposit(player)>0,"deliver required materials")
	scaffold.advance(0)
	check(scaffold.remaining==3 and scaffold.cargo.is_empty(),"materials consumed to start timed build")
	scaffold.advance(1)
	check(not PlayerState.founded_faction,"not operational before completion")
	check(SaveManager.save_game(PATH),"save active scaffold")
	check(await SaveManager.load_game(PATH),"load active scaffold")
	scaffold=get_tree().get_first_node_in_group("construction_scaffolds")
	check(scaffold.remaining==2,"countdown restored")
	scaffold.advance(2)
	for i in 4:await get_tree().process_frame
	check(PlayerState.founded_faction,"completed headquarters founds faction")
	check(SectorManager.current_sector.sector_data.controlling_faction_id==&"player","headquarters claims sector")
	check(get_tree().get_nodes_in_group("construction_scaffolds").is_empty(),"scaffold replaced")
	sector=SectorManager.current_sector
	sector.sector_data.controlling_faction_id=&""
	var sponsor: StringName=GameData.factions.keys()[0]
	PlayerState.joined_faction=sponsor
	player.inventory.add_item(&"construction_kit",1)
	var second: Vector2=point+Vector2(1800,0)
	player.global_position=second
	check(BUILD.deploy_kit(player,&"claim_beacon",second),"member deploys faction beacon")
	scaffold=get_tree().get_first_node_in_group("construction_scaffolds")
	check(scaffold.beneficiary==sponsor,"sponsor fixed at deployment")
	PlayerState.joined_faction=&""
	for id in scaffold.requirements():player.inventory.add_item(id,scaffold.requirements()[id])
	scaffold.deposit(player)
	scaffold.advance(0)
	scaffold.advance(3)
	for i in 4:await get_tree().process_frame
	check(sector.sector_data.controlling_faction_id==sponsor,"leaving does not steal sponsored claim")
	var beacon: StationInstance
	for station in SectorManager.get_sector_stations(sector):
		if station.station_data.station_type==&"claim_beacon":beacon=station
	check(is_instance_valid(beacon) and beacon.faction_id==sponsor,"beacon remains with faction")
	check(SaveManager.save_game(PATH),"save completed sponsored beacon")
	check(await SaveManager.load_game(PATH),"load completed sponsored beacon")
	check(SectorManager.current_sector.sector_data.controlling_faction_id==sponsor,"sponsored ownership restored")
	print("SCAFFOLD: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
