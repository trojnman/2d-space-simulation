extends Node
func _ready()->void:
 var planner=preload("res://scripts/FactionStrategy.gd")
 assert(planner.choose(&"terran_republic",2,0,0,0,100000,false).role=="miner")
 assert(planner.choose(&"terran_republic",2,1,0,0,100000,false).role=="hauler")
 assert(planner.choose(&"terran_republic",2,4,4,2,100000,true).phase=="Defend")
 assert(not planner.choose(&"terran_republic",2,4,4,20,100000,true).expand)
 assert(not planner.choose(&"terran_republic",2,4,4,20,1000,false).expand)
 assert(planner.choose(&"terran_republic",2,4,4,20,100000,false).expand)
 assert(planner.choose(&"ash_collective",2,4,4,8,100000,false).role=="fighter")
 assert(planner.choose(&"free_traders_guild",2,4,4,8,100000,false).role=="")
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 45:await get_tree().process_frame
 get_tree().paused=true
 FactionManager._run_faction_strategy()
 assert(FactionManager.strategy_status.size()==4)
 for plan in FactionManager.strategy_status.values():assert(plan.has("reason"))
 print("STRATEGY PASS: economy recovery, threat response, cash reserve, expansion gate, personalities, all four faction execution")
 get_tree().quit()
