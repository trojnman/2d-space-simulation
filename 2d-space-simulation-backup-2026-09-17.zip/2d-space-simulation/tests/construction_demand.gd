extends Node
func _ready() -> void:
 var main = load("res://scenes/Main.tscn").instantiate()
 main.process_mode = Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10: await get_tree().process_frame
 get_tree().paused = true
 var stations = SectorManager.get_sector_stations(SectorManager.current_sector)
 var a: StationInstance = stations[0]
 var b: StationInstance = stations[1]
 a.faction_id = &"supply_test"
 b.faction_id = &"supply_test"
 a.requested_supply_ship = &""
 a.replacement_supply_ship = &""
 b.requested_supply_ship = &""
 b.replacement_supply_ship = &""
 a.requested_station_blueprint = &""
 b.requested_station_blueprint = &""
 var baseline = a.get_faction_supply_request().duplicate()
 var blueprint = GameData.stations.keys()[0]
 var cost = StationData.BUILD_COSTS[GameData.stations[blueprint].station_type]
 a.requested_station_blueprint = blueprint
 b.requested_station_blueprint = blueprint
 var demand = a.get_faction_supply_request()
 for material in cost:
  assert(int(demand.get(material, 0)) == int(baseline.get(material, 0)) + int(cost[material]) * 2, "Concurrent construction demand must add")
 b._is_destroyed = true
 demand = a.get_faction_supply_request()
 for material in cost:
  assert(int(demand.get(material, 0)) <= int(baseline.get(material, 0)) + int(cost[material]), "Destroyed project must not contribute")
 print("CONSTRUCTION_DEMAND: combined requests and destroyed-station exclusion passed")
 get_tree().quit()
