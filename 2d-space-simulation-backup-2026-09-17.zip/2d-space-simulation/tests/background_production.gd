extends Node
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("BACKGROUND FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var home: SectorInstance = SectorManager.current_sector
	var yard: StationInstance
	var capital: StationInstance
	var factory: StationInstance
	for s in SectorManager.get_sector_stations(home):
		if s.station_data.id == &"sol_prime_shipyard": yard=s
		if s.station_data.id == &"sol_prime_capital_shipyard": capital=s
		if s.station_data.id == &"sol_prime_manufacturing": factory=s
	check(yard.order_player_ship(&"fighter"),"player order accepted")
	check(capital.queue_manufacture(capital.get_ship_recipe(&"heavy_fighter")),"faction order accepted")
	var recipe: Dictionary = factory.station_data.get_recipes()[0]
	check(factory.queue_manufacture(recipe),"factory batch accepted")
	var output: StringName = recipe.output_id
	var before := factory.inventory.get_amount(output)
	var credits := FactionManager.get_faction_credits(yard.faction_id)
	SectorManager.load_sector(&"frontier_reach")
	for i in 5: await get_tree().process_frame
	check(not home.is_inside_tree(),"home sector detached")
	SectorManager.advance_background_production(1.0)
	check(yard._manufacture_queue.size()==1 and is_equal_approx(yard._manufacture_queue[0].time_remaining,2.0),"background countdown")
	SectorManager.advance_background_production(2.1)
	check(PlayerState.get_station_hangar(yard.station_data.id).size()==1,"player ship delivered remotely")
	check(factory.inventory.get_amount(output)==before+int(recipe.output_amount),"factory output delivered once")
	check(FactionManager.get_faction_credits(yard.faction_id)==credits,"completion does not charge twice")
	var spawner: StationSpawner
	for child in capital.get_children():
		if child is StationSpawner: spawner=child
	check(spawner._spawned_ships.size()==1,"faction ship built remotely")
	var built: ShipInstance = spawner._spawned_ships[0]
	check(built.ship_data.id==&"heavy_fighter" and built.equipped_weapons[0]!=null,"remote build has paid equipment")
	SectorManager.load_sector(&"sol_prime")
	for i in 4: await get_tree().process_frame
	check(built.is_inside_tree() and built.get_node_or_null("HullArt")!=null,"remote ship activates on return")
	SectorManager.advance_background_production(4.0)
	check(PlayerState.get_station_hangar(yard.station_data.id).size()==1,"active sector not double advanced")
	print("BACKGROUND_PRODUCTION: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
