extends Node
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10:await get_tree().process_frame
 get_tree().paused=true
 var station:StationInstance=SectorManager.get_sector_stations(SectorManager.current_sector)[0]
 station.faction_id=&"player"
 for id in AsteroidInstance.MATERIAL_IDS.values():station.inventory.add_item(id,100000)
 station.inventory.remove_item(&"iron",station.inventory.get_amount(&"iron"))
 station.set_stock_target(&"iron",100)
 var miner:ShipInstance=load("res://scenes/Miner.tscn").instantiate()
 SectorManager.current_sector.add_child(miner)
 miner.initialize(GameData.ships[&"miner"])
 var ai:=AIShipController.new()
 ai._background_initialized=true
 miner.add_child(ai)
 ai._home_station=station
 var chosen=ai._find_nearest_asteroid()
 assert(chosen!=null and AsteroidInstance.MATERIAL_IDS[chosen.material_type]==&"iron","mining chooses scarce ore")
 station.inventory.add_item(&"iron",100000)
 var expected:Node2D
 var distance:=INF
 for asteroid in get_tree().get_nodes_in_group("asteroids"):
  var d:float=miner.global_position.distance_to(asteroid.global_position)
  if d<distance:distance=d;expected=asteroid
 assert(ai._find_nearest_asteroid()==expected,"stocked station uses nearest ore")
 print("MINING_PRIORITY: 2 checks passed")
 get_tree().quit()
