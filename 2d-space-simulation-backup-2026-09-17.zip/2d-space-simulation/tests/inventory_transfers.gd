extends Node
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 15:await get_tree().process_frame
 var player=PlayerState.current_ship
 var screen=get_tree().get_first_node_in_group("inventory_screen")
 screen._player=player
 screen._sync_slots_from_inventory()
 var source:=-1
 var destination:=-1
 for i in screen._cargo_slots.size():
  var slot=screen._cargo_slots[i]
  if slot==null:destination=i
  elif slot.id==&"missile_s1":source=i
 assert(source>=0 and destination>=0)
 var total:int=player.inventory.get_amount(&"missile_s1")
 screen.move_cargo(source,destination,3)
 assert(screen._cargo_slots[destination].amount==3)
 screen._sync_slots_from_inventory()
 assert(screen._cargo_slots[destination].amount==3)
 assert(player.inventory.get_amount(&"missile_s1")==total)
 screen.move_cargo(destination,source,3)
 assert(screen._cargo_slots[destination]==null)
 var transfer=load("res://scripts/CargoTransferPanel.gd").new()
 add_child(transfer)
 var other=PlayerState.fleet_ships[0]
 other.global_position=player.global_position+Vector2(500,0)
 transfer.target=other
 var old:int=other.inventory.get_amount(&"missile_s1")
 assert(transfer.transfer(&"missile_s1",2,true))
 assert(other.inventory.get_amount(&"missile_s1")==old+2)
 assert(player.inventory.get_amount(&"missile_s1")==total-2)
 assert(transfer.transfer(&"missile_s1",2,false))
 other.global_position=player.global_position+Vector2(5000,0)
 assert(not transfer.transfer(&"missile_s1",2,true))
 assert(player.inventory.get_amount(&"missile_s1")==total)
 assert(not transfer.transfer(&"missile_s1",-1,true))
 other.global_position=player.global_position+Vector2(500,0)
 other.inventory.capacity=0.01
 assert(not transfer.transfer(&"missile_s1",2,true))
 assert(player.inventory.get_amount(&"missile_s1")==total)
 var scaffold=load("res://scripts/ConstructionScaffold.gd").new()
 scaffold.blueprint=&"defense_platform"
 scaffold.beneficiary=&"player"
 SectorManager.current_sector.add_child(scaffold)
 scaffold.global_position=player.global_position+Vector2(100,0)
 transfer.target=scaffold
 var material=scaffold.requirements().keys()[0]
 player.inventory.capacity=0
 player.inventory.add_item(material,10,GameData.items)
 assert(transfer.transfer(material,2,true))
 assert(scaffold.cargo[material]==2)
 assert(transfer.transfer(material,1,false))
 assert(scaffold.cargo[material]==1)
 scaffold.remaining=2
 assert(not transfer.transfer(material,1,false))
 print("INVENTORY: capacity rejection and construction cargo lock passed")
 print("INVENTORY: partial split, resync, merge, ship transfers, range and conservation passed")
 get_tree().quit()
