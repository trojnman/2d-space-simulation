extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	check(PlayerState.joined_faction == &"" and not PlayerState.founded_faction,"starts independent")
	var id: StringName = GameData.factions.keys()[0]
	PlayerState.set_reputation(id,-1000)
	check(not PlayerState.join_faction(id),"hostile membership rejected")
	PlayerState.set_reputation(id,1000)
	var cash := PlayerState.credits
	PlayerState.hangar_add_ship(&"membership_test",&"fighter")
	var assets := PlayerState.station_hangar.duplicate(true)
	check(PlayerState.join_faction(id),"friendly membership accepted")
	check(PlayerState.credits == cash and PlayerState.station_hangar == assets,"personal assets retained")
	var state := PlayerState.serialize()
	PlayerState.joined_faction = &""
	PlayerState.deserialize(state)
	check(PlayerState.joined_faction == id,"membership persists")
	check(PlayerState.is_friendly_to_player(id),"member access friendly")
	check(PlayerState.beacon_claim_faction() == id,"member beacon expands joined faction")
	PlayerState.joined_faction = &""
	check(PlayerState.beacon_claim_faction() == &"","independent player cannot claim for nonexistent faction")
	PlayerState.founded_faction = true
	check(PlayerState.beacon_claim_faction() == &"player","founder beacon expands own faction")
	check(PlayerState.beacon_claim_problem(SectorManager.current_sector) != "","claimed sectors reject new claims")
	var enemy: StringName=GameData.factions.keys()[1]
	PlayerState.joined_faction=id
	PlayerState.set_reputation(enemy,1000)
	FactionManager.set_relation(id,enemy,-1)
	check(PlayerState.is_hostile_to_player(enemy),"membership inherits war despite positive reputation")
	check(not PlayerState.is_friendly_to_player(enemy),"enemy internal access denied")
	check(FactionManager.are_at_war(&"player",enemy),"owned assets inherit hostility")
	var attacker: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	attacker.faction_id=enemy
	SectorManager.add_sector_entity(attacker)
	attacker.initialize(GameData.ships[&"fighter"])
	attacker.global_position=Vector2(50000,50000)
	var ai:=AIShipController.new()
	attacker.add_child(ai)
	var fleet: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	fleet.add_to_group("player_fleet")
	SectorManager.add_sector_entity(fleet)
	fleet.initialize(GameData.ships[&"fighter"])
	fleet.global_position=attacker.global_position+Vector2(100,0)
	for i in 2:await get_tree().process_frame
	check(ai._find_nearest_enemy(500)==fleet,"enemy actually selects personal fleet ship")
	ai._target=fleet
	ai._state=AIShipController.State.ATTACK
	PlayerState.joined_faction=&""
	PlayerState.founded_faction=false
	ai._physics_process(0.01)
	check(ai._target!=fleet,"NPC releases target after hostility ends")
	check(PlayerState.is_friendly_to_player(enemy),"leaving restores personal reputation")
	check(PlayerState.get_reputation(enemy)==1000,"membership preserves personal reputation")
	print("MEMBERSHIP: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
