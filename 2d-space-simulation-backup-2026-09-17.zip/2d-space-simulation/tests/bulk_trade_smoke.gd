extends Node
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var player: Player = get_tree().get_first_node_in_group("player")
	var station: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		if candidate.station_data.id == &"sol_prime_military": station = candidate
	var ui: StationUI = load("res://scenes/StationUI.tscn").instantiate()
	add_child(ui)
	PlayerState.set_reputation(station.faction_id,1000)
	var ledger_before: int = FactionManager.get_treasury_history(station.faction_id).size()
	ui.open(station, player)
	player.inventory.clear()
	var input: LineEdit = ui._trade_controls[&"ballistic_ammo"].input
	input.text = "100"
	input.text_changed.emit(input.text)
	var before: int = station.inventory.get_amount(&"ballistic_ammo")
	ui._on_buy_pressed(&"ballistic_ammo")
	var ok: bool = player.inventory.get_amount(&"ballistic_ammo") == 100 and station.inventory.get_amount(&"ballistic_ammo") == before - 100
	ui._populate_trade()
	ok = ok and ui._trade_controls[&"ballistic_ammo"].input == input and input.text == "100"
	ui._on_sell_pressed(&"ballistic_ammo")
	ok = ok and player.inventory.get_amount(&"ballistic_ammo") == 0 and station.inventory.get_amount(&"ballistic_ammo") == before
	var history: Array = FactionManager.get_treasury_history(station.faction_id)
	ok = ok and history.size() == ledger_before + 2
	ok = ok and history[-2]["delta"] > 0 and history[-1]["delta"] < 0
	ok = ok and history[-1]["balance"] == station.station_credits
	history.clear()
	ok = ok and FactionManager.get_treasury_history(station.faction_id).size() == ledger_before + 2
	ui._trade_controls[&"ballistic_ammo"].increase.pressed.emit()
	ok = ok and input.text == "101"
	ui._trade_controls[&"ballistic_ammo"].decrease.pressed.emit()
	ok = ok and input.text == "100"
	for id in ui._trade_controls:
		if id != &"ballistic_ammo": ok = ok and ui._trade_controls[id].input.text == "1"
	input.text = "invalid"
	input.text_changed.emit(input.text)
	ok = ok and ui._trade_controls[&"ballistic_ammo"].buy.disabled
	ui._on_buy_pressed(&"ballistic_ammo")
	ok = ok and player.inventory.get_amount(&"ballistic_ammo") == 0
	input.text_submitted.emit(input.text)
	ok = ok and input.text == "1"
	print("BULK TRADE UI: ", "PASS" if ok else "FAIL")
	get_tree().quit(0 if ok else 1)
