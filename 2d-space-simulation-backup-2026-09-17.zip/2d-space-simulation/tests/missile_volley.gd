extends Node
var failures := 0
func check(ok: bool, message: String) -> void:
	if not ok:
		failures += 1
		push_error(message)
func _ready() -> void:
	var data := MissileData.new()
	data.speed = 500
	data.lock_on_range = 5000
	data.lifetime = 20
	var lanes: Array[Vector2] = []
	for angle in [0.0, 1.7]:
		lanes.clear()
		for spread in [-.2, 0.0, .2]:
			var missile := Missile.new()
			missile.configure_volley(angle, spread)
			missile.launch(Vector2.ZERO, null, data)
			missile._target_acquired = true
			for i in 10: missile._physics_process(.01)
			check(absf(angle_difference(missile.rotation, angle+spread)) < .001, "Initial wedge retained")
			for i in 40: missile._physics_process(.01)
			check(absf(angle_difference(missile.rotation, angle)) < .001, "Missile straightens onto original aim")
			var lateral: float = missile.position.rotated(-angle).y
			for i in 30: missile._physics_process(.01)
			check(absf(missile.position.rotated(-angle).y-lateral) < .01, "Parallel lane retains separation")
			lanes.append(missile.position.rotated(-angle))
			missile.free()
		check(lanes[0].y < -10 and lanes[2].y > 10, "Outer missiles stay separated")
	var target := Node2D.new()
	target.position = Vector2(0,500)
	var homing := Missile.new()
	homing.configure_volley(0,.2)
	homing.launch(Vector2.ZERO,null,data)
	homing._target_acquired = true
	homing._target = target
	homing._physics_process(.1)
	check(homing.rotation > .2, "Locked missile continues homing")
	homing.free()
	target.free()
	print("MISSILE VOLLEY: %d failures" % failures)
	get_tree().quit(1 if failures else 0)
