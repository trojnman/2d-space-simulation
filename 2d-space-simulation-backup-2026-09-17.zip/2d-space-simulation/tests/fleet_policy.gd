extends Node
const Policy=preload("res://scripts/FleetAutomation.gd")
const Jobs=preload("res://scripts/FleetJobs.gd")
var checks:=0
var failures:=0
func check(ok:bool,message:String)->void:
 checks+=1
 if not ok:failures+=1;print("POLICY FAIL: ",message)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate();add_child(main)
 for i in 12:await get_tree().process_frame
 get_tree().paused=true
 var home=SectorManager.current_sector_id
 var neighbour=GameData.sectors[home].connected_sectors[0]
 check(Policy.reachable(home,0,[]).size()==1,"zero hops means original sector")
 check(Policy.reachable(home,1,[]).has(neighbour),"one hop includes neighbour")
 check(not Policy.reachable(home,5,[neighbour]).has(neighbour),"no go excluded from search")
 check(Policy.path(home,neighbour,Policy.reachable(home,1,[])).size()==2,"gate route found")
 check(Policy.path(home,neighbour,Policy.reachable(home,5,[neighbour])).is_empty(),"no go cannot be transit route")
 var ship=PlayerState.fleet_ships[0]
 var ai=ship.get_node("AIShipController")
 ai.automation_home=home;ai.automation_hops=1
 await SectorManager._initialize_shared_sector(neighbour)
 var remote=SectorManager._visited_sectors.get(neighbour)
 check(is_instance_valid(remote) and not remote.is_inside_tree(),"remote economy prepared without changing player sector")
 var station=SectorManager.get_sector_stations(remote)[0]
 station.faction_id=&"player"
 ai.fleet_job={"kind":"trade","destination":station,"item":&"iron","amount":2,"repeat":false,"automatic":true,"phase":"deliver"}
 for gate in SectorManager.current_sector.get_node("JumpGates").get_children():
  if gate.destination_sector_id==neighbour:ship.position=gate.position
 Policy.navigate(ai,station,.1)
 await get_tree().process_frame
 check(preload("res://scripts/StationConstruction.gd").sector_of(ship)==remote,"fleet ship traverses gate independently")
 check(SectorManager.current_sector_id==home,"fleet jump preserves player sector")
 ai.no_go_sectors=[neighbour]
 Jobs.tick(ai,.1)
 check(ai.default_suspended and not ai.alert_message.is_empty() and ship.velocity==Vector2.ZERO,"blocked policy alerts and holds")
 var before=ai.alert_message
 Jobs.tick(ai,.1)
 check(ai.alert_message==before,"held warning remains available")
 ai.no_go_sectors=[]
 var attacker=ShipInstance.new();attacker.faction_id=&"rogue"
 preload("res://scripts/TurretOrders.gd").record_attack(ship,attacker)
 check(ai.hostile_alert_seconds>0,"attack triggers hostile alert")
 attacker.free()
 var styles=preload("res://scripts/FleetAlertStyle.gd")
 check(styles.accent(true,"Red")!=styles.accent(false,"Red"),"red theme alerts are distinct")
 check(styles.accent(true,"Yellow")!=styles.accent(false,"Yellow"),"yellow theme alerts are distinct")
 check(styles.accent(true,"Red")==Color("df8cff") and styles.accent(false,"Red")==Color("ffe066"),"red HUD uses violet attack and yellow warning")
 for palette in ["Yellow","Orange"]:
  check(styles.accent(true,palette)==Color("ff334d") and styles.accent(false,palette)==Color("42f5d7"),palette+" HUD uses bright red attack and teal warning")
 check(styles.background(true,"Blue",.25)!=styles.background(true,"Blue",.75),"alert background pulses")
 print("FLEET_POLICY: ",checks," checks, ",failures," failures")
 get_tree().quit(failures)
