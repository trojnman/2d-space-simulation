extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var scaffold=preload("res://scripts/ConstructionScaffold.gd").new()
	scaffold.blueprint=&"sol_prime_trade"
	scaffold.beneficiary=&"player"
	SectorManager.current_sector.add_child(scaffold)
	var player: Player=PlayerState.current_ship
	PlayerState.friendly_fire_enabled=false
	scaffold.take_damage(100,player)
	check(scaffold.hull==500,"friendly fire off protects scaffold")
	PlayerState.friendly_fire_enabled=true
	var shot=load("res://scenes/Bullet.tscn").instantiate()
	var weapon: WeaponData=GameData.weapons[&"ballistic_autocannon_s1"]
	shot.launch(Vector2.RIGHT,player,weapon)
	SectorManager.add_sector_entity(shot)
	shot._on_body_entered(scaffold)
	check(scaffold.hull==500-weapon.damage,"projectile damages scaffold")
	check(SaveManager.save_game(PATH),"save damaged scaffold")
	check(await SaveManager.load_game(PATH),"load damaged scaffold")
	scaffold=get_tree().get_first_node_in_group("construction_scaffolds")
	check(scaffold.hull==500-weapon.damage,"scaffold damage persists")
	scaffold.cargo[&"hull_parts"]=30
	scaffold.take_damage(10000,player)
	check(scaffold.is_queued_for_deletion() and scaffold.cargo.is_empty(),"destruction removes construction and materials")
	scaffold.advance(100)
	check(scaffold.completed,"destroyed construction cannot finish")
	print("SCAFFOLD_COMBAT: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
