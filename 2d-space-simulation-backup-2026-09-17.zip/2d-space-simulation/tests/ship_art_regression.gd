extends Node
var failures := 0
var checks := 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(message)
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var player: Player = main.get_node("Player")
	var background: ColorRect = main.get_node("ColorRect")
	check(player.get_node("HullArt").z_index > background.z_index, "Starting hull draws above opaque game background")
	player.set_process(false)
	player.set_physics_process(false)
	await get_tree().process_frame
	var silhouettes: Dictionary = {}
	for id in StationSpawner.SHIP_SCENES:
		var npc: ShipInstance = load(StationSpawner.SHIP_SCENES[id]).instantiate()
		add_child(npc)
		npc.initialize(GameData.ships[id])
		var art := npc.get_node_or_null("HullArt")
		check(art != null and art.get_meta("design_id") == id, "Correct NPC hull " + str(id))
		if art:
			check(art.z_index > background.z_index, "NPC hull above background " + str(id))
			var signature: String = str(art.get_child(0).polygon)
			check(not silhouettes.has(signature), "Unique silhouette " + str(id))
			silhouettes[signature] = true
			for polygon in art.get_children():
				check(not Geometry2D.triangulate_polygon(polygon.polygon).is_empty(), "Renderable polygon " + str(id))
		player.equipped_weapons.clear()
		player.initialize(GameData.ships[id])
		for weapon in GameData.weapons.values():
			if weapon.can_equip_on(player.ship_data.ship_class):
				for slot in player.ship_data.weapon_slots:
					player.equipped_weapons.append(weapon)
					npc.equipped_weapons.append(weapon)
				break
		player._refresh_visuals()
		npc._refresh_visuals()
		check(player.get_node("HullArt").get_meta("design_id") == id, "Player changes hull " + str(id))
		check(player.muzzle_points.size() == npc.muzzle_points.size(), "Player hardpoint count " + str(id))
		for i in npc.muzzle_points.size():
			check(player.muzzle_points[i].position.is_equal_approx(npc.muzzle_points[i].position * Vector2(-1, 1)), "Mirrored muzzle " + str(id))
		check(player.get_node("HullArt").z_index > background.z_index, "Swapped player hull above background " + str(id))
		var controllers := 0
		var collisions := 0
		for child in player.get_children():
			if child is ShipVisualController:
				controllers += 1
				check(child.shield_visual.z_index < player.get_node("HullArt").z_index, "Shield behind hull " + str(id))
				for mount in child.weapon_visuals + child.missile_visuals:
					if mount is Polygon2D and mount.visible:
						var hull_art: Node2D = player.get_node("HullArt")
						var corners: Array = [0,1,6,7] if child.weapon_visuals.has(mount) else [0,1,2,3]
						for index in corners:
							var local_point := hull_art.to_local(mount.to_global(mount.polygon[index]))
							check(Geometry2D.is_point_in_polygon(local_point,hull_art.get_child(0).polygon), "Housing mounted on hull " + str(id))
				for weapon in child.weapon_visuals:
					check(weapon.z_index > player.get_node("HullArt").z_index, "Weapons above hull " + str(id))
			if child is CollisionPolygon2D: collisions += 1
		check(controllers == 1 and collisions == 1, "No accumulated hull parts " + str(id))
		npc.free()
	print("SHIP ART REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
