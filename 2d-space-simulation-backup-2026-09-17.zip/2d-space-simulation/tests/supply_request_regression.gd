extends Node
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(message)
	else: print("PASS: " + message)
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var yard: StationInstance
	var military: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_capital_shipyard": yard = station
		if station.station_data.id == &"sol_prime_military": military = station
	check(yard != null and military != null, "Test stations loaded")
	if yard == null or military == null:
		get_tree().quit(1)
		return
	yard.inventory.clear()
	var initial_report := yard.get_production_report()
	check(initial_report.any(func(entry): return entry["state"] == "Waiting for supplies"), "Empty yard reports missing inputs")
	check(yard.inventory.get_all_items().is_empty(), "Production report never creates inventory")
	var balance: int = yard.station_credits
	var player_balance: int = PlayerState.credits
	var recipe := yard.get_ship_recipe(&"heavy_fighter")
	check(yard.request_ship_supplies(&"heavy_fighter"), "Large ship supply request accepted")
	check(yard.station_credits == balance and PlayerState.credits == player_balance and yard.inventory.get_all_items().is_empty(), "Request grants no stock and charges no money")
	for item_id in recipe["inputs"]:
		check(yard.get_input_reserve(item_id) >= int(recipe["inputs"][item_id]), "Yard reserves requested input: " + str(item_id))
		check(military.get_output_target(item_id) >= int(recipe["inputs"][item_id]) * 2, "Supply target includes requested input: " + str(item_id))
	check(not yard.request_ship_supplies(&"invalid_ship") and yard.requested_supply_ship == &"heavy_fighter", "Invalid request preserves selected ship")
	check(not military.request_ship_supplies(&"heavy_fighter"), "Non-shipyard cannot request ships")
	var controller := AIShipController.new()
	check(controller._station_shortage(yard, &"hull_parts") > 0, "Existing hauling planner sees missing requested cargo")
	var equipment_recipe: Dictionary = {}
	for candidate in military.station_data.get_recipes():
		if candidate["output_id"] == &"ballistic_cannon_s3": equipment_recipe = candidate
	check(not equipment_recipe.is_empty(), "Requested large weapon has a manufacturing recipe")
	military._manufacture_queue.clear()
	military.inventory.clear()
	for item_id in equipment_recipe["inputs"]:
		military.inventory.add_item(item_id, equipment_recipe["inputs"][item_id])
	var treasury_before: int = military.station_credits
	check(military.queue_manufacture(equipment_recipe), "Requested equipment can use funded production")
	check(military.station_credits == treasury_before - military.get_production_cost(equipment_recipe), "Equipment production pays labor")
	check(military.get_production_report().any(func(entry): return entry["id"] == &"ballistic_cannon_s3" and entry["state"] == "Producing"), "Active job reports producing after inputs consumed")
	military._process_manufacturing(3.1)
	check(military.inventory.get_amount(&"ballistic_cannon_s3") > 0, "Timed production creates the requested equipment")
	var hauler: ShipInstance = load("res://scenes/Hauler.tscn").instantiate()
	main.add_child(hauler)
	hauler.initialize(GameData.ships[&"hauler"])
	hauler.faction_id = yard.faction_id
	hauler.inventory.clear()
	hauler.add_child(controller)
	controller._ship = hauler
	controller._haul_source = military
	controller._haul_destination = yard
	controller._haul_item = &"ballistic_cannon_s3"
	controller._waypoint = military.global_position
	hauler.global_position = military.global_position
	var equipment_before: int = military.inventory.get_amount(&"ballistic_cannon_s3")
	controller._think_haul()
	check(hauler.inventory.get_amount(&"ballistic_cannon_s3") > 0 and military.inventory.get_amount(&"ballistic_cannon_s3") + hauler.inventory.get_amount(&"ballistic_cannon_s3") == equipment_before, "Pickup transfers real equipment into hauler")
	hauler.global_position = yard.global_position
	controller._think_haul()
	check(yard.inventory.get_amount(&"ballistic_cannon_s3") == equipment_before and hauler.inventory.get_amount(&"ballistic_cannon_s3") == 0, "Delivery transfers cargo to requesting yard")
	yard.inventory.clear()
	controller.free()
	var faction := military.faction_id
	military.faction_id = &"test_unrelated"
	check(military.get_faction_supply_request().is_empty(), "Request does not affect unrelated factions")
	military.faction_id = faction
	var ui: StationUI = load("res://scenes/StationUI.tscn").instantiate()
	add_child(ui)
	ui.open(yard, get_tree().get_first_node_in_group("player"))
	ui._on_request_ship_supplies(&"heavy_fighter")
	check(yard.requested_supply_ship == &"", "UI cancels active request")
	ui._on_request_ship_supplies(&"heavy_hauler")
	check(yard.requested_supply_ship == &"heavy_hauler", "UI selects replacement request")
	ui._on_request_ship_supplies(&"heavy_fighter")
	check(yard.requested_supply_ship == &"heavy_fighter", "Only one requested ship per yard")
	check(not yard.order_player_ship(&"heavy_fighter"), "Request cannot bypass missing build inputs")
	for item_id in recipe["inputs"]: yard.inventory.add_item(item_id, recipe["inputs"][item_id])
	check(yard.get_production_report().any(func(entry): return entry["id"] == &"heavy_fighter" and entry["state"] == "Ready to order"), "Stocked ship recipe reports ready to order")
	PlayerState.credits = 100000000
	check(yard.order_player_ship(&"heavy_fighter"), "Stocked requested ship can be ordered")
	check(yard.requested_supply_ship == &"", "Accepted order clears request")
	check(yard.inventory.get_all_items().is_empty(), "Order consumes actual build inputs")
	print("SUPPLY REQUEST REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
