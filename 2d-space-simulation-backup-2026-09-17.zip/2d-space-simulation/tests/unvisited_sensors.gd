extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:
  failures+=1
  print("FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10: await get_tree().process_frame
 get_tree().paused=true
 var original:=SectorManager.current_sector_id
 var candidate:StringName=&""
 var faction:StringName=&""
 for id in GameData.sectors:
  if SectorManager._visited_sectors.has(id):continue
  var data:SectorData=GameData.sectors[id]
  for station_id in data.starting_stations:
   var sd:StationData=GameData.get_station(station_id)
   if sd and GameData.factions.has(sd.faction_id):
    candidate=id
    faction=sd.faction_id
    break
  if candidate!=&"":break
 check(candidate!=&"","unvisited candidate")
 PlayerState.joined_faction=faction
 await SectorManager._initialize_shared_sector()
 check(SectorManager.current_sector_id==original,"player not moved")
 check(not MapMemory.has_visited(candidate),"not marked visited")
 check(SectorManager._visited_sectors.has(candidate),"sector initialized")
 check(MapMemory.has_active_vision(candidate),"live coverage")
 check(MapMemory.get_visibility(candidate)==2,"galaxy visibility")
 var remote:SectorInstance=SectorManager._visited_sectors[candidate]
 check(not remote.is_inside_tree(),"remote physics detached")
 SectorManager.advance_background_production(30.0)
 var ships:=0
 for node in remote.find_children("*","",true,false):
  if node is ShipInstance:ships+=1
 check(ships>0,"remote initial fleet seeds")
 SectorManager.advance_background_transport(0.25)
 var path="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/unvisited-save.dat"
 check(SaveManager.save_game(path),"save remote universe")
 check(await SaveManager.load_game(path),"restore remote universe")
 remote=SectorManager._visited_sectors[candidate]
 check(MapMemory.has_active_vision(candidate),"restored coverage")
 check(not MapMemory.has_visited(candidate),"restore preserves unexplored status")
 var panel=load("res://scripts/RemoteSensorPanel.gd").new()
 add_child(panel)
 panel.snapshot=SensorSystem.remote_sector_contacts(candidate)
 var station:StationInstance=SectorManager.get_sector_stations(remote)[0]
 var point:=Vector2(220,235)+station.position*0.004
 PlayerState.set_reputation(station.faction_id,1000)
 check(panel.inspect_contact_at(point),"remote station click")
 check(panel.inspector.details.get_parsed_text().contains("Faction funds"),"friendly details")
 PlayerState.joined_faction=&""
 PlayerState.set_reputation(station.faction_id,0)
 panel.inspector._refresh_card()
 check(not panel.inspector.details.get_parsed_text().contains("Faction funds"),"neutral privacy")
 PlayerState.set_reputation(station.faction_id,-1000)
 check(not panel.inspect_contact_at(point),"enemy inspect blocked")
 panel.inspector._refresh_card()
 check(panel.inspector.details.get_parsed_text().contains("ACCESS RESTRICTED"),"open panel revokes details")
 var remembered:=SensorSystem.remote_sector_contacts(candidate)
 var found_memory:=false
 for contact in remembered.contacts:
  if contact.position==station.position:
   found_memory=contact.get("remembered",false) and not contact.has("node")
 check(found_memory,"enemy remembered without live reference")
 panel.queue_free()
 var stations:=SectorManager.get_sector_stations(remote).size()
 SectorManager.load_sector(candidate)
 for i in 4:await get_tree().process_frame
 check(SectorManager.current_sector==remote,"visit reuses simulation")
 check(SectorManager.get_sector_stations(remote).size()==stations,"no duplicate stations")
 PlayerState.joined_faction=&""
 SectorManager.load_sector(original)
 check(not MapMemory.has_active_vision(candidate),"leaving removes remote coverage")
 print("UNVISITED: %d checks, %d failures" % [checks,failures])
 get_tree().quit(failures)
