extends Node
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 15:await get_tree().process_frame
 var dock=load("res://scenes/StationUI.tscn").instantiate()
 add_child(dock)
 var station=get_tree().get_first_node_in_group("stations")
 var player=PlayerState.current_ship
 dock.open(station,player)
 var initial:int=player.inventory.get_amount(&"satellite")
 var data={"type":"storage_cargo","item_id":&"satellite","amount":2,"from_player":true,"station":station}
 assert(dock._transfer_storage_drag(data,false))
 assert(player.inventory.get_amount(&"satellite")==initial-2)
 assert(PlayerState.get_station_storage(station.station_data.id)[&"satellite"]==2)
 data.amount=1
 data.from_player=false
 assert(dock._transfer_storage_drag(data,true))
 assert(player.inventory.get_amount(&"satellite")==initial-1)
 assert(PlayerState.get_station_storage(station.station_data.id)[&"satellite"]==1)
 data.amount=1000
 assert(not dock._transfer_storage_drag(data,true))
 assert(player.inventory.get_amount(&"satellite")==initial-1)
 data.amount=1
 assert(not dock._transfer_storage_drag(data,false))
 print("STORAGE DRAG: split deposit/retrieval, conservation, stale amount and same-inventory rejection passed")
 get_tree().quit()
