extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var sector=SectorManager.current_sector
	var hq: StationInstance
	for station in SectorManager.get_sector_stations(sector):
		if station.station_data.station_type==&"headquarters":hq=station;break
	hq.faction_id=&"player"
	sector.sector_data.controlling_faction_id=&"player"
	PlayerState.founded_faction=true
	var cash=PlayerState.credits
	PlayerState.hangar_add_ship(&"other_station",&"fighter")
	var player=PlayerState.current_ship
	var platform: StationInstance=load("res://scenes/Station.tscn").instantiate()
	platform.station_data=GameData.stations[&"defense_platform"]
	platform.constructed=true
	platform.faction_id=&"player"
	sector.get_node("Stations").add_child(platform)
	var civilian: StationInstance=load("res://scenes/Station.tscn").instantiate()
	civilian.station_data=GameData.stations[&"sol_prime_trade"].duplicate(true)
	civilian.station_data.id=&"collapse_civilian"
	civilian.constructed=true
	civilian.faction_id=&"player"
	sector.get_node("Stations").add_child(civilian)
	var fleet: ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
	fleet.faction_id=&"player"
	fleet.add_to_group("player_fleet")
	sector.add_child(fleet)
	fleet.initialize(GameData.ships[&"fighter"])
	for i in 4:await get_tree().process_frame
	var scaffold=preload("res://scripts/ConstructionScaffold.gd").new()
	scaffold.blueprint=&"sol_prime_trade"
	scaffold.beneficiary=&"player"
	scaffold.remaining=1.0
	sector.add_child(scaffold)
	var foreign_yard: StationInstance
	for st in SectorManager.get_sector_stations(sector):
		if st.station_data.station_type==&"shipyard" and st.faction_id!=&"player":foreign_yard=st;break
	foreign_yard._station_build_queue.append({"owner":&"player","blueprint":&"sol_prime_trade"})
	hq._destroy()
	check(scaffold.is_queued_for_deletion(),"unfinished player construction destroyed")
	check(foreign_yard._station_build_queue.is_empty(),"pending project removed from foreign builder")
	check(platform.faction_id==&"rogue" and not platform._is_destroyed,"player platform goes rogue")
	check(civilian._is_destroyed,"other player station destroyed")
	check(fleet.faction_id==&"player" and not fleet.is_queued_for_deletion(),"player fleet retained")
	check(PlayerState.is_hostile_to_player(&"rogue") and FactionManager.are_at_war(&"rogue",&"terran_republic"),"rogues hostile to all")
	check(not PlayerState.founded_faction and PlayerState.joined_faction==&"","HQ destruction ends player faction")
	check(sector.sector_data.controlling_faction_id==&"","ended faction releases territory")
	check(PlayerState.credits==cash and is_instance_valid(player),"wallet and piloted ship retained")
	check(PlayerState.get_station_hangar(&"other_station").size()==1,"remote assets retained")
	check(PlayerState.beacon_claim_faction()==&"","independent player cannot claim")
	for i in 3:await get_tree().process_frame
	check(SaveManager.save_game(PATH),"save defeat")
	check(await SaveManager.load_game(PATH),"load defeat")
	check(not PlayerState.founded_faction and SectorManager.current_sector.sector_data.controlling_faction_id==&"","defeat persists")
	print("HQ_DEFEAT: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)

