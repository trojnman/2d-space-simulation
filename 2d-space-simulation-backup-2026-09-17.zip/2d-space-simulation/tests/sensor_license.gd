extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:
  failures+=1
  print("FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10: await get_tree().process_frame
 get_tree().paused=true
 var id:StringName=GameData.factions.keys()[0]
 PlayerState.joined_faction=&""
 PlayerState.founded_faction=false
 PlayerState.sensor_licenses.clear()
 PlayerState.credits=1000000
 PlayerState.set_reputation(id,0)
 check(not PlayerState.buy_sensor_license(id),"neutral rejected")
 check(PlayerState.credits==1000000,"no charge rejected")
 PlayerState.set_reputation(id,1000)
 PlayerState.credits=0
 check(not PlayerState.buy_sensor_license(id),"insufficient funds")
 PlayerState.credits=1000000
 var treasury:=FactionManager.get_faction_credits(id)
 check(PlayerState.buy_sensor_license(id),"purchase succeeds")
 check(PlayerState.credits==750000,"price debited")
 check(FactionManager.get_faction_credits(id)==treasury+250000,"seller receives money")
 check(PlayerState.has_shared_sensors(id),"license enables vision")
 check(not PlayerState.buy_sensor_license(id),"duplicate rejected")
 check(PlayerState.credits==750000,"duplicate not charged")
 PlayerState.set_reputation(id,0)
 check(not PlayerState.has_shared_sensors(id),"neutral suspends")
 PlayerState.set_reputation(id,-1000)
 check(not PlayerState.has_shared_sensors(id),"enemy suspends")
 PlayerState.set_reputation(id,1000)
 check(PlayerState.has_shared_sensors(id),"friendly reactivates")
 var path="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/license-save.dat"
 check(SaveManager.save_game(path),"save")
 PlayerState.sensor_licenses.clear()
 check(await SaveManager.load_game(path),"load")
 check(PlayerState.has_shared_sensors(id),"license restored")
 PlayerState.sensor_licenses.clear()
 PlayerState.joined_faction=id
 check(PlayerState.has_shared_sensors(id),"membership free")
 check(not PlayerState.buy_sensor_license(id),"member cannot pay twice")
 print("LICENSE: %d checks, %d failures" % [checks,failures])
 get_tree().quit(failures)
