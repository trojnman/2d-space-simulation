extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var sector = SectorManager.current_sector
	var original = sector.sector_data.controlling_faction_id
	check(not FactionManager.recheck_sector_claim(sector),"military retains ownership without beacon")
	var defender: StationInstance
	for station in SectorManager.get_sector_stations(sector):
		if station.faction_id == original and station.station_data.station_type in [&"headquarters", &"military", &"defense_platform"]:
			station._is_destroyed = true
			defender = station
	defender.station_data = defender.station_data.duplicate(true)
	defender.station_data.station_type = &"defense_platform"
	defender.faction_id = &"player"
	defender.claim_faction_id = original
	defender._is_destroyed = false
	check(not FactionManager.recheck_sector_claim(sector), "personal member defense protects joined territory")
	check(defender.faction_id == &"player", "defender remains personal property")
	defender._is_destroyed = true
	FactionManager.on_station_destroyed(defender, null)
	check(sector.sector_data.controlling_faction_id == &"", "destruction callback releases last claim")
	sector.sector_data.controlling_faction_id = original
	check(FactionManager.recheck_sector_claim(sector),"ownership released after last defense")
	check(sector.sector_data.controlling_faction_id == &"","civilian stations do not block release")
	var path := "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/claim-save.dat"
	check(SaveManager.save_game(path),"save released sector")
	check(await SaveManager.load_game(path),"load released sector")
	check(SectorManager.current_sector.sector_data.controlling_faction_id == &"","released ownership persists")
	print("CLAIM_RULE: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
