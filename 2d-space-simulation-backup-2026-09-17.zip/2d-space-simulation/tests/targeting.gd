extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:failures+=1;print("FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10:await get_tree().process_frame
 get_tree().paused=true
 var hud=get_tree().get_first_node_in_group("targeting_hud")
 var player:Player=PlayerState.current_ship
 var enemy:ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
 enemy.faction_id=&"rogue"
 SectorManager.add_sector_entity(enemy)
 enemy.initialize(GameData.ships[&"fighter"])
 enemy.global_position=player.global_position+Vector2(400,0)
 hud.select_at(enemy.get_global_transform_with_canvas().origin)
 check(hud.target==enemy,"click contact selects")
 hud.select_at(Vector2(-10000,-10000))
 check(hud.target==null,"empty click clears")
 check(hud.select_contact(enemy),"visible target selectable")
 check(hud.missile_lock()==null,"lock takes time")
 hud._process(1.1)
 check(hud.missile_lock()==enemy,"hostile lock acquired")
 enemy.velocity=Vector2(0,80)
 var pip=hud.fixed_weapon_lead()
 check(not pip.is_empty(),"fixed weapon lead pip available")
 if not pip.is_empty():check(pip.position.y>enemy.global_position.y,"lead pip predicts lateral motion")
 var original_weapons=player.equipped_weapons.duplicate()
 var original_groups=player.weapon_fire_groups.duplicate()
 player.equipped_weapons[0]=original_weapons[0].duplicate()
 player.equipped_weapons[1]=original_weapons[0].duplicate()
 player.equipped_weapons[1].projectile_speed*=.5
 player.weapon_fire_groups[0]=player._active_fire_group
 player.weapon_fire_groups[1]=player._active_fire_group
 player.energy=player.max_energy
 var pips=hud.fixed_weapon_leads()
 check(pips.size()==2,"two powered fixed weapons yield two pips")
 if pips.size()==2:check(pips[0].position.distance_to(pips[1].position)>1,"different speeds produce different lead points")
 player.equipped_weapons[1].energy_per_shot=player.max_energy+1
 check(hud.fixed_weapon_leads().size()==1,"unpowered weapon pip hidden")
 player.equipped_weapons[1].energy_per_shot=0
 player._weapon_cooldowns[1]=1
 check(hud.fixed_weapon_leads().size()==2,"cooldown keeps pip stable")
 player.weapon_fire_groups[1]=2 if player._active_fire_group==1 else 1
 check(hud.fixed_weapon_leads().size()==1,"inactive group pip hidden")
 player.equipped_weapons=original_weapons
 player.weapon_fire_groups=original_groups
 enemy.velocity=Vector2.ZERO

 var missiles=player.get_node("MissileSystem")
 missiles._armed_count=1
 missiles._fire_armed()
 var launched:Missile
 var found:=false
 for node in SectorManager.current_sector.get_children():
  if node is Missile and node._target==enemy:found=true;launched=node
 check(found,"missile uses selected lock")
 enemy.global_position=launched.global_position+Vector2(300,300)
 var before_error:float=absf(launched._velocity.angle_to(launched.global_position.direction_to(enemy.global_position)))
 launched._home_toward_target(.1)
 var after_error:float=absf(launched._velocity.angle_to(launched.global_position.direction_to(enemy.global_position)))
 check(after_error<before_error,"missile steers toward moving locked target")
 hud.clear_targets()
 check(launched._target==enemy,"launched missile retains its launch lock")
 var previous=get_tree().get_nodes_in_group("missiles")
 missiles._armed_count=1
 missiles._fire_armed()
 var unguided:Missile
 for node in get_tree().get_nodes_in_group("missiles"):
  if node not in previous:unguided=node
 check(unguided!=null and unguided._target==null and unguided._target_acquired,"no lock does not acquire arbitrary nearby enemy")
 var station=get_tree().get_first_node_in_group("stations")
 launched._target=station
 station.global_position=launched.global_position+Vector2(400,-300)
 before_error=absf(launched._velocity.angle_to(launched.global_position.direction_to(station.global_position)))
 launched._home_toward_target(.1)
 after_error=absf(launched._velocity.angle_to(launched.global_position.direction_to(station.global_position)))
 check(after_error<before_error,"missile guidance tracks station targets")
 hud.target=enemy
 enemy.global_position+=Vector2(100000,0)
 hud._process(0.1)
 check(hud.target==null,"loss of sensors clears target")
 check(hud.fixed_weapon_lead().is_empty(),"no pip without visible target")
 enemy.global_position=player.global_position+Vector2(400,0)
 enemy.faction_id=&"terran_republic"
 PlayerState.set_reputation(enemy.faction_id,1000)
 hud.select_contact(enemy)
 hud._process(1.1)
 check(hud.missile_lock()==null,"friendly cannot be locked")
 enemy.queue_free()
 await get_tree().process_frame
 hud._process(0.1)
 check(hud.target==null,"destroyed target cleared")
 for view in [Vector2(1280,720),Vector2(1920,1080),Vector2(800,600)]:
  hud.own_card.place_at(view,false)
  hud.target_card.place_at(view,true)
  await get_tree().process_frame
  for card in [hud.own_card,hud.target_card]:
   check(card.position.y>=0 and card.position.y+card.size.y*card.scale.y<=view.y,"panel vertical bounds "+str(view))
   check(card.position.x>=0 and card.position.x+card.size.x*card.scale.x<=view.x,"panel horizontal bounds "+str(view))
 var weapons_ui:Control
 for node in main.find_children("*","",true,false):
  if node.get_script()==preload("res://scripts/WeaponsHUD.gd"):weapons_ui=node
 for i in 20:player.equipped_weapons.append(GameData.weapons[&"laser_autocannon_s3"])
 hud._process(0)
 weapons_ui._process(0)
 for i in 3:await get_tree().process_frame
 weapons_ui._process(0)
 check(weapons_ui.entries.size()==player.equipped_weapons.size(),"large loadout lists every weapon")
 check(weapons_ui.scroll.custom_minimum_size.y<=180,"large loadout height capped")
 check(weapons_ui.position.y>=0,"weapon panel stays on screen")
 var asteroid=SectorManager.current_sector.get_node("Asteroids").get_child(0)
 asteroid.global_position=player.global_position+Vector2(100,0)
 hud.target=asteroid
 hud._process(0)
 check(hud.target==asteroid,"asteroid targeting supports objects without shields")
 print("TARGETING: %d checks, %d failures" % [checks,failures])
 get_tree().quit(failures)

