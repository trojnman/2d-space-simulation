extends Node
var failures := 0
func check(ok: bool, msg: String) -> void:
	if not ok:
		failures += 1
		push_error(msg)
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var station: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		if candidate.station_data.id == &"sol_prime_shipyard": station = candidate
	var inspector = get_tree().get_first_node_in_group("station_inspection")
	inspector.visible = true
	inspector.hovered = station
	var click := InputEventMouseButton.new()
	click.button_index = MOUSE_BUTTON_LEFT
	click.pressed = true
	inspector._unhandled_input(click)
	check(inspector.selected == station, "Click selects station")
	check(inspector.blocks_primary_fire(), "Station inspection blocks shooting")
	for rep in [0.0,1000.0]:
		PlayerState.set_reputation(station.faction_id,rep)
		check(station.can_share_station_info(), "Neutral/friendly access")
		check(inspector.station_text(station).contains("MARKET / INVENTORY"), "Selected station exposes market")
	inspector._displayed = station
	inspector.card.size.x = 490
	for tab in 4:
		inspector._select_tab(tab)
		await get_tree().process_frame
		check(inspector.details.get_parsed_text().length() > 20, "Inspection tab renders content")
	check(inspector.card.size.x <= 510, "Inspection panel respects width")
	PlayerState.set_reputation(station.faction_id,0)
	inspector._select_tab(3)
	check(not inspector._tabs.get_child(2).visible and not inspector._tabs.get_child(3).visible, "Neutral hides production and finance tabs")
	check(not inspector.details.get_parsed_text().contains("Faction funds") and not inspector.details.get_parsed_text().contains("Active jobs"), "Neutral overview hides private fields")
	check(not station.get_public_station_details().contains("PRODUCTION") and not station.get_public_station_details().contains("treasury"), "Neutral public API excludes private information")
	check(FactionManager.get_treasury_history(station.faction_id).is_empty(), "Neutral treasury history denied")
	PlayerState.set_reputation(station.faction_id,-1000)
	inspector._refresh_card()
	check(not inspector._tabs.visible and inspector.details.get_parsed_text().contains("ACCESS RESTRICTED"), "Hostile UI hides tabs and private content")
	check(not station.can_share_station_info(), "Hostile access denied")
	var hidden: String = inspector.station_text(station)
	check(hidden.contains("ACCESS DENIED") and not hidden.contains("MARKET / INVENTORY") and not hidden.contains("treasury"), "Reputation change removes internal details")
	check(not station.get_public_station_details().contains("PRODUCTION"), "Public info method also denies hostile details")
	PlayerState.set_reputation(station.faction_id, 0)
	SensorSystem.fog.update_contact(station.get_instance_id(), {"type": "station", "node": station, "pos": station.global_position, "in_range": true})
	station.global_position = Vector2(50000,50000)
	SensorSystem._do_sweep()
	var map: FreeCameraController = main.get_node("FreeCameraController")
	map._enter_free_cam()
	check(inspector.is_map_open(), "Actual M map recognized")
	check(inspector.station_marker_available(station), "Neutral remote station marker included")
	inspector.selected = station
	inspector._displayed = station
	inspector._select_tab(1)
	check(inspector.details.get_parsed_text().contains("MARKET & STOCK"), "Remote neutral market inspectable")
	PlayerState.set_reputation(station.faction_id,-1000)
	SensorSystem._do_sweep()
	check(inspector.station_marker_available(station), "Previously seen enemy remains marked")
	inspector._refresh_card()
	check(inspector.details.get_parsed_text().contains("ACCESS RESTRICTED"), "Enemy details hidden")
	SensorSystem.fog._last_known.erase(station.get_instance_id())
	check(not inspector.station_marker_available(station), "Unseen enemy remains hidden")
	map._exit_free_cam()
	check(not inspector.station_marker_available(station), "Distant markers hidden in flight")
	print("STATION ACCESS: %d failures" % failures)
	get_tree().quit(1 if failures else 0)
