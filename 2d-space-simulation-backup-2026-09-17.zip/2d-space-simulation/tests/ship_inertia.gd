extends Node
func _ready()->void:
 for i in 3:await get_tree().process_frame
 var previous_max:=0.0
 for prefix in ["","medium_","heavy_"]:
  var fighter=GameData.ships[StringName(prefix+"fighter")]
  var missile=GameData.ships[StringName(prefix+"missile_boat")]
  var miner=GameData.ships[StringName(prefix+"miner")]
  var hauler=GameData.ships[StringName(prefix+"hauler")]
  assert(fighter.inertia_seconds()>previous_max)
  assert(fighter.inertia_seconds()<missile.inertia_seconds())
  assert(missile.inertia_seconds()<miner.inertia_seconds())
  assert(miner.inertia_seconds()<hauler.inertia_seconds())
  previous_max=hauler.inertia_seconds()
  var fast:=100.0
  var slow:=100.0
  for i in 60:fast*=fighter.coast_factor(1.0/60.0)
  for i in 30:slow*=fighter.coast_factor(1.0/30.0)
  assert(absf(fast-slow)<.001)
  assert(hauler.coast_factor(.5)>fighter.coast_factor(.5))
 print("INERTIA: size/role ordering, heavier coasting and frame-rate independence passed")
 get_tree().quit()
