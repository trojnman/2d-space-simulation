extends Node
func _ready()->void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 20:await get_tree().process_frame
 var original=HUDLayout.layouts.duplicate(true)
 HUDLayout.open_editor()
 assert(get_tree().paused)
 var panel=HUDLayout.panels()["Weapons"]
 var click:=InputEventMouseButton.new()
 click.button_index=MOUSE_BUTTON_LEFT
 click.pressed=true
 click.position=panel.get_global_rect().position+Vector2(20,20)
 HUDLayout._edit_input(click)
 assert(HUDLayout.selected=="Weapons")
 var motion:=InputEventMouseMotion.new()
 motion.position=click.position+Vector2(60,-40)
 HUDLayout._edit_input(motion)
 assert(HUDLayout.layouts.has("Weapons"))
 var old_size=panel.get_global_rect().size
 click.position=panel.get_global_rect().position+Vector2(old_size.x-2,old_size.y*.5)
 HUDLayout._edit_input(click)
 motion.position=click.position+Vector2(45,30)
 motion.alt_pressed=true
 HUDLayout._edit_input(motion)
 assert(absf(panel.get_global_rect().size.y-old_size.y)<1)
 assert(panel.get_global_rect().size.x>old_size.x)
 var snapped=HUDLayout.snap_rect(Rect2(Vector2(5,60),Vector2(100,100)),Vector2.ZERO,"Weapons")
 assert(snapped.position.x==0)
 print("HUD LAYOUT: independent width and screen snapping passed")
 for color in HUDLayout.COLORS:
  HUDLayout.color_name=color
  HUDLayout.paint_panel(panel)
  assert(panel.get_meta("hud_palette")==color)
 HUDLayout._action("Cancel")
 assert(HUDLayout.color_name==HUDLayout.previous_color)
 assert(HUDLayout.layouts==original)
 assert(not get_tree().paused)
 print("HUD LAYOUT: open, drag, cancel, pause restoration passed")
 get_tree().quit()
