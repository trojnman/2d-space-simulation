extends Node
func _ready()->void:
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 12:await get_tree().process_frame
 var logic=preload("res://scripts/ShipLogicPanel.gd").new();add_child(logic);logic.popup_centered()
 for i in 12:await get_tree().process_frame
 await RenderingServer.frame_post_draw
 get_viewport().get_texture().get_image().save_png("C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/fleet-logic.png")
 get_tree().quit()
