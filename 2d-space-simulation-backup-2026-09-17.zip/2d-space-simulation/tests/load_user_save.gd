extends Node
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10:await get_tree().process_frame
 var menu=get_tree().get_first_node_in_group("pause_menu")
 menu.open()
 assert(get_tree().paused and menu.visible)
 menu._action("Settings")
 assert(menu.settings.visible)
 menu.toggle.button_pressed=true
 assert(PlayerState.friendly_fire_enabled)
 menu.close()
 assert(not get_tree().paused)
 for attempt in 3:
  if attempt==1:menu.open()
  if attempt==2:get_tree().paused=true
  var event:=InputEventKey.new()
  event.physical_keycode=KEY_F9
  event.pressed=true
  if attempt==1:menu._action("Load")
  else:Input.parse_input_event(event)
  for i in 30:await get_tree().process_frame
  var player:Player=PlayerState.current_ship
  print("USER_LOAD_END ",attempt," loading=",SaveManager.loading," paused=",get_tree().paused," physics=",player.is_physics_processing()," docked=",player._is_docked)
  var before:=player.position
  Input.action_press("thrust")
  for i in 60:await get_tree().physics_frame
  Input.action_release("thrust")
  print("USER_MOVED ",player.position.distance_to(before))
  event.pressed=false
  Input.parse_input_event(event)
 print("USER_LOAD_ADVANCED")
 get_tree().quit()
