extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	if "--read" in OS.get_cmdline_user_args():
		check(await SaveManager.load_game(PATH),"fresh process restores constructed station")
		var total := 0
		for node in get_tree().get_nodes_in_group("stations"):
			if node.constructed:
				total += 1
				check(node.inventory.get_all_items().is_empty(),"fresh process does not seed stock")
		check(total == 1,"fresh process restores one unique station")
		print("CONSTRUCTION_RESTART: %d checks, %d failures" % [checks, failures])
		get_tree().quit(failures)
		return
	var yard: StationInstance
	for s in get_tree().get_nodes_in_group("stations"):
		if s.station_data.id == &"sol_prime_shipyard": yard=s
	var blueprint: StringName = &"sol_prime_manufacturing"
	check(not BUILD.queue(yard,blueprint),"insufficient materials denied")
	yard.requested_station_blueprint = blueprint
	check(yard.get_input_reserve(&"reactor_parts") >= 3000,"construction drives supplies")
	for id in StationData.BUILD_COSTS[&"manufacturing"]: yard.inventory.add_item(id,StationData.BUILD_COSTS[&"manufacturing"][id])
	yard.station_credits = 10000000
	var balance := yard.station_credits
	var workers := FactionManager.civilian_credits
	var material := yard.inventory.get_amount(&"hull_parts")
	var count := SectorManager.get_sector_stations(SectorManager.current_sector).size()
	check(BUILD.queue(yard,blueprint),"funded complete station order")
	check(yard.inventory.get_amount(&"hull_parts")==material-2000,"materials charged once")
	check(yard.station_credits+FactionManager.civilian_credits==balance+workers,"wages conserved")
	check(not BUILD.queue(yard,blueprint),"duplicate queued build refused")
	BUILD.tick(yard,1.0)
	check(SaveManager.save_game(PATH),"save in progress")
	check(await SaveManager.load_game(PATH),"load in progress")
	for s in get_tree().get_nodes_in_group("stations"):
		if s.station_data.id == &"sol_prime_shipyard": yard=s
	check(yard._station_build_queue.size()==1 and is_equal_approx(yard._station_build_queue[0].remaining,2),"progress restored")
	var ui: StationUI = load("res://scenes/StationUI.tscn").instantiate()
	add_child(ui)
	PlayerState.set_reputation(yard.faction_id,1000)
	ui.open(yard,get_tree().get_first_node_in_group("player"))
	check(ui.tab_container.has_node("Expansion"),"construction UI available")
	BUILD.tick(yard,2.1)
	for i in 4: await get_tree().process_frame
	var built: StationInstance
	for s in get_tree().get_nodes_in_group("stations"):
		if s.constructed: built=s
	check(is_instance_valid(built),"completed station exists")
	check(built.inventory.get_all_items().is_empty(),"no free startup inventory")
	check(built.faction_id==yard.faction_id and built.station_data.id!=blueprint,"ownership and unique identity")
	for child in built.get_children():
		if child is StationSpawner:
			child._try_spawn()
			check(child._spawned_ships.is_empty(),"no free starter ships")
	check(SectorManager.get_sector_stations(SectorManager.current_sector).size()==count+1,"one station delivered")
	check(SaveManager.save_game(PATH),"save completed station")
	check(await SaveManager.load_game(PATH),"load constructed blueprint instance")
	var constructed_count := 0
	for s in get_tree().get_nodes_in_group("stations"):
		if s.constructed:
			constructed_count+=1
			check(s.inventory.get_all_items().is_empty(),"reload no replenishment")
	check(constructed_count==1,"no duplicate restored station")
	print("STATION_CONSTRUCTION: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
