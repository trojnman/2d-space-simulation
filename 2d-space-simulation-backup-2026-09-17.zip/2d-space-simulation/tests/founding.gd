extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/construction-save.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("CONSTRUCTION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var ids=GameData.factions.keys()
	PlayerState.set_reputation(ids[0],1000)
	PlayerState.set_reputation(ids[1],-1000)
	PlayerState.set_reputation(ids[2],300)
	var station: StationInstance=get_tree().get_first_node_in_group("stations")
	station.station_data=GameData.stations[&"player_headquarters"].duplicate(true)
	station.faction_id=&"player"
	check(PlayerState.establish_faction(station),"found faction")
	check(PlayerState.get_stance(ids[0])==GlobalEnums.FactionStance.ALLIED,"allied reputation inherited")
	check(PlayerState.get_stance(ids[1])==GlobalEnums.FactionStance.HOSTILE,"hostile reputation inherited")
	check(PlayerState.get_stance(ids[2])==GlobalEnums.FactionStance.FRIENDLY,"friendly reputation inherited")
	PlayerState.friendly_fire_enabled=true
	var bullet=load("res://scenes/Bullet.tscn").instantiate()
	var weapon: WeaponData=GameData.weapons[&"ballistic_autocannon_s1"]
	bullet.launch(Vector2.RIGHT,PlayerState.current_ship,weapon)
	SectorManager.add_sector_entity(bullet)
	station.hull=10000
	bullet._on_body_entered(station)
	check(station.hull==10000-weapon.damage,"ballistic hits damage station")
	var beam=load("res://scenes/LaserBeam.tscn").instantiate()
	var laser: WeaponData=GameData.weapons[&"laser_autocannon_s1"]
	beam.launch(Vector2.RIGHT,PlayerState.current_ship,laser)
	SectorManager.add_sector_entity(beam)
	var before:=station.hull
	beam._on_body_entered(station)
	check(station.hull==before-laser.damage,"laser hits damage station")
	var missile=load("res://scenes/Missile.tscn").instantiate()
	var payload: MissileData=GameData.missiles[&"missile_s1"]
	missile.launch(Vector2.RIGHT,PlayerState.current_ship,payload)
	SectorManager.add_sector_entity(missile)
	before=station.hull
	missile._detonate(station)
	check(station.hull==before-payload.damage,"missile direct hit damages station")
	print("FOUNDING: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
