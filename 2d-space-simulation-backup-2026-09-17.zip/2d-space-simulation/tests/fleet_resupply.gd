extends Node
const Supply=preload("res://scripts/FleetResupply.gd")
const Jobs=preload("res://scripts/FleetJobs.gd")
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:failures+=1;print("RESUPPLY FAIL: ",label)
func _ready()->void:
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 12:await get_tree().process_frame
 get_tree().paused=true
 var supplier=PlayerState.fleet_ships[3]
 var ai=supplier.get_node("AIShipController")
 var first=PlayerState.fleet_ships[0]
 var second=PlayerState.fleet_ships[1]
 first.fleet_name="Test supply";second.fleet_name="Test supply"
 for ship in [supplier,first,second]:ship.inventory.clear();ship.position=Vector2(60000,60000);ship.inventory.capacity=10000
 first.equipped_weapons[0]=GameData.weapons[&"ballistic_autocannon_s1"]
 ai.cancel_all_commands();ai.default_suspended=false
 ai.default_behavior="auto_resupply";ai.resupply_fleet="Test supply";ai.resupply_ammo=4;ai.resupply_volleys=1
 ai.automation_home=SectorManager.current_sector_id;ai.automation_hops=0
 var source:StationInstance
 for station in get_tree().get_nodes_in_group("stations"):
  if station.station_data.station_type==StationData.TYPE_HEADQUARTERS:source=station;break
 source.faction_id=&"terran_republic";PlayerState.set_reputation(source.faction_id,1000)
 source.position=supplier.position
 source.inventory.add_item(&"ballistic_ammo",100,GameData.items)
 source.inventory.add_item(&"missile_s1",100,GameData.items)
 PlayerState.credits=100000
 var requirements=Supply.needs(first,4,1)
 check(requirements.has(&"ballistic_ammo") and requirements.has(&"missile_s1"),"requirements follow equipped guns and racks")
 check(not Supply.needs(second,4,1).has(&"ballistic_ammo"),"laser-only guns need no ballistic ammo")
 check(Supply.supplier_score(100,0,100)<Supply.supplier_score(100,1,100),"nearer supplier wins equal-price choice")
 check(Supply.supplier_score(50,0,100)<Supply.supplier_score(100,0,100),"cheaper supplier wins equal-distance choice")
 var spent:=0
 for i in 12:
  Supply.plan(ai)
  if ai.fleet_job.is_empty():break
  var job=ai.fleet_job
  if job.phase=="collect":
   var seller=job.source
   supplier.position=seller.position
   var money=PlayerState.credits
   Jobs.tick(ai,.3)
   spent+=money-PlayerState.credits
  if not ai.fleet_job.is_empty():
   supplier.position=ai.fleet_job.destination.position
   Jobs.tick(ai,.3)
 for ship in [first,second]:
  var needed=Supply.needs(ship,4,1)
  for id in needed:check(ship.inventory.get_amount(id)==needed[id],ship.ship_data.display_name+" filled exactly: "+str(id))
 check(spent>0,"fleet supplies paid from player funds")
 Supply.plan(ai)
 check(ai.fleet_job.is_empty() and ai.job_status=="Fleet fully supplied","stocked fleet stays on standby")
 first.inventory.remove_item(&"ballistic_ammo",2)
 supplier.inventory.add_item(&"ballistic_ammo",2,GameData.items)
 var money=PlayerState.credits
 Supply.plan(ai)
 check(ai.fleet_job.get("phase")=="deliver","use carried cargo before buying")
 supplier.position=first.position
 Jobs.tick(ai,.3)
 check(first.inventory.get_amount(&"ballistic_ammo")==4 and PlayerState.credits==money,"replenishment reuses cargo without spending")
 first.inventory.remove_item(&"ballistic_ammo",1)
 Supply.plan(ai)
 first.fleet_name="Different fleet"
 Jobs.tick(ai,.3)
 check(ai.default_suspended and not ai.alert_message.is_empty(),"recipient leaving fleet alerts and holds")
 var editor=preload("res://scripts/ShipLogicPanel.gd").new();add_child(editor)
 check(editor.behavior.item_count==8 and editor.fleet.item_count>0,"fleet resupply configurable in ship logic")
 print("FLEET_RESUPPLY: ",checks," checks, ",failures," failures")
 get_tree().quit(failures)
