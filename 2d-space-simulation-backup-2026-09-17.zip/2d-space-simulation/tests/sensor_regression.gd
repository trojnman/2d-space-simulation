extends Node
var failures: int = 0
var checks: int = 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error("FAIL: " + message)
	else: print("PASS: " + message)
func _ready() -> void: call_deferred("run")
func run() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	FactionManager.set_process(false)
	var player: Player = get_tree().get_first_node_in_group("player")
	player.global_position = Vector2.ZERO
	var stations: Array = get_tree().get_nodes_in_group("stations")
	var station: StationInstance = stations[0]
	station.global_position = Vector2(4000,0)
	SensorSystem.register_observer(station, 30000)
	var ship := ShipInstance.new()
	ship.ship_data = GameData.ships[&"fighter"]
	SectorManager.current_sector.add_child(ship)
	ship.global_position = Vector2(4000,0)
	SensorSystem.register_observer(ship, 30000)
	SensorSystem._do_sweep()
	check(not SensorSystem.has_local_contact(station.global_position), "NPC stations and ships do not grant player vision")
	check(not station.visible and not ship.visible, "World ships and station hulls hidden outside local scan")
	var contacts: Array[Dictionary] = SensorSystem.fog.get_all_contacts_for_map()
	check(contacts.any(func(c): return c.get("node") == station and c.get("long_range", false)), "Long-range station reported as map marker")
	check(not contacts.any(func(c): return c.get("node") == ship), "Long-range scan reveals no ship contact")
	var identification: Node
	for child in get_tree().get_first_node_in_group("hud").get_children():
		if child.get_script() and child.get_script().resource_path == "res://scripts/StationIdentification.gd": identification = child
	check(identification.station_text(station).contains("LONG-RANGE") and not identification.station_text(station).contains(station.station_data.description), "Distant hover card withholds detailed description")
	identification._process(0)
	check(not identification.contacts.any(func(c): return c["station"] == station), "Distant station marker is map-only, absent from flight view")
	player.global_position = Vector2(3500,0)
	SensorSystem._do_sweep()
	check(station.visible and ship.visible, "Approaching reveals station hull and nearby ships")
	check(not identification.station_text(station).contains("LONG-RANGE"), "Close scan restores detailed station identification")
	player.global_position = Vector2.ZERO
	SensorSystem._do_sweep()
	check(not ship.visible and not SensorSystem.fog.get_all_contacts_for_map().any(func(c): return c.get("node") == ship), "Departing removes live ship location from world and map")
	station.global_position = Vector2(15000,0)
	SensorSystem._do_sweep()
	check(not SensorSystem.has_long_range_contact(station.global_position) and not SensorSystem.fog.get_all_contacts_for_map().any(func(c): return c.get("node") == station), "Station beyond long-range scan has no live marker")
	var asteroid: Node2D = get_tree().get_first_node_in_group("asteroids")
	asteroid.global_position = Vector2(9000,0)
	SensorSystem._do_sweep()
	check(not asteroid.visible, "Asteroid hidden outside local scan")
	var satellite: Node2D = load("res://scenes/Satellite.tscn").instantiate()
	satellite.position = Vector2(9000,0)
	SectorManager.add_sector_entity(satellite)
	SensorSystem._do_sweep()
	check(asteroid.visible, "Owned deployed satellite extends local coverage")
	satellite.queue_free()
	await get_tree().process_frame
	SensorSystem._do_sweep()
	check(not asteroid.visible, "Removing satellite removes its vision")
	print("SENSOR REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
