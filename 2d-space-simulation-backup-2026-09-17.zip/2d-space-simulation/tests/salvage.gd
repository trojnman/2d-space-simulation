extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("BOARDING FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player = get_tree().get_first_node_in_group("player")
	var station: StationInstance = get_tree().get_first_node_in_group("stations")
	var id := station.station_data.id
	station.inventory.clear()
	station.inventory.add_item(&"ballistic_ammo",100)
	PlayerState.hangar_add_ship(id,&"fighter")
	PlayerState.station_storage_add(id,&"ballistic_ammo",20)
	station._destroy()
	for i in 3: await get_tree().process_frame
	check(not PlayerState.station_hangar.has(id), "hangared ships destroyed")
	check(not PlayerState.station_storage.has(id), "stored goods removed")
	var debris = get_tree().get_first_node_in_group("cargo_salvage")
	check(debris != null and debris.cargo.get(&"ballistic_ammo") == 30, "quarter stock and storage becomes salvage")
	var path := "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/salvage-save.dat"
	check(SaveManager.save_game(path), "save debris")
	check(await SaveManager.load_game(path), "load debris")
	debris = get_tree().get_first_node_in_group("cargo_salvage")
	check(debris != null and debris.cargo.get(&"ballistic_ammo") == 30, "salvage persists")
	player.inventory.clear()
	player.global_position = debris.global_position + Vector2(200,0)
	check(debris.collect(player)==0, "requires proximity")
	player.global_position = debris.global_position
	player.inventory.capacity = 0.1
	check(debris.collect(player)==10 and debris.cargo.get(&"ballistic_ammo")==20, "partial pickup preserves excess")
	player.inventory.capacity = player.ship_data.cargo_capacity
	check(debris.collect(player)==20, "collect remaining salvage")
	check(player.inventory.get_amount(&"ballistic_ammo")==30, "cargo recovered exactly once")
	check(debris.collect(player)==0, "no duplicate pickup")
	var doomed: StationInstance = get_tree().get_first_node_in_group("stations")
	var dock = get_tree().get_first_node_in_group("docking_manager")
	dock.current_station = doomed
	player.dock()
	doomed._destroy()
	for i in 3: await get_tree().process_frame
	check(dock.current_station == null and not player._is_docked, "destroyed dock releases player")
	check(player.ship_data.id == &"escape_pod", "docked ship destruction ejects player")
	print("SALVAGE: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
