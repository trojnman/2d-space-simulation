extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("DOCK RANGE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var station: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		if candidate.station_data.id == &"sol_prime_manufacturing": station = candidate
	var ship: ShipInstance = load("res://scenes/Miner.tscn").instantiate()
	ship.faction_id = station.faction_id
	SectorManager.add_sector_entity(ship)
	ship.initialize(GameData.ships[&"miner"])
	var ai := AIShipController.new()
	ship.add_child(ai)
	for i in 2: await get_tree().process_frame
	ai._home_station = station
	ai._state = AIShipController.State.RETURN
	ship.inventory.add_item(&"iron", 5)
	ship.inventory.add_item(&"ballistic_ammo", 4)
	var before := station.inventory.get_amount(&"iron")
	ship.global_position = station.global_position + Vector2(station.get_docking_range()+1, 0)
	ai._think_return()
	check(ship.inventory.get_amount(&"iron") == 5, "no unloading outside docking range")
	ship.global_position = station.global_position + Vector2(station.get_docking_range()-1,0)
	ship.velocity = Vector2(-100,0)
	ai._execute_state(0.1)
	check(ship.velocity == Vector2.ZERO, "hold inside docking range")
	ai._think_return()
	check(ship.inventory.get_amount(&"iron") == 0, "unload without reaching center")
	check(station.inventory.get_amount(&"iron") == before+5, "conserve delivered cargo")
	check(ai._state == AIShipController.State.MINE, "resume mining")
	check(ship.inventory.get_amount(&"ballistic_ammo") == 4, "miner retains ammunition")
	ai._think_return()
	check(station.inventory.get_amount(&"iron") == before+5, "no duplicate delivery")
	station._is_destroyed = true
	check(not ai._in_service_range(station), "destroyed station unavailable")
	station._is_destroyed = false
	var yard: StationInstance
	for candidate in get_tree().get_nodes_in_group("stations"):
		if candidate.station_data.id == &"sol_prime_shipyard": yard = candidate
	for candidate in get_tree().get_nodes_in_group("stations"):
		if candidate != station: candidate.inventory.add_item(&"iron", 100000)
	station.inventory.clear()
	ship.inventory.remove_item(&"ballistic_ammo", 4)
	ship.inventory.add_item(&"iron", 5)
	ai._haul_loaded = true
	ai._haul_item = &"iron"
	ai._haul_source = station
	ai._haul_destination = yard
	yard._is_destroyed = true
	ai._think_haul()
	check(ai._haul_destination == station and ai._haul_loaded, "redirect loaded cargo from destroyed destination")
	check(ship.inventory.get_amount(&"iron") == 5, "reroute retains cargo")
	ship.global_position = station.global_position + Vector2(station.get_docking_range()-1,0)
	ai._think_haul()
	check(station.inventory.get_amount(&"iron") == 5 and ship.inventory.get_amount(&"iron") == 0, "rerouted delivery conserves goods")
	yard._is_destroyed = false
	ship.inventory.add_item(&"iron", 2)
	station.inventory.capacity = 0.001
	ai._home_station = station
	ai._deposit_cargo_to_station()
	check(ship.inventory.get_amount(&"iron") == 2, "rejected warehouse delivery retains cargo")
	station.inventory.capacity = 0
	ship.equip_weapon(GameData.weapons[&"ballistic_autocannon_s1"], 0)
	ship.inventory.clear()
	ship.inventory.add_item(&"ballistic_ammo", 120)
	ai._haul_loaded = false
	check(ai._deliverable_cargo(&"ballistic_ammo") == 20, "reserve ammunition for mounted gun")
	ai._haul_loaded = true
	ai._haul_item = &"ballistic_ammo"
	ai._haul_manifest_amount = 15
	check(ai._deliverable_cargo(&"ballistic_ammo") == 15, "delivery limited to manifest")
	ai._haul_destination = station
	ai._haul_source = station
	var ammo_before := station.inventory.get_amount(&"ballistic_ammo")
	ai._think_haul()
	check(ship.inventory.get_amount(&"ballistic_ammo") == 105, "delivery retains ship ammunition")
	check(station.inventory.get_amount(&"ballistic_ammo") == ammo_before+15, "manifest delivered exactly once")
	print("DOCK_RANGE: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
