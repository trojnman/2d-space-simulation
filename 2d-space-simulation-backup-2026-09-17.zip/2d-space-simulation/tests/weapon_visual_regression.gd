extends Node
var checks := 0
var failures := 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error(message)
func _ready() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	var player: Player = main.get_node("Player")
	for id in StationSpawner.SHIP_SCENES:
		player.initialize(GameData.ships[id])
		for weapon in GameData.weapons.values():
			if not weapon.can_equip_on(player.ship_data.ship_class): continue
			player.equipped_weapons = [weapon]
			player._refresh_visuals()
			var vc: ShipVisualController
			for child in player.get_children():
				if child is ShipVisualController: vc = child
			var barrel: Polygon2D = vc.weapon_visuals[0]
			var min_x := INF
			var max_x := -INF
			for point in barrel.polygon:
				min_x = minf(min_x, point.x)
				max_x = maxf(max_x, point.x)
			var tip := barrel.to_global(Vector2(max_x, (barrel.polygon[3].y+barrel.polygon[4].y)*.5))
			check(tip.distance_to(player._get_muzzle_position(0)) < .01, "Barrel/muzzle alignment " + str(id) + str(weapon.id))
			check(max_x-min_x <= vc.get_meta("hull_half_size").x*.4, "Compact barrel " + str(id))
	for data in GameData.weapons.values():
		var color: Color = preload("res://scripts/WeaponPalette.gd").shot_color(data)
		if data.weapon_type == GlobalEnums.WeaponType.ENERGY:
			check(color.r > color.g * 2 and color.r > color.b * 2, "Red laser " + str(data.id))
		elif data.weapon_type == GlobalEnums.WeaponType.MINING:
			check(color.g > color.r and color.g > color.b, "Green mining beam " + str(data.id))
		else:
			check(color == Color("687782"), "Gunmetal ballistic " + str(data.id))
	var weapon: WeaponData = GameData.weapons[&"laser_autocannon_s1"]
	for scene in ["LaserBeam", "Bullet"]:
		var shot: Node2D = load("res://scenes/%s.tscn" % scene).instantiate()
		shot.launch(Vector2(1000,0),player,weapon)
		main.add_child(shot)
		check(shot._art.core.points[1] == Vector2.ZERO, "No tail behind muzzle at spawn " + scene)
		shot._physics_process(.001)
		check(absf(shot._art.core.points[1].x) <= 1.01, "Tail limited to traveled distance " + scene)
		check(shot._art.core.width < 1.0, "Thin S1 projectile " + scene)
		shot.free()
	var missile: Missile = load("res://scenes/Missile.tscn").instantiate()
	missile.launch(Vector2.ZERO,player,GameData.missiles[&"missile_s1"])
	main.add_child(missile)
	check(missile._exhaust != null and missile.z_index > 0, "Missile exhaust and drawing layer")
	missile.free()
	var wheel := InputEventMouseButton.new()
	wheel.button_index = MOUSE_BUTTON_WHEEL_UP
	wheel.pressed = true
	for i in 100: player.camera._unhandled_input(wheel)
	check(is_equal_approx(player.camera._target_zoom.x,3.0), "Zoom caps at 3x")
	print("WEAPON VISUAL REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
