extends Node
var checks: int = 0
var failures: int = 0
func check(ok: bool, label: String) -> void:
 checks += 1
 if not ok:
  failures += 1
  print("HARDPOINT FAIL: ", label)
func _ready() -> void:
 var main = load("res://scenes/Main.tscn").instantiate()
 main.process_mode = Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 12: await get_tree().process_frame
 get_tree().paused = true
 for id in StationSpawner.SHIP_SCENES:
  if not GameData.ships.has(id): continue
  var data: ShipData = GameData.ships[id]
  var ship: ShipInstance = load(StationSpawner.SHIP_SCENES[id]).instantiate()
  SectorManager.current_sector.add_child(ship)
  ship.initialize(data)
  for slot in data.weapon_slots:
   var wid = ("mining_laser_s" if data.mount_kind(slot) == "Mining" else "laser_autocannon_s") + str(data.mount_size(slot))
   check(ship.equip_weapon(GameData.weapons[StringName(wid)], slot), str(id)+" accepts "+wid)
   var wrong = "laser_autocannon_s" + str(1 if data.mount_size(slot) != 1 else 2)
   check(not ship.equip_weapon(GameData.weapons[StringName(wrong)], slot), "reject wrong size")
  for slot in data.missile_slots:
   check(ship.equip_missile(GameData.missiles[&"missile_s1"],slot), "rack accepts smaller missile")
   check(ship.rack_capacity(slot) == int(pow(2,data.rack_sizes[slot]-1)), "rack scaling")
  check(ship.muzzle_points.size() == data.weapon_slots, str(id)+" muzzle count")
  ship.queue_free()
 var ship: ShipInstance = ShipInstance.new()
 add_child(ship)
 ship.initialize(GameData.ships[&"heavy_fighter"])
 ship.equip_weapon(GameData.weapons[&"laser_autocannon_s2"],4)
 ship.energy = 100000
 ship.turret_angles[4] = ship.ship_data.mount_arc_center(4)
 check(not ship.fire_weapon(4,Vector2.RIGHT,false), "side turret cannot fire forward")
 check(ship.fire_weapon(4,Vector2.from_angle(ship.ship_data.mount_arc_center(4)),false), "side turret can fire on aligned target")
 var player: Player = PlayerState.current_ship
 player.initialize(GameData.ships[&"heavy_missile_boat"])
 for i in 5: player.equip_missile(GameData.missiles[&"missile_s1"],i)
 player.inventory.add_item(&"missile_s1",100)
 var ms = player.get_node("MissileSystem")
 check(ms._get_max_missiles()==20,"five S3 racks arm twenty S1")
 # Each rack contributes only its own fitted ammunition type.
 player.equip_missile(GameData.missiles[&"missile_s3"],0)
 player.inventory.add_item(&"missile_s3",10)
 check(ms._get_max_missiles()==17,"mixed racks sum their own capacities")
 var old_entry = {"equipped_weapons":[&"mining_laser_s3",&"laser_autocannon_s3"],"equipped_missiles":[&"missile_s2"],"inventory":{}}
 ship.initialize(GameData.ships[&"heavy_miner"])
 PlayerState.restore_ship_entry(ship,old_entry)
 check(ship.equipped_weapons[4] == GameData.weapons[&"mining_laser_s3"],"old mining tool migrates to dedicated mount")
 check(ship.inventory.get_amount(&"laser_autocannon_s3")==1,"incompatible old gun preserved in cargo")
 check(ship.inventory.get_amount(&"missile_s2")==1,"removed old rack contents preserved")
 ship.initialize(GameData.ships[&"large_logistics"])
 ship.turret_angles.fill(PI)
 ship._update_mount_aim(0.1)
 var large_motion: float = absf(angle_difference(PI,ship.turret_angles[2]))
 var small_motion: float = absf(angle_difference(PI,ship.turret_angles[6]))
 check(small_motion > large_motion,"small turrets traverse faster")
 check(GameData.missiles[&"missile_s1"].turn_rate > GameData.missiles[&"missile_s2"].turn_rate and GameData.missiles[&"missile_s2"].turn_rate > GameData.missiles[&"missile_s3"].turn_rate,"missile agility follows size")
 var path = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/hardpoint-save.dat"
 check(SaveManager.save_game(path),"save mixed rack loadout")
 check(await SaveManager.load_game(path),"reload mixed rack loadout")
 get_tree().paused = true
 player = PlayerState.current_ship
 check(player.ship_data.id == &"heavy_missile_boat","ship class preserved")
 check(player.equipped_missiles.size()==5 and player.rack_capacity(0)==1 and player.rack_capacity(1)==4,"mixed racks preserved")
 check(player.get_node("MissileSystem")._get_max_missiles()==17,"mixed arming capacity preserved")
 print("HARDPOINTS: ",checks," checks, ",failures," failures")
 get_tree().quit(1 if failures else 0)
