extends Node
func _ready()->void:
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 45:await get_tree().process_frame
 get_tree().paused=true
 for data in GameData.ships.values():
  assert(data.manufacture_time==[60,120,300][int(data.ship_class)])
  assert(FactionManager.ship_supply_cost(data)==[2,5,10][int(data.ship_class)])
 var fid:StringName=&"supply_test"
 FactionManager._faction_state[fid]={"owned_ships":[],"owned_stations":[]}
 var fixtures:Array=[]
 for i in 99:
  var ship=ShipInstance.new()
  ship.ship_data=GameData.ships[&"fighter"]
  ship.faction_id=fid
  fixtures.append(ship)
  FactionManager.register_ship(ship)
 assert(FactionManager.get_ship_supply(fid)==198)
 assert(FactionManager.can_add_npc_ship(fid,GameData.ships[&"fighter"]))
 assert(not FactionManager.can_add_npc_ship(fid,GameData.ships[&"medium_fighter"]))
 var yard:StationInstance
 for station in FactionManager.get_faction_stations(&"terran_republic"):
  assert(station.inventory._items.is_empty())
  if station.station_data.id==&"sol_prime_shipyard":yard=station
 assert(yard!=null)
 var recipe:Dictionary
 for r in yard.station_data.get_recipes():
  if r.output_id==&"fighter":recipe=r
 for id in recipe.inputs:yard.inventory.add_item(id,int(recipe.inputs[id]))
 yard.station_credits=1000000
 assert(yard.queue_manufacture(recipe,true))
 assert(yard.get_manufacture_queue()[0].time_total==60.0)
 var before:int=FactionManager.get_ship_supply(&"player")
 assert(before==8)
 yard._manufacture_queue.clear()
 assert(FactionManager.get_ship_supply(&"player")==6)
 for ship in fixtures:ship.free()
 FactionManager._faction_state.erase(fid)
 print("SUPPLY PASS: all hull timings/costs, boundary cap, empty station stocks, player queue reservation")
 get_tree().quit()

