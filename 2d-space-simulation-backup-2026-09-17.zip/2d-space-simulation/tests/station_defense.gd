extends Node
var checks:=0
var failures:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:
  failures+=1
  print("FAIL: ",label)
func _ready()->void:
 var main=load("res://scenes/Main.tscn").instantiate()
 main.process_mode=Node.PROCESS_MODE_PAUSABLE
 add_child(main)
 for i in 10:await get_tree().process_frame
 get_tree().paused=true
 var remote:SectorInstance=SectorManager.current_sector
 var original:=SectorManager.current_sector_id
 SectorManager.load_sector(&"frontier_reach")
 for i in 4:await get_tree().process_frame
 var station:StationInstance
 for candidate in SectorManager.get_sector_stations(remote):
  if candidate.station_data.station_type==&"military":station=candidate
 var target:ShipInstance=load("res://scenes/Fighter.tscn").instantiate()
 remote.add_child(target)
 target.initialize(GameData.ships[&"fighter"])
 target.faction_id=&"player"
 target.add_to_group("player_fleet")
 target.position=station.position+Vector2(300,0)
 PlayerState.joined_faction=&""
 PlayerState.founded_faction=false
 PlayerState.set_reputation(station.faction_id,0)
 var before:=target.hull
 station._defense_tick(1)
 check(target.hull==before,"neutral not attacked")
 PlayerState.set_reputation(station.faction_id,-1000)
 station._defense_tick(1)
 check(target.hull<before,"hostile receives remote damage")
 before=target.hull
 station._defense_tick(0)
 check(target.hull==before,"cooldown enforced")
 station._rogue_fire_timer=0
 station.defense_energy=0
 station._defense_tick(0)
 check(target.hull==before,"empty capacitor prevents fire")
 station.defense_energy=100
 target.position=station.position+Vector2(100000,0)
 station._defense_tick(1)
 check(target.hull==before,"range enforced")
 target.position=station.position+Vector2(300,0)
 target.ship_data=target.ship_data.duplicate()
 target.ship_data.id=&"escape_pod"
 station._defense_tick(1)
 check(target.hull==before,"escape pod excluded")
 target.ship_data=GameData.ships[&"fighter"]
 station.faction_id=&"rogue"
 station._defense_tick(1)
 check(target.hull<before,"rogue defense still fires")
 station.defense_energy=37
 station._rogue_fire_timer=0.7
 var path="C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/defense-save.dat"
 check(SaveManager.save_game(path),"save defense state")
 check(await SaveManager.load_game(path),"load defense state")
 remote=SectorManager._visited_sectors[original]
 for candidate in SectorManager.get_sector_stations(remote):
  if candidate.station_data.station_type==&"military":station=candidate
 check(is_equal_approx(station.defense_energy,37),"capacitor restored")
 check(is_equal_approx(station._rogue_fire_timer,0.7),"cooldown restored")
 var dummy:=ShipInstance.new()
 dummy.hull=100
 dummy.shield=20
 dummy.take_damage(10,0)
 check(dummy.hull==100 and dummy.shield==10,"intact shield absorbs damage")
 dummy.take_damage(15,0)
 check(dummy.hull==95 and dummy.shield==0,"excess shield damage spills to hull")
 dummy.take_damage(10,0)
 check(dummy.hull==85,"unshielded hull receives energy damage")
 dummy.free()
 var platform:StationInstance=load("res://scenes/Station.tscn").instantiate()
 platform.station_data=GameData.stations[&"defense_platform"]
 platform.constructed=true
 platform.faction_id=&"terran_republic"
 SectorManager.current_sector.get_node("Stations").add_child(platform)
 check(platform.get_supply_target(&"missile_s3")==60,"platform missile stock target")
 check(platform._station_buys_item(&"missile_s1"),"platform accepts missile trade")
 check(platform.get_faction_supply_request().get(&"missile_s3",0)>=60,"empty platform requests production")
 platform.inventory.add_item(&"missile_s3",60)
 check(not platform.get_faction_supply_request().has(&"missile_s3"),"stocked platform clears demand")
 platform.inventory.remove_item(&"missile_s3",6)
 check(platform.get_faction_supply_request().get(&"missile_s3",0)==6,"firing renews shortage")
 print("STATION_DEFENSE: %d checks, %d failures" % [checks,failures])
 get_tree().quit(failures)
