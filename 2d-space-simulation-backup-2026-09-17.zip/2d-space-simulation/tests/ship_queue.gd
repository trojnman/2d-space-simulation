extends Node
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("QUEUE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player = get_tree().get_first_node_in_group("player")
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.station_type != StationData.TYPE_SHIPYARD: continue
		var id: StringName = &"heavy_fighter" if station.station_data.capital_yard else &"fighter"
		PlayerState.credits = 1000000
		PlayerState.set_reputation(station.faction_id, 0)
		check(station.order_player_ship(id), "order " + str(id))
		check(station.get_visible_ship_orders().size() == 1, "neutral personal visibility")
		var ui: StationUI = load("res://scenes/StationUI.tscn").instantiate()
		add_child(ui)
		ui.open(station, player)
		for i in 2: await get_tree().process_frame
		var panels: Array = []
		for panel in ui.find_children("*", "PanelContainer", true, false):
			if panel.get_script() == load("res://scripts/ShipProductionQueue.gd"): panels.append(panel)
		check(panels.size() == 2, "queue in Shipyard and Manufacture tabs")
		station._process_manufacturing(1.5)
		for panel in panels:
			panel.refresh()
			check(panel._labels.size() == 1 and panel._labels[0].text.contains(GameData.ships[id].display_name), "named active order")
			check(is_equal_approx(panel._bars[0].value, 50.0), "50 percent live progress")
		station._process_manufacturing(2.0)
		for panel in panels:
			panel.refresh()
			check(panel._labels.is_empty(), "completion removes active row")
		check(PlayerState.get_station_hangar(station.station_data.id).size() == 1, "completed ship in hangar")
		check(station.queue_manufacture(station.get_ship_recipe(id)), "faction order")
		check(station.get_visible_ship_orders().is_empty(), "neutral faction privacy")
		PlayerState.set_reputation(station.faction_id, 1000)
		check(station.get_visible_ship_orders().size() == 1, "friendly faction queue")
		PlayerState.set_reputation(station.faction_id, -1000)
		check(station.get_visible_ship_orders().is_empty(), "hostile denied")
		PlayerState.set_reputation(station.faction_id, 0)
		ui.queue_free()
		await get_tree().process_frame
	print("SHIP_QUEUE: %d checks, %d failures" % [checks, failures])
	get_tree().quit(failures)
