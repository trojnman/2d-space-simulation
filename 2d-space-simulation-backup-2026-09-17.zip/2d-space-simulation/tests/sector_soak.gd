extends Node
var elapsed: float = 0.0
var baseline_money: int = 0
var initialized: bool = false
func _ready() -> void:
	seed(1729)
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	baseline_money = total_money()
	Engine.time_scale = 20.0
	initialized = true
func total_money() -> int:
	var total: int = PlayerState.credits + FactionManager.civilian_credits
	for id in GameData.factions: total += FactionManager.get_faction_credits(id)
	return total
func _physics_process(delta: float) -> void:
	if not initialized: return
	elapsed += delta
	if elapsed < 1200: return
	set_physics_process(false)
	var failures: int = 0
	if total_money() != baseline_money:
		push_error("SOAK: Money conservation failed")
		failures += 1
	for station in get_tree().get_nodes_in_group("stations"):
		print("SOAK STATION ", station.station_data.id, " stock=", station.inventory.get_all_items(), " jobs=", station.get_manufacture_queue().size())
		if station.station_credits < 0: failures += 1
		for amount in station.inventory.get_all_items().values():
			if amount < 0: failures += 1
	for ship in get_tree().get_nodes_in_group("ships"):
		if ship.inventory.get_used_capacity(GameData.items) > ship.inventory.capacity + 0.001:
			push_error("SOAK: Cargo over capacity " + str(ship.ship_data.id))
			failures += 1
	print("SOAK: 1200 simulated seconds at 20x; money conserved=", total_money() == baseline_money, "; ships=", get_tree().get_nodes_in_group("ships").size(), "; failures=", failures)
	get_tree().quit(1 if failures else 0)
