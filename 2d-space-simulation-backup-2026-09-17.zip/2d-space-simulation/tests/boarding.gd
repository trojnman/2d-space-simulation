extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("BOARDING FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player = get_tree().get_first_node_in_group("player")
	var old_id = player.ship_data.id
	player.hull = 23
	player.inventory.clear()
	player.inventory.add_item(&"ballistic_ammo", 17)
	var target: ShipInstance = load(StationSpawner.SHIP_SCENES[&"hauler"]).instantiate()
	SectorManager.add_sector_entity(target)
	target.initialize(GameData.ships[&"hauler"])
	target.global_position = player.global_position + Vector2(200,0)
	check(not PlayerState.board_ship(target), "reject unowned ship")
	target.add_to_group("player_fleet")
	target.global_position += Vector2(1000,0)
	check(not PlayerState.board_ship(target), "reject distant ship")
	target.global_position = player.global_position + Vector2(200,0)
	target.hull = 31
	target.inventory.clear()
	target.inventory.add_item(&"ballistic_ammo", 43)
	var money = PlayerState.credits
	check(PlayerState.board_ship(target), "board nearby owned ship")
	check(player.ship_data.id == &"hauler" and player.hull == 31, "incoming hull and damage preserved")
	check(player.inventory.get_amount(&"ballistic_ammo") == 43, "incoming cargo preserved")
	check(PlayerState.credits == money, "money preserved")
	var outgoing: ShipInstance
	for ship in get_tree().get_nodes_in_group("player_fleet"):
		if ship.ship_data.id == old_id and ship.hull == 23: outgoing = ship
	check(is_instance_valid(outgoing), "outgoing ship survives")
	if outgoing:
		for i in 2: await get_tree().process_frame
		var ai := outgoing.get_node_or_null("AIShipController") as AIShipController
		check(ai != null and ai._is_fleet_ship, "pilot takes over outgoing ship")
		if ai:
			ai.queue_command({"type": GlobalEnums.FleetCommand.FOLLOW_SHIP, "target": player})
			check(ai._state == AIShipController.State.FOLLOW, "transferred pilot accepts orders")
		check(outgoing.inventory.get_amount(&"ballistic_ammo") == 17, "outgoing cargo preserved")
		check(PlayerState.board_ship(outgoing), "board back")
		check(player.hull == 23 and player.ship_data.id == old_id, "roundtrip damage preserved")
	PlayerState.hangar_add_ship(&"boarding_test", &"hauler")
	PlayerState.station_hangar[&"boarding_test"][0]["has_pilot"] = true
	check(PlayerState.hangar_swap_to_ship(&"boarding_test", 0, player), "hangar swap")
	check(PlayerState.station_hangar[&"boarding_test"][0]["has_pilot"], "hangar pilot transfers to outgoing hull")
	var cash = PlayerState.credits
	var hangar_before = PlayerState.station_hangar.duplicate(true)
	player.take_damage(100000,100000)
	for i in 2: await get_tree().process_frame
	check(player.ship_data.id == &"escape_pod" and not player._is_destroyed, "destruction ejects pod")
	check(player.inventory.get_all_items().is_empty() and player.equipped_weapons.is_empty(), "destroyed equipment and cargo lost")
	check(PlayerState.credits == cash and PlayerState.station_hangar == hangar_before, "other assets retained")
	var path = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/pod-save.dat"
	check(SaveManager.save_game(path), "save pod")
	check(await SaveManager.load_game(path), "load pod")
	check(player.ship_data.id == &"escape_pod", "pod restored")
	var rescue: ShipInstance
	for ship in get_tree().get_nodes_in_group("player_fleet"): rescue = ship
	if rescue:
		rescue.global_position = player.global_position + Vector2(200,0)
		var count = get_tree().get_nodes_in_group("player_fleet").size()
		var ai := rescue.get_node_or_null("AIShipController") as AIShipController
		check(not ai._is_enemy(player), "pod excluded from enemy targeting")
		ai._target = player
		ai._state = AIShipController.State.ATTACK
		ai._physics_process(0.01)
		check(ai._target != player, "existing attack releases pod")
		check(PlayerState.board_ship(rescue), "board from pod")
		check(get_tree().get_nodes_in_group("player_fleet").size() == count-1, "no abandoned pod or free ship")
	print("BOARDING: %d checks, %d failures" % [checks, failures])
	get_tree().quit(failures)
