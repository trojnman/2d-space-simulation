extends Node
const PATH := "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/regression-save.dat"
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("SAVE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player = get_tree().get_first_node_in_group("player")
	var yard: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_shipyard": yard = station
	var spawner: StationSpawner
	for child in yard.get_children():
		if child is StationSpawner: spawner = child
	spawner._try_spawn()
	spawner._try_spawn()
	for i in 3: await get_tree().process_frame
	var ship: ShipInstance = spawner._spawned_ships[0]
	ship.inventory.add_item(&"iron", 7)
	var job_ai=ship.get_node("AIShipController")
	job_ai.resupply_fleet="Escort fleet"
	job_ai.resupply_ammo=150
	job_ai.resupply_volleys=4
	job_ai.automation_home=&"sol_prime"
	job_ai.automation_hops=2
	job_ai.no_go_sectors=[&"test_exclusion"]
	job_ai.alert_message="Test warning"
	job_ai.default_behavior="job"
	job_ai.default_job={"kind":"trade","source":yard,"destination":yard,"item":&"iron","amount":10,"repeat":true,"phase":"collect"}
	ship.hull = 42
	var ship_position := ship.position
	player.hull = 51
	player.inventory.add_item(&"iron", 3)
	PlayerState.credits = 654321
	yard.order_player_ship(&"fighter")
	var expected_credits := PlayerState.credits
	var expected_funds := FactionManager.get_faction_credits(yard.faction_id)
	var expected_stock := yard.inventory.serialize()
	var expected_queue := yard._manufacture_queue.size()
	var expected_asteroids := SectorManager.current_sector.get_node("Asteroids").get_child_count()
	var asteroid: AsteroidInstance = SectorManager.current_sector.get_node("Asteroids").get_child(0)
	asteroid.hull = 4
	asteroid._remaining_yield = 2
	var asteroid_pos := asteroid.position
	var docking = get_tree().get_first_node_in_group("docking_manager")
	yard._player_in_range = true
	docking._dock(yard)
	yard.shield = 123.0
	yard._shield_delay_timer = 7.0
	var expected_ship_count := get_tree().get_nodes_in_group("ships").size()
	check(SaveManager.save_game(PATH), "write file: " + SaveManager.last_error)
	PlayerState.credits = 1
	yard.inventory.clear()
	ship.queue_free()
	await get_tree().process_frame
	check(await SaveManager.load_game(PATH), "read file: " + SaveManager.last_error)
	check(PlayerState.credits == expected_credits, "player credits")
	check(player.hull == 51, "player damage")
	check(player.inventory.get_amount(&"iron") == 3, "player cargo")
	yard = docking.current_station
	check(is_instance_valid(yard) and player._is_docked, "dock restored")
	check(is_equal_approx(yard.shield,123.0), "station shield restored")
	check(yard._shield_delay_timer>6.0, "station shield recharge delay restored")
	check(FactionManager.get_faction_credits(yard.faction_id) == expected_funds, "faction funds")
	check(yard.inventory.serialize() == expected_stock, "station stock")
	check(yard._manufacture_queue.size() == expected_queue, "paid order")
	check(SectorManager.current_sector.get_node("Asteroids").get_child_count() == expected_asteroids, "asteroid count")
	var found := false
	for rock in SectorManager.current_sector.get_node("Asteroids").get_children():
		if rock.position == asteroid_pos: found = rock.hull == 4 and rock._remaining_yield == 2
	check(found, "ore depletion")
	for child in yard.get_children():
		if child is StationSpawner: spawner = child
	check(spawner._spawned_ships.size() == 2 and spawner._initial_ships_spawned == 2, "fleet ownership and starter count")
	ship = spawner._spawned_ships[0]
	job_ai=ship.get_node("AIShipController")
	check(job_ai.resupply_fleet=="Escort fleet" and job_ai.resupply_ammo==150 and job_ai.resupply_volleys==4,"fleet resupply settings restored")
	check(job_ai.automation_home==&"sol_prime" and job_ai.automation_hops==2 and &"test_exclusion" in job_ai.no_go_sectors and job_ai.alert_message=="Test warning","automation policy and alert restored")
	check(job_ai.default_behavior=="job" and job_ai.default_job.source==yard,"job default and station reference restored")
	check(ship.hull == 42 and ship.inventory.get_amount(&"iron") == 7 and ship.position == ship_position, "AI damage cargo position")
	check(await SaveManager.load_game(PATH), "repeat load")
	check(get_tree().get_nodes_in_group("ships").size() == expected_ship_count, "no duplicate ships")
	check(SaveManager.save_game(PATH), "overwrite and backup")
	check(FileAccess.file_exists(PATH + ".bak"), "backup file")
	var file := FileAccess.open(PATH + ".bad", FileAccess.WRITE)
	file.store_var({"version": 999})
	file.close()
	check(not await SaveManager.load_game(PATH + ".bad"), "reject incompatible")
	check(PlayerState.credits == expected_credits, "bad load preserves game")
	var source := FileAccess.open(PATH, FileAccess.READ)
	var envelope: Dictionary = source.get_var(false)
	source.close()
	envelope.payload[10] = envelope.payload[10] ^ 1
	file = FileAccess.open(PATH + ".corrupt", FileAccess.WRITE)
	file.store_var(envelope)
	file.close()
	check(not await SaveManager.load_game(PATH + ".corrupt"), "reject damaged checksum")
	check(PlayerState.credits == expected_credits, "corruption preserves active session")
	print("SAVE_REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(failures)
