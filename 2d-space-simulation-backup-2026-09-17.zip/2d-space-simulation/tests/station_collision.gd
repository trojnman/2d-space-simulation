extends Node
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("COLLISION FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player = get_tree().get_first_node_in_group("player")
	var seen := {}
	for data in GameData.stations.values():
		var key := str(data.station_type) + str(data.capital_yard)
		if seen.has(key): continue
		seen[key] = true
		var station: StationInstance = load("res://scenes/Station.tscn").instantiate()
		station.station_data = data
		station.position = Vector2(1000000, 1000000)
		main.add_child(station)
		for i in 4: await get_tree().process_frame
		await get_tree().physics_frame
		var art: StationVisuals = station.get_node("StationVisuals")
		check(art._hull_colliders.size() > 1, key + " structure shapes")
		var polygon: CollisionPolygon2D = art._hull_colliders[0]
		var center := Vector2.ZERO
		for point in polygon.polygon: center += point
		center /= polygon.polygon.size()
		player.global_position = station.position + center + Vector2(2000,0)
		await get_tree().physics_frame
		var hit := player.move_and_collide(Vector2(-2000,0), true)
		check(hit != null and hit.get_collider() == station, key + " blocks real player sweep")
		if data.station_type == "shipyard":
			var span: float = 96 if data.capital_yard else 65
			player.global_position = station.position + Vector2(700,span*1.5)
			await get_tree().physics_frame
			hit = player.move_and_collide(Vector2(-650,0),true)
			check(hit != null and hit.get_collider() == station, key + " outer gantry solid")
			player.global_position = station.position + Vector2(700,40)
			await get_tree().physics_frame
			hit = player.move_and_collide(Vector2(-600,0),true)
			check(hit == null, key + " open approach passable")
		station.queue_free()
		await get_tree().process_frame
	print("STATION_COLLISION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(failures)
