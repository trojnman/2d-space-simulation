extends Node
var failures: int = 0
var checks: int = 0
func check(ok: bool, message: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		push_error("FAIL: " + message)
	else: print("PASS: " + message)
func _ready() -> void: call_deferred("run")
func run() -> void:
	var main: Node = load("res://scenes/Main.tscn").instantiate()
	add_child(main)
	for i in 8: await get_tree().process_frame
	main.process_mode = Node.PROCESS_MODE_DISABLED
	FactionManager.set_process(false)
	var yard: StationInstance
	var factory: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_shipyard": yard = station
		if station.station_data.id == &"sol_prime_manufacturing": factory = station
	var player: Player = get_tree().get_first_node_in_group("player")
	check(player.inventory.get_used_capacity(GameData.items) <= player.inventory.capacity, "Starting cargo fits actual hold")
	check(yard._treasury_linked and factory._treasury_linked, "Stations link to faction treasury")
	var money: int = yard.station_credits
	factory.station_credits -= 10
	check(yard.station_credits == money - 10 and FactionManager.get_faction_credits(yard.faction_id) == money - 10, "Station expenses share one finite treasury")
	var recipe: Dictionary = yard.get_ship_recipe(&"fighter")
	yard.inventory.clear()
	for id in recipe["inputs"]: yard.inventory.add_item(id, recipe["inputs"][id])
	var ingredients: Dictionary = yard.inventory.get_all_items()
	var balance: int = yard.station_credits
	yard.station_credits = 0
	check(not yard.queue_manufacture(recipe) and yard.inventory.get_all_items() == ingredients, "No production without worker funding; materials unchanged")
	yard.station_credits = balance
	var price: int = yard.get_ship_order_price(&"fighter")
	PlayerState.credits = price - 1
	check(not yard.order_player_ship(&"fighter") and yard.inventory.get_all_items() == ingredients, "Unaffordable player order changes nothing")
	PlayerState.credits = price * 3
	var total: int = PlayerState.credits + yard.station_credits + FactionManager.civilian_credits
	var before: int = PlayerState.get_station_hangar(yard.station_data.id).size()
	check(yard.order_player_ship(&"fighter"), "Player can order fully funded ship")
	check(PlayerState.credits == price * 2 and yard.inventory.get_all_items().is_empty(), "Order charges once and reserves all materials")
	check(PlayerState.credits + yard.station_credits + FactionManager.civilian_credits == total, "Ship payment and worker payment conserve credits")
	check(not yard.order_player_ship(&"fighter") and PlayerState.credits == price * 2, "Busy yard cannot charge duplicate order")
	check(PlayerState.get_station_hangar(yard.station_data.id).size() == before, "Ship is unavailable before build finishes")
	yard._process_manufacturing(59)
	check(PlayerState.get_station_hangar(yard.station_data.id).size() == before, "Ship respects full construction time")
	yard._process_manufacturing(1)
	var hangar: Array = PlayerState.get_station_hangar(yard.station_data.id)
	check(hangar.size() == before + 1 and hangar.back()["equipped_weapons"][0] == &"ballistic_gatling_s1" and hangar.back()["inventory"][&"ballistic_ammo"] == 100, "Completed order arrives equipped and supplied in player hangar")
	yard._process_manufacturing(100)
	check(hangar.size() == before + 1, "Completion cannot duplicate ship")
	player.hull = 23
	player.energy = 17
	var cargo: Dictionary = player.inventory.get_all_items()
	var weapon_id: StringName = player.equipped_weapons[0].id
	check(PlayerState.hangar_swap_to_ship(yard.station_data.id, before, player), "Swap into purchased ship succeeds")
	check(player.equipped_weapons[0].id == &"ballistic_gatling_s1" and player.inventory.get_amount(&"ballistic_ammo") == 100, "Swap restores purchased equipment and ammo")
	check(PlayerState.hangar_swap_to_ship(yard.station_data.id, hangar.size() - 1, player), "Swap back into stored ship succeeds")
	check(player.hull == 23 and player.energy == 17 and player.inventory.get_all_items() == cargo and player.equipped_weapons[0].id == weapon_id, "Round trip preserves damage, energy, cargo and equipment")
	var gun: WeaponData = GameData.weapons[&"ballistic_gatling_s1"]
	player.equip_weapon(gun, 0)
	player.inventory.clear()
	check(not player.fire_weapon(0, Vector2.RIGHT), "Empty ballistic weapon cannot fire")
	player.inventory.add_item(&"ballistic_ammo", 1)
	check(player.fire_weapon(0, Vector2.RIGHT) and player.inventory.get_amount(&"ballistic_ammo") == 0, "Player shot consumes exactly one round")
	player._weapon_cooldowns[0] = 0
	check(not player.fire_weapon(0, Vector2.RIGHT), "Cannot fire again after last round")
	var ai_ship := ShipInstance.new()
	ai_ship.initialize(GameData.ships[&"fighter"])
	ai_ship.equip_weapon(gun, 0)
	ai_ship.inventory.add_item(&"ballistic_ammo", 1)
	check(ai_ship.fire_weapon(0, Vector2.RIGHT) and ai_ship.inventory.get_amount(&"ballistic_ammo") == 0, "AI ships obey the same ammo consumption")
	ai_ship.free()
	yard.inventory.clear()
	check(yard.repair_ship(player) == 0 and player.hull == 23, "Repairs cannot create hull without materials")
	yard.inventory.add_item(&"hull_parts", 6)
	total = PlayerState.credits + yard.station_credits
	check(yard.repair_ship(player) > 0 and player.hull == player.max_hull and yard.inventory.get_amount(&"hull_parts") == 0, "Repair consumes correct materials")
	check(PlayerState.credits + yard.station_credits == total, "Repair payment credits faction")
	var docking: DockingManager = get_tree().get_first_node_in_group("docking_manager")
	yard._player_in_range = true
	docking._dock(yard)
	for i in 3: await get_tree().process_frame
	check(player._is_docked and not get_tree().paused, "Docking keeps economy running")
	check(player.collision_layer == 0 and is_instance_valid(docking._station_ui), "Docked ship protected and station UI loads")
	docking._station_ui._process(2.1)
	check(docking._station_ui.shipyard_tab.get_child_count() > 0 and docking._station_ui.manufacture_tab.get_child_count() > 0, "Live shipyard and production panels populate")
	var station_ui: StationUI = docking._station_ui
	station_ui._populate_hangar()
	station_ui._populate_hangar()
	var swap_button: Button = station_ui.hangar_tab.get_node("ActionPanel/SwapBtn")
	check(not swap_button.disabled and station_ui._selected_hangar_index >= 0, "Completed hangar ship automatically enables swap after repeated refreshes")
	var selected_index: int = station_ui._selected_hangar_index
	station_ui._populate_hangar()
	check(station_ui._selected_hangar_index == selected_index and not station_ui.hangar_tab.get_node("ActionPanel/SwapBtn").disabled, "Hangar selection survives refresh")
	station_ui.hangar_tab.get_node("ActionPanel/SwapBtn").pressed.emit()
	check(player.equipped_weapons[0].id == &"ballistic_gatling_s1", "Hangar swap button performs equipped ship swap")
	var military: StationInstance
	for station in get_tree().get_nodes_in_group("stations"):
		if station.station_data.id == &"sol_prime_military": military = station
	docking._station_ui.open(military, player)
	for dimensions in [Vector2i(1280,720), Vector2i(1856,1044)]:
		get_window().size = dimensions
		docking._station_ui._on_viewport_resized()
		for i in 4: await get_tree().process_frame
		var ui: StationUI = docking._station_ui
		var viewport_rect := Rect2(Vector2.ZERO, get_viewport().get_visible_rect().size)
		check(viewport_rect.encloses(ui.undock_button.get_global_rect()), "Undock remains inside viewport at " + str(dimensions))
		check(ui.station_name_label.get_global_rect().position.y >= 0 and ui.tab_container.get_global_rect().position.y >= 0, "Station header and tabs remain on-screen at " + str(dimensions))
		var scroll: ScrollContainer = ui.trade_tab.get_parent()
		check(scroll.get_v_scroll_bar().max_value > scroll.size.y and scroll.get_global_rect().end.y <= viewport_rect.end.y, "Long trade list scrolls within bounded viewport at " + str(dimensions))
		ui.tab_container.current_tab = 1
		await get_tree().process_frame
		check(ui.shipyard_tab.is_visible_in_tree(), "Shipyard tab can be selected at " + str(dimensions))
		ui.tab_container.current_tab = 0
	docking._station_ui.undock_button.pressed.emit()
	check(not player._is_docked and player.collision_layer != 0, "Undock restores flight collision")
	var economy: Node
	for child in get_tree().get_first_node_in_group("hud").get_children():
		if child.get_script() and child.get_script().resource_path == "res://scripts/EconomyPanel.gd": economy = child
	var event := InputEventKey.new()
	event.physical_keycode = KEY_B
	event.pressed = true
	economy._unhandled_input(event)
	check(economy._panel.visible and economy._text.text.contains("treasury") and economy._text.text.contains("Terran Shipyard"), "B opens economy panel with live treasury and station data")
	economy._process(1.1)
	check(economy._panel.visible and economy._text.text.contains("Stock:"), "Economy panel refreshes while open")
	economy._unhandled_input(event)
	check(not economy._panel.visible, "B closes economy panel without ending game")
	print("PLAYTEST REGRESSION: %d checks, %d failures" % [checks, failures])
	get_tree().quit(1 if failures else 0)
