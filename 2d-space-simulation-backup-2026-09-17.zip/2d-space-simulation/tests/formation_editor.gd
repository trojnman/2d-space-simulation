extends Node
func _ready() -> void:
 var main=load("res://scenes/Main.tscn").instantiate()
 add_child(main)
 for i in 12:await get_tree().process_frame
 get_tree().paused=true
 var ships: Array[ShipInstance]=[]
 for i in 2:
  var ship=load("res://scenes/Fighter.tscn").instantiate()
  SectorManager.current_sector.add_child(ship)
  ship.initialize(GameData.ships[&"fighter"])
  if not ship.get_node_or_null("AIShipController"):
   var ai=AIShipController.new()
   ai.name="AIShipController"
   ship.add_child(ai)
  ships.append(ship)
 FleetCommandSystem.selected_ships=ships
 var editor=load("res://scripts/FormationEditor.gd").new()
 add_child(editor)
 editor.open_selection()
 assert(editor.points.size()==2)
 editor.points.assign([Vector2(0,-500),Vector2(0,500)])
 editor.title_input.text="Test pair"
 editor._save()
 assert(FleetCommandSystem.custom_formations.has("Test pair"))
 FleetCommandSystem.issue_formation_move(Vector2(9000,9000),0,false)
 var a=ships[0].get_node("AIShipController")
 var b=ships[1].get_node("AIShipController")
 assert(a._formation_token==b._formation_token)
 assert(a._waypoint.distance_to(b._waypoint)==1000)
 ships[0].position=a._waypoint
 ships[0].rotation=0
 a._think_go_wait()
 assert(a._state==AIShipController.State.GO_WAIT)
 ships[1].position=b._waypoint
 ships[1].rotation=0
 b._think_go_wait()
 a._think_go_wait()
 assert(a._state==AIShipController.State.STAY and b._state==AIShipController.State.STAY)
 a.command_move_to(Vector2(10000,10000))
 a.queue_command({"type":GlobalEnums.FleetCommand.GO_WAIT,"position":Vector2(11000,11000)})
 a.cancel_last_command()
 assert(a._state==AIShipController.State.GO_WAIT)
 assert(a._waypoint==Vector2(10000,10000))
 var leader=PlayerState.current_ship
 a.set_command_queue([{"type":GlobalEnums.FleetCommand.DEFEND_SHIP,"target":leader}])
 b.set_command_queue([{"type":GlobalEnums.FleetCommand.FOLLOW_SHIP,"target":leader}])
 assert(a.escort_position().distance_to(b.escort_position())>200)
 assert((a.escort_position()-leader.global_position).dot(Vector2.from_angle(leader.rotation+PI))<0)
 assert(leader.hull_changed.is_connected(a._on_defend_target_hull_changed))
 a.cancel_all_commands()
 assert(not leader.hull_changed.is_connected(a._on_defend_target_hull_changed))
 assert(a._follow_target==null and a._target==null)
 print("FLEET: queued cancellation, trailing escort slots and defense cleanup passed")
 print("FORMATION: editor save, slot assignment, shared arrival checks passed")
 get_tree().quit()

