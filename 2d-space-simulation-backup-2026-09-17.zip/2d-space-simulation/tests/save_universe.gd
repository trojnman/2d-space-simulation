extends Node
const PATH := "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/universe-save.dat"
var failures := 0
var checks := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("UNIVERSE FAIL: ", label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	if "--read" in OS.get_cmdline_user_args():
		check(await SaveManager.load_game(PATH), "fresh-process load: " + SaveManager.last_error)
		check(SectorManager._visited_sectors.size() == 2, "two saved sectors")
		var home: SectorInstance = SectorManager._visited_sectors[&"sol_prime"]
		check(home.get_node("Stations").get_child_count() == GameData.sectors[&"sol_prime"].starting_stations.size()-1, "destroyed station stays gone")
		var yard: StationInstance
		for station in home.get_node("Stations").get_children():
			if station.station_data.id == &"sol_prime_shipyard": yard = station
		check(yard._manufacture_queue.size() == 1, "one replacement under construction")
		var owner: StationSpawner = yard._manufacture_queue[0].get("replacement_owner")
		check(is_instance_valid(owner) and owner._replacement_requests.size() == 1, "replacement owner remapped")
		var player: Player = get_tree().get_first_node_in_group("player")
		check(player.ship_data.id == &"heavy_missile_boat" and player.hull == 355, "capital player and hull")
		check(PlayerState.station_storage[&"sol_prime_shipyard"][&"iron"] == 33, "station storage")
		check(PlayerState.get_station_hangar(&"sol_prime_shipyard").size() == 1, "hangar")
		check(PlayerState.fleet_ships.size() == 1, "player fleet")
		var fleet: ShipInstance = PlayerState.fleet_ships[0]
		var brain: AIShipController
		for child in fleet.get_children():
			if child is AIShipController: brain = child
		check(fleet.get_node_or_null("AIShipController") == brain, "restored fleet accepts UI commands")
		check(brain._follow_target == player and brain._haul_destination == yard, "cross-sector references")
		check(brain._command_queue.size() == 1 and brain._command_queue[0].get("target") == player, "queued order references")
		SectorManager.load_sector(&"sol_prime")
		check(home.is_inside_tree(), "reactivate stored sector")
		yard._process_manufacturing(4.0)
		check(owner._replacement_requests.is_empty() and owner._spawned_ships.size() == 1, "deliver replacement once")
		yard._process_manufacturing(4.0)
		check(owner._spawned_ships.size() == 1, "no repeat delivery")
		for i in 4: await get_tree().process_frame
		print("UNIVERSE_READ: %d checks, %d failures" % [checks, failures])
	else:
		var home: SectorInstance = SectorManager.current_sector
		var stations := home.get_node("Stations").get_children()
		var yard: StationInstance = stations[4]
		stations[2].free()
		var owner: StationSpawner
		for child in stations[1].get_children():
			if child is StationSpawner: owner = child
		owner._initial_ships_spawned = owner.max_ships
		owner._replacement_requests.append(&"fighter")
		check(owner._request_replacement(), "funded replacement queued")
		var second: StringName = home.sector_data.connected_sectors[0]
		SectorManager.load_sector(second)
		for i in 5: await get_tree().process_frame
		var ship: ShipInstance = load("res://scenes/Hauler.tscn").instantiate()
		ship.faction_id = &"player"
		ship.add_to_group("player_fleet")
		SectorManager.add_sector_entity(ship)
		ship.initialize(GameData.ships[&"hauler"])
		var ai := AIShipController.new()
		ship.add_child(ai)
		PlayerState.fleet_ships.append(ship)
		for i in 3: await get_tree().process_frame
		var player: Player = get_tree().get_first_node_in_group("player")
		player.initialize(GameData.ships[&"heavy_missile_boat"])
		player.hull = 355
		ai._follow_target = player
		ai._haul_destination = yard
		ai._command_queue.append({"target": player, "type": GlobalEnums.FleetCommand.FOLLOW_SHIP})
		PlayerState.station_storage_add(&"sol_prime_shipyard", &"iron", 33)
		PlayerState.hangar_add_ship(&"sol_prime_shipyard", &"miner")
		check(SaveManager.save_game(PATH), "write universe")
		print("UNIVERSE_WRITE: %d checks, %d failures" % [checks, failures])
	get_tree().quit(failures)
