extends Node
const BUILD = preload("res://scripts/StationConstruction.gd")
const PATH = "C:/Users/pauls/Documents/Codex/2026-09-17/im-l/work/personal-build.dat"
var checks := 0
var failures := 0
func check(ok: bool, label: String) -> void:
	checks += 1
	if not ok:
		failures += 1
		print("PERSONAL BUILD FAIL: ",label)
func _ready() -> void:
	var main = load("res://scenes/Main.tscn").instantiate()
	main.process_mode = Node.PROCESS_MODE_PAUSABLE
	add_child(main)
	for i in 10: await get_tree().process_frame
	get_tree().paused = true
	var player: Player=get_tree().get_first_node_in_group("player")
	var yard: StationInstance
	for s in get_tree().get_nodes_in_group("stations"):
		if s.station_data.id==&"sol_prime_shipyard": yard=s
	for id in StationData.BUILD_COSTS[&"manufacturing"]: yard.inventory.add_item(id,StationData.BUILD_COSTS[&"manufacturing"][id])
	PlayerState.credits=100000000
	var total: int=PlayerState.credits+yard.station_credits+FactionManager.civilian_credits
	var before: int=PlayerState.credits
	var price: int=BUILD.personal_price(yard,GameData.stations[&"sol_prime_manufacturing"])
	check(not BUILD.queue(yard,&"sol_prime_manufacturing",&"player",yard.position),"blocked site refuses order")
	check(PlayerState.credits==before,"blocked site charges nothing")
	var site: Vector2=BUILD.deployment_position(yard)
	check(BUILD.site_clear(SectorManager.current_sector,site),"clear chosen site")
	check(BUILD.queue(yard,&"sol_prime_manufacturing",&"player",site),"personal station funded")
	check(PlayerState.credits==before-price,"personal materials and wages paid")
	check(PlayerState.credits+yard.station_credits+FactionManager.civilian_credits==total,"money conserved across buyer supplier workers")
	check(SaveManager.save_game(PATH),"save personal build")
	check(await SaveManager.load_game(PATH),"load personal build")
	for s in get_tree().get_nodes_in_group("stations"):
		if s.station_data.id==&"sol_prime_shipyard": yard=s
	BUILD.tick(yard,4)
	for i in 4: await get_tree().process_frame
	var owned: StationInstance
	for s in get_tree().get_nodes_in_group("stations"):
		if s.faction_id==&"player": owned=s
	check(is_instance_valid(owned) and owned.position==site,"player owner at selected location")
	check(owned.can_share_internal_info(),"owner can inspect internals")
	check(owned.station_credits==PlayerState.credits,"one wallet without new money")
	player.global_position=site+Vector2(owned.get_docking_range()-1,0)
	player.inventory.clear()
	player.inventory.add_item(&"iron",5)
	check(owned.transfer_owned_warehouse(player,&"iron",3,true),"deposit materials")
	check(owned.inventory.get_amount(&"iron")==3 and player.inventory.get_amount(&"iron")==2,"deposit conserves items")
	check(owned.transfer_owned_warehouse(player,&"iron",2,false),"withdraw materials")
	check(owned.inventory.get_amount(&"iron")==1 and player.inventory.get_amount(&"iron")==4,"withdraw conserves items")
	owned.production_enabled=false
	owned.visiting_traders_enabled=true
	check(SaveManager.save_game(PATH),"save owned station")
	check(await SaveManager.load_game(PATH),"load owned station")
	for s in get_tree().get_nodes_in_group("stations"):
		if s.faction_id==&"player": owned=s
	check(owned.visiting_traders_enabled,"visitor trade setting persists")
	check(not owned.production_enabled and owned.inventory.get_amount(&"iron")==1,"warehouse and production setting persist")
	var ui: StationUI=load("res://scenes/StationUI.tscn").instantiate()
	add_child(ui)
	ui.open(owned,player)
	check(ui.tab_container.has_node("Warehouse"),"owned warehouse UI")
	print("PERSONAL_CONSTRUCTION: %d checks, %d failures" % [checks,failures])
	get_tree().quit(failures)
