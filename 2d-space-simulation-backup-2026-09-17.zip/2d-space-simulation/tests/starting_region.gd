extends Node
var failures:=0
var checks:=0
func check(ok:bool,label:String)->void:
 checks+=1
 if not ok:failures+=1;print("REGION FAIL: ",label)
func _ready()->void:
 add_child(load("res://scenes/Main.tscn").instantiate())
 for i in 45:await get_tree().process_frame
 get_tree().paused=true
 check(GameData.factions.size()==4,"only four active factions")
 check(GameData.sectors.size()==10,"ten sectors retained")
 var neutral:=0
 var headquarters:Dictionary={}
 for sector in GameData.sectors.values():
  if sector.controlling_faction_id==&"":
   neutral+=1
   check(sector.starting_stations.is_empty(),"unclaimed sector has no starting installations")
  var counts:Dictionary={}
  for next in sector.connected_sectors:
   check(GameData.sectors.has(next) and sector.id in GameData.sectors[next].connected_sectors,"reciprocal gate "+str(sector.id)+" / "+str(next))
  for id in sector.starting_stations:
   var station=GameData.stations[id]
   check(GameData.factions.has(station.faction_id),"station belongs to active faction")
   var type=station.station_type
   if type==&"headquarters":headquarters[station.faction_id]=int(headquarters.get(station.faction_id,0))+1
   if type in [&"military",&"defense_platform",&"shipyard"]:check(station.faction_id==sector.controlling_faction_id,"restricted installation belongs to sector owner")
   var key=str(station.faction_id)+":"+str(type)
   counts[key]=int(counts.get(key,0))+1
   if type==&"trade":check(counts[key]<=1,"one trade station per faction per sector")
   if type==&"manufacturing":check(counts[key]<=3,"manufacturing cap")
 for faction in GameData.factions:
  check(headquarters.get(faction,0)==1,"one headquarters for "+str(faction))
 check(neutral==3,"three unclaimed sectors")
 check(PlayerState.is_friendly_to_player(&"terran_republic") and PlayerState.is_friendly_to_player(&"free_traders_guild"),"two player-friendly factions")
 check(not PlayerState.is_hostile_to_player(&"ash_collective") and not PlayerState.is_friendly_to_player(&"ash_collective") and PlayerState.is_hostile_to_player(&"iron_corsairs"),"Ash neutral to player; pirates hostile")
 check(preload("res://scripts/FleetAutomation.gd").reachable(&"sol_prime",10,[]).size()==10,"whole region connected")
 for id in preload("res://resources/StartingRegion.gd").OWNERS:
  if preload("res://resources/StartingRegion.gd").OWNERS[id]!=&"":check(SectorManager._visited_sectors.has(id),"owned sector economy initialized "+str(id))
 check(PlayerState.current_ship.ship_data.id==&"fighter","player starts in small fighter")
 check(PlayerState.fleet_ships.size()==2,"exactly two companion ships")
 var companion_ids:Array=[]
 for ship in PlayerState.fleet_ships:companion_ids.append(ship.ship_data.id)
 check(&"hauler" in companion_ids and &"miner" in companion_ids,"small hauler and miner companions")
 check(SectorManager.current_sector_id==&"sol_prime","player starts in Terran space")
 var doctrine=preload("res://scripts/FactionDoctrine.gd")
 check(doctrine.profile(&"ash_collective").radius>doctrine.profile(&"terran_republic").radius,"Ash wider engagement range")
 check(doctrine.profile(&"ash_collective").attack_group<doctrine.profile(&"terran_republic").attack_group,"Ash commits smaller attack groups")
 check(doctrine.profile(&"free_traders_guild").attack_group==0 and doctrine.profile(&"free_traders_guild").defensive,"Guild defensive doctrine")
 for faction in GameData.factions:
  if faction!=&"iron_corsairs":check(FactionManager.are_at_war(&"iron_corsairs",faction),"Corsairs hostile to "+str(faction))
 print("STARTING_REGION: ",checks," checks, ",failures," failures")
 get_tree().quit(failures)
