# Hardpoint rework — September 17, 2026

All 14 ship definitions now contain separate fixed, turret, missile-rack, and dedicated mining mount sizes. Gun equipment must match mount size exactly; mining lasers fit only the mining mount. Missile racks accept their size and smaller, doubling arming capacity per step down. Mixed missile types share real cargo availability without counting the same ammunition twice.

Fixed guns fire along the hull heading. Turrets have 120-degree arcs, centered 120 degrees port/starboard so they cover the sides and stern; odd final turrets face aft. Prototype traverse rates are S1 3.2, S2 1.4, S3 0.45 radians/second. Missile homing rates follow the same size order. These values need combat playtesting, especially fighter evasion.

Old loadouts attempt compatible empty mounts, and displaced equipment is retained in cargo instead of silently discarded. Such migration can temporarily leave cargo over capacity; no extra goods can be loaded until space is available. New mounts do not grant free equipment. Shipyard default packages still equip their existing starter equipment rather than filling every mount.

Validation: 206 hardpoint checks, including all ship mount counts, exact-size fitting, dedicated mining mounts, rack capacity, mixed missiles, arc enforcement, traverse order, migration, and save/load. Background combat 12, background transport 14, boarding 24 passed. Rendered roster reviewed for mount placement. Manual combat tuning outstanding.

Turret orders are now available in the weapon HUD and each selected fleet ship's panel: Defend (default), Passive, Attack enemies, and Attack current target. Fixed guns remain manually/AI fired separately. Turrets independently select eligible targets within their arcs, preferring targets near their own mount size, and must physically traverse before firing. Current-target mode does not fall back to another target. Friendly-fire policy and sensor limits remain enforced.

Defend records direct damage, incoming gun trajectories (including near misses), and homing missiles. Retaliation lasts a provisional 30 seconds after the last incoming attack. Passive prevents automatic and trigger-based turret fire. Orders persist through saving, boarding, and hangar storage; live retaliation timers persist in disk saves. Offscreen turrets use the same policy and aiming gates with simplified direct damage.

Validation: 17 turret-policy checks passed, including incoming-fire response, passive manual-trigger isolation, range/arc gates, current-target behavior, traverse delay, persistence, boarding, and offscreen firing. Hardpoints (206), background combat (12), boarding (24), and targeting/layout (24) regressions also passed.
