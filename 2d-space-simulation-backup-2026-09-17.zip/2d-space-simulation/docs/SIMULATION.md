# Simulation requirements

The user explicitly wants a legitimate economic simulation, not scripted activity.

- Each faction owns finite credits, materials, equipment, stations, and ships.
- Starting assets are allocated once for a new game. Loading or revisiting a sector must never replenish them.
- Ships consume construction materials and production time. Equipment and ammunition must also be manufactured or purchased; default equipment is not a free recurring grant.
- Mining depletes deposits. Cargo capacity and physical transport constrain supply.
- Internal transfers conserve faction-owned goods. External purchases debit the buyer and credit the seller, with physical delivery and explicit ownership of cargo.
- Production should respond to demand and reserve strategic inputs instead of manufacturing everything indefinitely.
- AI must account for credits, shortages, logistics, replacement needs, threats, and expansion costs.
- Sector changes and save/load preserve economic state; distant sectors continue with simplified simulation.
- Medium hull material costs are twice small counterparts, large hull costs three times small. Logistics has no small counterpart and needs its own explicit baseline.
- Notify the user before major architecture changes, installations, or similarly substantial work.

## First Sol Prime playtest checkpoint

Ready for the first manual single-sector review. The game's wider roadmap remains unfinished.

- Finite starter fleets; destroyed ships require funded replacements.
- Material, weapon, shield and ammunition inputs reserved once per ship order.
- Timed player shipyard orders deliver to the local hangar. Hangar swaps retain equipment, cargo, hull and energy.
- Player goods trades conserve stock and credits and respect cargo capacity.
- Faction stations share one treasury. Starting money is allocated once, not upon sector visits. Production pays an explicit civilian worker account and rejects insufficient funds. Pilot hiring also pays that account; repairs transfer credits to the station's faction and consume hull parts.
- Ballistic shots consume cargo ammunition in the common player/AI firing path. Military stations manufacture rounds, AI combat ships can resupply from friendly stock, and missile boat loadouts include finite missiles. Player missile launches already consume cargo ammunition.
- Bounded stock targets, production reserves, rotating recipe priority and two concurrent factory jobs prevent unconditional unlimited output. Routine supply favors small-ship needs.
- Same-faction hauling physically transports stock. Docking approach distances account for large station hulls. Miners respect cargo limits and depleted deposits remain depleted.
- Visited sectors retain their exact state in memory. Inactive sectors pause. Only the piloted player changes sectors automatically.
- The station economy keeps running while docked. Inventory/map pause. F1 displays controls; B displays local economy and faction funds.

## Validation

130 automated checks pass: economy 23, sector persistence 39, trade 18, equipment 22, playtest integration 28. Test scenes are under res://tests with matching *_regression.tscn names. Final logs have no gameplay script errors.

res://tests/sector_soak.tscn ran 1200 simulated seconds at 20x. It ended with 33 ships, conserved aggregate player/faction/civilian credits, nonnegative station stocks and cargo within capacity. Deliveries reached the shipyard, which had supplies for small ship orders. This accelerated run does not verify real-time feel or visuals.

Use an explicit writable --log-file path with headless Godot. The default user log path failed and caused an engine crash in this sandbox; an explicit path succeeded. The environment also reports a root certificate store error unrelated to gameplay.

## Remaining scope and limitations

- No disk saves. Closing the game starts a fresh session. Inactive sectors do not simulate.
- No paid physical cross-faction freight contracts, autonomous expansion or advanced fleet logistics.
- No complete transaction-history ledger or civilian demand/spending model. The civilian account records worker and pilot payments.
- Medium/large recipes exist but routine supply targets favor small ships, so larger orders may be starved until production planning expands.
- Money prices, worker costs, stock targets and volumes are provisional balance. Equipment volumes are 5/15/30, missile rounds 0.1/0.2/0.3 by size, ballistic rounds 0.01.
- Combat balance, missile targeting/resupply and visual UI layout require manual review. Desktop capture remains unavailable.

The local outputs folder contains Start Space Simulation.cmd and PLAYTEST.md. The launcher uses an explicit log path and a 1280x720 window. It has been prepared but not launched on the user's desktop.

## Sensor fog prototype

Player/owned-fleet/satellite coverage controls world visibility and local economic details. NPC friendly observers do not grant vision. Local radii: small 2500, medium 4000, large 6000; station-only long range is 4x local. Long-range contacts render amber [LR] markers and hide descriptions until scanned locally. Map contacts omit stale ship positions and undeclared static layout. A screen-space fog shader darkens uncovered space. Thirteen sensor checks verify reveal/hide, station-only long range, detailed-info gating and satellite loss; rendering still requires manual review.

## Current implementation update (September 17)

Manual versioned/checksummed F5/F9 disk checkpoints are implemented. Visited inactive sectors now continue station production and existing NPC mining/hauling using simplified movement; the earlier statement that all inactive sectors pause is superseded. Off-screen combat, player fleet commands, unvisited sectors and AI activation for ships newly manufactured off-screen remain future work. Inventory pauses the game; the map does not.

Physical cross-faction spot trade settles finite faction funds and cargo at pickup. No money or stock is reserved during planning. Goods travel aboard the purchasing faction's hauler and are deposited into its own stations. Neutral/hostile inspection restrictions continue to apply. The new Guild Exchange appears only in new Sol Prime layouts; loading an older checkpoint preserves its saved layout.

Next architecture decision awaiting user: complete-station construction versus modular assembly.


## Player recovery and station exports
- Ship destruction ejects an escape pod; lost hull equipment/cargo are removed while other assets remain. Enemies and homing missiles exclude pods from targeting. Pods are not damage-immune.
- Select an owned ship in the map fleet panel and use Enter ship within 350 units. Outgoing ships retain cargo, equipment, damage and an AI pilot. Hangar swaps transfer the incoming hired pilot to the outgoing ship too.
- Owned stations now have a Warehouse option to allow visiting traders. Default is off. When enabled, non-hostile NPC haulers can purchase surplus at physical pickup and pay the player wallet. Production reserves are protected and receipts appear in the player treasury history. The setting persists in saves.
- Verification: 24 recovery/boarding checks, 21 physical trade checks and 20 personal construction/persistence checks passed. Visual playtesting remains outstanding.
- Remaining: player fleet automated supply orders, inter-sector trade routes, construction delivery ships, and strategic faction expansion decisions.


### Assigned player station supply
Select a fleet hauler or logistics ship in the map, choose an owned station in its dropdown, and press Supply station. It moves needed inputs from owned warehouses first, or buys available imports using the player wallet. Internal transfers are free; purchases require funds, capacity, non-hostile access and physical arrival. Cancel All ends the assignment and retains cargo. Assignments and cargo survive save/load. Routes are within one sector; assigned economic hauling also uses the existing visited-sector background update. Unassigned fleet commands and offscreen combat are still paused. Verified 15 supply checks plus 21 physical trade checks, no failures.


### Warehouse targets and station destruction
Owned warehouses now expose per-item Keep targets. Supply haulers fill the greater of that target and normal production needs; exports preserve the target. Targets survive save/load. Assigned player supply continued in a visited inactive sector in an 11-check regression.
Confirmed destruction rule: all hangared ships are lost; 25% of warehouse and stored goods (rounded down per item) become physical salvage. Destroying a station while the player is docked destroys the piloted hull and ejects the escape pod. Salvage observes fog, persists in saves, and is collected within 100 units subject to cargo capacity. Excess remains in space. Station destruction/salvage: 13 checks passed. Stock-target/supply, trade, and station suites: 61 checks passed.
Next design input requested: autonomous faction construction limited to owned territory versus also claiming unowned sectors.


### Station caps and owned-sector expansion
Confirmed caps: trade 1 and manufacturing 3 per faction per sector; military 2 and defense platforms 4 total per sector; one standard and one capital yard per sector; one HQ per faction globally. Military, defense, and yards require sector ownership. Queued construction counts. Existing stations are not deleted to enforce new caps.
NPC strategy now plans missing basic facilities in visited owned sectors using real construction queues, material requests and wages. It pursues one project per sector, preserves explicit requests and does not duplicate existing facilities. Six expansion checks passed. This does not yet dispatch construction ships or expand into unowned sectors.
Unowned territory requires a dedicated claim beacon (confirmed). Beacon implementation awaits the destruction/conquest rule: immediate loss of ownership versus clearance of remaining military stations and defense platforms.


### Membership, founding and territory decisions
Player starts independent. Membership requires friendly reputation and does not transfer personal assets. Building a personal HQ establishes the player's faction; HQ also protects its sector claim. Members may build civilian stations, claim beacons for their joined faction, and personally owned defense platforms in joined territory. Members may not build shipyards or military stations. Defense platforms share the sector-wide cap of four.
Personal defense platforms now store their defended faction separately from asset ownership, persist that affiliation and protect that faction's sector claim. Destruction updates control through the station destruction callback. Sector becomes unowned only after its claim beacon/HQ, military stations and defense platforms are gone. Verified nine claim, eighteen cap and six expansion checks.
Still unfinished: player-facing HQ/beacon deployment and autonomous expansion into unowned sectors. Pending design choice: construction ship with material cargo versus purchased deployable construction kit for sectors without a shipyard.


### Construction scaffold kits
Player flow: dock at a shipyard, open Expansion, buy a $1000 scaffold kit (yard consumes 1 hull part + 1 electronics). In flight open inventory > Construction, select blueprint, deploy 200 units ahead in clear space. Approach within 350 units and use Deliver required materials; it transfers only remaining inputs from cargo. All required materials are consumed when the 3-second test countdown begins. Scaffold becomes the selected station after completion; no seeded goods or free ships. HQ in unclaimed space founds the player's faction and claims the sector. Dedicated beacons claim for the joined faction or the player's founded faction. Sponsored projects retain their beneficiary even after leaving. New faction-sponsored structures are faction property. Old personal-build UI shortcut removed; NPC prefab construction remains.
Scaffold material inventory, beneficiary, location and countdown survive save/load. Timers advance in visited inactive sectors. Completion rechecks ownership/caps. New beacon art and scaffold ring frame are prototype visuals; UI still needs visual playtesting. Scaffold combat/destruction and automated supply deliveries to scaffolds are not yet implemented. NPC expansion into unowned sectors remains unfinished.
Verification: 21 scaffold/ownership/save checks, 18 cap checks, 6 owned expansion checks passed.
Pending decision: does the player's founded faction survive headquarters destruction?
