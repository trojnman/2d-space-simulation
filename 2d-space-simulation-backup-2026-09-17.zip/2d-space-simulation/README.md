# 2D Space Simulation

Godot 4.6.2 prototype of a 2D space trading, combat, and faction simulation.

## Run

Extract or clone the project, then import `project.godot` in Godot 4.6.2. Allow the editor to import assets and rebuild its cache before running the main scene.

Standalone play is recommended: save loading has previously stalled in Godot's embedded game window. You can run `godot --path . res://scenes/Main.tscn` with your Godot executable on PATH.

## Layout

- `scripts/`, `resources/`: game logic and resource definitions.
- `scenes/`, `data/`: scenes and game data.
- `docs/`: simulation documentation.
- `tests/`: development regression scenes. Some diagnostic tests contain local developer paths; review those before running on another computer.

## Current scope

Prototype systems include flight and combat, targeting, docking and trade, manufacturing, finite mining resources and asteroid respawns, station construction, faction economy and diplomacy, sensors, and save/load. Balance and wider simulation integration remain in development. Short production timers and seeded stock support playtesting.

## Controls

WASD flight; mouse aim and left mouse fire; I inventory; Tab target; X clear targets; M map; E dock; P pause; Escape menu; F5 save; F9 load. Missile controls use right mouse and scrolling while held. F1 opens help.

## Backup contents

Source, scenes, resources, UID metadata, documentation, and tests are included. Generated Godot caches, temporary files, logs, and runtime save files are excluded. Saved games are stored separately in Godot's user data folder and are not part of this source backup.
