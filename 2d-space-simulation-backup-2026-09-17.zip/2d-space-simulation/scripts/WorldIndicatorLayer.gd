extends CanvasLayer
var provider:Control
class Drawing extends Control:
 var provider:Control
 func _ready()->void:mouse_filter=Control.MOUSE_FILTER_IGNORE
 func _process(_delta:float)->void:
  visible=is_instance_valid(provider) and provider.is_visible_in_tree()
  if visible:queue_redraw()
 func _draw()->void:
  if is_instance_valid(provider):provider._draw_world(self)
func _ready()->void:
 layer=9
 var drawing:=Drawing.new()
 drawing.provider=provider
 add_child(drawing)
