extends CanvasLayer
var panel: Control
var toggle: CheckBox
var message: Label
var busy:=false
var settings: VBoxContainer
func _ready()->void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 layer=110
 add_to_group("pause_menu")
 panel=Control.new()
 panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 add_child(panel)
 var shade:=ColorRect.new()
 shade.color=Color(0.02,0.04,0.09,0.86)
 shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 panel.add_child(shade)
 var center:=CenterContainer.new()
 center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 panel.add_child(center)
 var card:=PanelContainer.new()
 card.theme=preload("res://scripts/ConsoleTheme.gd").build()
 card.custom_minimum_size=Vector2(400,0)
 center.add_child(card)
 var margin:=MarginContainer.new()
 for side in ["left","right","top","bottom"]:margin.add_theme_constant_override("margin_"+side,24)
 card.add_child(margin)
 var column:=VBoxContainer.new()
 column.add_theme_constant_override("separation",14)
 margin.add_child(column)
 var title:=Label.new()
 title.text="FLIGHT PAUSED"
 title.add_theme_font_size_override("font_size",24)
 column.add_child(title)
 for action in ["Resume","Save","Load","Settings","HUD Layout","Quit"]:
  var button:=Button.new()
  button.text=action
  button.custom_minimum_size.y=42
  button.pressed.connect(_action.bind(action))
  column.add_child(button)
 settings=VBoxContainer.new()
 column.add_child(settings)
 settings.add_child(HSeparator.new())
 settings.hide()
 toggle=CheckBox.new()
 toggle.text="Friendly fire"
 toggle.tooltip_text="When off, weapons cannot damage non-hostile ships or stations. Applies to everyone."
 toggle.toggled.connect(func(value):PlayerState.friendly_fire_enabled=value)
 settings.add_child(toggle)
 message=Label.new()
 message.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
 column.add_child(message)
 hide()
func _input(event:InputEvent)->void:
 if HUDLayout.editing or preload("res://scripts/UIInput.gd").typing(get_viewport()):return
 if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode==KEY_ESCAPE:
  get_viewport().set_input_as_handled()
  if busy or SaveManager.loading:return
  if visible:close()
  else:open()
func open()->void:
 HUDLayout.paint_panel(panel)
 var indicator=get_parent().get_node_or_null("PauseIndicator")
 if indicator:indicator.manual_pause=false
 for screen in get_tree().get_nodes_in_group("inventory_screen"):
  if screen.visible:screen.close()
 toggle.set_pressed_no_signal(PlayerState.friendly_fire_enabled)
 message.text=""
 settings.hide()
 show()
 get_tree().paused=true
func close()->void:
 hide()
 get_tree().paused=false
func _action(action:String)->void:
 if busy:return
 match action:
  "Resume":close()
  "HUD Layout":
   close()
   HUDLayout.open_editor()
  "Settings":settings.visible=not settings.visible
  "Quit":get_tree().quit()
  "Save":message.text="Game saved." if SaveManager.save_game() else SaveManager.last_error
  "Load":
   busy=true
   message.text="Loading..."
   _load.call_deferred()
func _load()->void:
 var ok:bool=await SaveManager.load_game()
 busy=false
 if ok:close()
 else:message.text=SaveManager.last_error
