extends Window
var ai:AIShipController
var kind:OptionButton
var source:OptionButton
var destination:OptionButton
var item:OptionButton
var amount:SpinBox
var repeat:CheckBox
var status:Label
func picker(column:VBoxContainer,title:String)->OptionButton:
 var label:=Label.new();label.text=title;column.add_child(label)
 var choice:=OptionButton.new();column.add_child(choice);return choice
func _ready()->void:
 title="Fleet automation"
 size=Vector2i(540,620)
 unresizable=true
 theme=preload("res://scripts/ConsoleTheme.gd").build()
 close_requested.connect(queue_free)
 var frame=preload("res://scripts/FleetWindowFrame.gd").build(self,"FLEET / AUTOMATED JOB")
 var margin:=MarginContainer.new();margin.size_flags_vertical=Control.SIZE_EXPAND_FILL;frame.add_child(margin)
 for side in ["left","top","right","bottom"]:margin.add_theme_constant_override("margin_"+side,18)
 var column:=VBoxContainer.new();margin.add_child(column)
 kind=picker(column,"Job")
 for name in ["Mine and sell / deposit","Trade route","Resupply owned ship"]:kind.add_item(name)
 source=picker(column,"Source station (trade / resupply)")
 destination=picker(column,"Home / destination station or resupply ship")
 item=picker(column,"Cargo priority")
 amount=SpinBox.new();amount.min_value=1;amount.max_value=10000;amount.value=50
 var label:=Label.new();label.text="Units per trip / recipient stock target";column.add_child(label);column.add_child(amount)
 repeat=CheckBox.new();repeat.text="Repeat automatically";repeat.button_pressed=true;column.add_child(repeat)
 status=Label.new();status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;column.add_child(status)
 var start:=Button.new();start.text="Assign job";start.pressed.connect(assign);column.add_child(start)
 var stop:=Button.new();stop.text="Stop job (keep cargo)";stop.pressed.connect(func():ai.cancel_all_commands());column.add_child(stop)
 kind.item_selected.connect(func(_index):populate())
 populate()
func populate()->void:
 source.clear();destination.clear();item.clear()
 for station in preload("res://scripts/TurretOrders.gd").sector_nodes(ai._ship,&"stations"):
  if not preload("res://scripts/FleetJobs.gd").station_ok(ai,station):continue
  source.add_item(station.station_data.display_name);source.set_item_metadata(source.item_count-1,station)
  if kind.selected!=2:
   destination.add_item(station.station_data.display_name);destination.set_item_metadata(destination.item_count-1,station)
 if kind.selected==2:
  for ship in preload("res://scripts/TurretOrders.gd").sector_nodes(ai._ship,&"ships"):
   if ship==ai._ship or not ship.is_in_group("player_fleet"):continue
   destination.add_item(ship.ship_data.display_name);destination.set_item_metadata(destination.item_count-1,ship)
 for id in GameData.items:
  if kind.selected==0 and not AsteroidInstance.MATERIAL_IDS.values().has(id):continue
  item.add_item(GameData.items[id].display_name);item.set_item_metadata(item.item_count-1,id)
 source.disabled=kind.selected==0
func assign()->void:
 if destination.selected<0 or item.selected<0 or (kind.selected!=0 and source.selected<0):status.text="Choose valid source, destination and cargo.";return
 if kind.selected==0:
  var mining:=false
  for weapon in ai._ship.equipped_weapons:
   if weapon and weapon.weapon_type==GlobalEnums.WeaponType.MINING:mining=true
  if not mining:status.text="Equip a mining laser first.";return
 var dest=destination.get_selected_metadata()
 var src=source.get_selected_metadata() if source.selected>=0 else null
 if kind.selected==1 and src==dest:status.text="Choose two different stations.";return
 ai.cancel_all_commands()
 ai.fleet_job={"kind":["mine","trade","resupply"][kind.selected],"source":src,"destination":dest,"item":item.get_selected_metadata(),"amount":int(amount.value),"repeat":repeat.button_pressed,"phase":"collect"}
 ai._home_station=dest if dest is StationInstance else src
 ai.default_job=ai.fleet_job.duplicate()
 ai.default_suspended=false
 ai.alert_message=""
 ai.job_status="Job assigned"
func _process(_delta:float)->void:
 if not is_instance_valid(ai):queue_free();return
 if not ai.fleet_job.is_empty():status.text=ai.job_status
