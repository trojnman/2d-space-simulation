class_name SatelliteInstance
extends Node2D

## A deployable sensor satellite.
## Placed in the world from inventory, registers with SensorSystem.
## Scene tree:
##   SatelliteInstance (Node2D + SatelliteInstance.gd)
##     Sprite2D / Polygon2D  (small diamond shape)
##     BlinkTimer (Timer)

const SENSOR_RADIUS : float = SensorSystem.RADIUS_SAT

var _blink_state : bool = false

@onready var blink_timer : Timer = $BlinkTimer if has_node("BlinkTimer") else null


func _enter_tree() -> void:
	SensorSystem.register_observer(self, SENSOR_RADIUS)


func _ready() -> void:
	add_to_group("satellites")
	if blink_timer:
		blink_timer.timeout.connect(_on_blink)
		blink_timer.start(0.8)


func _exit_tree() -> void:
	SensorSystem.unregister_observer(self)


func _on_blink() -> void:
	_blink_state = !_blink_state
	modulate = Color(0.4, 0.9, 1.0) if _blink_state else Color(0.2, 0.5, 0.7)
