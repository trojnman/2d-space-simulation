extends RefCounted
static func configure(projectile: Node2D, weapon: WeaponData, energy: bool) -> Dictionary:
	var factor: float = [1.0, 1.5, 2.1][clampi(int(weapon.equip_size) if weapon else 0, 0, 2)]
	var cannon: bool = weapon != null and str(weapon.id).contains("cannon") and not str(weapon.id).contains("autocannon")
	var mining: bool = weapon != null and str(weapon.id).contains("mining")
	var width: float = (0.65 if energy else 0.5) * factor * (1.35 if cannon else 1.0)
	var length: float = (5.0 if energy else 2.8) * factor * (1.35 if cannon else 1.0)
	var tint: Color = preload("res://scripts/WeaponPalette.gd").shot_color(weapon)
	var core := Line2D.new()
	core.name = "ShotCore"
	core.width = width
	core.default_color = tint.lightened(.12) if energy else tint
	var glow := Line2D.new()
	glow.name = "ShotGlow"
	glow.width = width * 3.0
	glow.default_color = Color(tint, .32)
	glow.visible = energy
	projectile.add_child(glow)
	projectile.add_child(core)
	projectile.z_index = 3
	return {"core": core, "glow": glow, "length": length, "distance": 0.0, "tint": tint}
static func advance(art: Dictionary, distance: float) -> void:
	if art.is_empty(): return
	art["distance"] += distance
	# Grow from the muzzle; never draw a full tail behind the launch point.
	var tail: float = minf(art["length"], art["distance"])
	var points := PackedVector2Array([Vector2.ZERO, Vector2(-tail,0)])
	art["core"].points = points
	art["glow"].points = points
static func impact(projectile: Node2D, art: Dictionary) -> void:
	if art.is_empty(): return
	var flash := preload("res://scripts/ShotFlash.gd").new()
	flash.impact = true
	flash.duration = .12
	flash.radius = art["length"] * .45
	flash.tint = art["tint"]
	projectile.get_parent().add_child(flash)
	flash.global_position = projectile.global_position
