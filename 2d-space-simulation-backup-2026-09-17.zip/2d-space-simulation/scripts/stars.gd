extends Node2D

func _ready() -> void:
	for i in 200:
		var x := randf_range(-5000, 5000)
		var y := randf_range(-5000, 5000)
		var star := ColorRect.new()
		star.size = Vector2(2, 2)
		star.position = Vector2(x, y)
		star.color = Color(1, 1, 1, randf_range(0.3, 1.0))
		add_child(star)
