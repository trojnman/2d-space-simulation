extends Node2D
## A bounded, repeating screen backdrop: no world-sized field of star nodes.
var canvas:Control
var stars:Array[Vector3]=[]
func _ready()->void:
 var layer:CanvasLayer=CanvasLayer.new()
 layer.layer=-99
 add_child(layer)
 canvas=Control.new()
 canvas.mouse_filter=Control.MOUSE_FILTER_IGNORE
 canvas.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 layer.add_child(canvas)
 var rng:RandomNumberGenerator=RandomNumberGenerator.new()
 rng.seed=1739
 for i in 200:stars.append(Vector3(rng.randf(),rng.randf(),rng.randf_range(0.2,0.7)))
 canvas.draw.connect(_draw_stars)
func _process(_delta:float)->void:
 canvas.queue_redraw()
func _draw_stars()->void:
 var camera:Camera2D=get_viewport().get_camera_2d()
 var extent:Vector2=get_viewport_rect().size
 var offset:Vector2=camera.get_screen_center_position()*0.015 if camera else Vector2.ZERO
 for star in stars:
  var point:Vector2=Vector2(fposmod(star.x*extent.x-offset.x,extent.x),fposmod(star.y*extent.y-offset.y,extent.y))
  canvas.draw_circle(point,0.8,Color(0.78,0.84,1.0,star.z))
