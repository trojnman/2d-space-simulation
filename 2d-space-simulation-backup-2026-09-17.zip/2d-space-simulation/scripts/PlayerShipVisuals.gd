extends Node
## Use the same hull, hardpoints and collision as the selected NPC ship.
var _built_id: StringName = &""
func _ready() -> void:
	call_deferred("_build_current")
func _build_current() -> void:
	var ship := get_parent() as ShipInstance
	if ship and ship.ship_data: rebuild(ship.ship_data.id)
func rebuild(id: StringName) -> void:
	if id == _built_id: return
	if id == &"escape_pod":
		_build_pod()
		return
	if not StationSpawner.SHIP_SCENES.has(id): return
	var ship := get_parent() as ShipInstance
	var template: ShipInstance = load(StationSpawner.SHIP_SCENES[id]).instantiate()
	template._build_visuals()
	for child in ship.get_children():
		if child.has_meta("player_hull_part"):
			ship.remove_child(child)
			child.queue_free()
	for child in template.get_children():
		template.remove_child(child)
		child.set_meta("player_hull_part", true)
		# Player aiming uses +PI, so its hull and hardpoints face local -X.
		if child is Node2D:
			child.position.x *= -1
			child.scale.x *= -1
		ship.add_child(child)
	template.free()
	_built_id = id
	ship._collect_muzzle_points()
	ship._refresh_visuals()

func _build_pod() -> void:
	var ship := get_parent() as ShipInstance
	for child in ship.get_children():
		if child.has_meta("player_hull_part"):
			ship.remove_child(child)
			child.queue_free()
	var outline := PackedVector2Array([Vector2(-9,-3),Vector2(-5,-6),Vector2(6,-6),Vector2(9,-3),Vector2(9,3),Vector2(6,6),Vector2(-5,6),Vector2(-9,3)])
	var hull := Polygon2D.new()
	hull.polygon = outline
	hull.color = Color(0.95,0.48,0.12)
	hull.set_meta("player_hull_part",true)
	ship.add_child(hull)
	var window := Polygon2D.new()
	window.polygon = PackedVector2Array([Vector2(-7,-2),Vector2(-3,-4),Vector2(-1,-4),Vector2(-1,4),Vector2(-3,4),Vector2(-7,2)])
	window.color = Color(0.35,0.9,1.0)
	window.set_meta("player_hull_part",true)
	ship.add_child(window)
	var collision := CollisionPolygon2D.new()
	collision.polygon = outline
	collision.set_meta("player_hull_part",true)
	ship.add_child(collision)
	_built_id = &"escape_pod"
	ship._collect_muzzle_points()
	ship._refresh_visuals()
