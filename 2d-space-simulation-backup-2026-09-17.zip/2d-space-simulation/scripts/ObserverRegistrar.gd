extends Node

## Add this as a child node to any ShipInstance or StationInstance
## that should contribute to sensor coverage.
## It auto-registers/unregisters with SensorSystem.
##
## For ships: radius is determined by ship class.
## For stations: radius is always RADIUS_STATION.
## Only registers if the ship/station belongs to a friendly faction.

@export var override_radius : float = 0.0   ## 0 = auto-detect from ship class

var _parent_node : Node2D = null
var _radius      : float  = 0.0


func _enter_tree() -> void:
	_register.call_deferred()


func _register() -> void:
	if not is_inside_tree(): return
	_parent_node = get_parent() as Node2D
	if not _parent_node: return
	if not _should_register(): return
	_radius = _get_radius()
	SensorSystem.register_observer(_parent_node, _radius)


func _exit_tree() -> void:
	if _parent_node:
		SensorSystem.unregister_observer(_parent_node)


func _should_register() -> bool:
	## Only register if this belongs to a faction friendly to the player
	var faction_id : StringName = &""
	if _parent_node is ShipInstance:
		faction_id = _parent_node.faction_id
	elif _parent_node is StationInstance:
		faction_id = _parent_node.faction_id

	## Player's own ship always registers
	if _parent_node.is_in_group("player") or _parent_node.is_in_group("player_fleet"):
		return true

	## Friendly factions register
	if faction_id == &"": return false
	return PlayerState.is_friendly_to_player(faction_id)


func _get_radius() -> float:
	if override_radius > 0.0:
		return override_radius

	if _parent_node is StationInstance:
		return SensorSystem.RADIUS_STATION

	if _parent_node is ShipInstance:
		return SensorSystem.get_radius_for_ship(_parent_node as ShipInstance)

	return SensorSystem.RADIUS_SMALL
