extends PanelContainer
var turret_order:OptionButton
var rows:VBoxContainer
var heading:Label
var missile:Label
var progress:ProgressBar
var scroll:ScrollContainer
var entries:Array=[]
var signature:=""
func _ready()->void:
 add_to_group("weapon_control_hud")
 theme=preload("res://scripts/ConsoleTheme.gd").build()
 var frame=preload("res://scripts/ConsoleTheme.gd").box(Color("0a1624"),Color("315766"))
 frame.set_corner_radius_all(14)
 add_theme_stylebox_override("panel",frame)
 var column:=VBoxContainer.new()
 add_child(column)
 heading=Label.new()
 heading.add_theme_font_size_override("font_size",12)
 heading.add_theme_color_override("font_color",Color("67dce8"))
 column.add_child(heading)
 turret_order=OptionButton.new()
 for label in ["Turrets: Defend", "Turrets: Passive", "Turrets: Attack enemies", "Turrets: Attack current target"]: turret_order.add_item(label)
 turret_order.tooltip_text="Defend: return incoming fire for 30 seconds. Passive: never fire. Attack: engage enemies. Current target: engage your selected target within each turret arc."
 turret_order.item_selected.connect(func(index:int):
  var ship=PlayerState.current_ship
  if is_instance_valid(ship):ship.set_turret_order(index))
 column.add_child(turret_order)
 column.add_child(HSeparator.new())
 scroll=ScrollContainer.new()
 scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
 column.add_child(scroll)
 rows=VBoxContainer.new()
 rows.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 scroll.add_child(rows)
 missile=Label.new()
 missile.add_theme_font_size_override("font_size",12)
 missile.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
 column.add_child(missile)
 progress=ProgressBar.new()
 progress.show_percentage=false
 progress.custom_minimum_size.y=5
 column.add_child(progress)
 var fill:=StyleBoxFlat.new()
 fill.bg_color=Color("e9c77b")
 fill.set_corner_radius_all(3)
 progress.add_theme_stylebox_override("fill",fill)
func rebuild(player:Player)->void:
 for node in rows.get_children():rows.remove_child(node);node.queue_free()
 entries.clear()
 for i in player.equipped_weapons.size():
  var weapon=player.equipped_weapons[i]
  if not weapon:continue
  var row:=HBoxContainer.new()
  rows.add_child(row)
  var badge:=Label.new()
  badge.custom_minimum_size.x=28
  badge.add_theme_font_size_override("font_size",12)
  row.add_child(badge)
  var name_label:=Label.new()
  name_label.text=weapon.display_name
  name_label.tooltip_text=weapon.display_name
  name_label.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
  name_label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
  name_label.add_theme_font_size_override("font_size",12)
  row.add_child(name_label)
  var status:=Label.new()
  status.add_theme_font_size_override("font_size",11)
  row.add_child(status)
  entries.append({"index":i,"badge":badge,"status":status,"name":name_label})
 if entries.is_empty():
  var empty:=Label.new()
  empty.text="No guns equipped"
  rows.add_child(empty)
func _process(_delta:float)->void:
 var player:Player=PlayerState.current_ship
 visible=is_instance_valid(player) and player.ship_data!=null and not player._is_docked
 if not visible:return
 turret_order.visible=not player.ship_data.turret_sizes.is_empty()
 if turret_order.selected!=player.turret_order:turret_order.select(player.turret_order)
 var key:=str(player.equipped_weapons)
 if key!=signature:signature=key;rebuild(player)
 heading.text="WEAPON CONTROL   •   GROUP %d   [1 / 2]" % player._active_fire_group
 for entry in entries:
  var i:int=entry.index
  var weapon:WeaponData=player.equipped_weapons[i]
  var group:int=player.weapon_fire_groups[i] if i<player.weapon_fire_groups.size() else 1
  entry.badge.text="T" if player.ship_data.mount_kind(i)=="Turret" else "G%d" % group
  entry.badge.add_theme_color_override("font_color",Color("67e8f9") if group==player._active_fire_group else Color("607789"))
  var cooldown:float=player._weapon_cooldowns[i] if i<player._weapon_cooldowns.size() else 0
  var status:String="READY"
  if weapon.uses_ammo:status="%d AMO" % player.inventory.get_amount(weapon.ammo_item_id)
  elif player.energy<weapon.energy_per_shot:status="LOW PWR"
  elif cooldown>0:status="CYCLING"
  entry.status.text=status
 var system=player.get_node_or_null("MissileSystem")
 var payload=system._get_equipped_missile() if system else null
 if payload:
  missile.text="%s  ×%d   |   %d / %d armed" % [payload.display_name,player.inventory.get_amount(payload.id),system.get_armed_count(),system.get_selected_count()]
  progress.value=100*(1-system._arm_timer/system._arm_total) if system._arm_total>0 and system._arm_timer>0 else (100 if system.get_armed_count()>0 else 0)
 else:missile.text="No missiles equipped";progress.value=0
 var targeting=get_tree().get_first_node_in_group("targeting_hud")
 var view:=get_viewport_rect().size
 var bottom:float=targeting.own_card.position.y-12 if targeting else view.y-280
 var factor:float=targeting.own_card.scale.x if targeting else 1.0
 scale=Vector2.ONE*factor
 scroll.custom_minimum_size.y=minf(rows.get_combined_minimum_size().y,minf(180,maxf(28,bottom/factor-140)))
 size=Vector2(320,get_combined_minimum_size().y)
 position=Vector2(16,maxf(16,bottom-size.y*factor))
 HUDLayout.apply_layout("Weapons",self)
