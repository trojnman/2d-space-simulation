class_name StationUI
extends CanvasLayer

## Full-screen station menu.

const BASE_SIZE             : Vector2 = Vector2(1920.0, 1080.0)
const PILOT_COST            : int     = 10000

const CARGO_SLOTS := {
	&"fighter": 5, &"hauler": 15, &"miner": 12, &"missile_boat": 6,
	&"medium_fighter": 10, &"medium_hauler": 30, &"medium_miner": 25,
	&"medium_missile_boat": 12, &"medium_logistics": 28,
	&"heavy_fighter": 15, &"heavy_hauler": 50, &"heavy_miner": 45,
	&"heavy_missile_boat": 20, &"large_logistics": 45,
}

const STATION_SHIP_TYPES := {
	"military":     ["fighter", "missile_boat", "medium_fighter", "medium_missile_boat",
					 "heavy_fighter", "heavy_missile_boat", "medium_logistics", "large_logistics"],
	"headquarters": ["fighter", "missile_boat", "medium_fighter", "medium_missile_boat",
					 "heavy_fighter", "heavy_missile_boat", "medium_logistics", "large_logistics"],
	"trade":        ["hauler", "medium_hauler", "heavy_hauler"],
	"mining":       ["miner", "medium_miner", "heavy_miner"],
}

const SHIP_PRICE_MULT := {
	"fighter":            1.0,
	"missile_boat":       1.0,
	"medium_fighter":     1.0,
	"medium_missile_boat":1.0,
	"heavy_fighter":      1.0,
	"heavy_missile_boat": 1.0,
	"medium_logistics":   0.8,
	"large_logistics":    0.8,
	"hauler":             0.65,
	"medium_hauler":      0.65,
	"heavy_hauler":       0.65,
	"miner":              0.5,
	"medium_miner":       0.5,
	"heavy_miner":        0.5,
}

const SLOT_SIZE             : int   = 64
const STATION_STORAGE_SLOTS : int   = 50
const SLOT_BG_COLOR         : Color = Color(0.1,  0.12, 0.18, 0.9)
const SLOT_BORDER           : Color = Color(0.3,  0.35, 0.5,  0.8)
const EMPTY_COLOR           : Color = Color(0.06, 0.07, 0.10, 0.8)
const WEAPON_COLOR          : Color = Color(0.15, 0.08, 0.08, 0.95)
const SHIELD_COLOR          : Color = Color(0.08, 0.08, 0.18, 0.95)
const MISSILE_COLOR         : Color = Color(0.08, 0.15, 0.08, 0.95)
const HANGAR_SHIP_COLOR     : Color = Color(0.08, 0.12, 0.2,  0.95)
const HANGAR_PILOTED_COLOR  : Color = Color(0.05, 0.18, 0.1,  0.95)

var _station               : StationInstance = null
var _player                : Player          = null
var _selected_hangar_index : int             = -1
var _hangar_slots          : Array           = []

@onready var station_name_label : Label        = $Panel/VBoxContainer/Header/StationName
@onready var faction_label      : Label        = $Panel/VBoxContainer/Header/FactionName
@onready var credits_label      : Label        = $Panel/VBoxContainer/Header/Credits
@onready var undock_button      : Button       = $Panel/VBoxContainer/Header/UndockButton
@onready var tab_container      : TabContainer = $Panel/VBoxContainer/TabContainer
@onready var trade_tab          : Control      = $Panel/VBoxContainer/TabContainer/Trade/Content
@onready var shipyard_tab       : Control      = $Panel/VBoxContainer/TabContainer/Shipyard
@onready var repairs_tab        : Control      = $Panel/VBoxContainer/TabContainer/Repairs
@onready var missions_tab       : Control      = $Panel/VBoxContainer/TabContainer/Missions
@onready var storage_tab        : Control      = $Panel/VBoxContainer/TabContainer/Storage
@onready var manufacture_tab    : Control      = $Panel/VBoxContainer/TabContainer/Manufacture/Content
@onready var hangar_tab         : Control      = $Panel/VBoxContainer/TabContainer/Hangar
@onready var _root_panel        : Control      = $Panel


# ===========================================================================
# InteractablePanel
# ===========================================================================
class InteractablePanel extends PanelContainer:
	var _base_color  : Color        = Color(0.1, 0.12, 0.18, 0.9)
	var _is_selected : bool         = false
	var _style       : StyleBoxFlat = null

	func setup_style(base_color: Color, border_color: Color, corner_radius: int = 4,
			margin_h: float = 8.0, margin_v: float = 6.0, min_height: float = 36.0) -> void:
		_base_color = base_color
		_style = StyleBoxFlat.new()
		_style.bg_color              = base_color
		_style.border_color          = border_color
		_style.set_border_width_all(1)
		_style.set_corner_radius_all(corner_radius)
		_style.content_margin_left   = margin_h
		_style.content_margin_right  = margin_h
		_style.content_margin_top    = margin_v
		_style.content_margin_bottom = margin_v
		add_theme_stylebox_override("panel", _style)
		custom_minimum_size   = Vector2(0, min_height)
		size_flags_horizontal = Control.SIZE_EXPAND_FILL
		mouse_entered.connect(_on_hover_enter)
		mouse_exited.connect(_on_hover_exit)

	func set_selected(selected: bool) -> void:
		_is_selected = selected
		if not _style: return
		if selected:
			_style.bg_color     = _base_color.lightened(0.35)
			_style.border_color = Color(0.3, 0.8, 1.0, 1.0)
			_style.set_border_width_all(2)
		else:
			_style.bg_color     = _base_color
			_style.border_color = Color(0.3, 0.35, 0.5, 0.8)
			_style.set_border_width_all(1)

	func _on_hover_enter() -> void:
		if _is_selected or not _style: return
		_style.bg_color     = _base_color.lightened(0.2)
		_style.border_color = Color(0.5, 0.6, 0.9, 1.0)

	func _on_hover_exit() -> void:
		if _is_selected or not _style: return
		_style.bg_color     = _base_color
		_style.border_color = Color(0.3, 0.35, 0.5, 0.8)


func _ready() -> void:
	preload("res://scripts/ConsoleTheme.gd").apply_to(self)
	$Background.color = Color(0.015, 0.025, 0.045, 0.97)
	$Panel/VBoxContainer/Header.custom_minimum_size.y = 64
	station_name_label.add_theme_font_size_override("font_size", 23)
	station_name_label.add_theme_color_override("font_color", Color("56dfeb"))
	undock_button.text = "DEPART  >"
	if undock_button:
		undock_button.pressed.connect(_on_undock_pressed)
	PlayerState.credits_changed.connect(_on_credits_changed)
	hide()
	get_viewport().size_changed.connect(_on_viewport_resized)
	await get_tree().process_frame
	_on_viewport_resized()


func _on_viewport_resized() -> void:
	if not _root_panel: return
	_root_panel.scale = Vector2.ONE
	_root_panel.pivot_offset = Vector2.ZERO
	_root_panel.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	_root_panel.offset_left = 12
	_root_panel.offset_top = 12
	_root_panel.offset_right = -12
	_root_panel.offset_bottom = -12



func open(station: StationInstance, player: Player) -> void:
	_station               = station
	_player                = player
	_selected_hangar_index = -1
	if not tab_container.has_node("Faction"):
		var membership := preload("res://scripts/FactionMembershipPanel.gd").new()
		membership.name = "Faction"
		membership.station = station
		tab_container.add_child(membership)
	if station.station_data.station_type == StationData.TYPE_SHIPYARD and not tab_container.has_node("Expansion"):
		var expansion := preload("res://scripts/StationConstructionPanel.gd").new()
		expansion.name = "Expansion"
		expansion.station = station
		tab_container.add_child(expansion)
	if station.faction_id == &"player" and not tab_container.has_node("Warehouse"):
		var warehouse := preload("res://scripts/OwnedWarehousePanel.gd").new()
		warehouse.name = "Warehouse"
		warehouse.station = station
		warehouse.player = player
		tab_container.add_child(warehouse)
	_hangar_slots.clear()
	_populate_header()
	_populate_trade()
	_populate_shipyard()
	_populate_repairs()
	_populate_storage()
	_populate_manufacture()
	_populate_hangar()
	show()


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------

func _populate_header() -> void:
	if not _station or not _station.station_data: return
	if station_name_label:
		station_name_label.text = _station.station_data.display_name.to_upper()
	if faction_label:
		var faction := GameData.get_faction(_station.faction_id)
		faction_label.text = "Your faction" if _station.faction_id == &"player" else (faction.display_name if faction else "Independent")
	_update_credits_label()

func _update_credits_label() -> void:
	if credits_label:
		credits_label.text = "$%d  |  Cargo %.1f / %.1f" % [PlayerState.credits, _player.inventory.get_used_capacity(GameData.items) if _player else 0.0, _player.inventory.capacity if _player else 0.0]

func _on_credits_changed(_new_amount: int) -> void:
	_update_credits_label()


# ---------------------------------------------------------------------------
# Trade tab
# ---------------------------------------------------------------------------

const MAX_TRADE_QUANTITY := 100000
var _trade_rows: VBoxContainer
var _trade_controls: Dictionary = {}

func _populate_trade() -> void:
	if not trade_tab or not _station.station_data: return
	if not is_instance_valid(_trade_rows):
		var hint := Label.new()
		hint.text = "Choose a quantity beside each item. Buy and sell prices are batch totals."
		trade_tab.add_child(hint)
		_trade_rows = VBoxContainer.new()
		trade_tab.add_child(_trade_rows)
		_trade_rows.add_child(_make_trade_row("Item", "Stock", "Buy total", "Sell total", "Yours", true))
	for item_id in GameData.items:
		var supported: bool = _station._station_sells_item(item_id) or _station._station_buys_item(item_id)
		if not supported:
			if _trade_controls.has(item_id): _trade_controls[item_id].row.hide()
			continue
		if not _trade_controls.has(item_id):
			var item: ItemData = GameData.get_item(item_id)
			if not item: continue
			var row := _make_trade_row(item.display_name, "", "", "", "", false)
			var quantity := HBoxContainer.new()
			row.add_child(quantity)
			var decrease := Button.new()
			decrease.text = "<"
			decrease.tooltip_text = "Decrease quantity"
			quantity.add_child(decrease)
			var input := LineEdit.new()
			input.text = "1"
			input.custom_minimum_size.x = 90
			input.alignment = HORIZONTAL_ALIGNMENT_CENTER
			input.tooltip_text = "Quantity (1 to 100000)"
			quantity.add_child(input)
			var increase := Button.new()
			increase.text = ">"
			increase.tooltip_text = "Increase quantity"
			quantity.add_child(increase)
			var buy := Button.new()
			buy.text = "Buy"
			row.add_child(buy)
			var sell := Button.new()
			sell.text = "Sell"
			row.add_child(sell)
			_trade_rows.add_child(row)
			_bind_trade_drag(row,item_id)
			_trade_controls[item_id] = {"row": row, "input": input, "decrease": decrease, "increase": increase, "buy": buy, "sell": sell}
			decrease.pressed.connect(_adjust_trade_quantity.bind(item_id, -1))
			increase.pressed.connect(_adjust_trade_quantity.bind(item_id, 1))
			input.text_changed.connect(func(_text: String): _refresh_trade_row(item_id))
			input.text_submitted.connect(func(_text: String): _commit_trade_quantity(item_id))
			input.focus_exited.connect(_commit_trade_quantity.bind(item_id))
			buy.pressed.connect(_on_buy_pressed.bind(item_id))
			sell.pressed.connect(_on_sell_pressed.bind(item_id))
		_trade_controls[item_id].row.show()
		_refresh_trade_row(item_id)

func _get_trade_quantity(item_id: StringName) -> int:
	var value: String = _trade_controls[item_id].input.text.strip_edges()
	if not value.is_valid_int(): return 0
	var amount := value.to_int()
	return amount if amount >= 1 and amount <= MAX_TRADE_QUANTITY else 0

func _commit_trade_quantity(item_id: StringName) -> void:
	var input: LineEdit = _trade_controls[item_id].input
	var value := input.text.strip_edges()
	input.text = str(clampi(value.to_int(), 1, MAX_TRADE_QUANTITY)) if value.is_valid_int() else "1"
	_refresh_trade_row(item_id)

func _adjust_trade_quantity(item_id: StringName, change: int) -> void:
	var amount := _get_trade_quantity(item_id)
	_trade_controls[item_id].input.text = str(clampi(maxi(1, amount) + change, 1, MAX_TRADE_QUANTITY))
	_refresh_trade_row(item_id)

func _refresh_trade_row(item_id: StringName) -> void:
	var controls: Dictionary = _trade_controls[item_id]
	var amount := _get_trade_quantity(item_id)
	var stock: int = _station.inventory.get_amount(item_id)
	var yours: int = _player.inventory.get_amount(item_id)
	var buy_price: int = _station.get_sell_price(item_id) * amount
	var sell_price: int = _station.get_buy_price(item_id) * amount
	controls.row.get_child(1).text = str(stock)
	controls.row.get_child(2).text = "$%d" % buy_price if amount > 0 else "--"
	controls.row.get_child(3).text = "$%d" % sell_price if amount > 0 else "--"
	controls.row.get_child(4).text = str(yours)
	controls.decrease.disabled = amount == 1
	controls.increase.disabled = amount == MAX_TRADE_QUANTITY
	controls.buy.disabled = amount == 0 or not _station._station_sells_item(item_id) or not PlayerState.can_afford(buy_price) or stock < amount or not _station._can_receive_trade(_player.inventory, item_id, amount)
	controls.sell.disabled = amount == 0 or not _station._station_buys_item(item_id) or yours < amount or _station.station_credits < sell_price or not _station._can_receive_trade(_station.inventory, item_id, amount)

func _make_trade_row(c1: String, c2: String, c3: String, c4: String, c5: String, is_header: bool) -> HBoxContainer:
	var row := HBoxContainer.new()
	row.custom_minimum_size.y = 42
	for text in [c1, c2, c3, c4, c5]:
		var lbl := Label.new()
		lbl.text = text
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		if is_header:
			lbl.text = text.to_upper()
			lbl.add_theme_color_override("font_color", Color("56dfeb"))
			lbl.add_theme_font_size_override("font_size", 14)
		row.add_child(lbl)
	return row

func _on_buy_pressed(item_id: StringName) -> void:
	var amount := _get_trade_quantity(item_id)
	if amount < 1: return
	_station.player_buy_item(item_id, amount, _player.inventory)
	_populate_trade()
	_populate_storage()

func _on_sell_pressed(item_id: StringName) -> void:
	var amount := _get_trade_quantity(item_id)
	if amount < 1: return
	_station.player_sell_item(item_id, amount, _player.inventory, PlayerState.credits)
	_populate_trade()
	_populate_storage()


# ---------------------------------------------------------------------------
# Shipyard tab
# ---------------------------------------------------------------------------

func _populate_shipyard() -> void:
	if not shipyard_tab: return
	for child in shipyard_tab.get_children(): child.queue_free()
	shipyard_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	shipyard_tab.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	var equip_panel := VBoxContainer.new()
	equip_panel.custom_minimum_size = Vector2(280, 0)
	equip_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	var equip_title := Label.new()
	equip_title.text = "Current Equipment"
	equip_title.add_theme_font_size_override("font_size", 15)
	equip_panel.add_child(equip_title)
	var hint_lbl := Label.new()
	hint_lbl.text = "Right-click to unequip to station storage"
	hint_lbl.add_theme_font_size_override("font_size", 10)
	hint_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	equip_panel.add_child(hint_lbl)
	if _player and _player.ship_data:
		var ship_lbl := Label.new()
		ship_lbl.text = "%s  [%s]" % [_player.ship_data.display_name, _class_label(_player.ship_data.ship_class)]
		ship_lbl.add_theme_font_size_override("font_size", 12)
		ship_lbl.add_theme_color_override("font_color", Color(0.6, 0.65, 0.75))
		equip_panel.add_child(ship_lbl)
		var w_header := Label.new()
		w_header.text = "Weapons"
		w_header.add_theme_color_override("font_color", Color(0.6, 0.7, 0.9))
		equip_panel.add_child(w_header)
		for i in _player.ship_data.weapon_slots:
			var w : WeaponData = _player.equipped_weapons[i] if i < _player.equipped_weapons.size() else null
			var slot := _make_equip_slot(w.display_name if w else "-- Empty --", WEAPON_COLOR, w != null)
			if w: slot.gui_input.connect(_on_unequip_weapon.bind(i))
			equip_panel.add_child(slot)
		var s_header := Label.new()
		s_header.text = "Shield"
		s_header.add_theme_color_override("font_color", Color(0.6, 0.7, 0.9))
		equip_panel.add_child(s_header)
		var sh    : ShieldData = _player.equipped_shield
		var sslot := _make_equip_slot(sh.display_name if sh else "-- Empty --", SHIELD_COLOR, sh != null)
		if sh: sslot.gui_input.connect(_on_unequip_shield)
		equip_panel.add_child(sslot)
		var m_header := Label.new()
		m_header.text = "Missiles"
		m_header.add_theme_color_override("font_color", Color(0.6, 0.7, 0.9))
		equip_panel.add_child(m_header)
		for i in _player.ship_data.missile_slots:
			var m : MissileData = _player.equipped_missiles[i] if i < _player.equipped_missiles.size() else null
			var mslot := _make_equip_slot(m.display_name if m else "-- Empty --", MISSILE_COLOR, m != null)
			if m: mslot.gui_input.connect(_on_unequip_missile.bind(i))
			equip_panel.add_child(mslot)
	shipyard_tab.add_child(equip_panel)
	shipyard_tab.add_child(VSeparator.new())

	var ships_panel := VBoxContainer.new()
	ships_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	ships_panel.size_flags_vertical   = Control.SIZE_EXPAND_FILL
	var ships_title := Label.new()
	ships_title.text = "Shipyard Build Orders"
	ships_title.add_theme_font_size_override("font_size", 15)
	ships_panel.add_child(ships_title)
	if _station.station_data.station_type == StationData.TYPE_SHIPYARD:
		var production_queue := preload("res://scripts/ShipProductionQueue.gd").new()
		production_queue.station = _station
		ships_panel.add_child(production_queue)
	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal  = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical    = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	ships_panel.add_child(scroll)
	var list := VBoxContainer.new()
	list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(list)

	var station_type  : String = _station.station_data.station_type if _station.station_data else "trade"
	var allowed_types: Array = GameData.ships.keys().filter(func(id): return _station.station_data.supports_ship(id)) if station_type == "shipyard" else []
	if allowed_types.is_empty():
		var unavailable := Label.new()
		unavailable.text = "Order ships at Terran Shipyard. Orders require materials and build time."
		list.add_child(unavailable)

	for ship_id in GameData.ships:
		var sd : ShipData = GameData.ships[ship_id]
		if not allowed_types.has(sd.id): continue
		var price_mult : float = SHIP_PRICE_MULT.get(str(sd.id), 1.0)
		var price: int = _station.get_ship_order_price(ship_id)
		var row_panel := InteractablePanel.new()
		row_panel.setup_style(Color(0.045, 0.10, 0.15, 0.95), SLOT_BORDER, 4, 8.0, 6.0, 60.0)
		var row      := HBoxContainer.new()
		var info_col := VBoxContainer.new()
		info_col.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var name_lbl := Label.new()
		name_lbl.text = "%s  [%s]" % [sd.display_name, _class_label(sd.ship_class)]
		name_lbl.add_theme_font_size_override("font_size", 13)
		info_col.add_child(name_lbl)
		var desc_lbl := Label.new()
		desc_lbl.text = sd.description
		desc_lbl.add_theme_font_size_override("font_size", 11)
		desc_lbl.add_theme_color_override("font_color", Color(0.6, 0.65, 0.75))
		desc_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
		info_col.add_child(desc_lbl)
		row.add_child(info_col)
		var right_col := VBoxContainer.new()
		right_col.custom_minimum_size = Vector2(120, 0)
		var price_lbl := Label.new()
		price_lbl.text = "$%d" % price
		price_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
		right_col.add_child(price_lbl)
		var buy_btn := Button.new()
		var problem: String = _station.get_ship_order_problem(ship_id)
		buy_btn.text = "Order Ship" if problem == "" else problem
		buy_btn.disabled = problem != ""
		buy_btn.pressed.connect(_on_buy_ship_pressed.bind(ship_id, price))
		right_col.add_child(buy_btn)
		var supply_btn := Button.new()
		var supply_active: bool = _station.requested_supply_ship == ship_id
		supply_btn.text = "Cancel supply request" if supply_active else "Request supplies"
		supply_btn.tooltip_text = "Choose one ship type for this yard to restock. Factories and haulers use real resources; this does not buy or reserve a ship."
		supply_btn.disabled = _station.get_ship_recipe(ship_id).is_empty() or not StationSpawner.SHIP_SCENES.has(ship_id)
		supply_btn.pressed.connect(_on_request_ship_supplies.bind(ship_id))
		right_col.add_child(supply_btn)
		if supply_active:
			var supply_status := Label.new()
			var missing := PackedStringArray()
			var recipe: Dictionary = _station.get_ship_recipe(ship_id)
			for item_id in recipe["inputs"]:
				var required: int = recipe["inputs"][item_id]
				var stocked: int = _station.inventory.get_amount(item_id)
				if stocked < required:
					missing.append("%s: %d / %d" % [GameData.items[item_id].display_name, stocked, required])
			supply_status.text = "Supplies ready — place order when ready" if missing.is_empty() else "Awaiting supplies:\n" + "\n".join(missing)
			supply_status.autowrap_mode = TextServer.AUTOWRAP_WORD
			info_col.add_child(supply_status)
		row.add_child(right_col)
		row_panel.add_child(row)
		list.add_child(row_panel)
		list.add_child(HSeparator.new())
	shipyard_tab.add_child(ships_panel)


func _on_unequip_weapon(event: InputEvent, slot_idx: int) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_RIGHT: return
	if slot_idx >= _player.equipped_weapons.size(): return
	var w : WeaponData = _player.equipped_weapons[slot_idx]
	if not w: return
	_player.equipped_weapons[slot_idx] = null
	_player._refresh_visuals()
	var station_id : StringName = _station.station_data.id if _station.station_data else &""
	PlayerState.station_storage_add(station_id, w.id, 1)
	_populate_shipyard()
	_populate_storage()

func _on_unequip_shield(event: InputEvent) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_RIGHT: return
	if not _player.equipped_shield: return
	var s := _player.equipped_shield
	_player.equipped_shield = null
	_player._apply_shield()
	_player._refresh_visuals()
	var station_id : StringName = _station.station_data.id if _station.station_data else &""
	PlayerState.station_storage_add(station_id, s.id, 1)
	_populate_shipyard()
	_populate_storage()

func _on_unequip_missile(event: InputEvent, slot_idx: int) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_RIGHT: return
	if slot_idx >= _player.equipped_missiles.size(): return
	var m : MissileData = _player.equipped_missiles[slot_idx]
	if not m: return
	_player.equipped_missiles[slot_idx] = null
	_player._refresh_visuals()
	var station_id : StringName = _station.station_data.id if _station.station_data else &""
	PlayerState.station_storage_add(station_id, m.id, 1)
	_populate_shipyard()
	_populate_storage()

func _on_request_ship_supplies(ship_id: StringName) -> void:
	if _station.requested_supply_ship == ship_id:
		_station.requested_supply_ship = &""
	else:
		_station.request_ship_supplies(ship_id)
	_populate_shipyard()


func _on_buy_ship_pressed(ship_id: StringName, price: int) -> void:
	if not _station.order_player_ship(ship_id): return
	_populate_shipyard()
	_populate_hangar()
	_update_credits_label()


# ---------------------------------------------------------------------------
# Hangar tab
# ---------------------------------------------------------------------------

func _populate_hangar(preserve_selection: int = -1) -> void:
	if not hangar_tab: return
	for child in hangar_tab.get_children():
		hangar_tab.remove_child(child)
		child.queue_free()
	_hangar_slots.clear()
	hangar_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	hangar_tab.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	var station_id : StringName = _station.station_data.id if _station.station_data else &""
	var hangar     : Array      = PlayerState.get_station_hangar(station_id)

	var list_panel := VBoxContainer.new()
	list_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	list_panel.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	var title := Label.new()
	title.text = "Ship Hangar"
	title.add_theme_font_size_override("font_size", 15)
	list_panel.add_child(title)

	var hint := Label.new()
	hint.text = "Left-click to select  •  Right-click piloted ship to undock"
	hint.add_theme_font_size_override("font_size", 10)
	hint.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	list_panel.add_child(hint)

	var scroll := ScrollContainer.new()
	scroll.size_flags_horizontal  = Control.SIZE_EXPAND_FILL
	scroll.size_flags_vertical    = Control.SIZE_EXPAND_FILL
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	list_panel.add_child(scroll)

	var ship_list := VBoxContainer.new()
	ship_list.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	scroll.add_child(ship_list)

	if hangar.is_empty():
		var empty_lbl := Label.new()
		empty_lbl.text = "No ships in hangar."
		empty_lbl.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
		ship_list.add_child(empty_lbl)
	else:
		for i in hangar.size():
			var entry      : Dictionary = hangar[i]
			var sd         : ShipData   = GameData.get_ship(entry["ship_data_id"])
			var is_piloted : bool       = entry["has_pilot"]
			var slot                    = _make_hangar_slot(sd, is_piloted, i, station_id)
			ship_list.add_child(slot)
			_hangar_slots.append(slot)

	hangar_tab.add_child(list_panel)
	hangar_tab.add_child(VSeparator.new())

	var action_panel := VBoxContainer.new()
	action_panel.custom_minimum_size = Vector2(220, 0)
	action_panel.size_flags_vertical = Control.SIZE_EXPAND_FILL
	action_panel.name                = "ActionPanel"

	var action_title := Label.new()
	action_title.text = "Actions"
	action_title.add_theme_font_size_override("font_size", 15)
	action_panel.add_child(action_title)

	var select_hint := Label.new()
	select_hint.text = "Select a ship to enable actions."
	select_hint.add_theme_font_size_override("font_size", 11)
	select_hint.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	select_hint.autowrap_mode = TextServer.AUTOWRAP_WORD
	select_hint.name          = "SelectHint"
	action_panel.add_child(select_hint)

	var pilot_btn      := Button.new()
	pilot_btn.name     = "PilotBtn"
	pilot_btn.text     = "Buy Pilot  ($%d)" % PILOT_COST
	pilot_btn.disabled = true
	pilot_btn.pressed.connect(_on_buy_pilot_pressed)
	action_panel.add_child(pilot_btn)

	var swap_btn      := Button.new()
	swap_btn.name     = "SwapBtn"
	swap_btn.text     = "Swap to This Ship"
	swap_btn.disabled = true
	swap_btn.pressed.connect(_on_swap_ship_pressed)
	action_panel.add_child(swap_btn)

	hangar_tab.add_child(action_panel)

	# Keep selection through refreshes, and select the first completed ship by default.
	if preserve_selection < 0:
		preserve_selection = _selected_hangar_index if _selected_hangar_index >= 0 and _selected_hangar_index < hangar.size() else 0
	_last_hangar_count = hangar.size()
	## Restore previous selection if valid
	if preserve_selection >= 0 and preserve_selection < hangar.size():
		_selected_hangar_index = preserve_selection
		for i in _hangar_slots.size():
			var s := _hangar_slots[i] as InteractablePanel
			if s: s.set_selected(i == preserve_selection)
		var entry    : Dictionary = hangar[preserve_selection]
		var sel_ship : ShipData   = GameData.get_ship(entry.get("ship_data_id", &""))
		var sel_hint : Label      = action_panel.get_node_or_null("SelectHint")
		var pbtn     : Button     = action_panel.get_node_or_null("PilotBtn")
		var sbtn     : Button     = action_panel.get_node_or_null("SwapBtn")
		if sel_hint: sel_hint.text = "Selected: %s" % (sel_ship.display_name if sel_ship else "?")
		if pbtn:     pbtn.disabled = entry.get("has_pilot", false) or not PlayerState.can_afford(PILOT_COST)
		if sbtn:     sbtn.disabled = false
	else:
		_selected_hangar_index = -1


func _make_hangar_slot(sd: ShipData, is_piloted: bool, index: int, station_id: StringName) -> InteractablePanel:
	var base_color : Color = HANGAR_PILOTED_COLOR if is_piloted else HANGAR_SHIP_COLOR
	var panel      := InteractablePanel.new()
	panel.setup_style(base_color, SLOT_BORDER, 4, 10.0, 8.0, 60.0)
	var hbox := HBoxContainer.new()
	hbox.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var info := VBoxContainer.new()
	info.mouse_filter = Control.MOUSE_FILTER_IGNORE
	info.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var name_lbl := Label.new()
	name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	name_lbl.text = sd.display_name if sd else "Unknown Ship"
	name_lbl.add_theme_font_size_override("font_size", 13)
	info.add_child(name_lbl)
	var class_lbl := Label.new()
	class_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
	class_lbl.text = "[%s]%s" % [_class_label(sd.ship_class) if sd else "?",
		"  ✦ PILOTED" if is_piloted else ""]
	class_lbl.add_theme_font_size_override("font_size", 11)
	class_lbl.add_theme_color_override("font_color",
		Color(0.3, 0.9, 0.5) if is_piloted else Color(0.6, 0.65, 0.75))
	info.add_child(class_lbl)
	hbox.add_child(info)
	panel.add_child(hbox)
	panel.gui_input.connect(_on_hangar_slot_input.bind(index, is_piloted, station_id))
	return panel


func _on_hangar_slot_input(event: InputEvent, index: int, is_piloted: bool, station_id: StringName) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed: return
	if mb.button_index == MOUSE_BUTTON_LEFT:
		_selected_hangar_index = index
		for i in _hangar_slots.size():
			var slot := _hangar_slots[i] as InteractablePanel
			if slot: slot.set_selected(i == index)
		var action_panel := hangar_tab.get_node_or_null("ActionPanel")
		if not action_panel: return
		var hangar    : Array      = PlayerState.get_station_hangar(station_id)
		var entry     : Dictionary = hangar[index] if index < hangar.size() else {}
		var pilot_btn : Button     = action_panel.get_node_or_null("PilotBtn")
		var swap_btn  : Button     = action_panel.get_node_or_null("SwapBtn")
		var sel_hint  : Label      = action_panel.get_node_or_null("SelectHint")
		var sel_ship  : ShipData   = GameData.get_ship(entry.get("ship_data_id", &""))
		if sel_hint:  sel_hint.text      = "Selected: %s" % (sel_ship.display_name if sel_ship else "?")
		if pilot_btn: pilot_btn.disabled = entry.get("has_pilot", false) or not PlayerState.can_afford(PILOT_COST)
		if swap_btn:  swap_btn.disabled  = false
	elif mb.button_index == MOUSE_BUTTON_RIGHT and is_piloted:
		_on_undock_hangar_ship(index, station_id)


func _on_buy_pilot_pressed() -> void:
	if _selected_hangar_index < 0: return
	var station_id : StringName = _station.station_data.id if _station.station_data else &""
	var prev_index : int        = _selected_hangar_index
	if PlayerState.hangar_buy_pilot(station_id, _selected_hangar_index):
		FactionManager.civilian_credits += PILOT_COST
		_populate_hangar(prev_index)
		_update_credits_label()


func _on_swap_ship_pressed() -> void:
	if _selected_hangar_index < 0: return
	var station_id : StringName = _station.station_data.id if _station.station_data else &""
	if PlayerState.hangar_swap_to_ship(station_id, _selected_hangar_index, _player):
		_populate_hangar()
		_populate_shipyard()
		_update_credits_label()


func _on_undock_hangar_ship(index: int, station_id: StringName) -> void:
	var hangar : Array = PlayerState.get_station_hangar(station_id)
	if index >= hangar.size(): return
	var entry  : Dictionary = hangar[index]
	if not entry.get("has_pilot", false): return


	var ship_id    : StringName = entry["ship_data_id"]
	var scene_path : String     = StationSpawner.SHIP_SCENES.get(ship_id, "")
	if scene_path == "":
		push_warning("StationUI: no scene for ship id '%s'" % ship_id)
		_populate_hangar()
		return

	var ship_scene : PackedScene = load(scene_path)
	if not ship_scene:
		push_warning("StationUI: could not load scene '%s'" % scene_path)
		_populate_hangar()
		return

	var ship_node : ShipInstance = ship_scene.instantiate() as ShipInstance
	if not ship_node:
		push_warning("StationUI: scene root is not ShipInstance for '%s'" % ship_id)
		_populate_hangar()
		return

	PlayerState.hangar_remove_ship(station_id, index)
	var sd : ShipData = GameData.get_ship(ship_id)
	ship_node.global_position = _station.global_position + Vector2(400, 0)
	ship_node.faction_id      = _player.faction_id if _player.get("faction_id") != null else &"terran_republic"
	ship_node.add_to_group("player_fleet")

	SectorManager.add_sector_entity(ship_node)

	if sd and ship_node.has_method("initialize"):
		ship_node.initialize(sd)

	PlayerState.restore_ship_entry(ship_node, entry)

	## Add AI controller
	var ai := AIShipController.new()
	ai.name = "AIShipController"
	ship_node.add_child(ai)

	_populate_hangar()


# ---------------------------------------------------------------------------
# Repairs tab
# ---------------------------------------------------------------------------

func _populate_repairs() -> void:
	if not repairs_tab: return
	for child in repairs_tab.get_children(): child.queue_free()
	if not _station.station_data.offers_repairs:
		var lbl := Label.new()
		lbl.text = "This station does not offer repairs."
		repairs_tab.add_child(lbl)
		return
	var cost : int = _station.get_repair_cost(_player)
	var info := Label.new()
	info.text = "Repairs require 1 hull part per 10 HP.\nHull: %.0f / %.0f\nRepair cost: $%d\nYour credits: $%d" % [
		_player.hull, _player.max_hull, cost, PlayerState.credits]
	repairs_tab.add_child(info)
	var btn := Button.new()
	btn.text     = "Repair ($%d)" % cost
	btn.disabled = cost == 0 or not PlayerState.can_afford(cost)
	btn.pressed.connect(_on_repair_pressed)
	repairs_tab.add_child(btn)

func _on_repair_pressed() -> void:
	_station.repair_ship(_player)
	_populate_repairs()


# ---------------------------------------------------------------------------
# Storage tab
# ---------------------------------------------------------------------------

func _populate_storage() -> void:
	if not storage_tab: return
	for child in storage_tab.get_children(): child.queue_free()
	storage_tab.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	storage_tab.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	var station_id : StringName = _station.station_data.id if _station.station_data else &""

	var player_panel := VBoxContainer.new()
	player_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	player_panel.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	var p_header := HBoxContainer.new()
	var p_title  := Label.new()
	p_title.text = "Your Cargo"
	p_title.add_theme_font_size_override("font_size", 15)
	p_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p_header.add_child(p_title)
	var slot_count : int = _get_slot_count(_player.ship_data.id if _player and _player.ship_data else &"")
	var p_items    : Dictionary = _player.inventory.get_all_items() if _player else {}
	var p_count    := Label.new()
	p_count.text   = "%d / %d slots" % [p_items.size(), slot_count]
	p_count.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	p_header.add_child(p_count)
	player_panel.add_child(p_header)

	var p_hint := Label.new()
	p_hint.text = "Drag to storage • Shift-click to split • Right-click: deposit one"
	p_hint.add_theme_font_size_override("font_size", 10)
	p_hint.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	player_panel.add_child(p_hint)

	var p_scroll := ScrollContainer.new()
	p_scroll.size_flags_horizontal  = Control.SIZE_EXPAND_FILL
	p_scroll.size_flags_vertical    = Control.SIZE_EXPAND_FILL
	p_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	player_panel.add_child(p_scroll)

	var p_grid := GridContainer.new()
	p_grid.columns = 5
	p_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	p_scroll.add_child(p_grid)

	var p_item_list : Array = []
	for item_id in p_items: p_item_list.append({"id": item_id, "amount": p_items[item_id]})
	for entry in p_item_list:
		var item_id : StringName = entry["id"]
		var amount  : int        = entry["amount"]
		var item    : ItemData   = GameData.get_item(item_id)
		var slot                 = _make_cargo_slot(item_id, amount, item, true)
		slot.gui_input.connect(_on_cargo_deposit_input.bind(station_id, item_id))
		p_grid.add_child(slot)
		_bind_storage_drag(slot,item_id,amount,true)
	for i in (slot_count - p_item_list.size()):
		var empty=_make_empty_cargo_slot()
		p_grid.add_child(empty)
		_bind_storage_drag(empty,&"",0,true)
	storage_tab.add_child(player_panel)
	storage_tab.add_child(VSeparator.new())

	var stored     : Dictionary = PlayerState.get_station_storage(station_id)
	var stor_panel := VBoxContainer.new()
	stor_panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stor_panel.size_flags_vertical   = Control.SIZE_EXPAND_FILL

	var stor_header := HBoxContainer.new()
	var stor_title  := Label.new()
	stor_title.text = "Station Storage"
	stor_title.add_theme_font_size_override("font_size", 15)
	stor_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stor_header.add_child(stor_title)
	var stor_count := Label.new()
	stor_count.text = "%d / %d slots" % [stored.size(), STATION_STORAGE_SLOTS]
	stor_count.horizontal_alignment = HORIZONTAL_ALIGNMENT_RIGHT
	stor_header.add_child(stor_count)
	stor_panel.add_child(stor_header)

	var stor_hint := Label.new()
	stor_hint.text = "Drag to cargo • Shift-click to split • Right-click: retrieve one"
	stor_hint.add_theme_font_size_override("font_size", 10)
	stor_hint.add_theme_color_override("font_color", Color(0.5, 0.5, 0.6))
	stor_panel.add_child(stor_hint)

	var stor_scroll := ScrollContainer.new()
	stor_scroll.size_flags_horizontal  = Control.SIZE_EXPAND_FILL
	stor_scroll.size_flags_vertical    = Control.SIZE_EXPAND_FILL
	stor_scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	stor_panel.add_child(stor_scroll)

	var stor_grid := GridContainer.new()
	stor_grid.columns = 5
	stor_grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	stor_scroll.add_child(stor_grid)

	for item_id in stored:
		var amount : int      = stored[item_id]
		var item   : ItemData = GameData.get_item(item_id)
		var slot              = _make_cargo_slot(item_id, amount, item, false)
		slot.gui_input.connect(_on_storage_retrieve_input.bind(station_id, item_id))
		stor_grid.add_child(slot)
		_bind_storage_drag(slot,item_id,amount,false)
	for i in (STATION_STORAGE_SLOTS - stored.size()):
		var empty=_make_empty_cargo_slot()
		stor_grid.add_child(empty)
		_bind_storage_drag(empty,&"",0,false)

	storage_tab.add_child(stor_panel)


func _on_cargo_deposit_input(event: InputEvent, station_id: StringName, item_id: StringName) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_RIGHT: return
	var stored : Dictionary = PlayerState.get_station_storage(station_id)
	if stored.size() >= STATION_STORAGE_SLOTS and not stored.has(item_id): return
	var amount : int = _player.inventory.get_amount(item_id) if mb.shift_pressed else 1
	if amount <= 0: return
	if _player.inventory.has_item(item_id, amount):
		_player.inventory.remove_item(item_id, amount)
		PlayerState.station_storage_add(station_id, item_id, amount)
		_populate_storage()

func _on_storage_retrieve_input(event: InputEvent, station_id: StringName, item_id: StringName) -> void:
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if not mb.pressed or mb.button_index != MOUSE_BUTTON_RIGHT: return
	var stored : Dictionary = PlayerState.get_station_storage(station_id)
	var amount : int        = stored.get(item_id, 0) if mb.shift_pressed else 1
	if amount <= 0: return
	if not _station._can_receive_trade(_player.inventory, item_id, amount): return
	if PlayerState.station_storage_remove(station_id, item_id, amount):
		_player.inventory.add_item(item_id, amount, GameData.items)
		_populate_storage()


# ---------------------------------------------------------------------------
# Manufacture tab
# ---------------------------------------------------------------------------

func _populate_manufacture() -> void:
	if not manufacture_tab: return
	for child in manufacture_tab.get_children():
		manufacture_tab.remove_child(child)
		child.queue_free()
	if not _station.station_data: return
	if _station.station_data.station_type == StationData.TYPE_SHIPYARD:
		var production_queue := preload("res://scripts/ShipProductionQueue.gd").new()
		production_queue.station = _station
		manufacture_tab.add_child(production_queue)
	var info := Label.new()
	if not _station.can_share_internal_info():
		info.text = "Internal production information is shared with friendly factions only."
		info.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		manufacture_tab.add_child(info)
		return
	info.text = "PRODUCTION STATUS  |  Faction funds: $%d" % _station.station_credits
	manufacture_tab.add_child(info)
	var hint := Label.new()
	hint.text = "Stock counts show available / required. Production uses real materials and pays workers."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	manufacture_tab.add_child(hint)
	var report := _station.get_production_report()
	if report.is_empty():
		var empty := Label.new()
		empty.text = "This station has no manufacturing facilities."
		manufacture_tab.add_child(empty)
	for entry in report:
		var card := PanelContainer.new()
		manufacture_tab.add_child(card)
		var column := VBoxContainer.new()
		card.add_child(column)
		var title := Label.new()
		title.text = "%s  —  %s" % [entry["name"], entry["state"]]
		title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		title.add_theme_color_override("font_color", Color("56dfeb") if entry["state"] in ["Producing", "Ready", "Ready to order"] else Color("e9c17b"))
		column.add_child(title)
		var detail := Label.new()
		detail.text = entry["detail"]
		detail.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		column.add_child(detail)
		var counts := Label.new()
		counts.text = "Stock %d / target %d  |  Worker cost $%d per batch" % [entry["stock"], entry["target"], entry["labor"]] if entry["target"] > 0 else "Worker cost $%d per build" % entry["labor"]
		counts.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		column.add_child(counts)

func _on_queue_manufacture_pressed(recipe: Dictionary) -> void:
	_station.queue_manufacture(recipe)
	_populate_manufacture()


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------

func _make_cargo_slot(item_id: StringName, amount: int, item: ItemData, is_player: bool) -> InteractablePanel:
	var panel := InteractablePanel.new()
	panel.setup_style(SLOT_BG_COLOR, SLOT_BORDER, 4, 4.0, 4.0, SLOT_SIZE)
	var vbox       := VBoxContainer.new()
	vbox.alignment  = BoxContainer.ALIGNMENT_CENTER
	vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	var display    : String = item.display_name if item else str(item_id)
	var name_lbl   := Label.new()
	name_lbl.text   = display
	name_lbl.add_theme_font_size_override("font_size", 10)
	name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	name_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	name_lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.95))
	vbox.add_child(name_lbl)
	var amt_lbl    := Label.new()
	amt_lbl.text    = "x%d" % amount
	amt_lbl.add_theme_font_size_override("font_size", 11)
	amt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	amt_lbl.add_theme_color_override("font_color", Color(0.6, 0.8, 1.0) if is_player else Color(0.8, 0.7, 0.4))
	vbox.add_child(amt_lbl)
	panel.add_child(vbox)
	return panel


func _make_empty_cargo_slot() -> PanelContainer:
	var panel := PanelContainer.new()
	var style := StyleBoxFlat.new()
	style.bg_color     = EMPTY_COLOR
	style.border_color = Color(0.2, 0.22, 0.3, 0.6)
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	panel.add_theme_stylebox_override("panel", style)
	panel.custom_minimum_size   = Vector2(0, SLOT_SIZE)
	panel.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	return panel


func _make_equip_slot(label_text: String, bg_color: Color, filled: bool) -> InteractablePanel:
	var panel := InteractablePanel.new()
	panel.setup_style(bg_color if filled else EMPTY_COLOR, SLOT_BORDER, 4, 8.0, 6.0, 36.0)
	var lbl := Label.new()
	lbl.text = label_text
	lbl.add_theme_font_size_override("font_size", 12)
	lbl.add_theme_color_override("font_color", Color(0.9, 0.9, 1.0) if filled else Color(0.4, 0.4, 0.5))
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	panel.add_child(lbl)
	return panel


func _class_label(ship_class: GlobalEnums.ShipClass) -> String:
	match ship_class:
		GlobalEnums.ShipClass.SMALL:  return "Small"
		GlobalEnums.ShipClass.MEDIUM: return "Medium"
		GlobalEnums.ShipClass.LARGE:  return "Large"
	return ""


func _get_slot_count(ship_id: StringName) -> int:
	return CARGO_SLOTS.get(ship_id, 10)


# ---------------------------------------------------------------------------
# Undock
# ---------------------------------------------------------------------------

func _on_undock_pressed() -> void:
	var docking_manager := get_tree().get_first_node_in_group("docking_manager")
	if docking_manager and docking_manager.has_method("_undock"):
		docking_manager._undock()


var _refresh_timer: float = 0.0
var _last_hangar_count: int = -1
func _process(delta: float) -> void:
	if not visible or not is_instance_valid(_station): return
	_refresh_timer += delta
	if _refresh_timer < 2.0: return
	_refresh_timer = 0.0
	_update_credits_label()
	_populate_trade()
	_populate_shipyard()
	_populate_manufacture()
	var count: int = PlayerState.get_station_hangar(_station.station_data.id).size()
	if count != _last_hangar_count:
		_last_hangar_count = count
		_populate_hangar()


func _bind_storage_drag(control:Control,item_id:StringName,amount:int,from_player:bool)->void:
	for child in control.find_children("*","Control",true,false):child.mouse_filter=Control.MOUSE_FILTER_IGNORE
	control.set_drag_forwarding(
		func(_point):
			if item_id==&"":return null
			var preview:=Label.new()
			preview.text="%s ×%d" % [GameData.get_item(item_id).display_name,amount]
			control.set_drag_preview(preview)
			return {"type":"storage_cargo","item_id":item_id,"amount":amount,"from_player":from_player,"station":_station},
		func(_point,data):return _valid_storage_drop(data,from_player),
		func(_point,data):_transfer_storage_drag(data,from_player))
	if amount>1:
		control.gui_input.connect(func(event):
			if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT and event.shift_pressed:
				_split_storage_stack(control,item_id,amount,from_player)
				control.accept_event())

func _valid_storage_drop(data,to_player:bool)->bool:
	if not data is Dictionary or data.get("type")!="storage_cargo":return false
	if not is_instance_valid(_station) or not is_instance_valid(_player) or not visible:return false
	return data.get("station")==_station and data.get("from_player")==not to_player

func _transfer_storage_drag(data,to_player:bool)->bool:
	if not _valid_storage_drop(data,to_player):return false
	var id:StringName=data.item_id
	var amount:int=int(data.amount)
	if amount<=0:return false
	var station_id:StringName=_station.station_data.id
	var stored:Dictionary=PlayerState.get_station_storage(station_id)
	if to_player:
		if int(stored.get(id,0))<amount or not _station._can_receive_trade(_player.inventory,id,amount):return false
		if not PlayerState.station_storage_remove(station_id,id,amount):return false
		_player.inventory.add_item(id,amount,GameData.items)
	else:
		if not _player.inventory.has_item(id,amount):return false
		if stored.size()>=STATION_STORAGE_SLOTS and not stored.has(id):return false
		_player.inventory.remove_item(id,amount)
		PlayerState.station_storage_add(station_id,id,amount)
	_populate_storage.call_deferred()
	return true

func _split_storage_stack(control:Control,id:StringName,amount:int,from_player:bool)->void:
	var dialog:=ConfirmationDialog.new()
	dialog.title="Split stack — choose quantity to drag"
	dialog.ok_button_text="Drag split stack"
	dialog.theme=preload("res://scripts/ConsoleTheme.gd").build()
	var quantity:=SpinBox.new()
	quantity.min_value=1
	quantity.max_value=amount
	quantity.value=maxi(1,int(amount/2))
	dialog.add_child(quantity)
	add_child(dialog)
	dialog.confirmed.connect(func():
		var count:int=int(quantity.value)
		dialog.hide()
		if is_instance_valid(control):
			var preview:=Label.new()
			preview.text="%s ×%d" % [GameData.get_item(id).display_name,count]
			control.force_drag.call_deferred({"type":"storage_cargo","item_id":id,"amount":count,"from_player":from_player,"station":_station},preview)
		dialog.queue_free())
	dialog.canceled.connect(dialog.queue_free)
	dialog.popup_centered(Vector2i(360,100))


func _bind_trade_drag(row:HBoxContainer,id:StringName)->void:
	for column in [1,4]:
		var from_player:bool=column==4
		var cell:Control=row.get_child(column)
		cell.tooltip_text="Drag between station stock and your cargo to trade; Shift-click to choose quantity. Normal prices apply."
		preload("res://scripts/CargoDrag.gd").bind(cell,
			func():return {"type":"trade_cargo","item_id":id,"amount":(_player.inventory if from_player else _station.inventory).get_amount(id),"from_player":from_player,"station":_station},
			func(data):return data is Dictionary and data.get("type")=="trade_cargo" and data.get("station")==_station and data.get("from_player")!=from_player,
			func(data):
				if not visible:return
				if from_player:_station.player_buy_item(data.item_id,int(data.amount),_player.inventory)
				else:_station.player_sell_item(data.item_id,int(data.amount),_player.inventory,PlayerState.credits)
				_populate_trade.call_deferred()
				_populate_storage.call_deferred())
