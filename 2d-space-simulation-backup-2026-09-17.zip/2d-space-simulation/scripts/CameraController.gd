class_name CameraController
extends Camera2D

## Attach to the Camera2D inside the Player scene.
## Smooth zoom with mouse wheel. Blocked when game is paused.

const ZOOM_MIN  : float = 0.3
const ZOOM_MAX  : float = 4.5
const ZOOM_STEP : float = 0.1

@export var zoom_speed : float = 10.0

var _target_zoom : Vector2 = Vector2(0.5, 0.5)


func _ready() -> void:
	make_current()
	_target_zoom = zoom


func _process(delta: float) -> void:
	zoom = zoom.lerp(_target_zoom, zoom_speed * delta)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
		if preload("res://scripts/UIInput.gd").over_menu(get_viewport()):return
		var player := get_tree().get_first_node_in_group("player")
		var missiles := player.get_node_or_null("MissileSystem") if player else null
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) or (missiles and missiles.is_arm_button_held()): return

	if get_tree().paused: return

	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_WHEEL_UP:
			_target_zoom = (_target_zoom * (1.0 + ZOOM_STEP)).clamp(
				Vector2(ZOOM_MIN, ZOOM_MIN), Vector2(ZOOM_MAX, ZOOM_MAX)
			)
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_target_zoom = (_target_zoom * (1.0 - ZOOM_STEP)).clamp(
				Vector2(ZOOM_MIN, ZOOM_MIN), Vector2(ZOOM_MAX, ZOOM_MAX)
			)
