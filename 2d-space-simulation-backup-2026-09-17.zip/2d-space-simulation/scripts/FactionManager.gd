extends Node

## FactionManager — Autoload singleton.
## Tracks live faction-vs-faction relations, territory, and faction strategic state.
## Add to Project → Autoload as "FactionManager".

signal faction_relation_changed(faction_a: StringName, faction_b: StringName, new_value: float)
signal faction_war_declared(attacker: StringName, defender: StringName)
signal faction_peace_declared(faction_a: StringName, faction_b: StringName)
signal station_captured(station_id: StringName, new_faction_id: StringName)
signal faction_defeated(faction_id: StringName)

## Live relation matrix: { "faction_a:faction_b" → float }
var _relations : Dictionary = {}

## Territory: station_id → faction_id
var _territory : Dictionary = {}

## Faction strategic state: faction_id → Dictionary
var _faction_state : Dictionary = {}
var civilian_credits: int = 0
var _defeated_factions: Array = []
var diplomacy_time: float = 0.0
var diplomacy_pairs: Dictionary = {}
var diplomacy_events: Array = []
var _sector_ownership: Dictionary = {}
var _initial_sector_owners: Dictionary = {}

## Strategic think interval
const STRATEGY_INTERVAL : float = 30.0
var _strategy_timer     : float = 0.0


func _ready() -> void:
	await get_tree().process_frame
	_init_relations()
	_init_territory()
	_init_faction_states()


func _process(delta: float) -> void:
	_strategy_timer += delta
	if _strategy_timer >= STRATEGY_INTERVAL:
		_strategy_timer = 0.0
		_run_faction_strategy()


# ---------------------------------------------------------------------------
# Initialization
# ---------------------------------------------------------------------------

func _init_relations() -> void:
	for faction_id in GameData.factions:
		var faction : FactionData = GameData.factions[faction_id]
		for other_id in faction.base_relations:
			_set_relation_raw(faction_id, other_id, faction.base_relations[other_id])


func _init_territory() -> void:
	for id in GameData.sectors: _initial_sector_owners[id] = GameData.sectors[id].controlling_faction_id
	for sector_id in GameData.sectors:
		var sector : SectorData = GameData.sectors[sector_id]
		for station_id in sector.starting_stations:
			var station: StationData = GameData.stations.get(station_id)
			_territory[station_id] = station.faction_id if station and station.faction_id != &"" else sector.controlling_faction_id


func _init_faction_states() -> void:
	for faction_id in GameData.factions:
		var starting_funds: int = 20000
		for sector in GameData.sectors.values():
			for station_id in sector.starting_stations:
				if GameData.stations[station_id].faction_id == faction_id: starting_funds += 20000
		_faction_state[faction_id] = {
			"credits":        starting_funds,
			"owned_stations": [],
			"owned_ships":    [],
			"known_sectors":  [],
			"hq_station":     null,
		}


# ---------------------------------------------------------------------------
# Relations
# ---------------------------------------------------------------------------

func get_relation(faction_a: StringName, faction_b: StringName) -> float:
	if faction_a == faction_b: return 1.0
	var key := _make_key(faction_a, faction_b)
	return _relations.get(key, 0.0)


func set_relation(faction_a: StringName, faction_b: StringName, value: float) -> void:
	value = clampf(value, -1.0, 1.0)
	var was_at_war := are_at_war(faction_a, faction_b)
	_set_relation_raw(faction_a, faction_b, value)
	var now_at_war := are_at_war(faction_a, faction_b)
	faction_relation_changed.emit(faction_a, faction_b, value)
	if not was_at_war and now_at_war:
		faction_war_declared.emit(faction_a, faction_b)
		print("FactionManager: WAR declared — %s vs %s" % [faction_a, faction_b])
	elif was_at_war and not now_at_war:
		faction_peace_declared.emit(faction_a, faction_b)
		print("FactionManager: Peace — %s and %s" % [faction_a, faction_b])


func modify_relation(faction_a: StringName, faction_b: StringName, delta: float) -> void:
	set_relation(faction_a, faction_b, get_relation(faction_a, faction_b) + delta)


func are_at_war(faction_a: StringName, faction_b: StringName) -> bool:
	if faction_a == &"rogue" or faction_b == &"rogue": return true
	if faction_a == &"player": return PlayerState.is_hostile_to_player(faction_b)
	if faction_b == &"player": return PlayerState.is_hostile_to_player(faction_a)
	return get_relation(faction_a, faction_b) <= -0.5


func are_allied(faction_a: StringName, faction_b: StringName) -> bool:
	return get_relation(faction_a, faction_b) >= 0.5


func get_stance(faction_a: StringName, faction_b: StringName) -> GlobalEnums.FactionStance:
	var rel := get_relation(faction_a, faction_b)
	if rel <= -0.5: return GlobalEnums.FactionStance.HOSTILE
	if rel >=  0.5: return GlobalEnums.FactionStance.ALLIED
	if rel >=  0.1: return GlobalEnums.FactionStance.FRIENDLY
	return GlobalEnums.FactionStance.NEUTRAL


func _set_relation_raw(a: StringName, b: StringName, value: float) -> void:
	_relations[_make_key(a, b)] = clampf(value, -1.0, 1.0)


func _make_key(a: StringName, b: StringName) -> String:
	if str(a) < str(b): return "%s:%s" % [a, b]
	return "%s:%s" % [b, a]


# ---------------------------------------------------------------------------
# Territory
# ---------------------------------------------------------------------------

func get_station_faction(station_id: StringName) -> StringName:
	return _territory.get(station_id, &"")


func capture_station(station_id: StringName, new_faction_id: StringName) -> void:
	var old_faction := get_station_faction(station_id)
	_territory[station_id] = new_faction_id
	station_captured.emit(station_id, new_faction_id)
	print("FactionManager: Station %s captured by %s (was %s)" % [station_id, new_faction_id, old_faction])
	if old_faction != &"" and old_faction != new_faction_id:
		modify_relation(new_faction_id, old_faction, -0.3)


# ---------------------------------------------------------------------------
# Faction state tracking
# ---------------------------------------------------------------------------

func get_faction_credits(faction_id: StringName) -> int:
	if faction_id == &"player": return PlayerState.credits
	return _faction_state.get(faction_id, {}).get("credits", 0)


func add_faction_credits(faction_id: StringName, amount: int) -> void:
	if amount <= 0: return
	if not _faction_state.has(faction_id): return
	_faction_state[faction_id]["credits"] += amount
	record_treasury_change(faction_id, amount, "Faction income")


func spend_faction_credits(faction_id: StringName, amount: int) -> bool:
	if amount < 0: return false
	if not _faction_state.has(faction_id): return false
	if _faction_state[faction_id]["credits"] < amount: return false
	_faction_state[faction_id]["credits"] -= amount
	record_treasury_change(faction_id, -amount, "Faction spending")
	return true


func register_station(station: StationInstance) -> void:
	if _defeated_factions.has(station.faction_id) and station.faction_id != &"player":
		if station.station_data.station_type == &"defense_platform":
			station.faction_id=&"rogue"
			station.claim_faction_id=&""
		else:station.call_deferred("_destroy")
		return
	var fid : StringName = station.faction_id
	if not _faction_state.has(fid): return
	var owned : Array = _faction_state[fid]["owned_stations"]
	if not owned.has(station):
		owned.append(station)
	if station.station_data and station.station_data.station_type == StationData.TYPE_HEADQUARTERS:
		_faction_state[fid]["hq_station"] = station
	if station.station_data:
		_territory[station.station_data.id] = fid


func register_ship(ship: ShipInstance) -> void:
	if _defeated_factions.has(ship.faction_id) and ship.faction_id != &"player" and not ship.is_in_group("player_fleet") and not ship.is_in_group("player"):
		ship.faction_id=&"rogue"
	var fid : StringName = ship.faction_id
	if not _faction_state.has(fid): return
	var owned : Array = _faction_state[fid]["owned_ships"]
	if not owned.has(ship):
		owned.append(ship)


func unregister_ship(ship: ShipInstance) -> void:
	var fid : StringName = ship.faction_id
	if not _faction_state.has(fid): return
	_faction_state[fid]["owned_ships"].erase(ship)


func get_faction_stations(faction_id: StringName) -> Array:
	if not _faction_state.has(faction_id): return []
	var valid : Array = []
	for s in _faction_state[faction_id]["owned_stations"]:
		if is_instance_valid(s):
			valid.append(s)
	_faction_state[faction_id]["owned_stations"] = valid
	return valid


func get_faction_ships(faction_id: StringName) -> Array:
	if not _faction_state.has(faction_id): return []
	var valid : Array = []
	for s in _faction_state[faction_id]["owned_ships"]:
		if is_instance_valid(s):
			valid.append(s)
	_faction_state[faction_id]["owned_ships"] = valid
	return valid


func get_faction_hq(faction_id: StringName) -> StationInstance:
	if not _faction_state.has(faction_id): return null
	return _faction_state[faction_id].get("hq_station", null)


# ---------------------------------------------------------------------------
# Station destroyed
# ---------------------------------------------------------------------------

func on_station_destroyed(station: StationInstance, killer: Node) -> void:
	if station.faction_id == &"player" and station.station_data and station.station_data.station_type == StationData.TYPE_HEADQUARTERS:
		PlayerState.end_founded_faction()
		_collapse_assets(&"player")
	var region = preload("res://scripts/StationConstruction.gd").sector_of(station)
	if region and station.station_data and station.station_data.station_type in [&"claim_beacon", &"headquarters", &"military", &"defense_platform"]:
		recheck_sector_claim(region)
	var fid : StringName = station.faction_id
	if not _faction_state.has(fid): return

	_faction_state[fid]["owned_stations"].erase(station)
	_territory.erase(station.station_data.id if station.station_data else &"")

	if station.station_data and station.station_data.station_type == StationData.TYPE_HEADQUARTERS:
		_faction_state[fid]["hq_station"] = null
		_on_faction_hq_destroyed(fid, killer)
		return

	if killer and killer.is_in_group("player"):
		PlayerState.add_reputation(fid, -100.0)
		for other_id in GameData.factions:
			if other_id == fid: continue
			if are_at_war(fid, other_id):
				PlayerState.add_reputation(other_id, 30.0)
	elif killer and killer is ShipInstance:
		modify_relation(fid, killer.faction_id, -0.2)

	print("FactionManager: Station destroyed — faction %s lost a %s" % [
		fid,
		station.station_data.station_type if station.station_data else "unknown"
	])


func _on_faction_hq_destroyed(faction_id: StringName, killer: Node) -> void:
	if _defeated_factions.has(faction_id):return
	print("FactionManager: FACTION DEFEATED — %s HQ destroyed!" % faction_id)
	faction_defeated.emit(faction_id)

	_collapse_assets(faction_id)

	if killer and killer.is_in_group("player"):
		PlayerState.add_reputation(faction_id, -500.0)
		for other_id in GameData.factions:
			if other_id == faction_id: continue
			if are_at_war(faction_id, other_id):
				PlayerState.add_reputation(other_id, 100.0)


# ---------------------------------------------------------------------------
# Sector control
# ---------------------------------------------------------------------------

func check_sector_control(sector_id: StringName) -> StringName:
	var sector : SectorData = GameData.get_sector(sector_id)
	if not sector: return &""
	var faction_counts : Dictionary = {}
	for station in get_tree().get_nodes_in_group("stations"):
		if not station is StationInstance: continue
		if not is_instance_valid(station): continue
		if station.faction_id == &"": continue
		var count : int = faction_counts.get(station.faction_id, 0)
		faction_counts[station.faction_id] = count + 1
	if faction_counts.size() == 1:
		return faction_counts.keys()[0]
	return &""


# ---------------------------------------------------------------------------
# Faction strategy
# ---------------------------------------------------------------------------

var strategy_status:Dictionary={}

func _run_faction_strategy() -> void:
	advance_diplomacy(STRATEGY_INTERVAL)
	for faction_id in GameData.factions:
		_think_faction(faction_id)
	_plan_owned_expansion()


func _think_faction(faction_id: StringName) -> void:
	if not _faction_state.has(faction_id): return
	var hq : StationInstance = get_faction_hq(faction_id)
	if not is_instance_valid(hq): return

	var credits  : int   = get_faction_credits(faction_id)
	var stations : Array = get_faction_stations(faction_id).filter(func(s): return not s._is_destroyed)
	var ships    : Array = get_faction_ships(faction_id).filter(func(s): return not s._is_destroyed)

	var has_shipyard : bool = false
	for s in stations:
		if not is_instance_valid(s) or not s.station_data: continue
		if s.station_data.station_type == StationData.TYPE_SHIPYARD:
			has_shipyard = true

	# Physical cargo deliveries are handled by haulers; no instant stock transfers.
	_faction_manufacture(faction_id, stations)
	if has_shipyard:
		_faction_build_ships(faction_id, stations, ships)
	_faction_strategic_decisions(faction_id, ships, credits)


func _faction_trade(faction_id: StringName, stations: Array) -> void:
	for other_id in GameData.factions:
		if other_id == faction_id: continue
		if are_at_war(faction_id, other_id): continue
		var other_stations : Array = get_faction_stations(other_id)
		for other_station in other_stations:
			if not is_instance_valid(other_station): continue
			if not other_station.station_data: continue
			if other_station.station_data.station_type != StationData.TYPE_TRADE: continue
			for our_station in stations:
				if not is_instance_valid(our_station): continue
				if not our_station.station_data: continue
				if our_station.station_data.station_type != StationData.TYPE_MANUFACTURING: continue
				if other_station.inventory.has_item(&"electronics", 10):
					var price : int = other_station.get_sell_price(&"electronics") * 10
					if spend_faction_credits(faction_id, price):
						other_station.inventory.remove_item(&"electronics", 10)
						our_station.inventory.add_item(&"electronics", 10)
						add_faction_credits(other_id, price)


func _faction_manufacture(faction_id: StringName, stations: Array) -> void:
	for station in stations:
		if is_instance_valid(station): station._auto_queue_recipes()


func _faction_build_ships(faction_id: StringName, stations: Array, ships: Array) -> void:
	var combat_count : int = 0
	var miner_count  : int = 0
	var hauler_count: int = 0
	for ship in ships:
		if not is_instance_valid(ship) or not ship.ship_data: continue
		if ship.ship_data.id.contains("fighter") or ship.ship_data.id.contains("missile_boat"):
			combat_count += 1
		elif ship.ship_data.id.contains("miner"):
			miner_count += 1
		elif ship.ship_data.id.contains("hauler"):
			hauler_count += 1

	var building_replacements: Dictionary = {}
	# Count paid, unfinished ships so multiple yards do not order the same shortage.
	for station in stations:
		if not is_instance_valid(station): continue
		for job in station.get_manufacture_queue():
			if job.get("player_order", false): continue
			var owner = job.get("replacement_owner")
			if is_instance_valid(owner): building_replacements[owner] = true
			var output: String = str(job["recipe"].get("output_id", ""))
			if output.contains("miner"): miner_count += 1
			elif output.contains("hauler"): hauler_count += 1
			elif output.contains("fighter") or output.contains("missile_boat"): combat_count += 1

	# Pending replacements count toward fleet goals even before they can be funded.
	for station in stations:
		if not is_instance_valid(station) or station._is_destroyed: continue
		for spawner in station.get_children():
			if not spawner is StationSpawner: continue
			var start: int = 1 if building_replacements.has(spawner) else 0
			for i in range(start, spawner._replacement_requests.size()):
				var id: String = str(spawner._replacement_requests[i])
				if id.contains("miner"): miner_count += 1
				elif id.contains("hauler"): hauler_count += 1
				elif id.contains("fighter") or id.contains("missile_boat"): combat_count += 1

	var owned_sectors:int=0
	var threatened:bool=false
	for sector in GameData.sectors.values():
		if sector.controlling_faction_id==faction_id:owned_sectors+=1
	for other in GameData.factions:
		if not are_at_war(faction_id,other):continue
		for enemy in get_faction_ships(other):
			var sector=preload("res://scripts/StationConstruction.gd").sector_of(enemy)
			if not enemy._is_destroyed and sector and sector.sector_data.controlling_faction_id==faction_id:threatened=true
	var plan:Dictionary=preload("res://scripts/FactionStrategy.gd").choose(faction_id,owned_sectors,miner_count,hauler_count,combat_count,get_faction_credits(faction_id),threatened)
	strategy_status[faction_id]=plan
	if plan.role=="" or get_faction_credits(faction_id)<int(plan.reserve):return
	for station in stations:
		if station.station_data.station_type!=StationData.TYPE_SHIPYARD:continue
		if station.requested_supply_ship!=&"" or station.requested_station_blueprint!=&"" or not station.get_manufacture_queue().is_empty():continue
		var recipe:Dictionary=_find_ship_recipe(station,plan.role)
		if recipe.is_empty():continue
		var data:ShipData=GameData.ships.get(recipe.output_id)
		if not can_add_npc_ship(faction_id,data):continue
		# Publish demand even when currently short of materials; haulers service it.
		station.replacement_supply_ship=recipe.output_id
		if station.queue_manufacture(recipe):
			station.replacement_supply_ship=&""
			return


func _find_ship_recipe(shipyard: StationInstance, ship_id_contains: String) -> Dictionary:
	for recipe in shipyard.station_data.get_recipes():
		if str(recipe.get("output_id", &"")).contains(ship_id_contains):
			return recipe
	return {}


func _faction_strategic_decisions(faction_id: StringName, ships: Array, credits: int) -> void:
	var combat_ships : Array = []
	for ship in ships:
		if not is_instance_valid(ship) or not ship.ship_data: continue
		if ship.ship_data.id.contains("fighter") or ship.ship_data.id.contains("missile_boat"):
			combat_ships.append(ship)
	var group_size:int=preload("res://scripts/FactionDoctrine.gd").profile(faction_id).attack_group
	if group_size>0 and combat_ships.size() >= group_size:
		_consider_attack(faction_id, combat_ships)


func _consider_attack(faction_id: StringName, combat_ships: Array) -> void:
	for other_id in GameData.factions:
		if other_id == faction_id: continue
		if not are_at_war(faction_id, other_id): continue
		var enemy_stations : Array = get_faction_stations(other_id).filter(func(s): return not s._is_destroyed)
		if enemy_stations.is_empty(): continue
		var target     : StationInstance = null
		var lowest_hull : float          = INF
		for es in enemy_stations:
			if is_instance_valid(es) and es.hull < lowest_hull:
				lowest_hull = es.hull
				target = es
		if not target: continue
		var sector=preload("res://scripts/StationConstruction.gd").sector_of(target)
		var available:Array=[]
		var strength:float=0.0
		var opposition:float=maxf(0,target.hull)+maxf(0,target.shield)
		for ship in combat_ships:
			if preload("res://scripts/StationConstruction.gd").sector_of(ship)!=sector or ship.hull<ship.max_hull*0.7:continue
			available.append(ship)
		for enemy in get_faction_ships(other_id):
			if not enemy._is_destroyed and preload("res://scripts/StationConstruction.gd").sector_of(enemy)==sector:opposition+=maxf(0,enemy.hull)+maxf(0,enemy.shield)
		var attack_count:int=mini(available.size(),combat_ships.size()/2)
		for i in attack_count:strength+=available[i].hull+available[i].shield
		if attack_count<int(preload("res://scripts/FactionDoctrine.gd").profile(faction_id).attack_group) or strength<opposition*float(preload("res://scripts/FactionDoctrine.gd").profile(faction_id).advantage):continue
		var sent : int = 0
		for ship in available:
			if sent >= attack_count: break
			if not is_instance_valid(ship): continue
			if preload("res://scripts/StationConstruction.gd").sector_of(ship)!=preload("res://scripts/StationConstruction.gd").sector_of(target):continue
			var ai := ship.get_node_or_null("AIShipController") as AIShipController
			if ai:
				ai._target = target
				ai._set_state(AIShipController.State.ATTACK)
				sent += 1
		if sent > 0:
			print("FactionManager [%s]: sending %d ships to attack %s" % [faction_id, sent, target.name])
		return


# ---------------------------------------------------------------------------
# Reputation consequences
# ---------------------------------------------------------------------------

func player_killed_ship(victim_faction_id: StringName) -> void:
	if victim_faction_id == &"": return
	PlayerState.add_reputation(victim_faction_id, -50.0)
	for faction_id in GameData.factions:
		if faction_id == victim_faction_id: continue
		if are_at_war(faction_id, victim_faction_id):
			PlayerState.add_reputation(faction_id, 15.0)


func player_completed_mission(mission: MissionData) -> void:
	PlayerState.add_reputation(mission.issuing_faction_id, mission.reputation_reward)
	if mission.mission_type == GlobalEnums.MissionType.KILL:
		var target_faction : StringName = mission.objective.get("target_faction_id", &"")
		if target_faction != &"":
			PlayerState.add_reputation(target_faction, -mission.reputation_reward * 0.5)


func should_attack_player(faction_id: StringName) -> bool:
	return PlayerState.is_hostile_to_player(faction_id)


func should_attack(faction_a: StringName, faction_b: StringName) -> bool:
	if faction_b == &"player": return should_attack_player(faction_a)
	return are_at_war(faction_a, faction_b)


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

func get_all_relations_for(faction_id: StringName) -> Dictionary:
	var result : Dictionary = {}
	for faction_b in GameData.factions:
		if faction_b == faction_id: continue
		result[faction_b] = get_relation(faction_id, faction_b)
	return result


func get_player_stance(faction_id: StringName) -> GlobalEnums.FactionStance:
	var rep     : float       = PlayerState.get_reputation(faction_id)
	var faction : FactionData = GameData.get_faction(faction_id)
	if not faction: return GlobalEnums.FactionStance.NEUTRAL
	return faction.get_player_stance(rep)


const MAX_TREASURY_HISTORY := 200
var _treasury_history: Dictionary = {}
var _treasury_sequence: int = 0
func record_treasury_change(faction_id: StringName, delta: int, reason: String, station_name: String = "", counterparty: String = "") -> void:
	if delta == 0: return
	if not _treasury_history.has(faction_id): _treasury_history[faction_id] = []
	_treasury_sequence += 1
	_treasury_history[faction_id].append({"sequence": _treasury_sequence, "delta": delta, "reason": reason, "station": station_name, "counterparty": counterparty, "balance": get_faction_credits(faction_id)})
	if _treasury_history[faction_id].size() > MAX_TREASURY_HISTORY: _treasury_history[faction_id].pop_front()

func get_treasury_history(faction_id: StringName) -> Array:
	if not PlayerState.is_friendly_to_player(faction_id): return []
	return _treasury_history.get(faction_id, []).duplicate(true)


func purchase_cargo(buyer: ShipInstance, seller: StationInstance, item_id: StringName, amount: int) -> bool:
	# Settle at pickup, not when planning a route. Payment and cargo change together.
	if not is_instance_valid(buyer) or not is_instance_valid(seller) or buyer._is_destroyed or seller._is_destroyed: return false
	if amount <= 0 or buyer.faction_id == seller.faction_id or are_at_war(buyer.faction_id, seller.faction_id): return false
	if (buyer.faction_id != &"player" and not _faction_state.has(buyer.faction_id)) or (seller.faction_id != &"player" and not _faction_state.has(seller.faction_id)): return false
	if buyer.global_position.distance_to(seller.global_position) > seller.get_docking_range(): return false
	if not seller.can_export_to_traders(item_id) or not seller.inventory.has_item(item_id, amount): return false
	if seller.faction_id == &"player" and seller.inventory.get_amount(item_id) - amount < seller.get_export_reserve(item_id): return false
	var unit_price: int = seller.get_sell_price(item_id)
	if unit_price <= 0: return false
	var price: int = unit_price * amount
	if get_faction_credits(buyer.faction_id) < price: return false
	if not buyer.inventory.add_item(item_id, amount, GameData.items): return false
	seller.inventory.remove_item(item_id, amount)
	if buyer.faction_id == &"player": PlayerState.spend_credits(price)
	else: _faction_state[buyer.faction_id]["credits"] -= price
	if seller.faction_id == &"player": PlayerState.add_credits(price)
	else: _faction_state[seller.faction_id]["credits"] += price
	var label := "%d %s" % [amount, str(item_id).replace("_", " ")]
	record_treasury_change(buyer.faction_id, -price, "Cargo purchase: " + label, seller.station_data.display_name, str(seller.faction_id))
	record_treasury_change(seller.faction_id, price, "Cargo sale: " + label, seller.station_data.display_name, str(buyer.faction_id))
	return true


func _plan_owned_expansion() -> void:
	# Reuse real yard queues, material requests and cap validation. No free stock.
	var construction = preload("res://scripts/StationConstruction.gd")
	for sector in SectorManager._visited_sectors.values():
		var owner: StringName = sector.sector_data.controlling_faction_id
		if owner == &"" or owner == &"player" or _defeated_factions.has(owner) or not _faction_state.has(owner): continue
		if not strategy_status.get(owner,{}).get("expand",false):continue
		var stations := SectorManager.get_sector_stations(sector)
		var busy := false
		for station in stations:
			if station.faction_id == owner and not station._station_build_queue.is_empty(): busy = true
		if busy: continue
		for yard in stations:
			if yard._is_destroyed or yard.faction_id != owner or yard.station_data.station_type != StationData.TYPE_SHIPYARD: continue
			# Explicit supply requests have priority over choosing a new project.
			var desired: StringName = yard.requested_station_blueprint
			if desired == &"":
				for id in [&"sol_prime_manufacturing", &"sol_prime_trade", &"sol_prime_military", &"sol_prime_shipyard", &"sol_prime_capital_shipyard"]:
					var blueprint: StationData = GameData.stations.get(id)
					if not blueprint or construction.limit_problem(sector,blueprint,owner) != "": continue
					var exists := false
					for station in stations:
						if not station._is_destroyed and station.faction_id == owner and construction._same_category(station.station_data,blueprint): exists = true
					if not exists:
						desired = id
						break
			if desired == &"": continue
			var blueprint: StationData = GameData.stations.get(desired)
			if not blueprint or construction.limit_problem(sector,blueprint,owner) != "": continue
			yard.requested_station_blueprint = desired
			if construction.problem(yard,desired) == "": construction.queue(yard,desired)
			break # One expansion project per owned sector at a time.


func recheck_sector_claim(sector: SectorInstance) -> bool:
	var owner: StringName = sector.sector_data.controlling_faction_id
	if owner == &"": return false
	for station in SectorManager.get_sector_stations(sector):
		if station._is_destroyed or not station.station_data: continue
		var defended: StringName = station.claim_faction_id if station.claim_faction_id != &"" else station.faction_id
		if defended != owner: continue
		if station.station_data.station_type in [&"claim_beacon", &"headquarters", &"military", &"defense_platform"]: return false
	_sector_ownership[sector.sector_data.id] = &""
	sector.sector_data.controlling_faction_id = &""
	return true

func restore_sector_ownership() -> void:
	for id in _initial_sector_owners:
		if GameData.sectors.has(id): GameData.sectors[id].controlling_faction_id = _initial_sector_owners[id]
	for id in _sector_ownership:
		if GameData.sectors.has(id): GameData.sectors[id].controlling_faction_id = _sector_ownership[id]


func _collapse_assets(faction: StringName) -> void:
	if not _defeated_factions.has(faction):_defeated_factions.append(faction)
	# Personal ships survive the player's political collapse.
	if faction == &"player":
		var docking=get_tree().get_first_node_in_group("docking_manager")
		if docking and is_instance_valid(docking.current_station) and docking.current_station.faction_id==faction:docking._undock()
	for sector in SectorManager._visited_sectors.values():
		for node in sector.find_children("*","",true,false):
			if node.get_script()==preload("res://scripts/ConstructionScaffold.gd") and node.beneficiary==faction:
				node.completed=true
				node.queue_free()
			if node is StationInstance:
				node._station_build_queue = node._station_build_queue.filter(func(job): return job.get("owner",node.faction_id)!=faction)
			if node is ShipInstance and faction != &"player" and node.faction_id==faction and not node.is_in_group("player_fleet") and not node.is_in_group("player"):
				node.faction_id=&"rogue"
				var ai=node.get_node_or_null("AIShipController")
				if ai:
					ai.cancel_all_commands()
					ai._is_combat_ship=true
					ai._set_state(AIShipController.State.PATROL)
			elif node is StationInstance and node.faction_id==faction and not node._is_destroyed:
				if node.station_data.station_type==&"defense_platform":
					node.faction_id=&"rogue"
					node.claim_faction_id=&""
					node._treasury_linked=false
				else:node._destroy()
		if sector.sector_data.controlling_faction_id==faction:
			sector.sector_data.controlling_faction_id=&""
			_sector_ownership[sector.sector_data.id]=&""
	for id in GameData.sectors:
		if GameData.sectors[id].controlling_faction_id==faction:
			GameData.sectors[id].controlling_faction_id=&""
			_sector_ownership[id]=&""
	if PlayerState.joined_faction==faction:PlayerState.joined_faction=&""
	if _faction_state.has(faction):
		_faction_state[faction]["owned_ships"].clear()
		_faction_state[faction]["owned_stations"].clear()


func _diplomatic_strength(id: StringName) -> float:
	var total:=0.0
	for ship in get_faction_ships(id):
		if ship._is_destroyed or not ship.ship_data:continue
		if "fighter" in str(ship.ship_data.id) or "missile_boat" in str(ship.ship_data.id):total+=maxf(0,ship.hull)+maxf(0,ship.shield)
	return total

func _diplomatic_neighbors(a: StringName,b: StringName) -> bool:
	for sector in GameData.sectors.values():
		if sector.controlling_faction_id!=a:continue
		for id in sector.connected_sectors:
			if GameData.sectors.has(id) and GameData.sectors[id].controlling_faction_id==b:return true
	return false

func advance_diplomacy(delta: float) -> void:
	diplomacy_time+=maxf(0,delta)
	var ids: Array=GameData.factions.keys()
	ids.sort()
	for i in ids.size():
		var a: StringName=ids[i]
		if _defeated_factions.has(a) or not is_instance_valid(get_faction_hq(a)):continue
		for j in range(i+1,ids.size()):
			var b: StringName=ids[j]
			if _defeated_factions.has(b) or not is_instance_valid(get_faction_hq(b)):continue
			if not _diplomatic_neighbors(a,b) and not _diplomatic_neighbors(b,a):continue
			var key:=_make_key(a,b)
			if not diplomacy_pairs.has(key):diplomacy_pairs[key]={"since":diplomacy_time,"war":are_at_war(a,b)}
			var state: Dictionary=diplomacy_pairs[key]
			var war:=are_at_war(a,b)
			if state.war!=war:state.war=war;state.since=diplomacy_time
			var elapsed: float=diplomacy_time-float(state.since)
			var power_a:=_diplomatic_strength(a)
			var power_b:=_diplomatic_strength(b)
			var reason:=""
			var relation:=get_relation(a,b)
			if &"iron_corsairs" in [a,b]:
				if not war:set_relation(a,b,-1.0)
				continue
			if war and elapsed>=300:
				if get_faction_credits(a)<5000 or get_faction_credits(b)<5000 or minf(power_a,power_b)<maxf(power_a,power_b)*0.35:
					reason="Peace after military or financial exhaustion"
				elif elapsed>=900:reason="Peace after prolonged war"
				if reason!="":relation=0.0
			elif not war and relation<0.1:
				var stronger: StringName=a if power_a>=power_b else b
				var doctrine=preload("res://scripts/FactionDoctrine.gd").profile(stronger)
				if elapsed>=float(doctrine.war_delay) and maxf(power_a,power_b)>=400 and maxf(power_a,power_b)>=maxf(1,minf(power_a,power_b))*float(doctrine.advantage) and get_faction_credits(stronger)>=20000:
					reason="War over neighboring territory; stronger fleet commits"
					relation=-0.75
			if reason=="":continue
			set_relation(a,b,relation)
			state.war=relation<=-0.5
			state.since=diplomacy_time
			diplomacy_events.append({"time":diplomacy_time,"a":a,"b":b,"reason":reason})
			if diplomacy_events.size()>100:diplomacy_events.pop_front()
			if PlayerState.joined_faction in [a,b]:SaveManager._message(reason+": "+GameData.factions[a].display_name+" / "+GameData.factions[b].display_name)

const SHIP_SUPPLY_CAP:int=200
func ship_supply_cost(data:ShipData)->int:
	if not data or data.id==&"escape_pod":return 0
	return [2,5,10][clampi(int(data.ship_class),0,2)]

func get_ship_supply(faction_id:StringName)->int:
	var used:int=0
	var ships:Array=get_faction_ships(faction_id).duplicate()
	if faction_id==&"player":
		for ship in PlayerState.fleet_ships:
			if is_instance_valid(ship) and not ships.has(ship):ships.append(ship)
		if is_instance_valid(PlayerState.current_ship) and not ships.has(PlayerState.current_ship):ships.append(PlayerState.current_ship)
		for entries in PlayerState.station_hangar.values():
			for entry in entries:used+=ship_supply_cost(GameData.ships.get(entry.get("ship_data_id",&"")))
	for ship in ships:
		if is_instance_valid(ship) and not ship._is_destroyed and not ship.is_queued_for_deletion():used+=ship_supply_cost(ship.ship_data)
	for fid in _faction_state:
		for station in get_faction_stations(fid):
			if station._is_destroyed:continue
			for job in station.get_manufacture_queue():
				var owner:StringName=&"player" if job.get("player_order",false) else station.faction_id
				if owner==faction_id:used+=ship_supply_cost(GameData.ships.get(job.recipe.get("output_id",&"")))*int(job.recipe.get("output_amount",1))
	return used

func can_add_npc_ship(faction_id:StringName, data:ShipData, amount:int=1)->bool:
	return get_ship_supply(faction_id)+ship_supply_cost(data)*amount<=SHIP_SUPPLY_CAP
