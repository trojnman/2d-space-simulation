extends Control
var inspector: Control
var selector: OptionButton
var status: Label
var camera: FreeCameraController
var snapshot: Dictionary={"circles":[],"contacts":[]}
var galaxy:bool=true
var overview:Button
var timer:=0.0
var ids: Array=[]
func _ready() -> void:
	position=Vector2(maxf(24,get_viewport_rect().size.x-464),90)
	size=Vector2(440,500)
	custom_minimum_size=Vector2(440,500)
	mouse_filter=Control.MOUSE_FILTER_STOP
	selector=OptionButton.new()
	selector.custom_minimum_size=Vector2(310,30)
	add_child(selector)
	overview=Button.new()
	overview.text="All sectors"
	overview.position=Vector2(318,0)
	overview.size=Vector2(122,30)
	add_child(overview)
	overview.pressed.connect(func():galaxy=true;refresh())
	status=Label.new()
	status.position=Vector2(0,445)
	add_child(status)
	inspector=preload("res://scripts/StationIdentification.gd").new()
	inspector.map_inspection=true
	inspector.remote_inspection=true
	add_child(inspector)
	inspector.position=-position
	selector.item_selected.connect(func(_index):
		inspector.selected=null
		galaxy=false
		refresh())
func _process(delta: float) -> void:
	if not camera or not camera.is_free_mode():
		hide()
		return
	timer-=delta
	if timer>0:return
	timer=0.25
	var next: Array=[]
	for id in GameData.sectors:next.append(id)
	if next!=ids:
		ids=next
		selector.clear()
		for id in ids:selector.add_item(GameData.sectors[id].display_name)
	visible = not ids.is_empty()
	if visible:refresh()
func refresh() -> void:
	snapshot=SensorSystem.remote_sector_contacts(ids[selector.selected]) if selector.selected>=0 and selector.selected<ids.size() else {"circles":[],"contacts":[]}
	status.text="Remote map: %d contacts • Click a station to inspect" % snapshot.contacts.size()
	if galaxy:status.text="10-sector overview • Click a sector to view sensor contacts"
	elif snapshot.circles.is_empty():status.text="No sensor coverage • Live contacts are hidden"
	if is_instance_valid(inspector.selected):
		var still_visible:=false
		for contact in snapshot.contacts:
			if contact.get("node")==inspector.selected:still_visible=true
		if not still_visible:inspector.selected=null
	queue_redraw()
func _draw() -> void:
	# Draw charted gates above world fog in the active sector map.
	if is_instance_valid(SectorManager.current_sector):
		var gates:Node=SectorManager.current_sector.get_node_or_null("JumpGates")
		if gates:
			for gate in gates.get_children():
				if not gate is JumpGate:continue
				var point:Vector2=gate.get_global_transform_with_canvas().origin-global_position
				if Rect2(Vector2.ZERO,size).has_point(point):continue
				draw_rect(Rect2(point-Vector2(5,5),Vector2(10,10)),Color("73dfea"),false,2)
				var dest:SectorData=GameData.sectors.get(gate.destination_sector_id)
				if dest:draw_string(ThemeDB.fallback_font,point+Vector2(9,-7),dest.display_name,HORIZONTAL_ALIGNMENT_LEFT,180,12,Color("a6e7ef"))
	draw_rect(Rect2(0,35,440,400),Color("111827"))
	if galaxy:
		draw_overview()
		return
	var center:=Vector2(220,235)
	var scale_factor:=0.004
	if selector.selected>=0 and selector.selected<ids.size():
		var data:SectorData=GameData.sectors[ids[selector.selected]]
		for i in data.connected_sectors.size():
			var angle:float=float(i)*PI/3.0
			var gate_pos:Vector2=(Vector2.from_angle(angle)+Vector2.from_angle(angle+PI/3.0))*HexBoundary.HEX_RADIUS/2.0
			var point:Vector2=center+gate_pos*scale_factor
			draw_rect(Rect2(point-Vector2(4,4),Vector2(8,8)),Color("73dfea"),false,2)
			draw_string(ThemeDB.fallback_font,point+Vector2(-35,-8),GameData.sectors[data.connected_sectors[i]].display_name,HORIZONTAL_ALIGNMENT_LEFT,120,10,Color("a6e7ef"))
	for circle in snapshot.circles:draw_circle(center+circle.center*scale_factor,circle.radius*scale_factor,Color(0.15,0.35,0.4,0.35))
	for contact in snapshot.contacts:
		var point: Vector2=center+contact.position*scale_factor
		draw_circle(point,4 if contact.station else 2,Color("ff6655") if contact.hostile else Color("69dfd3"))
		if contact.station:draw_string(ThemeDB.fallback_font,point+Vector2(6,0),contact.label,HORIZONTAL_ALIGNMENT_LEFT,160,11,Color("b9d5df"))

func inspect_contact_at(point: Vector2) -> bool:
	var nearest: StationInstance=null
	var best:=12.0
	for contact in snapshot.contacts:
		if not contact.station:continue
		var distance: float=point.distance_to(Vector2(220,235)+contact.position*0.004)
		if distance<best and is_instance_valid(contact.get("node")):
			best=distance
			nearest=contact.node
	if not is_instance_valid(nearest) or not nearest.can_share_station_info():return false
	inspector.selected=nearest
	inspector._displayed=nearest
	inspector._refresh_card(true)
	return true

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		if galaxy:
			for index in ids.size():
				if event.position.distance_to(sector_point(ids[index]))<24:
					selector.select(index)
					galaxy=false
					refresh()
					break
		else:inspect_contact_at(event.position)
		accept_event()

func sector_point(id:StringName)->Vector2:
	var bounds:Rect2
	var first:bool=true
	for data in GameData.sectors.values():
		if first:bounds=Rect2(data.map_position,Vector2.ZERO);first=false
		else:bounds=bounds.expand(data.map_position)
	var factor:float=minf(300.0/maxf(bounds.size.x,1),280.0/maxf(bounds.size.y,1))
	return Vector2(220,230)+(GameData.sectors[id].map_position-bounds.get_center())*factor

func draw_overview()->void:
	for id in ids:
		var data:SectorData=GameData.sectors[id]
		for other in data.connected_sectors:
			if GameData.sectors.has(other):draw_line(sector_point(id),sector_point(other),Color("395269"),1.5)
	for id in ids:
		var point:Vector2=sector_point(id)
		var color:Color=Color("79bde8") if MapMemory.has_active_vision(id) else Color("81909f")
		draw_circle(point,7,color)
		if id==SectorManager.current_sector_id:draw_arc(point,11,0,TAU,24,Color.WHITE,2)
		draw_string(ThemeDB.fallback_font,point+Vector2(-48,23),GameData.sectors[id].display_name,HORIZONTAL_ALIGNMENT_LEFT,130,11,Color("d4e3ef"))
