extends Control
var inspector: Control
var selector: OptionButton
var status: Label
var camera: FreeCameraController
var snapshot: Dictionary={"circles":[],"contacts":[]}
var timer:=0.0
var ids: Array=[]
func _ready() -> void:
	position=Vector2(24,120)
	size=Vector2(440,500)
	custom_minimum_size=Vector2(440,500)
	mouse_filter=Control.MOUSE_FILTER_STOP
	selector=OptionButton.new()
	selector.custom_minimum_size=Vector2(440,30)
	add_child(selector)
	status=Label.new()
	status.position=Vector2(0,445)
	add_child(status)
	inspector=preload("res://scripts/StationIdentification.gd").new()
	inspector.map_inspection=true
	inspector.remote_inspection=true
	add_child(inspector)
	inspector.position=-position
	selector.item_selected.connect(func(_index):
		inspector.selected=null
		refresh())
func _process(delta: float) -> void:
	visible=camera and camera.is_free_mode()
	if not visible:return
	timer-=delta
	if timer>0:return
	timer=0.25
	var next: Array=[]
	for id in SectorManager._visited_sectors:
		if MapMemory.has_visited(id) or MapMemory.has_active_vision(id) or not MapMemory.get_sector_memory(id).is_empty():next.append(id)
	next.erase(SectorManager.current_sector_id)
	if next!=ids:
		ids=next
		selector.clear()
		for id in ids:selector.add_item(GameData.sectors[id].display_name)
	refresh()
func refresh() -> void:
	snapshot=SensorSystem.remote_sector_contacts(ids[selector.selected]) if selector.selected>=0 and selector.selected<ids.size() else {"circles":[],"contacts":[]}
	status.text="Remote map: %d contacts • Click a station to inspect" % snapshot.contacts.size()
	if is_instance_valid(inspector.selected):
		var still_visible:=false
		for contact in snapshot.contacts:
			if contact.get("node")==inspector.selected:still_visible=true
		if not still_visible:inspector.selected=null
	queue_redraw()
func _draw() -> void:
	draw_rect(Rect2(0,35,440,400),Color("111827"))
	var center:=Vector2(220,235)
	var scale_factor:=0.004
	for circle in snapshot.circles:draw_circle(center+circle.center*scale_factor,circle.radius*scale_factor,Color(0.15,0.35,0.4,0.35))
	for contact in snapshot.contacts:
		var point: Vector2=center+contact.position*scale_factor
		draw_circle(point,4 if contact.station else 2,Color("ff6655") if contact.hostile else Color("69dfd3"))
		if contact.station:draw_string(ThemeDB.fallback_font,point+Vector2(6,0),contact.label,HORIZONTAL_ALIGNMENT_LEFT,160,11,Color("b9d5df"))

func inspect_contact_at(point: Vector2) -> bool:
	var nearest: StationInstance=null
	var best:=12.0
	for contact in snapshot.contacts:
		if not contact.station:continue
		var distance: float=point.distance_to(Vector2(220,235)+contact.position*0.004)
		if distance<best and is_instance_valid(contact.get("node")):
			best=distance
			nearest=contact.node
	if not is_instance_valid(nearest) or not nearest.can_share_station_info():return false
	inspector.selected=nearest
	inspector._displayed=nearest
	inspector._refresh_card(true)
	return true

func _gui_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		inspect_contact_at(event.position)
		accept_event()
