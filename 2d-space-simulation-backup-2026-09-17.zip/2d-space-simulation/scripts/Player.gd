class_name Player
extends ShipInstance

## Player-controlled ship.
## MissileSystem child handles all missile arming/firing.

@export var bullet_scene  : PackedScene = null
@export var laser_scene   : PackedScene = null
@export var missile_scene : PackedScene = null

@onready var camera           : Camera2D       = $Camera2D
@onready var thrust_particles : GPUParticles2D = $ThrustParticles if has_node("ThrustParticles") else null

var _mouse_world_pos  : Vector2 = Vector2.ZERO
var _is_docked        : bool    = false
var _flight_layer: int = 0
var _flight_mask: int = 0
var _free_cam         : FreeCameraController = null
var _active_fire_group : int   = 1


func _ready() -> void:
	super()
	weapon_fired.connect(_on_weapon_fired)
	if camera:
		camera.make_current()
	await get_tree().process_frame
	_free_cam = get_tree().get_first_node_in_group("free_camera")


func initialize(data: ShipData) -> void:
	super(data)
	var visuals := get_node_or_null("ShipVisuals")
	if visuals: visuals.rebuild(data.id)


func _process(_delta: float) -> void:
	if _is_docked: return
	if _free_cam and _free_cam.is_free_mode(): return
	_mouse_world_pos = get_global_mouse_position()
	_handle_weapon_firing()
	_update_thrust_particles()


func _physics_process(delta: float) -> void:
	if _is_docked: return
	tick(delta)
	if _free_cam and _free_cam.is_free_mode(): return
	_handle_movement(delta)
	_aim_at_mouse(delta)
	move_and_slide()


func _unhandled_input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if event.is_action_pressed("fire_group_1"):
		_active_fire_group = 1
	elif event.is_action_pressed("fire_group_2"):
		_active_fire_group = 2


# ---------------------------------------------------------------------------
# Movement
# ---------------------------------------------------------------------------

func _handle_movement(delta: float) -> void:
	if not ship_data:return
	var typing:bool=preload("res://scripts/UIInput.gd").typing(get_viewport())
	var horizontal:float=0 if typing else Input.get_axis("strafe_left","strafe_right")
	var vertical:float=0 if typing else Input.get_axis("thrust","reverse")
	if horizontal!=0:velocity.x+=horizontal*ship_data.lateral_acceleration()*delta
	else:velocity.x*=ship_data.coast_factor(delta)
	if vertical!=0:velocity.y+=vertical*ship_data.forward_acceleration()*(.6 if vertical>0 else 1.0)*delta
	else:velocity.y*=ship_data.coast_factor(delta)
	if not typing and Input.is_action_pressed("brake"):
		velocity=velocity.move_toward(Vector2.ZERO,ship_data.forward_acceleration()*2.0*delta)
	velocity=velocity.limit_length(ship_data.max_speed)


func _aim_at_mouse(delta: float) -> void:
	if not ship_data or global_position.distance_squared_to(_mouse_world_pos) < 0.001: return
	var target_angle := global_position.direction_to(_mouse_world_pos).angle() + PI
	rotation = rotate_toward(rotation, target_angle, maxf(0.0, ship_data.rotation_speed * delta))


# ---------------------------------------------------------------------------
# Weapon firing
# ---------------------------------------------------------------------------

func _handle_weapon_firing() -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()) or preload("res://scripts/UIInput.gd").over_menu(get_viewport()):return
	var weapons_panel = get_tree().get_first_node_in_group("weapon_control_hud")
	if weapons_panel and weapons_panel.visible and weapons_panel.get_global_rect().has_point(weapons_panel.get_global_mouse_position()): return
	var hovered = get_viewport().gui_get_hovered_control()
	if hovered is BaseButton or hovered is PopupMenu: return
	if BuildPlacement.active: return
	var inspector := get_tree().get_first_node_in_group("station_inspection")
	if inspector and inspector.blocks_primary_fire(): return
	## Check if any weapon in the active group uses hold vs click
	var should_fire := false
	var group_slots := get_slots_in_group(_active_fire_group)
	if group_slots.is_empty(): return

	## Use the first weapon in group to determine fire mode
	var first_slot := group_slots[0]
	if first_slot < equipped_weapons.size() and equipped_weapons[first_slot] != null:
		var w := equipped_weapons[first_slot]
		if w.fire_rate_rpm <= 60:
			should_fire = Input.is_action_just_pressed("shoot")
		else:
			should_fire = Input.is_action_pressed("shoot")

	if should_fire:
		var dir := global_position.direction_to(_mouse_world_pos)
		fire_group(_active_fire_group, dir)


func _on_weapon_fired(w: WeaponData, origin: Vector2, direction: Vector2) -> void:
	if w == null: return

	var scene : PackedScene
	if w.weapon_type == GlobalEnums.WeaponType.ENERGY or w.weapon_type == GlobalEnums.WeaponType.MINING:
		scene = laser_scene
	else:
		scene = bullet_scene

	if scene == null:
		push_warning("Player: no scene assigned for weapon type %s" % w.weapon_type)
		return


	var b : Node2D = scene.instantiate()
	b.global_position = origin
	b.rotation        = direction.angle()
	if b.has_method("launch"):
		b.launch(velocity + direction * w.projectile_speed, self, w)
	SectorManager.add_sector_entity(b)


# ---------------------------------------------------------------------------
# Visuals
# ---------------------------------------------------------------------------

func _update_thrust_particles() -> void:
	if not thrust_particles: return
	thrust_particles.emitting = Input.is_action_pressed("thrust")


# ---------------------------------------------------------------------------
# Docking
# ---------------------------------------------------------------------------

func dock() -> void:
	_flight_layer = collision_layer
	_flight_mask = collision_mask
	collision_layer = 0
	collision_mask = 0
	velocity = Vector2.ZERO
	_is_docked = true
	visible    = false
	set_physics_process(false)
	set_process(false)
	var ms := get_node_or_null("MissileSystem") as MissileSystem
	if ms: ms.cancel()


func undock(spawn_position: Vector2) -> void:
	collision_layer = _flight_layer
	collision_mask = _flight_mask
	global_position = spawn_position
	_is_docked      = false
	visible         = true
	set_physics_process(true)
	set_process(true)


func _destroy(killer: Node = null) -> void:
	if _is_destroyed: return
	if ship_data.id == &"escape_pod":
		super(killer)
		return
	_is_destroyed = true
	# Defer hull/collision replacement until the physics callback has finished.
	call_deferred("_eject_escape_pod")

func _eject_escape_pod() -> void:
	BuildPlacement.cancel()
	var missiles := get_node_or_null("MissileSystem")
	if missiles: missiles.cancel()
	equipped_weapons.clear()
	equipped_shield = null
	equipped_missiles.clear()
	inventory.clear()
	initialize(GameData.get_ship(&"escape_pod"))
	PlayerState.restore_ship_entry(self, {})
	_shield_delay_timer = 0.0
	_energy_delay_timer = 0.0
	velocity = velocity.limit_length(ship_data.max_speed)
	_is_destroyed = false
	SaveManager._message("Ship destroyed  -  escape pod deployed. Dock or select a nearby owned ship on the map to board.")
