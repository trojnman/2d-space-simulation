extends RefCounted
## Shared local/offscreen role priorities and steering.
static func civilian(ship: ShipInstance) -> bool:
 var id: String = str(ship.ship_data.id)
 return "miner" in id or "hauler" in id

static func logistics(ship: ShipInstance) -> bool:
 return "logistics" in str(ship.ship_data.id)

static func preferred_size(ship: ShipInstance) -> int:
 if "missile_boat" in str(ship.ship_data.id):
  var totals: Dictionary = {}
  for slot in ship.equipped_missiles.size():
   var missile: MissileData = ship.equipped_missiles[slot]
   if missile and ship.inventory.has_item(missile.id):
    totals[int(missile.equip_size)] = float(totals.get(int(missile.equip_size),0.0)) + missile.damage * mini(ship.rack_capacity(slot),ship.inventory.get_amount(missile.id))
  var best: int = 0
  for size in totals:
   if best == 0 or totals[size] > totals[best]: best = size
  if best > 0: return best
 # Fighters prioritize enemies matching their hull; turrets select independently.
 if "fighter" in str(ship.ship_data.id): return int(ship.ship_data.ship_class)+1
 var preferred: int = 0
 var damage: float = 0.0
 for weapon in ship.equipped_weapons:
  if not weapon or weapon.weapon_type == GlobalEnums.WeaponType.MINING: continue
  if weapon.uses_ammo and not ship.inventory.has_item(weapon.ammo_item_id): continue
  var dps: float = weapon.damage / weapon.get_fire_interval()
  if dps > damage: damage=dps;preferred=int(weapon.equip_size)
 return preferred if preferred > 0 else int(ship.ship_data.ship_class)+1

static func weapon_range(ship: ShipInstance) -> float:
 var ranges: Array[float] = []
 var missile_range: float = 0.0
 for missile in ship.equipped_missiles:
  if missile and ship.inventory.has_item(missile.id): missile_range=maxf(missile_range,minf(missile.lock_on_range,missile.speed*missile.lifetime))
 if "missile_boat" in str(ship.ship_data.id) and missile_range>0:return missile_range
 for weapon in ship.equipped_weapons:
  if not weapon or weapon.weapon_type == GlobalEnums.WeaponType.MINING: continue
  if weapon.uses_ammo and not ship.inventory.has_item(weapon.ammo_item_id): continue
  ranges.append(weapon.max_range)
 if ranges.is_empty(): return missile_range if missile_range>0 else 600.0
 ranges.sort()
 return maxf(ranges.back(),missile_range)

static func radius(node: Node2D) -> float:
 for child in node.get_children():
  if child is CollisionPolygon2D:
   var extent: float = 0.0
   for point in child.polygon: extent=maxf(extent,point.length())
   return maxf(15,extent)
 return 30.0

static func desired_range(ship: ShipInstance, target: Node2D) -> float:
 var fraction: float = 0.8
 return maxf(radius(ship)+radius(target)+90,weapon_range(ship)*fraction)

static func avoidance(ai: AIShipController) -> Vector2:
 var ship: ShipInstance=ai._ship
 var force:=Vector2.ZERO
 for group in [&"ships",&"stations"]:
  for other in ai._local_nodes(group):
   if other==ship or not is_instance_valid(other) or other.get("_is_destroyed"):continue
   var offset:Vector2=ship.global_position-other.global_position
   var safe:float=(radius(ship)+radius(other))*2.0+200
   if ai._state == AIShipController.State.GO_WAIT and other in ai._formation_members:safe=radius(ship)+radius(other)+20
   var distance:float=offset.length()
   if distance>=safe:continue
   var away:Vector2=offset.normalized() if distance>0.01 else Vector2.from_angle(float(ship.get_instance_id()%360)*PI/180)
   force+=away*(1.0-distance/safe)*ship.ship_data.max_speed*2.0
 return force.limit_length(ship.ship_data.max_speed*2.0)

static func steer(ai: AIShipController, wanted: Vector2, facing: Vector2, delta: float) -> void:
 var ship: ShipInstance=ai._ship
 var data: ShipData=ship.ship_data
 wanted=(wanted+avoidance(ai)).limit_length(data.max_speed)
 var forward: Vector2=Vector2.from_angle(ship.rotation)
 var side: Vector2=forward.orthogonal()
 var change: Vector2=wanted-ship.velocity
 ship.velocity+=forward*clampf(change.dot(forward),-data.forward_acceleration()*delta,data.forward_acceleration()*delta)
 ship.velocity+=side*clampf(change.dot(side),-data.lateral_acceleration()*delta,data.lateral_acceleration()*delta)
 ship.velocity=ship.velocity.limit_length(data.max_speed)
 if facing.length_squared()>0.001:ship.rotation=rotate_toward(ship.rotation,facing.angle(),data.rotation_speed*delta)
 if ai.is_inside_tree():ship.move_and_slide()
 else:ship.position+=ship.velocity*delta

static func travel(ai: AIShipController, point: Vector2, delta: float) -> void:
 var offset:Vector2=point-ai._ship.global_position
 var desired:Vector2=offset.normalized()*minf(ai._ship.ship_data.max_speed,minf(offset.length()*1.5,sqrt(2.0*ai._ship.ship_data.lateral_acceleration()*offset.length())*.8))
 steer(ai,desired,offset,delta)

static func fight(ai: AIShipController, delta: float) -> void:
 var ship:ShipInstance=ai._ship
 var target:Node2D=ai._target
 if not is_instance_valid(target):return
 var offset:Vector2=target.global_position-ship.global_position
 var ideal:float=desired_range(ship,target)
 var radial:Vector2=offset.normalized()
 var closing:float=clampf((offset.length()-ideal)/maxf(100,ideal*.3),-1,1)
 var orbit:float=(-1.0 if ship.get_instance_id()%2==0 else 1.0)*(.22 if logistics(ship) else .45)
 var wanted:Vector2=(radial*closing+radial.orthogonal()*orbit)*ship.ship_data.max_speed
 if target is ShipInstance:wanted+=target.velocity*.35
 steer(ai,wanted,offset,delta)
