extends RefCounted
## Per-ship turret policy. Fixed weapons never enter this controller.
static var background_sector:Node
static var background_groups:Dictionary={}
const DEFEND = 0
const PASSIVE = 1
const ATTACK = 2
const CURRENT_TARGET = 3
const RETALIATION_SECONDS = 30.0

static func sector_nodes(ship: Node, group: StringName) -> Array:
 var sector = sector_for(ship)
 if not sector: return []
 if sector==background_sector and background_groups.has(group):return background_groups[group].filter(func(node):return is_instance_valid(node) and not node.is_queued_for_deletion())
 var result: Array = []
 if sector.is_inside_tree():
  for node in sector.get_tree().get_nodes_in_group(group):
   if node is Player:continue
   if sector_for(node)==sector:result.append(node)
 else:
  for node in sector.find_children("*", "", true, false):
   if node.is_in_group(group): result.append(node)
 if group == &"ships" and sector == SectorManager.current_sector and is_instance_valid(PlayerState.current_ship): result.append(PlayerState.current_ship)
 return result

static func record_attack(ship: ShipInstance, attacker: Node) -> void:
 if not is_instance_valid(attacker) or attacker == ship: return
 if not (attacker is ShipInstance or attacker is StationInstance): return
 if not PlayerState.combat_damage_allowed(attacker, ship): return
 var controller=ship.get_node_or_null("AIShipController")
 if controller and ship.is_in_group("player_fleet"):controller.hostile_alert_seconds=30.0
 for threat in ship.turret_threats:
  if threat.target == attacker:
   threat.remaining = RETALIATION_SECONDS
   return
 ship.turret_threats.append({"target":attacker,"remaining":RETALIATION_SECONDS})

static func notify_shot(attacker: Node, origin: Vector2, direction: Vector2, distance: float) -> void:
 if not is_instance_valid(attacker): return
 for candidate in sector_nodes(attacker, &"ships"):
  if candidate == attacker or candidate._is_destroyed: continue
  var offset: Vector2 = candidate.global_position-origin
  var along: float = offset.dot(direction)
  # Incoming fire is recognized before impact, including narrowly missed shots.
  if along > 0 and along <= distance and absf(offset.cross(direction)) <= 45.0:
   record_attack(candidate,attacker)

static func hostile(ship: ShipInstance, target: Node) -> bool:
 if ship is Player or ship.is_in_group("player_fleet"): return PlayerState.is_hostile_to_player(target.faction_id)
 var faction: StringName = &"player" if target is Player or target.is_in_group("player_fleet") else target.faction_id
 return FactionManager.are_at_war(ship.faction_id, faction)

static func valid(ship: ShipInstance, target: Node, slot: int) -> bool:
 if not is_instance_valid(target) or target == ship or target.is_queued_for_deletion() or target.get("_is_destroyed"): return false
 if target is Missile:
  if not target.threatens(ship):return false
 elif not (target is ShipInstance or target is StationInstance):return false
 elif not PlayerState.combat_damage_allowed(ship,target):return false
 if target is ShipInstance and target.ship_data and target.ship_data.id == &"escape_pod": return false
 if sector_for(target) != sector_for(ship): return false
 if ship is Player or ship.is_in_group("player_fleet"):
  if ship.is_inside_tree() and not SensorSystem.has_local_contact(target.global_position): return false
 var weapon: WeaponData = ship.equipped_weapons[slot]
 if ship.global_position.distance_to(target.global_position) > minf(weapon.max_range,8000.0): return false
 var forward: float = ship.global_rotation + (PI if ship is Player else 0.0)
 var angle: float = ship.global_position.direction_to(target.global_position).angle()
 return absf(wrapf(angle-forward-ship.ship_data.mount_arc_center(slot),-PI,PI)) <= PI/3.0

static func current_target(ship: ShipInstance) -> Node2D:
 if ship is Player:
  var hud = ship.get_tree().get_first_node_in_group("targeting_hud")
  return hud.target if hud and is_instance_valid(hud.target) else null
 for child in ship.get_children():
  if child is AIShipController: return child._target if is_instance_valid(child._target) else null
 return null

static func select_targets(ship: ShipInstance, delta: float) -> void:
 for i in range(ship.turret_threats.size()-1,-1,-1):
  ship.turret_threats[i].remaining -= delta
  if ship.turret_threats[i].remaining <= 0 or not is_instance_valid(ship.turret_threats[i].target): ship.turret_threats.remove_at(i)
 ship.turret_targets.resize(ship.ship_data.weapon_slots)
 ship.turret_targets.fill(null)
 if ship.turret_order == PASSIVE: return
 var has_turret := false
 for slot in ship.equipped_weapons.size():
  if ship.equipped_weapons[slot] and ship.ship_data.mount_kind(slot)=="Turret":
   has_turret=true
   break
 if not has_turret:return
 var candidates: Array = []
 if ship.turret_order == CURRENT_TARGET:
  var target = current_target(ship)
  if is_instance_valid(target) and PlayerState.combat_damage_allowed(ship,target): candidates.append(target)
 elif ship.turret_order == DEFEND:
  for threat in ship.turret_threats:
   if is_instance_valid(threat.target): candidates.append(threat.target)
 else:
  for group in [&"ships",&"stations"]:
   for target in sector_nodes(ship,group):
    if hostile(ship,target): candidates.append(target)
 for missile in sector_nodes(ship,&"missiles"):
  if missile is Missile and missile.threatens(ship):candidates.append(missile)
 for slot in ship.equipped_weapons.size():
  if ship.ship_data.mount_kind(slot) != "Turret" or not ship.equipped_weapons[slot]: continue
  var best: float = INF
  for target in candidates:
   if not valid(ship,target,slot): continue
   var target_size: int = int(target.ship_data.ship_class)+1 if target is ShipInstance else 3
   var score: float = (-1000000.0 if target is Missile else abs(target_size-ship.ship_data.mount_size(slot))*10000.0) + ship.global_position.distance_to(target.global_position)
   if score < best:
    best = score
    ship.turret_targets[slot] = target

static func fire(ship: ShipInstance) -> void:
 if ship.turret_order == PASSIVE: return
 for slot in ship.turret_targets.size():
  var target = ship.turret_targets[slot]
  if not is_instance_valid(target) or not valid(ship,target,slot): continue
  var direction: Vector2 = ship.global_position.direction_to(aim_point(ship,target,slot))
  if not ship.fire_weapon(slot,direction,ship.is_inside_tree()): continue
  var weapon: WeaponData = ship.equipped_weapons[slot]
  if not ship.is_inside_tree():
   if target is ShipInstance:
    record_attack(target,ship)
    target.take_damage_from_weapon(weapon,ship)
   elif target is StationInstance: target.take_damage_from_weapon(weapon,ship)
   else: target.take_damage(weapon.damage,ship)
  elif not ship is Player:
   var path: String = "res://scenes/Bullet.tscn" if weapon.weapon_type == GlobalEnums.WeaponType.BALLISTIC else "res://scenes/LaserBeam.tscn"
   var projectile: Node2D = load(path).instantiate()
   projectile.position = ship._get_muzzle_position(slot)
   direction = ship.weapon_direction(slot)
   projectile.rotation = direction.angle()
   projectile.launch(ship.velocity+direction*weapon.projectile_speed,ship,weapon)
   SectorManager.add_sector_entity(projectile)

static func sector_for(node: Node) -> Node:
 if node is Player: return SectorManager.current_sector
 return preload("res://scripts/StationConstruction.gd").sector_of(node)

static func intercept_point(origin:Vector2, shooter_velocity:Vector2, target_position:Vector2, target_velocity:Vector2, speed:float)->Vector2:
 # Projectiles inherit shooter velocity; solve the relative-motion intercept.
 var offset:=target_position-origin
 var relative:=target_velocity-shooter_velocity
 var a:=relative.length_squared()-speed*speed
 var b:=2.0*offset.dot(relative)
 var c:=offset.length_squared()
 var time:float=-1.0
 if absf(a)<.0001:
  if absf(b)>.0001:time=-c/b
 else:
  var discriminant:=b*b-4.0*a*c
  if discriminant>=0:
   var first:=(-b-sqrt(discriminant))/(2.0*a)
   var second:=(-b+sqrt(discriminant))/(2.0*a)
   if first>0:time=first
   if second>0 and (time<0 or second<time):time=second
 if time<=0:return target_position
 return target_position+relative*time

static func aim_point(ship: ShipInstance, target: Node2D, slot: int) -> Vector2:
 if slot>=ship.equipped_weapons.size() or not ship.equipped_weapons[slot]:return target.global_position
 var target_velocity:=Vector2.ZERO
 if target is ShipInstance:target_velocity=target.velocity
 elif target is Missile:target_velocity=target._velocity
 return intercept_point(ship.global_position,ship.velocity,target.global_position,target_velocity,ship.equipped_weapons[slot].projectile_speed)

static func cache_background_sector(sector:Node)->void:
 background_sector=sector
 background_groups={&"ships":[],&"stations":[],&"asteroids":[],&"missiles":[]}
 for node in sector.find_children("*","",true,false):
  for group in background_groups:
   if node.is_in_group(group):background_groups[group].append(node)
static func clear_background_cache()->void:
 background_sector=null
 background_groups.clear()
