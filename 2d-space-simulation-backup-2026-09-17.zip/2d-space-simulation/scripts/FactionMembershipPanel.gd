extends VBoxContainer
var station: StationInstance
func _ready() -> void: refresh()
func refresh() -> void:
	for child in get_children():
		remove_child(child)
		child.queue_free()
	var status := Label.new()
	var member := GameData.get_faction(PlayerState.joined_faction) if PlayerState.joined_faction != &"" else null
	status.text = "Member of " + member.display_name if member else ("Your own faction" if PlayerState.founded_faction else "Independent - no faction membership")
	add_child(status)
	var note := Label.new()
	note.text = "Your existing assets remain yours. New projects built for this faction stay with it when you leave."
	note.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	add_child(note)
	var join := Button.new()
	join.text = "Join this faction"
	join.disabled = not PlayerState.can_join_faction(station.faction_id) or PlayerState.joined_faction == station.faction_id
	join.tooltip_text = "Requires Friendly or Allied reputation."
	join.pressed.connect(func():
		PlayerState.join_faction(station.faction_id)
		refresh())
	add_child(join)

	var leave:=Button.new()
	leave.text="Leave faction"
	leave.disabled=PlayerState.joined_faction==&""
	leave.pressed.connect(func():
		PlayerState.joined_faction=&""
		refresh())
	add_child(leave)

	var history:=Label.new()
	history.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	var lines:=PackedStringArray(["Recent diplomatic events"])
	var events: Array=FactionManager.diplomacy_events
	for i in range(maxi(0,events.size()-5),events.size()):
		var event: Dictionary=events[i]
		lines.append("%s / %s: %s" % [GameData.factions[event.a].display_name,GameData.factions[event.b].display_name,event.reason])
	if events.is_empty():lines.append("No new war or peace decisions recorded.")
	history.text="\n".join(lines)
	add_child(history)

	var license:=Button.new()
	var id: StringName=station.faction_id
	license.text="Buy sensor-sharing license - $%d" % PlayerState.SENSOR_LICENSE_PRICE
	if PlayerState.joined_faction==id:license.text="Sensor vision included with membership"
	elif PlayerState.sensor_licenses.has(id):license.text="Sensor license active" if PlayerState.has_shared_sensors(id) else "Sensor license suspended - friendly relations required"
	license.disabled=not GameData.factions.has(id) or PlayerState.joined_faction==id or PlayerState.sensor_licenses.has(id) or not PlayerState.is_friendly_to_player(id) or not PlayerState.can_afford(PlayerState.SENSOR_LICENSE_PRICE)
	license.tooltip_text="One-time purchase. Shares this faction's ship and station sensor coverage while relations remain friendly."
	license.pressed.connect(func():
		PlayerState.buy_sensor_license(id)
		refresh())
	add_child(license)
