extends Node

## MapMemory — Autoload singleton.
## Tracks which sectors have been visited and stores last-known
## object positions for the galaxy map.
## Add to Project -> Autoload as 'MapMemory'.

## Set of visited sector ids
var visited_sectors : Dictionary = {}   ## sector_id -> true

## Last known objects per sector
## sector_id -> Array of { type, pos, faction_id, label }
var sector_memory   : Dictionary = {}


func _ready() -> void:
	await get_tree().process_frame
	## Connect to sector changes
	SectorManager.sector_changed.connect(_on_sector_changed)


func _on_sector_changed(old_id: StringName, new_id: StringName) -> void:
	if new_id != &"":
		mark_visited(new_id)


func mark_visited(sector_id: StringName) -> void:
	visited_sectors[sector_id] = true
	## Record static layout from SectorData on first visit
	if not sector_memory.has(sector_id):
		sector_memory[sector_id] = []


func has_visited(sector_id: StringName) -> bool:
	return visited_sectors.has(sector_id)


func has_active_vision(sector_id: StringName) -> bool:
	if sector_id==SectorManager.current_sector_id:
		return not SensorSystem.get_sensor_circles().is_empty()
	return not SensorSystem.remote_sector_contacts(sector_id).circles.is_empty()

func get_visibility(sector_id: StringName) -> int:
	if has_active_vision(sector_id):return 2
	return 1 if has_visited(sector_id) else 0


func _record_sector_layout(sector_id: StringName) -> void:
	var sd : SectorData = GameData.get_sector(sector_id)
	if not sd: return
	var objects : Array = []
	var rng := RandomNumberGenerator.new()
	## Record stations
	rng.seed = hash(sector_id + "stations")
	for station_id in sd.starting_stations:
		var station_res : StationData = GameData.get_station(station_id)
		if not station_res: continue
		var pos : Vector2 = Vector2(
			rng.randf_range(-SectorInstance.HALF_SIZE * 0.7, SectorInstance.HALF_SIZE * 0.7),
			rng.randf_range(-SectorInstance.HALF_SIZE * 0.7, SectorInstance.HALF_SIZE * 0.7)
		)
		objects.append({"type": "station", "pos": pos, "faction_id": sd.controlling_faction_id, "label": station_res.display_name})
	## Record asteroid fields (center positions)
	rng.seed = hash(sector_id + "asteroids")
	for field in sd.asteroid_fields:
		var pos : Vector2 = Vector2(
			rng.randf_range(-SectorInstance.HALF_SIZE * 0.6, SectorInstance.HALF_SIZE * 0.6),
			rng.randf_range(-SectorInstance.HALF_SIZE * 0.6, SectorInstance.HALF_SIZE * 0.6)
		)
		objects.append({"type": "asteroid_field", "pos": pos, "faction_id": &"", "label": ""})
	## Record jump gates
	var connected  : Array = sd.connected_sectors
	var angle_step : float = TAU / float(max(connected.size(), 1))
	for i in connected.size():
		var angle    : float   = float(i) * angle_step
		var pos      : Vector2 = Vector2(cos(angle), sin(angle)) * SectorInstance.HALF_SIZE * 0.85
		var dest_sd  : SectorData = GameData.get_sector(connected[i])
		objects.append({"type": "jump_gate", "pos": pos, "faction_id": &"", "label": "-> %s" % (dest_sd.display_name if dest_sd else str(connected[i]))})
	## Record POIs (deterministic positions)
	rng.seed = hash(sector_id + "poi")
	var poi_types := ["Anomaly", "Ancient Ruins", "Signal Source", "Abandoned Cache", "Wormhole Trace"]
	var poi_count : int = rng.randi_range(1, 3)
	for i in poi_count:
		var pos : Vector2 = Vector2(
			rng.randf_range(-SectorInstance.HALF_SIZE * 0.7, SectorInstance.HALF_SIZE * 0.7),
			rng.randf_range(-SectorInstance.HALF_SIZE * 0.7, SectorInstance.HALF_SIZE * 0.7)
		)
		objects.append({"type": "poi", "pos": pos, "faction_id": &"", "label": poi_types[rng.randi() % poi_types.size()]})
	sector_memory[sector_id] = objects


func get_sector_memory(sector_id: StringName) -> Array:
	return sector_memory.get(sector_id, [])


func update_live_contact(sector_id: StringName, contact_type: String, pos: Vector2, faction_id: StringName, label: String) -> void:
	## Update last-known position for a live contact
	if not sector_memory.has(sector_id):
		sector_memory[sector_id] = []
	var arr : Array = sector_memory[sector_id]
	## Find existing entry of same type+label and update, or add new
	for entry in arr:
		if entry.get("type") == contact_type and entry.get("label") == label:
			entry["pos"]        = pos
			entry["faction_id"] = faction_id
			return
	arr.append({"type": contact_type, "pos": pos, "faction_id": faction_id, "label": label})


func serialize() -> Dictionary:
	return {
		"visited": visited_sectors.duplicate(),
		"memory":  sector_memory.duplicate(true),
	}


func deserialize(data: Dictionary) -> void:
	visited_sectors = data.get("visited", {})
	sector_memory   = data.get("memory",  {})
