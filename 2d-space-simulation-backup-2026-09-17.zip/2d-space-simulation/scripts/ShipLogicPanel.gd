extends Window
var ships:OptionButton
var behavior:OptionButton
var orders:ItemList
var status:Label
var fleet:OptionButton
var ammo_stock:SpinBox
var missile_stock:SpinBox
var home:OptionButton
var hops:SpinBox
var priority:OptionButton
var excluded:ItemList
var loading_settings:=false
var ai:AIShipController
func _ready()->void:
 title="Ship logic"
 size=Vector2i(580,mini(740,maxi(400,get_tree().root.size.y-60)))
 theme=preload("res://scripts/ConsoleTheme.gd").build()
 close_requested.connect(queue_free)
 var frame=preload("res://scripts/FleetWindowFrame.gd").build(self,"FLEET / SHIP LOGIC")
 var scroll:=ScrollContainer.new();scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL;frame.add_child(scroll)
 scroll.horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
 var panel:=VBoxContainer.new();panel.size_flags_horizontal=Control.SIZE_EXPAND_FILL;scroll.add_child(panel)
 ships=OptionButton.new();panel.add_child(ships)
 for ship in PlayerState.fleet_ships:
  if not is_instance_valid(ship):continue
  ships.add_item(ship.ship_data.display_name);ships.set_item_metadata(ships.item_count-1,ship)
  if ship in FleetCommandSystem.selected_ships:ships.select(ships.item_count-1)
 ships.item_selected.connect(func(_index):select_ship())
 status=Label.new();status.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;panel.add_child(status)
 var label:=Label.new();label.text="After all commands finish";panel.add_child(label)
 behavior=OptionButton.new()
 for name in ["Hold position","Patrol nearby","Follow player","Defend player","Resume configured job","Auto Mine","Auto Trade","Auto Resupply Fleet"]:behavior.add_item(name)
 panel.add_child(behavior)
 behavior.item_selected.connect(func(index):
  if is_instance_valid(ai):
   ai.default_behavior=["hold","patrol","follow","defend","job","auto_mine","auto_trade","auto_resupply"][index]
   ai.default_suspended=false
   ai.alert_message="")
 var supply_label:=Label.new();supply_label.text="Fleet resupply: fleet / ammo units / missile volleys per ship";panel.add_child(supply_label)
 fleet=OptionButton.new();panel.add_child(fleet)
 var fleet_names:Array=[]
 for ship in PlayerState.fleet_ships:
  if is_instance_valid(ship) and not ship.fleet_name.is_empty() and ship.fleet_name not in fleet_names:fleet_names.append(ship.fleet_name)
 for name in fleet_names:fleet.add_item(name)
 fleet.item_selected.connect(func(_i):store_policy())
 ammo_stock=SpinBox.new();ammo_stock.min_value=1;ammo_stock.max_value=10000;ammo_stock.value=200;ammo_stock.suffix="ammo";panel.add_child(ammo_stock)
 missile_stock=SpinBox.new();missile_stock.min_value=1;missile_stock.max_value=100;missile_stock.value=5;missile_stock.suffix="volleys";panel.add_child(missile_stock)
 ammo_stock.value_changed.connect(func(_v):store_policy())
 missile_stock.value_changed.connect(func(_v):store_policy())
 var help:=Label.new();help.text="Matches fleet loadouts. Supplier selection balances price and travel distance.";help.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART;panel.add_child(help)
 var home_label:=Label.new();home_label.text="Original sector / search radius in gate hops";panel.add_child(home_label)
 home=OptionButton.new();panel.add_child(home)
 for id in GameData.sectors:home.add_item(GameData.sectors[id].display_name);home.set_item_metadata(home.item_count-1,id)
 hops=SpinBox.new();hops.min_value=0;hops.max_value=20;hops.suffix="hops";panel.add_child(hops)
 home.item_selected.connect(func(_i):store_policy())
 hops.value_changed.connect(func(_v):store_policy())
 priority=OptionButton.new();priority.add_item("Any cargo / mineral");priority.set_item_metadata(0,&"");panel.add_child(priority)
 for id in GameData.items:
  if GameData.items[id].is_component or GameData.items[id].is_raw_material:
   priority.add_item(GameData.items[id].display_name);priority.set_item_metadata(priority.item_count-1,id)
 priority.item_selected.connect(func(_i):store_policy())
 var no_go:=Label.new();no_go.text="No-go sectors: click to toggle (never enter or trade)";panel.add_child(no_go)
 excluded=ItemList.new();excluded.custom_minimum_size.y=100;panel.add_child(excluded)
 for id in GameData.sectors:excluded.add_item(GameData.sectors[id].display_name);excluded.set_item_metadata(excluded.item_count-1,id)
 excluded.item_clicked.connect(func(index,_position,_button):
  if not is_instance_valid(ai):return
  var id=excluded.get_item_metadata(index)
  if id in ai.no_go_sectors:ai.no_go_sectors.erase(id)
  else:ai.no_go_sectors.append(id)
  show_policy())
 var resume:=Button.new();resume.text="Apply default now / acknowledge alert";panel.add_child(resume)
 resume.pressed.connect(func():
  if not is_instance_valid(ai):return
  store_policy()
  ai.cancel_all_commands();ai.default_suspended=false;ai.alert_message="";ai._run_default_behavior())
 var jobs:=Button.new();jobs.text="Configure automated job";panel.add_child(jobs)
 jobs.pressed.connect(func():
  if not is_instance_valid(ai):return
  var editor=preload("res://scripts/FleetJobEditor.gd").new();editor.ai=ai;add_child(editor);editor.popup_centered())
 orders=ItemList.new();orders.custom_minimum_size.y=110;orders.size_flags_vertical=Control.SIZE_EXPAND_FILL;panel.add_child(orders)
 var remove:=Button.new();remove.text="Remove selected queued order";panel.add_child(remove)
 remove.pressed.connect(func():
  if is_instance_valid(ai) and not orders.get_selected_items().is_empty():
   var index=orders.get_selected_items()[0]
   if index<ai._command_queue.size():ai._command_queue.remove_at(index))
 var stop:=Button.new();stop.text="Stop all orders and hold";panel.add_child(stop)
 stop.pressed.connect(func():
  if is_instance_valid(ai):ai.cancel_all_commands())
 select_ship()
func select_ship()->void:
 ai=null
 if ships.selected>=0:
  var ship=ships.get_selected_metadata()
  if is_instance_valid(ship):ai=ship.get_node_or_null("AIShipController")
 if is_instance_valid(ai):behavior.select(maxi(0,["hold","patrol","follow","defend","job","auto_mine","auto_trade","auto_resupply"].find(ai.default_behavior)))
 show_policy()
func store_policy()->void:
 if loading_settings or not is_instance_valid(ai):return
 ai.resupply_fleet=fleet.get_item_text(fleet.selected) if fleet.selected>=0 else ""
 ai.resupply_ammo=int(ammo_stock.value)
 ai.resupply_volleys=int(missile_stock.value)
 ai.automation_home=home.get_selected_metadata()
 ai.automation_hops=int(hops.value)
 ai.automation_item=priority.get_selected_metadata()
func show_policy()->void:
 if not is_instance_valid(ai):return
 loading_settings=true
 ammo_stock.value=ai.resupply_ammo
 missile_stock.value=ai.resupply_volleys
 for i in fleet.item_count:
  if fleet.get_item_text(i)==ai.resupply_fleet:fleet.select(i)
 if ai.automation_home==&"":ai.automation_home=preload("res://scripts/StationConstruction.gd").sector_of(ai._ship).sector_data.id
 for i in home.item_count:
  if home.get_item_metadata(i)==ai.automation_home:home.select(i)
 hops.value=ai.automation_hops
 for i in priority.item_count:
  if priority.get_item_metadata(i)==ai.automation_item:priority.select(i)
 for i in excluded.item_count:
  var id=excluded.get_item_metadata(i)
  excluded.set_item_text(i,("[NO GO] " if id in ai.no_go_sectors else "[Allowed] ")+GameData.sectors[id].display_name)
 loading_settings=false
func _process(_delta:float)->void:
 if not is_instance_valid(ai):status.text="Select an owned ship";return
 status.text=("ALERT: "+ai.alert_message+"\n" if not ai.alert_message.is_empty() else "")+"Current: "+(ai.job_status if not ai.fleet_job.is_empty() else AIShipController.State.keys()[ai._state].capitalize())
 var descriptions:Array[String]=[]
 for command in ai._command_queue:
  var label=GlobalEnums.FleetCommand.keys()[int(command.get("type",0))].capitalize()
  var target=command.get("target")
  if is_instance_valid(target):label+=" - "+str(target.name)
  elif command.has("position"):label+=" - "+str(command.position)
  descriptions.append(label)
 var signature="|".join(descriptions)
 if orders.get_meta("signature","")!=signature:
  orders.set_meta("signature",signature);orders.clear()
  for index in descriptions.size():orders.add_item(str(index+1)+". "+descriptions[index])
