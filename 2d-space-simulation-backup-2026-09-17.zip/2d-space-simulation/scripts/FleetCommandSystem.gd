extends Node

## FleetCommandSystem — Autoload singleton.
## Handles fleet ship selection, box select, right-click context menus,
## and command queuing for player fleet ships in free cam mode.

signal selection_changed(selected_ships: Array)
signal command_issued(ships: Array, command: Dictionary)

## Currently selected fleet ships
var selected_ships : Array[ShipInstance] = []

## Box select state
var _box_selecting   : bool    = false
var _box_start_world : Vector2 = Vector2.ZERO
var _box_start_screen: Vector2 = Vector2.ZERO

## Patrol route building state
var _building_patrol_route : bool           = false
var _patrol_route_points   : Array[Vector2] = []
var _patrol_route_ships    : Array          = []

## Context menu state
var _context_menu         : PopupMenu = null
var _context_menu_pos     : Vector2   = Vector2.ZERO
var _context_menu_target  : Node2D    = null
var _context_menu_ships   : Array     = []
var _shift_queuing        : bool      = false

## Radius drag state
var _radius_dragging      : bool    = false
var _radius_center        : Vector2 = Vector2.ZERO
var _radius_drag_start    : Vector2 = Vector2.ZERO
var _pending_command_type : GlobalEnums.FleetCommand = GlobalEnums.FleetCommand.PATROL_AREA

## Selection circle visual
var _selection_circles    : Array   = []

## Reference to free camera
var formation_name: String = "Wedge"
var formation_spacing: float = 400.0
var custom_formations: Dictionary = {}
var control_groups: Dictionary = {}
var _move_drag: bool = false
var _move_start: Vector2
var _move_screen: Vector2
var _move_end: Vector2
var _move_path: Array[Vector2] = []
var _move_spread: bool = false
var _move_draw_path: bool = false
var _move_queue: bool = false
var _editing_ship: ShipInstance
var _editing_index: int = -1
var _free_cam : FreeCameraController = null


func _ready() -> void:
	await get_tree().process_frame
	_free_cam = get_tree().get_first_node_in_group("free_camera")
	_build_context_menu()


func _build_context_menu() -> void:
	_context_menu = PopupMenu.new()
	_context_menu.theme=preload("res://scripts/ConsoleTheme.gd").build()
	_context_menu.name = "FleetContextMenu"
	## IDs match GlobalEnums.FleetCommand values
	_context_menu.add_item("Go Here and Wait",   GlobalEnums.FleetCommand.GO_WAIT)
	_context_menu.add_item("Patrol Area",        GlobalEnums.FleetCommand.PATROL_AREA)
	_context_menu.add_item("Add Patrol Point",   GlobalEnums.FleetCommand.PATROL_ROUTE)
	_context_menu.add_separator()
	_context_menu.add_item("Cancel Last Order",  100)
	_context_menu.add_item("Cancel All Orders",  101)
	_context_menu.id_pressed.connect(_on_context_menu_space_selected)
	get_tree().root.add_child(_context_menu)


func _build_ship_context_menu() -> PopupMenu:
	var menu := PopupMenu.new()
	menu.theme=preload("res://scripts/ConsoleTheme.gd").build()
	menu.add_item("Follow Ship",   GlobalEnums.FleetCommand.FOLLOW_SHIP)
	menu.add_item("Defend Ship",   GlobalEnums.FleetCommand.DEFEND_SHIP)
	menu.add_separator()
	menu.add_item("Cancel Last Order", 100)
	menu.add_item("Cancel All Orders", 101)
	menu.id_pressed.connect(_on_context_menu_ship_selected)
	get_tree().root.add_child(menu)
	return menu


# ---------------------------------------------------------------------------
# Main input handler — called by FreeCameraController when in free cam
# ---------------------------------------------------------------------------

func handle_input(event: InputEvent, camera: Camera2D) -> bool:
	## Returns true if input was consumed

	_shift_queuing = Input.is_key_pressed(KEY_SHIFT)
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_ESCAPE:
			_move_drag=false;_editing_ship=null;_box_selecting=false
			return true
		if event.ctrl_pressed and event.keycode == KEY_A:
			selected_ships.clear()
			for ship in get_tree().get_nodes_in_group("player_fleet"):
				if ship is ShipInstance and not ship._is_destroyed:selected_ships.append(ship)
			_refresh_circles();selection_changed.emit(selected_ships)
			return true
		if event.keycode>=KEY_1 and event.keycode<=KEY_9:
			var number:int=event.keycode-KEY_0
			if event.ctrl_pressed:control_groups[number]=selected_ships.duplicate()
			elif control_groups.has(number):
				selected_ships.clear()
				for ship in control_groups[number]:
					if is_instance_valid(ship) and not ship._is_destroyed and ship.is_inside_tree():selected_ships.append(ship)
				_refresh_circles();selection_changed.emit(selected_ships)
			return true
	if is_instance_valid(_editing_ship):
		if event is InputEventMouseMotion:
			var ai=_editing_ship.get_node_or_null("AIShipController")
			var point:Vector2=camera.get_canvas_transform().affine_inverse()*event.position
			if ai:
				if _editing_index<0:ai._waypoint=point;ai._set_state(AIShipController.State.GO_WAIT)
				elif _editing_index<ai._command_queue.size():ai._command_queue[_editing_index].position=point
			return true
		if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT and not event.pressed:
			_editing_ship=null;selection_changed.emit(selected_ships)
			return true
	if _move_drag:
		if event is InputEventMouseMotion:
			_move_end=camera.get_canvas_transform().affine_inverse()*event.position
			if _move_draw_path and _move_path.back().distance_to(_move_end)>80.0/camera.zoom.x:_move_path.append(_move_end)
			return true
		if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_RIGHT and not event.pressed:
			_move_end=camera.get_canvas_transform().affine_inverse()*event.position
			_move_drag=false
			if event.position.distance_to(_move_screen)<8:
				_open_order_menu(event.position,_move_start,camera)
			elif _move_draw_path:
				_move_path.append(_move_end)
				for i in _move_path.size():issue_formation_move(_move_path[i],0.0,_move_queue or i>0)
			elif _move_spread:issue_spread(_move_start,_move_end,_move_queue)
			else:issue_formation_move(_move_start,(_move_end-_move_start).angle() if event.position.distance_to(_move_screen)>8 else 0.0,_move_queue)
			return true


	## Box select drag
	if _box_selecting:
		if event is InputEventMouseMotion:
			_update_box_select(event.position, camera)
			return true
		if event is InputEventMouseButton:
			var mb := event as InputEventMouseButton
			if mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed:
				_finish_box_select(event.position, camera)
				return true

	## Radius drag
	if _radius_dragging:
		if event is InputEventMouseMotion:
			return true
		if event is InputEventMouseButton:
			var mb := event as InputEventMouseButton
			if mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed:
				_finish_radius_drag(event.position, camera)
				return true

	if not event is InputEventMouseButton: return false
	var mb := event as InputEventMouseButton
	if not mb.pressed: return false

	var world_pos := camera.get_canvas_transform().affine_inverse() * mb.position

	if mb.button_index == MOUSE_BUTTON_LEFT:
		for marker in waypoint_markers():
			if (camera.get_canvas_transform()*marker.position).distance_to(mb.position)<12:
				_editing_ship=marker.ship;_editing_index=marker.index
				return true
		## Check if clicking a fleet ship
		var clicked_ship := _get_fleet_ship_at(world_pos)
		if clicked_ship:
			if mb.ctrl_pressed:
				_toggle_selection(clicked_ship)
			elif mb.shift_pressed:
				if not selected_ships.has(clicked_ship):
					selected_ships.append(clicked_ship)
					_refresh_circles();selection_changed.emit(selected_ships)
			else:
				_select_single(clicked_ship)
			return true
		else:
			## Start box select
			if true:
				_start_box_select(mb.position, world_pos, camera)
			return true

	if mb.button_index == MOUSE_BUTTON_RIGHT and selected_ships.size() > 0:
		_move_drag=true
		_move_start=world_pos;_move_end=world_pos;_move_screen=mb.position
		_move_path=[world_pos]
		_move_spread=Input.is_key_pressed(KEY_ALT)
		_move_draw_path=Input.is_key_pressed(KEY_CTRL)
		_move_queue=_shift_queuing
		return true

	return false


# ---------------------------------------------------------------------------
# Selection
# ---------------------------------------------------------------------------

func _select_single(ship: ShipInstance) -> void:
	selected_ships = [ship]
	_refresh_circles()
	selection_changed.emit(selected_ships)


func _toggle_selection(ship: ShipInstance) -> void:
	if selected_ships.has(ship):
		selected_ships.erase(ship)
	else:
		selected_ships.append(ship)
	_refresh_circles()
	selection_changed.emit(selected_ships)


func deselect_all() -> void:
	selected_ships.clear()
	_refresh_circles()
	selection_changed.emit(selected_ships)


func _start_box_select(screen_pos: Vector2, world_pos: Vector2, _camera: Camera2D) -> void:
	_box_selecting    = true
	_box_start_screen = screen_pos
	_box_start_world  = world_pos


func _update_box_select(_screen_pos: Vector2, _camera: Camera2D) -> void:
	pass ## Visual drawn by FreeCameraController overlay


func _finish_box_select(screen_pos: Vector2, camera: Camera2D) -> void:
	_box_selecting = false
	var end_world  := camera.get_canvas_transform().affine_inverse() * screen_pos
	var rect       := Rect2(_box_start_world, Vector2.ZERO)
	rect = rect.expand(end_world)
	## Find all fleet ships inside the rect
	var found : Array[ShipInstance] = []
	for ship in get_tree().get_nodes_in_group("player_fleet"):
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		if rect.has_point(ship.global_position):
			found.append(ship)
	if found.size() > 0:
		if Input.is_key_pressed(KEY_CTRL) or Input.is_key_pressed(KEY_SHIFT):
			for s in found:
				if not selected_ships.has(s):
					selected_ships.append(s)
		else:
			selected_ships = found
		_refresh_circles()
		selection_changed.emit(selected_ships)
	else:
		if not Input.is_key_pressed(KEY_CTRL) and not Input.is_key_pressed(KEY_SHIFT):
			deselect_all()


func _get_fleet_ship_at(world_pos: Vector2) -> ShipInstance:
	var cam := get_viewport().get_camera_2d()
	var radius: float = 14.0 / maxf(0.005,cam.zoom.x) if cam else 80.0
	for ship in get_tree().get_nodes_in_group("player_fleet"):
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		if ship._is_destroyed or preload("res://scripts/StationConstruction.gd").sector_of(ship)!=SectorManager.current_sector:continue
		if ship.global_position.distance_to(world_pos) < maxf(radius,preload("res://scripts/ShipTactics.gd").radius(ship)):
			return ship
	return null


# ---------------------------------------------------------------------------
# Context menus
# ---------------------------------------------------------------------------

func _show_ship_context_menu(screen_pos: Vector2, target_ship: ShipInstance) -> void:
	var menu := _build_ship_context_menu()
	_context_menu_target = target_ship
	_context_menu_ships  = selected_ships.duplicate()
	menu.popup(Rect2i(int(screen_pos.x), int(screen_pos.y), 0, 0))


func _on_context_menu_space_selected(id: int) -> void:
	match id:
		GlobalEnums.FleetCommand.GO_WAIT:
			_issue_command_to_ships(_context_menu_ships, {
				"type":     GlobalEnums.FleetCommand.GO_WAIT,
				"position": _context_menu_pos,
			})
		GlobalEnums.FleetCommand.PATROL_AREA:
			## Start radius drag
			_radius_center        = _context_menu_pos
			_pending_command_type = GlobalEnums.FleetCommand.PATROL_AREA
			_radius_dragging      = true
			_radius_drag_start    = _context_menu_pos
		GlobalEnums.FleetCommand.PATROL_ROUTE:
			## Add patrol point to route
			_patrol_route_points.append(_context_menu_pos)
			_patrol_route_ships = _context_menu_ships.duplicate()
			## If shift not held, commit route immediately with current points
			if not _shift_queuing and _patrol_route_points.size() >= 2:
				_issue_command_to_ships(_patrol_route_ships, {
					"type":   GlobalEnums.FleetCommand.PATROL_ROUTE,
					"points": _patrol_route_points.duplicate(),
				})
				_patrol_route_points.clear()
		100: ## Cancel last
			for ship in _context_menu_ships:
				_cancel_last_order(ship)
		101: ## Cancel all
			for ship in _context_menu_ships:
				_cancel_all_orders(ship)


func _on_context_menu_ship_selected(id: int) -> void:
	match id:
		GlobalEnums.FleetCommand.FOLLOW_SHIP:
			_issue_command_to_ships(_context_menu_ships, {
				"type":   GlobalEnums.FleetCommand.FOLLOW_SHIP,
				"target": _context_menu_target,
			})
		GlobalEnums.FleetCommand.DEFEND_SHIP:
			_issue_command_to_ships(_context_menu_ships, {
				"type":   GlobalEnums.FleetCommand.DEFEND_SHIP,
				"target": _context_menu_target,
			})
		100:
			for ship in _context_menu_ships:
				_cancel_last_order(ship)
		101:
			for ship in _context_menu_ships:
				_cancel_all_orders(ship)


func _finish_radius_drag(screen_pos: Vector2, camera: Camera2D) -> void:
	_radius_dragging = false
	var world_pos := camera.get_canvas_transform().affine_inverse() * screen_pos
	var radius    := _radius_center.distance_to(world_pos)
	radius = maxf(radius, 200.0)
	_issue_command_to_ships(_context_menu_ships, {
		"type":     _pending_command_type,
		"position": _radius_center,
		"radius":   radius,
	})


# ---------------------------------------------------------------------------
# Command issuing
# ---------------------------------------------------------------------------

func _issue_command_to_ships(ships: Array, command: Dictionary) -> void:
	for ship in ships:
		if not is_instance_valid(ship): continue
		var ai := ship.get_node_or_null("AIShipController") as AIShipController
		if not ai: continue
		if _shift_queuing:
			ai.queue_command(command)
		else:
			ai.set_command_queue([command])
	command_issued.emit(ships, command)
	selection_changed.emit(selected_ships)


func _cancel_last_order(ship: ShipInstance) -> void:
	var ai := ship.get_node_or_null("AIShipController") as AIShipController
	if ai: ai.cancel_last_command()
	selection_changed.emit(selected_ships)


func _cancel_all_orders(ship: ShipInstance) -> void:
	var ai := ship.get_node_or_null("AIShipController") as AIShipController
	if ai: ai.cancel_all_commands()
	selection_changed.emit(selected_ships)


# ---------------------------------------------------------------------------
# Selection circles (drawn in world space on ships)
# ---------------------------------------------------------------------------

func _refresh_circles() -> void:
	## Remove old circles
	for circle in _selection_circles:
		if is_instance_valid(circle):
			circle.queue_free()
	_selection_circles.clear()
	## Add new circles
	for ship in selected_ships:
		if not is_instance_valid(ship): continue
		var circle := SelectionCircle.new()
		circle.name = "SelectionCircle"
		ship.add_child(circle)
		_selection_circles.append(circle)


func get_box_select_rect_screen() -> Rect2:
	if not _box_selecting: return Rect2()
	var mouse := get_viewport().get_mouse_position()
	return Rect2(_box_start_screen, mouse - _box_start_screen)


func get_radius_drag_info() -> Dictionary:
	if not _radius_dragging: return {}
	var cam := get_tree().get_first_node_in_group("free_camera") as Camera2D
	if not cam: return {}
	var mouse_world := cam.get_canvas_transform().affine_inverse() * get_viewport().get_mouse_position()
	return {
		"center": _radius_center,
		"radius": _radius_center.distance_to(mouse_world),
	}


# ===========================================================================
# SelectionCircle — Node2D that draws a circle around a selected ship
# ===========================================================================
class SelectionCircle extends Node2D:
	const RADIUS : float = 80.0
	const COLOR  : Color = Color(0.3, 0.9, 1.0, 0.8)
	const WIDTH  : float = 2.0

	func _draw() -> void:
		draw_arc(Vector2.ZERO, RADIUS, 0.0, TAU, 32, COLOR, WIDTH)

	func _process(_delta: float) -> void:
		queue_redraw()


func prepare_sector_change() -> void:
	_move_drag=false;_editing_ship=null
	selected_ships.clear()
	_refresh_circles()
	_box_selecting = false
	_building_patrol_route = false
	_patrol_route_points.clear()
	_patrol_route_ships.clear()
	_radius_dragging = false
	_context_menu_ships.clear()
	_context_menu_target = null
	if is_instance_valid(_context_menu): _context_menu.hide()
	selection_changed.emit(selected_ships)


func formation_offsets(count: int, heading: float) -> Array[Vector2]:
	var offsets: Array[Vector2]=[]
	for i in count:
		var point:=Vector2.ZERO
		match formation_name:
			"Line":point=Vector2(0,(i-(count-1)*.5)*formation_spacing)
			"Column":point=Vector2(-i*formation_spacing,0)
			"Box":
				var width:int=maxi(1,ceili(sqrt(count)))
				point=Vector2(-int(i/width)*formation_spacing,(i%width-(width-1)*.5)*formation_spacing)
			"Wedge":point=Vector2(-ceili(i/2.0)*formation_spacing,(-1 if i%2 else 1)*ceili(i/2.0)*formation_spacing*.7)
			_:
				var saved:Array=custom_formations.get(formation_name,[])
				point=saved[i]*formation_spacing if i<saved.size() else Vector2(-i*formation_spacing,0)
		offsets.append(point.rotated(heading))
	return offsets

func save_custom_formation(label: String) -> bool:
	label=label.strip_edges()
	if label.is_empty() or selected_ships.is_empty() or label in ["Line","Column","Box","Wedge"]:return false
	var center:=Vector2.ZERO
	var live:Array=[]
	for ship in selected_ships:
		if is_instance_valid(ship) and not ship._is_destroyed:live.append(ship);center+=ship.global_position
	if live.is_empty():return false
	center/=live.size()
	var offsets:Array=[]
	for ship in live:offsets.append((ship.global_position-center)/formation_spacing)
	custom_formations[label]=offsets
	formation_name=label
	return true

func issue_formation_move(point: Vector2, heading: float, queued: bool) -> void:
	var token: int = Time.get_ticks_usec()
	var offsets=formation_offsets(selected_ships.size(),heading)
	for i in selected_ships.size():
		var ship=selected_ships[i]
		if not is_instance_valid(ship):continue
		var ai=ship.get_node_or_null("AIShipController")
		if not ai:continue
		var command={"type":GlobalEnums.FleetCommand.GO_WAIT,"position":point+offsets[i],"facing":heading,"formation_members":selected_ships.duplicate(),"formation_token":token}
		if queued:ai.queue_command(command)
		else:ai.set_command_queue([command])
	selection_changed.emit(selected_ships)

func issue_spread(start: Vector2, end: Vector2, queued: bool) -> void:
	for i in selected_ships.size():
		var ship=selected_ships[i]
		if not is_instance_valid(ship):continue
		var ai=ship.get_node_or_null("AIShipController")
		if not ai:continue
		var command={"type":GlobalEnums.FleetCommand.GO_WAIT,"position":start.lerp(end,float(i)/maxi(1,selected_ships.size()-1))}
		if queued:ai.queue_command(command)
		else:ai.set_command_queue([command])
	selection_changed.emit(selected_ships)

func waypoint_markers() -> Array:
	var markers:Array=[]
	for ship in selected_ships:
		if not is_instance_valid(ship):continue
		var ai=ship.get_node_or_null("AIShipController")
		if not ai:continue
		if ai._state in [AIShipController.State.GO_WAIT,AIShipController.State.STAY]:markers.append({"ship":ship,"index":-1,"position":ai._waypoint})
		for i in ai._command_queue.size():
			var cmd:Dictionary=ai._command_queue[i]
			if cmd.has("position"):markers.append({"ship":ship,"index":i,"position":cmd.position})
	return markers


func _open_order_menu(screen:Vector2, world:Vector2, camera:Camera2D) -> void:
	_context_menu_pos=world
	_context_menu_ships=selected_ships.duplicate()
	_shift_queuing=_move_queue
	_context_menu_target=null
	var best:float=INF
	for group in [&"ships",&"stations",&"asteroids"]:
		for target in get_tree().get_nodes_in_group(group):
			if not target is Node2D or target in selected_ships or target.get("_is_destroyed"):continue
			if not SensorSystem.has_local_contact(target.global_position):continue
			var distance:float=world.distance_to(target.global_position)
			if distance<maxf(14.0/camera.zoom.x,preload("res://scripts/ShipTactics.gd").radius(target)) and distance<best:
				best=distance
				_context_menu_target=target
	var menu:=PopupMenu.new()
	menu.theme=preload("res://scripts/ConsoleTheme.gd").build()
	if is_instance_valid(_context_menu_target):
		menu.add_item("Move near object",202)
		if _context_menu_target is ShipInstance or _context_menu_target is StationInstance:
			if PlayerState.is_hostile_to_player(_context_menu_target.faction_id):
				menu.add_item("Attack target",GlobalEnums.FleetCommand.ATTACK_TARGET)
			else:
				menu.add_item("Defend object",GlobalEnums.FleetCommand.DEFEND_SHIP)
				if _context_menu_target is ShipInstance:
					menu.add_item("Follow ship",GlobalEnums.FleetCommand.FOLLOW_SHIP)
					menu.add_item("Escort ship",203)
	else:
		menu.add_item("Move here in formation",201)
		menu.add_item("Patrol area…",GlobalEnums.FleetCommand.PATROL_AREA)
	var formations:=PopupMenu.new()
	formations.name="Formations"
	formations.theme=menu.theme
	menu.add_child(formations)
	var choices:Array=["Wedge","Line","Column","Box"]+custom_formations.keys()
	for i in choices.size():
		formations.add_radio_check_item(choices[i],i)
		formations.set_item_checked(i,formation_name==choices[i])
	formations.add_separator()
	formations.add_item("Create Formation…",10000)
	formations.id_pressed.connect(func(choice:int):
		if choice==10000:
			var sidebar=get_tree().get_first_node_in_group("fleet_sidebar")
			if sidebar:sidebar.formation_editor.open_selection()
		elif choice>=0 and choice<choices.size():
			formation_name=choices[choice]
		menu.hide())
	menu.add_submenu_item("Formation","Formations")
	menu.add_separator()
	menu.add_item("Cancel last queued order",100)
	menu.add_item("Hold position / cancel all",101)
	menu.id_pressed.connect(_order_chosen)
	menu.popup_hide.connect(menu.queue_free)
	get_tree().root.add_child(menu)
	menu.popup(Rect2i(Vector2i(screen),Vector2i.ZERO))

func _order_chosen(id:int)->void:
	if id in [100,101,GlobalEnums.FleetCommand.PATROL_AREA]:
		_on_context_menu_space_selected(id)
		return
	if id==201 or id==202:
		var destination:=_context_menu_pos
		if id==202:
			if not is_instance_valid(_context_menu_target):return
			var center:=Vector2.ZERO
			var count:=0
			for ship in _context_menu_ships:
				if is_instance_valid(ship):center+=ship.global_position;count+=1
			center/=maxi(1,count)
			destination=_context_menu_target.global_position+_context_menu_target.global_position.direction_to(center)*(preload("res://scripts/ShipTactics.gd").radius(_context_menu_target)+600)
		issue_formation_move(destination,0,_shift_queuing)
		return
	if not is_instance_valid(_context_menu_target):return
	_issue_command_to_ships(_context_menu_ships,{"type":GlobalEnums.FleetCommand.DEFEND_SHIP if id==203 else id,"target":_context_menu_target})
