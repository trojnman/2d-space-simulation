extends Node

## FleetCommandSystem — Autoload singleton.
## Handles fleet ship selection, box select, right-click context menus,
## and command queuing for player fleet ships in free cam mode.

signal selection_changed(selected_ships: Array)
signal command_issued(ships: Array, command: Dictionary)

## Currently selected fleet ships
var selected_ships : Array[ShipInstance] = []

## Box select state
var _box_selecting   : bool    = false
var _box_start_world : Vector2 = Vector2.ZERO
var _box_start_screen: Vector2 = Vector2.ZERO

## Patrol route building state
var _building_patrol_route : bool           = false
var _patrol_route_points   : Array[Vector2] = []
var _patrol_route_ships    : Array          = []

## Context menu state
var _context_menu         : PopupMenu = null
var _context_menu_pos     : Vector2   = Vector2.ZERO
var _context_menu_target  : Node2D    = null
var _context_menu_ships   : Array     = []
var _shift_queuing        : bool      = false

## Radius drag state
var _radius_dragging      : bool    = false
var _radius_center        : Vector2 = Vector2.ZERO
var _radius_drag_start    : Vector2 = Vector2.ZERO
var _pending_command_type : GlobalEnums.FleetCommand = GlobalEnums.FleetCommand.PATROL_AREA

## Selection circle visual
var _selection_circles    : Array   = []

## Reference to free camera
var _free_cam : FreeCameraController = null


func _ready() -> void:
	await get_tree().process_frame
	_free_cam = get_tree().get_first_node_in_group("free_camera")
	_build_context_menu()


func _build_context_menu() -> void:
	_context_menu = PopupMenu.new()
	_context_menu.name = "FleetContextMenu"
	## IDs match GlobalEnums.FleetCommand values
	_context_menu.add_item("Go Here and Wait",   GlobalEnums.FleetCommand.GO_WAIT)
	_context_menu.add_item("Patrol Area",        GlobalEnums.FleetCommand.PATROL_AREA)
	_context_menu.add_item("Add Patrol Point",   GlobalEnums.FleetCommand.PATROL_ROUTE)
	_context_menu.add_separator()
	_context_menu.add_item("Cancel Last Order",  100)
	_context_menu.add_item("Cancel All Orders",  101)
	_context_menu.id_pressed.connect(_on_context_menu_space_selected)
	get_tree().root.add_child(_context_menu)


func _build_ship_context_menu() -> PopupMenu:
	var menu := PopupMenu.new()
	menu.add_item("Follow Ship",   GlobalEnums.FleetCommand.FOLLOW_SHIP)
	menu.add_item("Defend Ship",   GlobalEnums.FleetCommand.DEFEND_SHIP)
	menu.add_separator()
	menu.add_item("Cancel Last Order", 100)
	menu.add_item("Cancel All Orders", 101)
	menu.id_pressed.connect(_on_context_menu_ship_selected)
	get_tree().root.add_child(menu)
	return menu


# ---------------------------------------------------------------------------
# Main input handler — called by FreeCameraController when in free cam
# ---------------------------------------------------------------------------

func handle_input(event: InputEvent, camera: Camera2D) -> bool:
	## Returns true if input was consumed

	_shift_queuing = Input.is_key_pressed(KEY_SHIFT)

	## Box select drag
	if _box_selecting:
		if event is InputEventMouseMotion:
			_update_box_select(event.position, camera)
			return true
		if event is InputEventMouseButton:
			var mb := event as InputEventMouseButton
			if mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed:
				_finish_box_select(event.position, camera)
				return true

	## Radius drag
	if _radius_dragging:
		if event is InputEventMouseMotion:
			return true
		if event is InputEventMouseButton:
			var mb := event as InputEventMouseButton
			if mb.button_index == MOUSE_BUTTON_LEFT and not mb.pressed:
				_finish_radius_drag(event.position, camera)
				return true

	if not event is InputEventMouseButton: return false
	var mb := event as InputEventMouseButton
	if not mb.pressed: return false

	var world_pos := camera.get_global_transform().affine_inverse() * mb.position

	if mb.button_index == MOUSE_BUTTON_LEFT:
		## Check if clicking a fleet ship
		var clicked_ship := _get_fleet_ship_at(world_pos)
		if clicked_ship:
			if Input.is_key_pressed(KEY_CTRL):
				_toggle_selection(clicked_ship)
			else:
				_select_single(clicked_ship)
			return true
		else:
			## Start box select
			if not Input.is_key_pressed(KEY_CTRL):
				_start_box_select(mb.position, world_pos, camera)
			return true

	if mb.button_index == MOUSE_BUTTON_RIGHT and selected_ships.size() > 0:
		var clicked_ship := _get_fleet_ship_at(world_pos)
		if clicked_ship and not selected_ships.has(clicked_ship):
			## Right clicked a non-selected ship — show ship context menu
			_show_ship_context_menu(mb.position, clicked_ship)
		else:
			## Right clicked space — show space context menu
			_context_menu_pos   = world_pos
			_context_menu_ships = selected_ships.duplicate()
			_context_menu.popup(Rect2i(int(mb.position.x), int(mb.position.y), 0, 0))
		return true

	return false


# ---------------------------------------------------------------------------
# Selection
# ---------------------------------------------------------------------------

func _select_single(ship: ShipInstance) -> void:
	selected_ships = [ship]
	_refresh_circles()
	selection_changed.emit(selected_ships)


func _toggle_selection(ship: ShipInstance) -> void:
	if selected_ships.has(ship):
		selected_ships.erase(ship)
	else:
		selected_ships.append(ship)
	_refresh_circles()
	selection_changed.emit(selected_ships)


func deselect_all() -> void:
	selected_ships.clear()
	_refresh_circles()
	selection_changed.emit(selected_ships)


func _start_box_select(screen_pos: Vector2, world_pos: Vector2, _camera: Camera2D) -> void:
	_box_selecting    = true
	_box_start_screen = screen_pos
	_box_start_world  = world_pos


func _update_box_select(_screen_pos: Vector2, _camera: Camera2D) -> void:
	pass ## Visual drawn by FreeCameraController overlay


func _finish_box_select(screen_pos: Vector2, camera: Camera2D) -> void:
	_box_selecting = false
	var end_world  := camera.get_global_transform().affine_inverse() * screen_pos
	var rect       := Rect2(_box_start_world, Vector2.ZERO)
	rect = rect.expand(end_world)
	## Find all fleet ships inside the rect
	var found : Array[ShipInstance] = []
	for ship in get_tree().get_nodes_in_group("player_fleet"):
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		if rect.has_point(ship.global_position):
			found.append(ship)
	if found.size() > 0:
		if Input.is_key_pressed(KEY_CTRL):
			for s in found:
				if not selected_ships.has(s):
					selected_ships.append(s)
		else:
			selected_ships = found
		_refresh_circles()
		selection_changed.emit(selected_ships)
	else:
		if not Input.is_key_pressed(KEY_CTRL):
			deselect_all()


func _get_fleet_ship_at(world_pos: Vector2) -> ShipInstance:
	var radius : float = 80.0
	for ship in get_tree().get_nodes_in_group("player_fleet"):
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		if ship.global_position.distance_to(world_pos) < radius:
			return ship
	return null


# ---------------------------------------------------------------------------
# Context menus
# ---------------------------------------------------------------------------

func _show_ship_context_menu(screen_pos: Vector2, target_ship: ShipInstance) -> void:
	var menu := _build_ship_context_menu()
	_context_menu_target = target_ship
	_context_menu_ships  = selected_ships.duplicate()
	menu.popup(Rect2i(int(screen_pos.x), int(screen_pos.y), 0, 0))


func _on_context_menu_space_selected(id: int) -> void:
	match id:
		GlobalEnums.FleetCommand.GO_WAIT:
			_issue_command_to_ships(_context_menu_ships, {
				"type":     GlobalEnums.FleetCommand.GO_WAIT,
				"position": _context_menu_pos,
			})
		GlobalEnums.FleetCommand.PATROL_AREA:
			## Start radius drag
			_radius_center        = _context_menu_pos
			_pending_command_type = GlobalEnums.FleetCommand.PATROL_AREA
			_radius_dragging      = true
			_radius_drag_start    = _context_menu_pos
		GlobalEnums.FleetCommand.PATROL_ROUTE:
			## Add patrol point to route
			_patrol_route_points.append(_context_menu_pos)
			_patrol_route_ships = _context_menu_ships.duplicate()
			## If shift not held, commit route immediately with current points
			if not _shift_queuing and _patrol_route_points.size() >= 2:
				_issue_command_to_ships(_patrol_route_ships, {
					"type":   GlobalEnums.FleetCommand.PATROL_ROUTE,
					"points": _patrol_route_points.duplicate(),
				})
				_patrol_route_points.clear()
		100: ## Cancel last
			for ship in _context_menu_ships:
				_cancel_last_order(ship)
		101: ## Cancel all
			for ship in _context_menu_ships:
				_cancel_all_orders(ship)


func _on_context_menu_ship_selected(id: int) -> void:
	match id:
		GlobalEnums.FleetCommand.FOLLOW_SHIP:
			_issue_command_to_ships(_context_menu_ships, {
				"type":   GlobalEnums.FleetCommand.FOLLOW_SHIP,
				"target": _context_menu_target,
			})
		GlobalEnums.FleetCommand.DEFEND_SHIP:
			_issue_command_to_ships(_context_menu_ships, {
				"type":   GlobalEnums.FleetCommand.DEFEND_SHIP,
				"target": _context_menu_target,
			})
		100:
			for ship in _context_menu_ships:
				_cancel_last_order(ship)
		101:
			for ship in _context_menu_ships:
				_cancel_all_orders(ship)


func _finish_radius_drag(screen_pos: Vector2, camera: Camera2D) -> void:
	_radius_dragging = false
	var world_pos := camera.get_global_transform().affine_inverse() * screen_pos
	var radius    := _radius_center.distance_to(world_pos)
	radius = maxf(radius, 200.0)
	_issue_command_to_ships(_context_menu_ships, {
		"type":     _pending_command_type,
		"position": _radius_center,
		"radius":   radius,
	})


# ---------------------------------------------------------------------------
# Command issuing
# ---------------------------------------------------------------------------

func _issue_command_to_ships(ships: Array, command: Dictionary) -> void:
	for ship in ships:
		if not is_instance_valid(ship): continue
		var ai := ship.get_node_or_null("AIShipController") as AIShipController
		if not ai: continue
		if _shift_queuing:
			ai.queue_command(command)
		else:
			ai.set_command_queue([command])
	command_issued.emit(ships, command)
	selection_changed.emit(selected_ships)


func _cancel_last_order(ship: ShipInstance) -> void:
	var ai := ship.get_node_or_null("AIShipController") as AIShipController
	if ai: ai.cancel_last_command()
	selection_changed.emit(selected_ships)


func _cancel_all_orders(ship: ShipInstance) -> void:
	var ai := ship.get_node_or_null("AIShipController") as AIShipController
	if ai: ai.cancel_all_commands()
	selection_changed.emit(selected_ships)


# ---------------------------------------------------------------------------
# Selection circles (drawn in world space on ships)
# ---------------------------------------------------------------------------

func _refresh_circles() -> void:
	## Remove old circles
	for circle in _selection_circles:
		if is_instance_valid(circle):
			circle.queue_free()
	_selection_circles.clear()
	## Add new circles
	for ship in selected_ships:
		if not is_instance_valid(ship): continue
		var circle := SelectionCircle.new()
		circle.name = "SelectionCircle"
		ship.add_child(circle)
		_selection_circles.append(circle)


func get_box_select_rect_screen() -> Rect2:
	if not _box_selecting: return Rect2()
	var mouse := get_viewport().get_mouse_position()
	return Rect2(_box_start_screen, mouse - _box_start_screen)


func get_radius_drag_info() -> Dictionary:
	if not _radius_dragging: return {}
	var cam := get_tree().get_first_node_in_group("free_camera") as Camera2D
	if not cam: return {}
	var mouse_world := cam.get_global_transform().affine_inverse() * get_viewport().get_mouse_position()
	return {
		"center": _radius_center,
		"radius": _radius_center.distance_to(mouse_world),
	}


# ===========================================================================
# SelectionCircle — Node2D that draws a circle around a selected ship
# ===========================================================================
class SelectionCircle extends Node2D:
	const RADIUS : float = 80.0
	const COLOR  : Color = Color(0.3, 0.9, 1.0, 0.8)
	const WIDTH  : float = 2.0

	func _draw() -> void:
		draw_arc(Vector2.ZERO, RADIUS, 0.0, TAU, 32, COLOR, WIDTH)

	func _process(_delta: float) -> void:
		queue_redraw()


func prepare_sector_change() -> void:
	selected_ships.clear()
	_refresh_circles()
	_box_selecting = false
	_building_patrol_route = false
	_patrol_route_points.clear()
	_patrol_route_ships.clear()
	_radius_dragging = false
	_context_menu_ships.clear()
	_context_menu_target = null
	if is_instance_valid(_context_menu): _context_menu.hide()
	selection_changed.emit(selected_ships)
