extends RefCounted
const LASER := Color("ff3038")
const BALLISTIC := Color("687782")
const MINING := Color("81ed88")
static func shot_color(weapon: WeaponData) -> Color:
	if weapon == null: return BALLISTIC
	if weapon.weapon_type == GlobalEnums.WeaponType.MINING or str(weapon.id).contains("mining"): return MINING
	if weapon.weapon_type == GlobalEnums.WeaponType.ENERGY: return LASER
	return BALLISTIC
static func muzzle_color(weapon: WeaponData) -> Color:
	return Color("ffce80") if weapon.weapon_type == GlobalEnums.WeaponType.BALLISTIC else shot_color(weapon)
