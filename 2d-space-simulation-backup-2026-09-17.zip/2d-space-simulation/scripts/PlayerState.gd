extends Node

## PlayerState — Autoload singleton.
## Tracks everything about the player that persists across scenes.

signal credits_changed(new_amount: int)
signal reputation_changed(faction_id: StringName, new_rep: float)

# ---------------------------------------------------------------------------
# Economy
# ---------------------------------------------------------------------------
var credits : int = 1000000
# Asset ownership remains player; membership is a separate allegiance.
var joined_faction: StringName = &""
var founded_faction: bool = false
var friendly_fire_enabled: bool = false
const SENSOR_LICENSE_PRICE := 250000
var sensor_licenses: Dictionary = {}

# ---------------------------------------------------------------------------
# Reputation
# ---------------------------------------------------------------------------
var reputation : Dictionary = {}

# ---------------------------------------------------------------------------
# Fleet — live piloted ships in the world
# ---------------------------------------------------------------------------
var fleet_ships : Array[Node] = []

# ---------------------------------------------------------------------------
# Station hangar — station_id → Array of hangar ship dicts
# Each entry: {
#   "ship_data_id":     StringName,
#   "equipped_weapons": Array,       # Array of weapon ids (StringName), null = empty slot
#   "equipped_shield":  StringName,  # shield id or ""
#   "equipped_missiles":Array,       # Array of missile ids
#   "inventory":        Dictionary,  # item_id → amount
#   "has_pilot":        bool,
# }
# ---------------------------------------------------------------------------
var station_hangar : Dictionary = {}

# ---------------------------------------------------------------------------
# Station item storage
# ---------------------------------------------------------------------------
var station_storage : Dictionary = {}

# ---------------------------------------------------------------------------
# Current ship reference
# ---------------------------------------------------------------------------
var current_ship : ShipInstance = null


func _ready() -> void:
	await get_tree().process_frame
	current_ship = get_tree().get_first_node_in_group("player") as ShipInstance
	_init_reputations()


func _init_reputations() -> void:
	for faction_id in GameData.factions:
		var faction : FactionData = GameData.factions[faction_id]
		if not reputation.has(faction_id):
			reputation[faction_id] = faction.starting_reputation


# ---------------------------------------------------------------------------
# Credits
# ---------------------------------------------------------------------------

func add_credits(amount: int) -> void:
	if amount <= 0: return
	credits += amount
	credits_changed.emit(credits)

func spend_credits(amount: int) -> bool:
	if amount < 0 or credits < amount: return false
	credits -= amount
	credits_changed.emit(credits)
	return true

func can_afford(amount: int) -> bool:
	return amount >= 0 and credits >= amount


# ---------------------------------------------------------------------------
# Reputation
# ---------------------------------------------------------------------------

func get_reputation(faction_id: StringName) -> float:
	return reputation.get(faction_id, 0.0)

func add_reputation(faction_id: StringName, amount: float) -> void:
	var current : float = get_reputation(faction_id)
	reputation[faction_id] = clampf(current + amount, -1000.0, 1000.0)
	reputation_changed.emit(faction_id, reputation[faction_id])

func get_stance(faction_id: StringName) -> GlobalEnums.FactionStance:
	if faction_id == &"rogue": return GlobalEnums.FactionStance.HOSTILE
	if joined_faction != &"" and faction_id not in [&"player",joined_faction] and FactionManager.are_at_war(joined_faction,faction_id): return GlobalEnums.FactionStance.HOSTILE
	if joined_faction != &"" and faction_id == joined_faction: return GlobalEnums.FactionStance.ALLIED
	if faction_id == &"player": return GlobalEnums.FactionStance.ALLIED
	if founded_faction and joined_faction==&"":return FactionManager.get_stance(&"player",faction_id)
	var faction : FactionData = GameData.get_faction(faction_id)
	if not faction: return GlobalEnums.FactionStance.NEUTRAL
	return faction.get_player_stance(get_reputation(faction_id))

func is_hostile_to_player(faction_id: StringName) -> bool:
	if faction_id == &"rogue": return true
	return get_stance(faction_id) == GlobalEnums.FactionStance.HOSTILE

func is_friendly_to_player(faction_id: StringName) -> bool:
	var stance := get_stance(faction_id)
	return stance == GlobalEnums.FactionStance.FRIENDLY or stance == GlobalEnums.FactionStance.ALLIED

func set_reputation(faction_id: StringName, value: float) -> void:
	reputation[faction_id] = clampf(value, -1000.0, 1000.0)
	reputation_changed.emit(faction_id, reputation[faction_id])


# ---------------------------------------------------------------------------
# Station hangar
# ---------------------------------------------------------------------------

func get_station_hangar(station_id: StringName) -> Array:
	return station_hangar.get(station_id, [])

func hangar_add_ship(station_id: StringName, ship_data_id: StringName) -> void:
	if not station_hangar.has(station_id):
		station_hangar[station_id] = []
	station_hangar[station_id].append({
		"ship_data_id":      ship_data_id,
		"equipped_weapons":  [],
		"equipped_shield":   &"",
		"equipped_missiles": [],
		"inventory":         {},
		"has_pilot":         false,
	})

func hangar_remove_ship(station_id: StringName, index: int) -> Dictionary:
	if not station_hangar.has(station_id): return {}
	var arr : Array = station_hangar[station_id]
	if index < 0 or index >= arr.size(): return {}
	return arr.pop_at(index)

func hangar_buy_pilot(station_id: StringName, index: int) -> bool:
	if not can_afford(10000): return false
	if not station_hangar.has(station_id): return false
	var arr : Array = station_hangar[station_id]
	if index < 0 or index >= arr.size(): return false
	if arr[index]["has_pilot"]: return false
	spend_credits(10000)
	arr[index]["has_pilot"] = true
	return true

func hangar_store_player_ship(station_id: StringName, player: Player) -> void:
	## Snapshot current player ship into hangar
	if player.ship_data.id == &"escape_pod": return
	if not station_hangar.has(station_id):
		station_hangar[station_id] = []
	var weapon_ids : Array = []
	for w in player.equipped_weapons:
		weapon_ids.append(w.id if w else &"")
	var shield_id : StringName = player.equipped_shield.id if player.equipped_shield else &""
	var missile_ids : Array = []
	for m in player.equipped_missiles:
		missile_ids.append(m.id if m else &"")
	station_hangar[station_id].append({
		"ship_data_id":      player.ship_data.id if player.ship_data else &"",
		"turret_order": player.turret_order,
		"equipped_weapons":  weapon_ids,
		"equipped_shield":   shield_id,
		"equipped_missiles": missile_ids,
		"inventory":         player.inventory.get_all_items(),
		"has_pilot":         false,
		"hull": player.hull,
		"shield": player.shield,
		"energy": player.energy,
	})

func hangar_swap_to_ship(station_id: StringName, index: int, player: Player) -> bool:
	## Store current ship, swap player into hangar ship at index
	if not station_hangar.has(station_id): return false
	var arr : Array = station_hangar[station_id]
	if index < 0 or index >= arr.size(): return false
	var entry : Dictionary = arr[index]
	var sd: ShipData = GameData.get_ship(entry["ship_data_id"])
	if not sd: return false
	hangar_store_player_ship(station_id, player)
	# The incoming ship's hired pilot takes over the outgoing hull.
	if player.ship_data.id != &"escape_pod": arr.back()["has_pilot"] = entry.get("has_pilot", false)
	arr.remove_at(index)
	player.initialize(sd)
	restore_ship_entry(player, entry)
	return true


# ---------------------------------------------------------------------------
# Station item storage
# ---------------------------------------------------------------------------

func get_station_storage(station_id: StringName) -> Dictionary:
	return station_storage.get(station_id, {})

func station_storage_add(station_id: StringName, item_id: StringName, amount: int) -> void:
	if amount <= 0: return
	if not station_storage.has(station_id):
		station_storage[station_id] = {}
	var current : int = station_storage[station_id].get(item_id, 0)
	station_storage[station_id][item_id] = current + amount

func station_storage_remove(station_id: StringName, item_id: StringName, amount: int) -> bool:
	if amount <= 0: return false
	if not station_storage.has(station_id): return false
	var current : int = station_storage[station_id].get(item_id, 0)
	if current < amount: return false
	station_storage[station_id][item_id] = current - amount
	if station_storage[station_id][item_id] <= 0:
		station_storage[station_id].erase(item_id)
	return true

func station_storage_has(station_id: StringName, item_id: StringName, amount: int) -> bool:
	if not station_storage.has(station_id): return false
	return station_storage[station_id].get(item_id, 0) >= amount


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------

func serialize() -> Dictionary:
	return {
		"sensor_licenses": sensor_licenses.duplicate(),
		"friendly_fire_enabled": friendly_fire_enabled,
		"joined_faction": joined_faction,
		"founded_faction": founded_faction,
		"credits":         credits,
		"reputation":      reputation.duplicate(),
		"station_hangar":  station_hangar.duplicate(true),
		"station_storage": station_storage.duplicate(true),
	}

func deserialize(data: Dictionary) -> void:
	sensor_licenses=data.get("sensor_licenses",{}).duplicate()
	friendly_fire_enabled = data.get("friendly_fire_enabled", false)
	joined_faction = data.get("joined_faction", &"")
	founded_faction = data.get("founded_faction", false)
	credits         = data.get("credits", 1000000)
	reputation      = data.get("reputation", {})
	station_hangar  = data.get("station_hangar", {})
	station_storage = data.get("station_storage", {})
	credits_changed.emit(credits)


func restore_ship_entry(ship: ShipInstance, entry: Dictionary) -> void:
	ship.set_turret_order(int(entry.get("turret_order", 0)))
	ship.turret_threats.clear()
	ship.equipped_weapons.clear()
	ship.equipped_weapons.resize(ship.ship_data.weapon_slots)
	ship.equipped_shield = null
	ship.equipped_missiles.clear()
	ship.equipped_missiles.resize(ship.ship_data.missile_slots)
	ship.inventory.clear()
	var weapon_ids: Array = entry.get("equipped_weapons", [])
	var displaced: Dictionary = {}
	for i in weapon_ids.size():
		if not GameData.weapons.has(weapon_ids[i]): continue
		var weapon: WeaponData = GameData.weapons[weapon_ids[i]]
		var fitted: bool = i < ship.equipped_weapons.size() and ship.equipped_weapons[i] == null and ship.equip_weapon(weapon, i)
		if not fitted:
			for slot in ship.ship_data.weapon_slots:
				if ship.equipped_weapons[slot] == null and ship.equip_weapon(weapon, slot):
					fitted = true
					break
		if not fitted: displaced[weapon.id] = int(displaced.get(weapon.id,0)) + 1
	var shield_id: StringName = entry.get("equipped_shield", &"")
	if GameData.shields.has(shield_id): ship.equip_shield(GameData.shields[shield_id])
	var missile_ids: Array = entry.get("equipped_missiles", [])
	for i in missile_ids.size():
		if not GameData.missiles.has(missile_ids[i]): continue
		var missile: MissileData = GameData.missiles[missile_ids[i]]
		var fitted: bool = i < ship.equipped_missiles.size() and ship.equipped_missiles[i] == null and ship.equip_missile(missile, i)
		if not fitted:
			for slot in ship.ship_data.missile_slots:
				if ship.equipped_missiles[slot] == null and ship.equip_missile(missile, slot):
					fitted = true
					break
		if not fitted: displaced[missile.id] = int(displaced.get(missile.id,0)) + 1
	for item_id in entry.get("inventory", {}):
		ship.inventory.add_item(item_id, entry["inventory"][item_id])
	for id in displaced: ship.inventory.add_item(id, displaced[id])
	ship._apply_shield()
	ship.hull = clampf(entry.get("hull", ship.max_hull), 0, ship.max_hull)
	ship.shield = clampf(entry.get("shield", ship.max_shield), 0, ship.max_shield)
	ship.energy = clampf(entry.get("energy", ship.max_energy), 0, ship.max_energy)
	ship.hull_changed.emit(ship.hull, ship.max_hull)
	ship.shield_changed.emit(ship.shield, ship.max_shield)
	ship.energy_changed.emit(ship.energy, ship.max_energy)
	ship._refresh_visuals()


const BOARDING_RANGE: float = 350.0

func boarding_problem(target: ShipInstance) -> String:
	var player := current_ship as Player
	if not is_instance_valid(player) or player._is_destroyed or player._is_docked: return "Unavailable while docked or destroyed"
	if not is_instance_valid(target) or target == player or target._is_destroyed or target.is_queued_for_deletion(): return "Ship unavailable"
	if not target.is_in_group("player_fleet"): return "You do not own this ship"
	if not target.is_inside_tree() or not target.ship_data: return "Ship unavailable"
	if player.global_position.distance_to(target.global_position) > BOARDING_RANGE: return "Approach within 350 units"
	if BuildPlacement.active: return "Finish station placement first"
	return ""

func _boarding_snapshot(ship: ShipInstance) -> Dictionary:
	var weapons: Array = []
	var missiles: Array = []
	for w in ship.equipped_weapons: weapons.append(w.id if w else &"")
	for m in ship.equipped_missiles: missiles.append(m.id if m else &"")
	return {"ship_data_id": ship.ship_data.id, "turret_order": ship.turret_order, "equipped_weapons": weapons,
		"equipped_shield": ship.equipped_shield.id if ship.equipped_shield else &"",
		"equipped_missiles": missiles, "inventory": ship.inventory.get_all_items().duplicate(),
		"hull": ship.hull, "shield": ship.shield, "energy": ship.energy,
		"groups": ship.weapon_fire_groups.duplicate(), "cooldowns": ship._weapon_cooldowns.duplicate(),
		"shield_delay": ship._shield_delay_timer, "energy_delay": ship._energy_delay_timer}

func _restore_boarding(ship: ShipInstance, entry: Dictionary) -> void:
	restore_ship_entry(ship, entry)
	ship.weapon_fire_groups.assign(entry.groups)
	ship._weapon_cooldowns.assign(entry.cooldowns)
	ship._shield_delay_timer = entry.shield_delay
	ship._energy_delay_timer = entry.energy_delay

func board_ship(target: ShipInstance) -> bool:
	if boarding_problem(target) != "": return false
	var player := current_ship as Player
	var outgoing := _boarding_snapshot(player)
	var incoming := _boarding_snapshot(target)
	var old_ship: ShipInstance = null
	if player.ship_data.id != &"escape_pod":
		if not StationSpawner.SHIP_SCENES.has(player.ship_data.id): return false
		old_ship = load(StationSpawner.SHIP_SCENES[player.ship_data.id]).instantiate()
		old_ship.faction_id = player.faction_id
		old_ship.add_to_group("player_fleet")
		SectorManager.add_sector_entity(old_ship)
		old_ship.initialize(player.ship_data)
		_restore_boarding(old_ship, outgoing)
		old_ship.global_position = player.global_position
		old_ship.rotation = player.rotation + PI
		old_ship.velocity = Vector2.ZERO
		var ai := AIShipController.new()
		ai.name = "AIShipController"
		old_ship.add_child(ai)
		fleet_ships.append(old_ship)
	var missiles := player.get_node_or_null("MissileSystem")
	if missiles: missiles.cancel()
	player.initialize(target.ship_data)
	_restore_boarding(player, incoming)
	player.global_position = target.global_position
	player.rotation = target.rotation + PI
	player.velocity = target.velocity
	FleetCommandSystem.deselect_all()
	var camera := get_tree().get_first_node_in_group("free_camera")
	if camera and camera.is_free_mode(): camera._exit_free_cam()
	fleet_ships.erase(target)
	target.remove_from_group("player_fleet")
	target.remove_from_group("ships")
	target.get_parent().remove_child(target)
	target.queue_free()
	return true


func can_join_faction(id: StringName) -> bool:
	if id == &"player" or not GameData.factions.has(id) or FactionManager._defeated_factions.has(id): return false
	var stance: int = GameData.factions[id].get_player_stance(get_reputation(id))
	return stance in [GlobalEnums.FactionStance.FRIENDLY, GlobalEnums.FactionStance.ALLIED]

func join_faction(id: StringName) -> bool:
	if not can_join_faction(id): return false
	joined_faction = id
	reputation_changed.emit(id,get_reputation(id))
	return true

func establish_faction(headquarters: StationInstance) -> bool:
	if not is_instance_valid(headquarters) or headquarters._is_destroyed or headquarters.faction_id != &"player" or headquarters.station_data.station_type != StationData.TYPE_HEADQUARTERS: return false
	if not founded_faction:
		for id in GameData.factions:
			var stance: int=GameData.factions[id].get_player_stance(get_reputation(id))
			var relation:=0.0
			match stance:
				GlobalEnums.FactionStance.HOSTILE:relation=-1.0
				GlobalEnums.FactionStance.FRIENDLY:relation=0.25
				GlobalEnums.FactionStance.ALLIED:relation=1.0
			FactionManager._set_relation_raw(&"player",id,relation)
	founded_faction = true
	joined_faction = &""
	var sector = preload("res://scripts/StationConstruction.gd").sector_of(headquarters)
	if sector and sector.sector_data.controlling_faction_id in [&"", &"player"]:
		sector.sector_data.controlling_faction_id = &"player"
		FactionManager._sector_ownership[sector.sector_data.id] = &"player"
	return true


func beacon_claim_faction() -> StringName:
	# Personal asset ownership is separate from the territory's beneficiary.
	if joined_faction != &"": return joined_faction
	return &"player" if founded_faction else &""

func beacon_claim_problem(sector: SectorInstance) -> String:
	if not sector: return "Sector unavailable"
	if beacon_claim_faction() == &"": return "Join a faction or establish your own headquarters first"
	if sector.sector_data.controlling_faction_id != &"": return "Sector is already claimed"
	return ""


func end_founded_faction() -> void:
	if not founded_faction: return
	founded_faction = false
	joined_faction = &""
	for id in GameData.sectors:
		if GameData.sectors[id].controlling_faction_id == &"player":
			GameData.sectors[id].controlling_faction_id = &""
			FactionManager._sector_ownership[id] = &""
	FactionManager.faction_defeated.emit(&"player")
	SaveManager._message("Headquarters destroyed. Your faction has ended; you are independent. Personal assets remain yours.")


func combat_damage_allowed(attacker: Node, target: Node) -> bool:
	if friendly_fire_enabled or not is_instance_valid(attacker): return true
	if not (attacker is ShipInstance or attacker is StationInstance): return true
	if not (target is ShipInstance or target is StationInstance or target.is_in_group("construction_scaffolds")): return true
	var source: StringName= &"player" if attacker.is_in_group("player") or attacker.is_in_group("player_fleet") else attacker.faction_id
	var destination: StringName= &"player" if target.is_in_group("player") or target.is_in_group("player_fleet") else target.faction_id
	return FactionManager.are_at_war(source,destination)


func has_shared_sensors(id: StringName) -> bool:
	if id==&"" or id==&"rogue" or FactionManager._defeated_factions.has(id):return false
	return id==joined_faction or (sensor_licenses.has(id) and is_friendly_to_player(id))

func buy_sensor_license(id: StringName) -> bool:
	if not GameData.factions.has(id) or id==joined_faction or sensor_licenses.has(id) or not is_friendly_to_player(id) or FactionManager._defeated_factions.has(id):return false
	if not spend_credits(SENSOR_LICENSE_PRICE):return false
	sensor_licenses[id]=true
	FactionManager.add_faction_credits(id,SENSOR_LICENSE_PRICE)
	return true
