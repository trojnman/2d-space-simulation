extends VBoxContainer
var picker:OptionButton
var rows:VBoxContainer
var targets:Array=[]
var target:Node
func _ready()->void:
 var hint:=Label.new()
 hint.text="Nearby owned ships / construction • Drag cargo between columns • Shift-click to split"
 hint.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
 add_child(hint)
 picker=OptionButton.new()
 add_child(picker)
 picker.item_selected.connect(func(index):target=targets[index];refresh())
 var update:=Button.new()
 update.text="Refresh nearby inventories"
 update.pressed.connect(scan)
 add_child(update)
 var scroll:=ScrollContainer.new()
 scroll.size_flags_vertical=Control.SIZE_EXPAND_FILL
 add_child(scroll)
 rows=VBoxContainer.new()
 rows.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 scroll.add_child(rows)
 visibility_changed.connect(func():
  if is_visible_in_tree():scan())
 scan()
func accessible(node:Node)->bool:
 var player=PlayerState.current_ship
 if not is_instance_valid(node) or not is_instance_valid(player) or node.get("_is_destroyed"):return false
 if preload("res://scripts/StationConstruction.gd").sector_of(node)!=SectorManager.current_sector:return false
 if node is ShipInstance:return node.is_in_group("player_fleet") and node!=player and node.global_position.distance_to(player.global_position)<=800
 return node.is_in_group("construction_scaffolds") and node.beneficiary in [&"player",PlayerState.joined_faction] and not node.completed and node.remaining<0 and not player._is_docked and node.global_position.distance_to(player.global_position)<=350
func scan()->void:
 targets.clear();picker.clear()
 for group in ["player_fleet","construction_scaffolds"]:
  for node in get_tree().get_nodes_in_group(group):
   if not accessible(node):continue
   targets.append(node)
   picker.add_item(node.ship_data.display_name if node is ShipInstance else GameData.stations[node.blueprint].display_name+" construction")
 target=targets[0] if not targets.is_empty() else null
 refresh()
func contents()->Dictionary:
 if not accessible(target):return {}
 return target.inventory.get_all_items() if target is ShipInstance else target.cargo
func refresh()->void:
 for child in rows.get_children():rows.remove_child(child);child.queue_free()
 if not accessible(target):
  var empty:=Label.new();empty.text="No accessible inventory nearby.";rows.add_child(empty);return
 var cargo=PlayerState.current_ship.inventory.get_all_items()
 var other=contents()
 var ids:Array=cargo.keys()
 for id in other:
  if not ids.has(id):ids.append(id)
 for id in ids:
  var row:=HBoxContainer.new();rows.add_child(row)
  var label:=Label.new();label.text=GameData.items[id].display_name;label.size_flags_horizontal=Control.SIZE_EXPAND_FILL;row.add_child(label)
  for from_player in [true,false]:
   var cell:=Button.new()
   cell.text=("Your cargo ×%d" % int(cargo.get(id,0))) if from_player else ("Target ×%d" % int(other.get(id,0)))
   cell.custom_minimum_size.x=150
   row.add_child(cell)
   preload("res://scripts/CargoDrag.gd").bind(cell,
    func():return {"type":"nearby_cargo","item_id":id,"amount":PlayerState.current_ship.inventory.get_amount(id) if from_player else int(contents().get(id,0)),"target":target,"from_player":from_player},
    func(data):return data is Dictionary and data.get("type")=="nearby_cargo" and data.get("target")==target and accessible(target) and data.get("from_player")!=from_player,
    func(data):transfer(data.item_id,int(data.amount),not from_player);refresh.call_deferred())
func transfer(id:StringName,amount:int,deposit:bool)->bool:
 if amount<=0 or not accessible(target):return false
 var inventory=PlayerState.current_ship.inventory
 if target is ShipInstance:
  var source=inventory if deposit else target.inventory
  var destination=target.inventory if deposit else inventory
  if not source.has_item(id,amount):return false
  if not destination.add_item(id,amount,GameData.items):return false
  source.remove_item(id,amount)
 else:
  if deposit:
   var needed:int=int(target.requirements().get(id,0))-int(target.cargo.get(id,0))
   if amount>needed or not inventory.has_item(id,amount):return false
   inventory.remove_item(id,amount)
   target.cargo[id]=int(target.cargo.get(id,0))+amount
  else:
   if int(target.cargo.get(id,0))<amount or not inventory.add_item(id,amount,GameData.items):return false
   target.cargo[id]-=amount
   if target.cargo[id]==0:target.cargo.erase(id)
 return true
