extends Control
var target:Node2D
var lock_time:=0.0
var own_card:PanelContainer
var target_card:PanelContainer
func _ready()->void:
 add_to_group("targeting_hud")
 mouse_filter=Control.MOUSE_FILTER_IGNORE
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 own_card=preload("res://scripts/TelemetryCard.gd").new()
 target_card=preload("res://scripts/TelemetryCard.gd").new()
 add_child(own_card)
 add_child(target_card)
 own_card.heading.text="FLIGHT SYSTEMS  /  YOUR SHIP"
 target_card.heading.text="SENSOR ARRAY  /  TARGET"
func valid_contact(node)->bool:
 return is_instance_valid(node) and node.is_inside_tree() and not node.is_queued_for_deletion() and not node.get("_is_destroyed") and SensorSystem.has_local_contact(node.global_position)
func select_contact(node:Node2D)->bool:
 if not valid_contact(node) or node==PlayerState.current_ship:return false
 target=node
 lock_time=0
 return true
func missile_lock()->Node2D:
 if lock_time<1.0 or not valid_contact(target):return null
 var player=PlayerState.current_ship
 if not is_instance_valid(player):return null
 var missiles=player.get_node_or_null("MissileSystem")
 var payload=missiles._get_equipped_missile() if missiles else null
 if not payload or player.global_position.distance_to(target.global_position)>payload.lock_on_range:return null
 if target is ShipInstance and target.ship_data.id==&"escape_pod":return null
 if not (target is ShipInstance or target is StationInstance) or not PlayerState.is_hostile_to_player(target.faction_id):return null
 return target
func select_at(point:Vector2) -> void:
 var best:=40.0
 var nearest:Node2D
 for group in ["ships","stations","asteroids"]:
  for node in get_tree().get_nodes_in_group(group):
   if node==PlayerState.current_ship or not valid_contact(node):continue
   var distance:float=node.get_global_transform_with_canvas().origin.distance_to(point)
   if distance<best:best=distance;nearest=node
 target=null
 lock_time=0
 if nearest:select_contact(nearest)
func clear_targets()->void:
 target=null
 lock_time=0
 for node in get_tree().root.find_children("*","",true,false):
  if node.get_script()==preload("res://scripts/StationIdentification.gd"):
   node.selected=null
   node.hovered=null
func _input(event:InputEvent)->void:
 if not visible or get_tree().paused:return
 if not event is InputEventKey or not event.pressed or event.echo:return
 var focus=get_viewport().gui_get_focus_owner()
 if focus is LineEdit or focus is TextEdit:return
 if event.physical_keycode==KEY_TAB:
  select_at(get_viewport().get_mouse_position())
  get_viewport().set_input_as_handled()
 elif event.physical_keycode==KEY_X:
  clear_targets()
  get_viewport().set_input_as_handled()
func _process(delta:float)->void:
 var player=PlayerState.current_ship
 visible=is_instance_valid(player) and player.ship_data!=null and not player._is_docked
 if not visible:return
 own_card.title.text=player.ship_data.display_name
 own_card.metric("Hull",player.hull,player.max_hull)
 own_card.metric("Shields",player.shield,player.max_shield)
 own_card.metric("Energy",player.energy,player.max_energy)
 own_card.footer.text="SPEED  %d   •   I  Inventory" % player.velocity.length()
 if not valid_contact(target):target=null;lock_time=0
 if target:
  var missiles=player.get_node_or_null("MissileSystem")
  var payload=missiles._get_equipped_missile() if missiles else null
  var hostile:bool=(target is ShipInstance or target is StationInstance) and PlayerState.is_hostile_to_player(target.faction_id)
  var in_range:bool=payload!=null and player.global_position.distance_to(target.global_position)<=payload.lock_on_range
  if hostile and in_range:lock_time=minf(1,lock_time+delta)
  else:lock_time=0
  var title:String=target.ship_data.display_name if target is ShipInstance else (target.station_data.display_name if target is StationInstance else "Asteroid")
  target_card.title.text=title
  target_card.metric("Hull",target.hull,target.max_hull)
  target_card.metric("Shields",target.shield if target is ShipInstance else 0,target.max_shield if target is ShipInstance else 0)
  target_card.metric("Energy",lock_time*100,100,"MISSILE LOCK")
  target_card.footer.text="%s   •   %d m   •   X Clear" % ["LOCKED" if missile_lock()!=null else "TRACKING",player.global_position.distance_to(target.global_position)]
  if target is AsteroidInstance:
   target_card.title.text=String(AsteroidInstance.MATERIAL_IDS[target.material_type]).capitalize()+" Asteroid"
   target_card.metric("Energy",maxi(0,target._remaining_yield),maxi(target.initial_yield,target._remaining_yield),"ORE REMAINING")
   target_card.footer.text="Mining laser required   •   %d m" % player.global_position.distance_to(target.global_position)
 else:
  target_card.title.text="No contact selected"
  for id in ["Hull","Shields","Energy"]:target_card.metric(id,0,0,"MISSILE LOCK" if id=="Energy" else "")
  target_card.footer.text="Tab  Target near cursor   •   X  Clear"
 own_card.place_at(get_viewport_rect().size,false)
 target_card.place_at(get_viewport_rect().size,true)
 queue_redraw()
func _draw()->void:
 if not visible:return
 for group in ["ships","stations","asteroids"]:
  for node in get_tree().get_nodes_in_group(group):
   if node==PlayerState.current_ship or not valid_contact(node):continue
   var point:Vector2=node.get_global_transform_with_canvas().origin
   if not get_viewport_rect().has_point(point):continue
   var maximum:float=node.max_hull if node is ShipInstance or node is StationInstance else maxf(1,node.hull)
   if node==target:draw_arc(point,26,0,TAU,32,Color("67e8f9"),2)
   if node==target or node.hull<maximum or point.distance_to(get_global_mouse_position())<40:
    draw_rect(Rect2(point+Vector2(-24,32),Vector2(48,5)),Color("192533"))
    draw_rect(Rect2(point+Vector2(-24,32),Vector2(48*clampf(node.hull/maximum,0,1),5)),Color("6de2a5"))
