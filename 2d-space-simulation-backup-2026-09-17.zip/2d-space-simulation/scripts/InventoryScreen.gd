class_name InventoryScreen
extends CanvasLayer

## Player inventory screen. I key opens/closes.

const BASE_SIZE    : Vector2 = Vector2(1920.0, 1080.0)

const CARGO_SLOTS := {
	&"fighter": 5, &"hauler": 15, &"miner": 12, &"missile_boat": 6,
	&"medium_fighter": 10, &"medium_hauler": 30, &"medium_miner": 25,
	&"medium_missile_boat": 12, &"medium_logistics": 28,
	&"heavy_fighter": 15, &"heavy_hauler": 50, &"heavy_miner": 45,
	&"heavy_missile_boat": 20, &"large_logistics": 45,
}

const GRID_COLUMNS  : int   = 5
const SLOT_SIZE     : int   = 64
const SLOT_BG_COLOR : Color = Color(0.1,  0.12, 0.18, 0.9)
const SLOT_BORDER   : Color = Color(0.3,  0.35, 0.5,  0.8)
const WEAPON_COLOR  : Color = Color(0.15, 0.08, 0.08, 0.95)
const SHIELD_COLOR  : Color = Color(0.08, 0.08, 0.18, 0.95)
const MISSILE_COLOR : Color = Color(0.08, 0.15, 0.08, 0.95)
const EMPTY_COLOR   : Color = Color(0.06, 0.07, 0.10, 0.8)

var _cargo_slots   : Array  = []
var _player        : Player = null
var _tooltip_popup : Panel  = null

@onready var header_ship_name    : Label         = $VBoxContainer/Header/ShipName
@onready var header_sector_name  : Label         = $VBoxContainer/Header/SectorName
@onready var header_faction      : Label         = $VBoxContainer/Header/FactionName
@onready var ship_name_lbl       : Label         = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/ShipName
@onready var ship_class_lbl      : Label         = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/ShipClass
@onready var weapons_section     : VBoxContainer = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/WeaponsSection
@onready var shield_section      : VBoxContainer = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/ShieldSection
@onready var missiles_section    : VBoxContainer = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/MissilesSection
@onready var stats_section       : VBoxContainer = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/StatsSection
@onready var fire_groups_section : VBoxContainer = $VBoxContainer/TabContainer/Inventory/MainContainer/EquipmentPanel/FireGroupsSection
@onready var cargo_label         : Label         = $VBoxContainer/TabContainer/Inventory/MainContainer/CargoPanel/CargoHeader/CargoLabel
@onready var cargo_count         : Label         = $VBoxContainer/TabContainer/Inventory/MainContainer/CargoPanel/CargoHeader/CargoCount
@onready var cargo_grid          : GridContainer = $VBoxContainer/TabContainer/Inventory/MainContainer/CargoPanel/CargoScroll/CargoGrid
@onready var tab_container       : TabContainer  = $VBoxContainer/TabContainer
@onready var _root_vbox          : Control       = $VBoxContainer


func _ready() -> void:
	preload("res://scripts/ConsoleTheme.gd").apply_to(self)
	hide()
	add_to_group("inventory_screen")
	_build_tooltip()
	var construction:=preload("res://scripts/ConstructionKitPanel.gd").new()
	construction.name="Construction"
	construction.screen=self
	tab_container.add_child(construction)
	if cargo_grid:
		cargo_grid.columns = GRID_COLUMNS
	get_viewport().size_changed.connect(_on_viewport_resized)
	_on_viewport_resized()


func _on_viewport_resized() -> void:
	if not _root_vbox: return
	var screen_size  := get_viewport().get_visible_rect().size
	var scale_factor := minf(screen_size.x / BASE_SIZE.x, screen_size.y / BASE_SIZE.y)
	_root_vbox.scale        = Vector2(scale_factor, scale_factor)
	_root_vbox.pivot_offset = _root_vbox.size / 2.0


func _build_tooltip() -> void:
	_tooltip_popup = Panel.new()
	_tooltip_popup.visible = false
	_tooltip_popup.z_index = 100
	add_child(_tooltip_popup)
	var lbl := Label.new()
	lbl.name = "TooltipLabel"
	lbl.autowrap_mode = TextServer.AUTOWRAP_WORD
	lbl.custom_minimum_size = Vector2(200, 0)
	_tooltip_popup.add_child(lbl)


# ---------------------------------------------------------------------------
# Open / Close
# ---------------------------------------------------------------------------

func open(player: Player) -> void:
	_player = player
	_sync_slots_from_inventory()
	_populate_header()
	_populate_equipment()
	_populate_cargo()
	get_tree().paused = true
	show()


func close() -> void:
	get_tree().paused = false
	hide()
	_hide_tooltip()


func toggle(player: Player) -> void:
	if visible: close()
	else: open(player)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("inventory") or (visible and event.is_action_pressed("ui_cancel")):
		get_viewport().set_input_as_handled()
		if visible:
			close()
			return
		var dm := get_tree().get_first_node_in_group("docking_manager")
		if dm and dm.current_station != null:
			return
		var p := get_tree().get_first_node_in_group("player") as Player
		if p:
			open(p)


# ---------------------------------------------------------------------------
# Header
# ---------------------------------------------------------------------------

func _populate_header() -> void:
	if not _player: return
	if header_ship_name:
		header_ship_name.text = _player.ship_data.display_name if _player.ship_data else "Unknown Ship"
	var sd : SectorData = SectorManager.get_current_sector_data()
	if header_sector_name:
		header_sector_name.text = sd.display_name if sd else "Unknown Sector"
	if header_faction:
		var faction : FactionData = GameData.get_faction(sd.controlling_faction_id if sd else &"")
		header_faction.text = faction.display_name if faction else "Unclaimed"


# ---------------------------------------------------------------------------
# Cargo slot sync
# ---------------------------------------------------------------------------

func _sync_slots_from_inventory() -> void:
	if not _player or not _player.ship_data: return
	var slot_count : int = _get_slot_count(_player.ship_data.id)
	while _cargo_slots.size() < slot_count:
		_cargo_slots.append(null)
	var items      : Dictionary = _player.inventory.get_all_items()
	var placed_ids : Dictionary = {}
	for i in _cargo_slots.size():
		if _cargo_slots[i] == null: continue
		var sid : StringName = _cargo_slots[i]["id"]
		if not items.has(sid):
			_cargo_slots[i] = null
		elif placed_ids.has(sid):
			_cargo_slots[i] = null
		else:
			_cargo_slots[i]["amount"] = items[sid]
			placed_ids[sid] = true
	for item_id in items:
		if placed_ids.has(item_id): continue
		for i in _cargo_slots.size():
			if _cargo_slots[i] == null:
				_cargo_slots[i] = {"id": item_id, "amount": items[item_id]}
				placed_ids[item_id] = true
				break


func _write_slots_to_inventory() -> void:
	if not _player: return
	_player.inventory.clear()
	for slot in _cargo_slots:
		if slot != null:
			_player.inventory.add_item(slot["id"], slot["amount"])


# ---------------------------------------------------------------------------
# Equipment panel
# ---------------------------------------------------------------------------

func _populate_equipment() -> void:
	if not _player or not _player.ship_data: return
	var sd := _player.ship_data
	ship_name_lbl.text  = sd.display_name
	ship_class_lbl.text = _class_label(sd.ship_class)

	_clear_section(weapons_section, "Weapons")
	for i in sd.weapon_slots:
		var w   : WeaponData = _player.equipped_weapons[i] if i < _player.equipped_weapons.size() else null
		var tip : String     = "%s\n%d RPM  %.0f dmg" % [w.display_name, w.fire_rate_rpm, w.damage] if w else ""
		weapons_section.add_child(_make_equip_panel(w.display_name if w else "-- Empty --", tip, WEAPON_COLOR, w != null, "weapon", i))

	_clear_section(shield_section, "Shield")
	var sh   : ShieldData = _player.equipped_shield
	var stip : String     = "%s\n%.0f HP  %.1f/s  %.1fs delay" % [sh.display_name, sh.max_hp, sh.recharge_rate, sh.recharge_delay] if sh else ""
	shield_section.add_child(_make_equip_panel(sh.display_name if sh else "-- Empty --", stip, SHIELD_COLOR, sh != null, "shield", 0))

	_clear_section(missiles_section, "Missiles")
	for i in sd.missile_slots:
		var m    : MissileData = _player.equipped_missiles[i] if i < _player.equipped_missiles.size() else null
		var mtip : String      = "%s\n%.0f dmg  %.0f blast" % [m.display_name, m.damage, m.blast_radius] if m else ""
		missiles_section.add_child(_make_equip_panel(m.display_name if m else "-- Empty --", mtip, MISSILE_COLOR, m != null, "missile", i))

	_clear_section(stats_section, "Stats")
	var lbl := Label.new()
	lbl.add_theme_font_size_override("font_size", 12)
	stats_section.add_child(lbl)
	_refresh_stats()

	_populate_fire_groups()


func _populate_fire_groups() -> void:
	if not fire_groups_section: return
	for child in fire_groups_section.get_children(): child.queue_free()
	if not _player or not _player.ship_data: return

	var header := Label.new()
	header.text = "Fire Groups"
	header.add_theme_font_size_override("font_size", 13)
	header.add_theme_color_override("font_color", Color(0.6, 0.7, 0.9))
	fire_groups_section.add_child(header)

	for i in _player.ship_data.weapon_slots:
		var w : WeaponData = _player.equipped_weapons[i] if i < _player.equipped_weapons.size() else null
		if w == null: continue
		var row := HBoxContainer.new()
		row.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var slot_lbl := Label.new()
		slot_lbl.text = "[%d] %s" % [i + 1, w.display_name]
		slot_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		slot_lbl.add_theme_font_size_override("font_size", 12)
		row.add_child(slot_lbl)
		var opt := OptionButton.new()
		opt.add_item("Group 1", 1)
		opt.add_item("Group 2", 2)
		var current_group : int = _player.weapon_fire_groups[i] if i < _player.weapon_fire_groups.size() else 1
		opt.selected = 0 if current_group == 1 else 1
		opt.item_selected.connect(_on_fire_group_changed.bind(i))
		row.add_child(opt)
		fire_groups_section.add_child(row)


func _on_fire_group_changed(index: int, slot: int) -> void:
	var group := index + 1
	_player.set_weapon_fire_group(slot, group)


func _clear_section(section: VBoxContainer, header_text: String) -> void:
	if not section: return
	for child in section.get_children(): child.queue_free()
	var header := Label.new()
	header.text = header_text
	header.add_theme_font_size_override("font_size", 13)
	header.add_theme_color_override("font_color", Color(0.6, 0.7, 0.9))
	section.add_child(header)


func _make_equip_panel(label_text: String, tooltip_text: String, bg_color: Color, filled: bool, slot_type: String, slot_idx: int) -> Control:
	var panel := EquipSlot.new()
	panel.setup(label_text, tooltip_text, bg_color, filled, slot_type, slot_idx, _player, self)
	return panel


# ---------------------------------------------------------------------------
# Cargo panel
# ---------------------------------------------------------------------------

func _populate_cargo() -> void:
	if not _player or not _player.ship_data: return
	if not cargo_grid: return
	for child in cargo_grid.get_children(): child.queue_free()
	var slot_count : int = _get_slot_count(_player.ship_data.id)
	var used : int = 0
	for s in _cargo_slots:
		if s != null: used += 1
	cargo_label.text = "Cargo"
	cargo_count.text = "%d / %d slots used" % [used, slot_count]
	for i in slot_count:
		var slot_data = _cargo_slots[i] if i < _cargo_slots.size() else null
		if slot_data != null:
			cargo_grid.add_child(_make_cargo_panel(i, slot_data["id"], slot_data["amount"]))
		else:
			cargo_grid.add_child(_make_empty_panel(i))


func _make_cargo_panel(slot_idx: int, item_id: StringName, amount: int) -> Control:
	var panel := CargoSlot.new()
	panel.setup(slot_idx, item_id, amount, _player, self)
	return panel


func _make_empty_panel(slot_idx: int) -> Control:
	var panel := EmptySlot.new()
	panel.setup(slot_idx, self)
	return panel


# ---------------------------------------------------------------------------
# Equipment interactions
# ---------------------------------------------------------------------------

func equip_from_cargo(item_id: StringName, cargo_slot: int, slot_type: String, slot_idx: int) -> void:
	if not _player or not _player.inventory.has_item(item_id): return
	var old_id: StringName = _equipped_id(slot_type, slot_idx)
	var item: ItemData = GameData.items.get(item_id)
	if item == null: return
	var old_volume: float = GameData.items[old_id].volume if GameData.items.has(old_id) else 0.0
	if _player.inventory.get_free_capacity(GameData.items) + item.volume < old_volume: return
	var equipped: bool = false
	match slot_type:
		"weapon":
			if GameData.weapons.has(item_id): equipped = _player.equip_weapon(GameData.weapons[item_id], slot_idx)
		"shield":
			if GameData.shields.has(item_id): equipped = _player.equip_shield(GameData.shields[item_id])
		"missile":
			if GameData.missiles.has(item_id): equipped = _player.equip_missile(GameData.missiles[item_id], slot_idx)
	if not equipped: return
	_player.inventory.remove_item(item_id, 1)
	if old_id != &"": _player.inventory.add_item(old_id, 1, GameData.items)
	_sync_slots_from_inventory()
	_populate_equipment()
	_populate_cargo()


func _equipped_id(slot_type: String, slot_idx: int) -> StringName:
	if slot_idx < 0: return &""
	match slot_type:
		"weapon":
			if slot_idx < _player.equipped_weapons.size() and _player.equipped_weapons[slot_idx]: return _player.equipped_weapons[slot_idx].id
		"shield":
			if _player.equipped_shield: return _player.equipped_shield.id
		"missile":
			if slot_idx < _player.equipped_missiles.size() and _player.equipped_missiles[slot_idx]: return _player.equipped_missiles[slot_idx].id
	return &""


func unequip_to_slot(slot_type: String, slot_idx: int, cargo_slot: int) -> void:
	if not _player: return
	var item_id: StringName = _equipped_id(slot_type, slot_idx)
	if item_id == &"" or not _player.inventory.add_item(item_id, 1, GameData.items): return
	match slot_type:
		"weapon": _player.equipped_weapons[slot_idx] = null
		"shield":
			_player.equipped_shield = null
			_player._apply_shield()
		"missile": _player.equipped_missiles[slot_idx] = null
	_player._refresh_visuals()
	_sync_slots_from_inventory()
	_populate_equipment()
	_populate_cargo()


func move_cargo(from_slot: int, to_slot: int) -> void:
	if from_slot == to_slot: return
	while _cargo_slots.size() <= maxi(from_slot, to_slot):
		_cargo_slots.append(null)
	var tmp                 = _cargo_slots[from_slot]
	_cargo_slots[from_slot] = _cargo_slots[to_slot]
	_cargo_slots[to_slot]   = tmp
	_write_slots_to_inventory()
	_populate_cargo()


func deploy_satellite(slot_idx: int) -> void:
	if not _player: return
	var sat_scene : PackedScene = load("res://scenes/Satellite.tscn")
	if sat_scene == null:
		push_warning("InventoryScreen: Satellite.tscn not found")
		return
	if slot_idx < _cargo_slots.size() and _cargo_slots[slot_idx] != null:
		_cargo_slots[slot_idx]["amount"] -= 1
		if _cargo_slots[slot_idx]["amount"] <= 0:
			_cargo_slots[slot_idx] = null
	_write_slots_to_inventory()
	var sat : Node2D = sat_scene.instantiate()
	sat.global_position = _player.global_position + Vector2(120, 0)
	SectorManager.add_sector_entity(sat)
	_populate_cargo()


func get_cargo_slot(idx: int):
	if idx < 0 or idx >= _cargo_slots.size(): return null
	return _cargo_slots[idx]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

func _class_label(ship_class: GlobalEnums.ShipClass) -> String:
	match ship_class:
		GlobalEnums.ShipClass.SMALL:  return "Small Ship"
		GlobalEnums.ShipClass.MEDIUM: return "Medium Ship"
		GlobalEnums.ShipClass.LARGE:  return "Large Ship"
	return ""


func _get_slot_count(ship_id: StringName) -> int:
	return CARGO_SLOTS.get(ship_id, 10)


func _show_tooltip(text: String) -> void:
	if not _tooltip_popup: return
	var lbl : Label = _tooltip_popup.get_node_or_null("TooltipLabel")
	if lbl: lbl.text = text
	_tooltip_popup.visible = true


func _hide_tooltip() -> void:
	if _tooltip_popup:
		_tooltip_popup.visible = false


func _process(_delta: float) -> void:
	if not visible: return
	if _tooltip_popup and _tooltip_popup.visible:
		_tooltip_popup.position = get_viewport().get_mouse_position() + Vector2(14, 14)
	_refresh_stats()


func _refresh_stats() -> void:
	if not stats_section or not _player or not _player.ship_data: return
	var children := stats_section.get_children()
	if children.size() >= 2:
		var lbl := children[1] as Label
		if lbl:
			lbl.text = "Hull:    %.0f / %.0f\nShield:  %.0f / %.0f\nEnergy:  %.0f / %.0f\nSpeed:   %.0f max" % [
				_player.hull,   _player.max_hull,
				_player.shield, _player.max_shield,
				_player.energy, _player.max_energy,
				_player.ship_data.max_speed,
			]


# ===========================================================================
# EquipSlot
# ===========================================================================

class EquipSlot extends PanelContainer:
	var _slot_type  : String          = ""
	var _slot_idx   : int             = 0
	var _player     : Player          = null
	var _screen     : InventoryScreen = null
	var _filled     : bool            = false
	var _base_color : Color           = Color(0.06, 0.07, 0.10, 0.8)
	var _style      : StyleBoxFlat    = null

	func setup(label_text: String, tooltip_text: String, bg_color: Color, filled: bool,
			slot_type: String, slot_idx: int, player: Player, screen: InventoryScreen) -> void:
		_slot_type  = slot_type
		_slot_idx   = slot_idx
		_player     = player
		_screen     = screen
		_filled     = filled
		_base_color = bg_color if filled else Color(0.06, 0.07, 0.10, 0.8)
		_style = StyleBoxFlat.new()
		_style.bg_color              = _base_color
		_style.border_color          = Color(0.3, 0.35, 0.5, 0.8)
		_style.set_border_width_all(1)
		_style.set_corner_radius_all(4)
		_style.content_margin_left   = 8
		_style.content_margin_right  = 8
		_style.content_margin_top    = 6
		_style.content_margin_bottom = 6
		add_theme_stylebox_override("panel", _style)
		custom_minimum_size   = Vector2(0, 36)
		size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var lbl := Label.new()
		lbl.text = label_text
		lbl.add_theme_font_size_override("font_size", 12)
		lbl.add_theme_color_override("font_color", Color(0.9, 0.9, 1.0) if filled else Color(0.4, 0.4, 0.5))
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		add_child(lbl)
		if _filled:
			mouse_entered.connect(_on_hover_enter)
			mouse_exited.connect(_on_hover_exit)
		if tooltip_text != "":
			mouse_entered.connect(screen._show_tooltip.bind(tooltip_text))
			mouse_exited.connect(screen._hide_tooltip)

	func _on_hover_enter() -> void:
		if not _style: return
		_style.bg_color     = _base_color.lightened(0.2)
		_style.border_color = Color(0.5, 0.6, 0.9, 1.0)

	func _on_hover_exit() -> void:
		if not _style: return
		_style.bg_color     = _base_color
		_style.border_color = Color(0.3, 0.35, 0.5, 0.8)

	func _get_drag_data(_pos: Vector2):
		if not _filled: return null
		var preview := Label.new()
		preview.text = "[equipped]"
		set_drag_preview(preview)
		return {"type": "equip", "slot_type": _slot_type, "slot_idx": _slot_idx}

	func _can_drop_data(_pos: Vector2, data: Variant) -> bool:
		if not data is Dictionary: return false
		if data.get("type") != "cargo": return false
		var item_id : StringName = data.get("item_id", &"")
		match _slot_type:
			"weapon":  return GameData.weapons.has(item_id)
			"shield":  return GameData.shields.has(item_id)
			"missile": return GameData.missiles.has(item_id)
		return false

	func _drop_data(_pos: Vector2, data: Variant) -> void:
		if data.get("type") == "cargo":
			_screen.equip_from_cargo(data.get("item_id", &""), data.get("cargo_slot", -1), _slot_type, _slot_idx)


# ===========================================================================
# CargoSlot
# ===========================================================================

class CargoSlot extends PanelContainer:
	var _slot_idx   : int             = 0
	var _item_id    : StringName      = &""
	var _amount     : int             = 0
	var _player     : Player          = null
	var _screen     : InventoryScreen = null
	var _base_color : Color           = Color(0.1, 0.12, 0.18, 0.9)
	var _style      : StyleBoxFlat    = null

	func setup(slot_idx: int, item_id: StringName, amount: int, player: Player, screen: InventoryScreen) -> void:
		_slot_idx = slot_idx
		_item_id  = item_id
		_amount   = amount
		_player   = player
		_screen   = screen
		_style = StyleBoxFlat.new()
		_style.bg_color              = _base_color
		_style.border_color          = Color(0.3, 0.35, 0.5, 0.8)
		_style.set_border_width_all(1)
		_style.set_corner_radius_all(4)
		_style.content_margin_left   = 4
		_style.content_margin_right  = 4
		_style.content_margin_top    = 4
		_style.content_margin_bottom = 4
		add_theme_stylebox_override("panel", _style)
		custom_minimum_size   = Vector2(0, SLOT_SIZE)
		size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var item    : ItemData = GameData.get_item(item_id)
		var display : String   = item.display_name if item else str(item_id)
		var vbox      := VBoxContainer.new()
		vbox.alignment = BoxContainer.ALIGNMENT_CENTER
		vbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var name_lbl := Label.new()
		name_lbl.text = display
		name_lbl.add_theme_font_size_override("font_size", 10)
		name_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		name_lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		name_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		name_lbl.add_theme_color_override("font_color", Color(0.85, 0.85, 0.95))
		vbox.add_child(name_lbl)
		var amt_lbl := Label.new()
		amt_lbl.text = "x%d" % amount
		amt_lbl.add_theme_font_size_override("font_size", 11)
		amt_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		amt_lbl.add_theme_color_override("font_color", Color(0.6, 0.8, 1.0))
		vbox.add_child(amt_lbl)
		add_child(vbox)
		var tooltip : String = "%s\nAmount: %d" % [display, amount]
		if item:
			tooltip += "\nVolume: %.1f\nValue: $%d each" % [item.volume, item.base_price]
		if GameData.weapons.has(item_id) or GameData.shields.has(item_id) or GameData.missiles.has(item_id):
			tooltip += "\nDrag to equipment slot to equip"
		if item_id == &"satellite":
			tooltip += "\nRight-click to deploy"
		mouse_entered.connect(_on_hover_enter)
		mouse_exited.connect(_on_hover_exit)
		mouse_entered.connect(screen._show_tooltip.bind(tooltip))
		mouse_exited.connect(screen._hide_tooltip)

	func _on_hover_enter() -> void:
		if not _style: return
		_style.bg_color     = _base_color.lightened(0.2)
		_style.border_color = Color(0.5, 0.6, 0.9, 1.0)

	func _on_hover_exit() -> void:
		if not _style: return
		_style.bg_color     = _base_color
		_style.border_color = Color(0.3, 0.35, 0.5, 0.8)

	func _get_drag_data(_pos: Vector2):
		var item    : ItemData = GameData.get_item(_item_id)
		var display : String   = item.display_name if item else str(_item_id)
		var preview := Label.new()
		preview.text = display
		set_drag_preview(preview)
		return {"type": "cargo", "item_id": _item_id, "cargo_slot": _slot_idx, "amount": _amount}

	func _can_drop_data(_pos: Vector2, data: Variant) -> bool:
		if not data is Dictionary: return false
		var t : String = data.get("type", "")
		return t == "cargo" or t == "equip"

	func _drop_data(_pos: Vector2, data: Variant) -> void:
		if data.get("type") == "cargo":
			_screen.move_cargo(data.get("cargo_slot", -1), _slot_idx)
		elif data.get("type") == "equip":
			_screen.unequip_to_slot(data.get("slot_type", ""), data.get("slot_idx", 0), _slot_idx)

	func _gui_input(event: InputEvent) -> void:
		if event is InputEventMouseButton and event.pressed:
			if event.button_index == MOUSE_BUTTON_RIGHT:
				if _item_id == &"satellite":
					_screen.deploy_satellite(_slot_idx)


# ===========================================================================
# EmptySlot
# ===========================================================================

class EmptySlot extends PanelContainer:
	var _slot_idx : int             = 0
	var _screen   : InventoryScreen = null

	func setup(slot_idx: int, screen: InventoryScreen) -> void:
		_slot_idx = slot_idx
		_screen   = screen
		var style := StyleBoxFlat.new()
		style.bg_color     = Color(0.06, 0.07, 0.10, 0.8)
		style.border_color = Color(0.2, 0.22, 0.3, 0.6)
		style.set_border_width_all(1)
		style.set_corner_radius_all(4)
		add_theme_stylebox_override("panel", style)
		custom_minimum_size   = Vector2(0, SLOT_SIZE)
		size_flags_horizontal = Control.SIZE_EXPAND_FILL

	func _can_drop_data(_pos: Vector2, data: Variant) -> bool:
		if not data is Dictionary: return false
		var t : String = data.get("type", "")
		return t == "cargo" or t == "equip"

	func _drop_data(_pos: Vector2, data: Variant) -> void:
		if data.get("type") == "cargo":
			_screen.move_cargo(data.get("cargo_slot", -1), _slot_idx)
		elif data.get("type") == "equip":
			_screen.unequip_to_slot(data.get("slot_type", ""), data.get("slot_idx", 0), _slot_idx)
