extends Node
## Versioned, data-only checkpoints. No scripts/resources are deserialized from disk.
const VERSION := 1
const SAVE_PATH := "user://quicksave.dat"
const SHIP_FIELDS := ["fleet_name", "turret_order", "turret_threats", "turret_angles", "position", "rotation", "velocity", "faction_id", "weapon_fire_groups", "_weapon_cooldowns", "_shield_delay_timer", "_energy_delay_timer"]
const STATION_FIELDS := ["shield", "_shield_delay_timer", "_civilian_timer", "defense_cooldowns", "defense_energy", "_rogue_fire_timer", "claim_faction_id", "stock_targets", "visiting_traders_enabled", "production_enabled", "requested_station_blueprint", "constructed", "blueprint_id", "runtime_station_id", "_station_build_queue", "position", "rotation", "faction_id", "hull", "_manufacture_queue", "_auto_manufacture_timer", "_recipe_cursor", "requested_supply_ship", "replacement_supply_ship"]
const SPAWNER_FIELDS := ["max_ships", "spawn_interval", "_initial_ships_spawned", "_replacement_requests", "_spawned_ships", "_check_timer", "_spawn_timer"]
const AI_FIELDS := ["resupply_fleet", "resupply_ammo", "resupply_volleys", "alert_message", "hostile_alert_seconds", "automation_home", "automation_hops", "no_go_sectors", "automation_item", "automation_amount", "default_behavior", "default_job", "default_suspended", "fleet_job", "job_status", "_formation_members", "_formation_token", "_formation_arrived", "_arrival_facing", "_resume_state", "_explicit_attack", "supply_scaffold", "supply_station", "_state", "_target", "_waypoint", "_follow_target", "_defend_target", "_patrol_radius", "_patrol_center", "_patrol_route", "_patrol_route_idx", "_home_station", "_think_timer", "_state_timer", "_pursue_timer", "_is_combat_ship", "_is_fleet_ship", "_patrol_points", "_patrol_idx", "_haul_source", "_haul_destination", "_haul_item", "_haul_loaded", "_haul_manifest_amount", "_command_queue", "_missile_cooldown"]
signal runtime_resumed

func wait_until_resumed() -> void:
	# ALWAYS nodes run during gameplay pause, but not editor suspension.
	# SceneTree.process_frame still fires while suspended, so it is unsafe here.
	await runtime_resumed

var load_stage := "Idle"
const LOAD_DIAGNOSTICS := false
var _post_load_frames := 0
var _post_load_physics := 0

func _load_stage(value: String) -> void:
	load_stage = value
	if LOAD_DIAGNOSTICS:print("LOAD_STAGE: ", value)
	_message("Loading: " + value)
	if not LOAD_DIAGNOSTICS:return
	var trace := FileAccess.open("user://load-trace.txt", FileAccess.WRITE)
	if trace:
		trace.store_string(value + "\npaused=" + str(get_tree().paused))
		trace.flush()

var loading := false
var _load_requested := false
var restoring_layout: Dictionary = {}
var last_error := ""
var _ids: Dictionary = {}
var _nodes: Dictionary = {}
var _notice: Label
var _notice_time := 0.0

func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	if LOAD_DIAGNOSTICS:get_tree().process_frame.connect(_trace_after_load)
	var layer := CanvasLayer.new()
	layer.layer = 100
	add_child(layer)
	_notice = Label.new()
	_notice.position = Vector2(24, 65)
	_notice.add_theme_color_override("font_color", Color(0.4, 0.95, 1.0))
	_notice.add_theme_color_override("font_shadow_color", Color.BLACK)
	_notice.add_theme_constant_override("shadow_outline_size", 6)
	_notice.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(_notice)

func _process(delta: float) -> void:
	runtime_resumed.emit()
	_notice_time -= delta
	_notice.visible = _notice_time > 0

func _trace_after_load() -> void:
	if _post_load_frames <= 0:return
	_post_load_frames -= 1
	if _post_load_frames not in [119,60,0]:return
	var player = PlayerState.current_ship
	var trace := FileAccess.open("user://load-trace.txt", FileAccess.WRITE)
	if trace:
		trace.store_string("Post-load frames remaining=%s\npaused=%s loading=%s manager_can_process=%s physics_frames=%s time_scale=%s\n" % [_post_load_frames,get_tree().paused,loading,can_process(),Engine.get_physics_frames()-_post_load_physics,Engine.time_scale])
		if is_instance_valid(player):
			trace.store_string("player_can_process=%s mode=%s physics_enabled=%s docked=%s free_camera=%s\n" % [player.can_process(),player.process_mode,player.is_physics_processing(),player._is_docked,player._free_cam.is_free_mode() if player._free_cam else false])
		trace.flush()

func _message(message: String) -> void:
	_notice.text = message
	_notice_time = 6.0

func _input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if loading or _load_requested or not event is InputEventKey or not event.pressed or event.echo: return
	if event.physical_keycode == KEY_F5:
		get_viewport().set_input_as_handled()
		_message("Game saved — F9 to load" if save_game() else "Save failed: " + last_error)
	elif event.physical_keycode == KEY_F9:
		get_viewport().set_input_as_handled()
		_load_requested = true
		_message("Loading checkpoint…")
		_load_from_input.call_deferred()

func _load_from_input() -> void:
	var ok: bool = await load_game()
	_load_requested = false
	_message("Checkpoint loaded" if ok else "Load failed: " + last_error)

func _walk(node: Node) -> Array[Node]:
	var result: Array[Node] = []
	for child in node.get_children():
		if child is StationInstance or child is ShipInstance or child is AsteroidInstance or child is SatelliteInstance or child.get_script() == preload("res://scripts/CargoSalvage.gd") or child.get_script() == preload("res://scripts/ConstructionScaffold.gd"):
			if not child.get("_is_destroyed") and not child.is_queued_for_deletion():
				result.append(child)
		else:
			result.append_array(_walk(child))
	return result

func _encode(value: Variant) -> Variant:
	if typeof(value) == TYPE_OBJECT and not is_instance_valid(value): return null
	if value is Object:
		return {"@ref": _ids.get(value.get_instance_id(), "")} if is_instance_valid(value) else null
	if value is Array:
		var result: Array = []
		for item in value: result.append(_encode(item))
		return result
	if value is Dictionary:
		var result: Dictionary = {}
		for key in value: result[key] = _encode(value[key])
		return result
	return value

func _decode(value: Variant) -> Variant:
	if value is Dictionary:
		if value.has("@ref"): return _nodes.get(value["@ref"])
		var result: Dictionary = {}
		for key in value: result[key] = _decode(value[key])
		return result
	if value is Array:
		var result: Array = []
		for item in value: result.append(_decode(item))
		return result
	return value

func _fields(node: Object, names: Array) -> Dictionary:
	var result: Dictionary = {}
	for key in names: result[key] = _encode(node.get(key))
	return result

func _apply(node: Object, fields: Dictionary) -> void:
	for key in fields:
		var value: Variant = _decode(fields[key])
		# Preserve the declared type of Array[ShipInstance], Array[StringName], etc.
		var previous: Variant = node.get(key)
		if previous is Array and value is Array:
			previous.assign(value)
		else:
			node.set(key, value)

func _ship_entry(ship: ShipInstance) -> Dictionary:
	var result := {"ship_data_id": ship.ship_data.id, "turret_order": ship.turret_order, "equipped_weapons": [], "equipped_missiles": [], "equipped_shield": ship.equipped_shield.id if ship.equipped_shield else &"", "inventory": ship.inventory.get_all_items(), "hull": ship.hull, "shield": ship.shield, "energy": ship.energy}
	for weapon in ship.equipped_weapons: result.equipped_weapons.append(weapon.id if weapon else &"")
	for missile in ship.equipped_missiles: result.equipped_missiles.append(missile.id if missile else &"")
	return result

func snapshot() -> Dictionary:
	var player := get_tree().get_first_node_in_group("player") as Player
	if not player or not player.ship_data or player._is_destroyed or SectorManager._is_transitioning:
		last_error = "No active flight to save."
		return {}
	_ids.clear()
	_ids[player.get_instance_id()] = "player"
	var sector_actors: Dictionary = {}
	for sector_id in SectorManager._visited_sectors:
		var actors := _walk(SectorManager._visited_sectors[sector_id])
		sector_actors[sector_id] = actors
		for i in actors.size():
			var actor: Node = actors[i]
			var id := "%s/%d" % [sector_id, i]
			_ids[actor.get_instance_id()] = id
			for child in actor.get_children():
				if child is StationSpawner: _ids[child.get_instance_id()] = id + "/spawner"
	var layout: Dictionary = {}
	for sector_id in SectorManager._visited_sectors:
		layout[sector_id] = SectorManager._visited_sectors[sector_id].layout_rng_state
	var sectors: Dictionary = {}
	for sector_id in sector_actors:
		var entries: Array = []
		for actor in sector_actors[sector_id]:
			var entry := {"id": _ids[actor.get_instance_id()]}
			if actor is StationInstance:
				entry.merge({"type": "station", "data": actor.blueprint_id if actor.blueprint_id != &"" else actor.station_data.id, "fields": _fields(actor, STATION_FIELDS), "inventory": actor.inventory.serialize()})
				for child in actor.get_children():
					if child is StationSpawner: entry["spawner"] = _fields(child, SPAWNER_FIELDS)
			elif actor is ShipInstance:
				entry.merge({"type": "ship", "ship": _ship_entry(actor), "fields": _fields(actor, SHIP_FIELDS), "fleet": actor.is_in_group("player_fleet")})
				for child in actor.get_children():
					if child is AIShipController: entry["ai"] = _fields(child, AI_FIELDS)
			elif actor is AsteroidInstance:
				entry.merge({"type": "asteroid", "fields": _fields(actor, ["position", "material_type", "size_class", "hull", "_remaining_yield", "initial_yield", "visual_seed"])})
			elif actor.get_script() == preload("res://scripts/ConstructionScaffold.gd"):
				entry.merge({"type":"scaffold", "fields":_fields(actor,["position","blueprint","beneficiary","cargo","remaining","hull"])})
			elif actor.get_script() == preload("res://scripts/CargoSalvage.gd"):
				entry.merge({"type": "salvage", "fields": _fields(actor,["position","cargo"])})
			elif actor is SatelliteInstance:
				entry.merge({"type": "satellite", "fields": _fields(actor, ["position"])})
			entries.append(entry)
		sectors[sector_id] = entries
	var docking := get_tree().get_first_node_in_group("docking_manager")
	var dock_id: String = _ids.get(docking.current_station.get_instance_id(), "") if docking and is_instance_valid(docking.current_station) else ""
	var contacts: Array = []
	if is_instance_valid(SensorSystem.fog):
		for contact in SensorSystem.fog._last_known.values():
			if is_instance_valid(contact.get("node")) and _ids.has(contact.node.get_instance_id()): contacts.append(_encode(contact))
	return {"scenario": preload("res://resources/StartingRegion.gd").ID, "version": VERSION, "saved_at": Time.get_datetime_string_from_system(), "sector": SectorManager.current_sector_id, "sectors": sectors, "respawns": _respawn_snapshot(), "layout": layout, "player": _ship_entry(player), "flight": _fields(player, SHIP_FIELDS), "player_state": PlayerState.serialize(), "fleet_settings": _fields(FleetCommandSystem,["formation_name","formation_spacing","custom_formations"]), "factions": _fields(FactionManager, ["diplomacy_time", "diplomacy_pairs", "diplomacy_events", "_defeated_factions", "_sector_ownership", "_relations", "_territory", "_faction_state", "civilian_credits", "_strategy_timer", "_treasury_history", "_treasury_sequence"]), "map": MapMemory.serialize(), "contacts": contacts, "docked": dock_id}

func save_game(path: String = SAVE_PATH) -> bool:
	if SectorManager._sensor_initializing:
		last_error="Sensor sector initializing; please retry in a moment."
		return false
	if loading: return false
	var data := snapshot()
	if data.is_empty(): return false
	var file := FileAccess.open(path + ".tmp", FileAccess.WRITE)
	if not file:
		last_error = "Cannot write checkpoint (%s)." % FileAccess.get_open_error()
		return false
	var payload := var_to_bytes(data)
	file.store_var({"payload": payload, "sha256": _checksum(payload)}, false)
	file.flush()
	var error := file.get_error()
	file.close()
	if error != OK:
		last_error = "Checkpoint write failed."
		return false
	if FileAccess.file_exists(path):
		if DirAccess.copy_absolute(path, path + ".bak") != OK:
			last_error = "Could not back up the previous checkpoint."
			return false
	if DirAccess.rename_absolute(path + ".tmp", path) != OK:
		last_error = "Could not commit checkpoint."
		return false
	last_error = ""
	return true

func _checksum(bytes: PackedByteArray) -> String:
	var context := HashingContext.new()
	context.start(HashingContext.HASH_SHA256)
	context.update(bytes)
	return context.finish().hex_encode()

func _valid(data: Variant) -> bool:
	if not data is Dictionary or data.get("version") != VERSION: return false
	for key in ["sectors", "player", "flight", "player_state", "factions", "map"]:
		if not data.get(key) is Dictionary: return false
	if not GameData.sectors.has(data.get("sector")) or not data.sectors.has(data.sector): return false
	if GameData.get_ship(data.player.get("ship_data_id", &"")) == null: return false
	var ids := {"player": true}
	for sector_id in data.sectors:
		if not GameData.sectors.has(sector_id) or not data.sectors[sector_id] is Array: return false
		for entry in data.sectors[sector_id]:
			if not entry is Dictionary or not entry.get("id") is String or ids.has(entry.id): return false
			ids[entry.id] = true
			if not entry.get("fields") is Dictionary: return false
			match entry.get("type"):
				"station":
					if not GameData.stations.has(entry.get("data")) or not entry.get("inventory") is Dictionary: return false
				"ship":
					if not entry.get("ship") is Dictionary or not StationSpawner.SHIP_SCENES.has(entry.ship.get("ship_data_id")): return false
				"asteroid", "satellite", "salvage": pass
				"scaffold":
					if not GameData.stations.has(entry.fields.get("blueprint")):return false
				_: return false
	return true

func load_game(path: String = SAVE_PATH) -> bool:
	_load_stage("Waiting for runtime")
	await wait_until_resumed()
	_load_stage("Reading checkpoint")
	while SectorManager._sensor_initializing:await get_tree().process_frame
	if loading: return false
	var file := FileAccess.open(path, FileAccess.READ)
	if not file:
		last_error = "No checkpoint found. Press F5 to save first."
		return false
	if file.get_length() > 64000000:
		file.close()
		last_error = "Checkpoint is too large."
		return false
	var envelope: Variant = file.get_var(false)
	file.close()
	var data: Variant = null
	if envelope is Dictionary and envelope.get("payload") is PackedByteArray:
		if envelope.get("sha256") == _checksum(envelope.payload): data = bytes_to_var(envelope.payload)
	if not _valid(data):
		last_error = "Invalid or incompatible checkpoint; current game was kept."
		return false
	if data.get("scenario","") != preload("res://resources/StartingRegion.gd").ID:
		last_error = "This checkpoint belongs to the previous region setup. Start a fresh run for the four-faction region. Your checkpoint was not changed."
		return false
	var player := get_tree().get_first_node_in_group("player") as Player
	if not player:
		last_error = "Start a flight before loading."
		return false
	_load_stage("Preparing world")
	BuildPlacement.cancel()
	loading = true
	restoring_layout = data.get("layout", {})
	for menu in get_tree().get_nodes_in_group("pause_menu"):menu.hide()
	for screen in get_tree().root.find_children("*", "", true, false):
		if (screen is InventoryScreen or screen is MapScreen) and screen.visible:
			screen.close()
		elif screen is SectorMap and screen.visible:
			screen._close()
	var missiles := player.get_node_or_null("MissileSystem")
	if missiles: missiles.cancel()
	var docking := get_tree().get_first_node_in_group("docking_manager")
	if docking: docking.prepare_sector_change()
	# Do not pause SceneTree during restoration: the embedded debugger may
	# suspend it in response, preventing the load coroutine from finishing.
	get_tree().paused = false
	var stopped_nodes: Dictionary = {}
	for node in get_tree().root.find_children("*", "", true, false):
		if node == self or is_ancestor_of(node):continue
		stopped_nodes[node] = node.process_mode
		node.process_mode = Node.PROCESS_MODE_DISABLED
	var inspector := get_tree().get_first_node_in_group("station_inspection")
	if inspector:
		inspector.selected = null
		inspector.hovered = null
		inspector._displayed = null
		inspector.card.hide()
	var camera := get_tree().get_first_node_in_group("free_camera")
	if camera and camera.is_free_mode(): camera._exit_free_cam()
	FleetCommandSystem.prepare_sector_change()
	for sector in SectorManager._visited_sectors.values():
		if is_instance_valid(sector): sector.free()
	SectorManager._visited_sectors.clear()
	SectorManager.current_sector = null
	SectorManager.current_sector_id = &""
	FactionManager._defeated_factions.clear()
	PlayerState.fleet_ships.clear()
	_nodes = {"player": player}
	var pending: Array = []
	_load_stage("Restoring sectors")
	for sector_id in data.sectors:
		SectorManager.load_sector(sector_id)
		var sector: SectorInstance = SectorManager.current_sector
		sector.asteroid_respawns=data.get("respawns",{}).get(sector_id,[]).duplicate(true)
		for entry in data.sectors[sector_id]:
			var actor: Node2D
			match entry.type:
				"station":
					actor = load("res://scenes/Station.tscn").instantiate()
					actor.station_data = GameData.stations[entry.data]
					actor.constructed = entry.fields.get("constructed", false)
					if actor.constructed:
						actor.station_data = actor.station_data.duplicate(true)
						actor.station_data.id = entry.fields.runtime_station_id
						actor.station_data.display_name = actor.station_data.get_yard_class_name() if actor.station_data.station_type == StationData.TYPE_SHIPYARD else str(actor.station_data.station_type).capitalize() + " Station"
					actor.faction_id = entry.fields.faction_id
					sector.get_node("Stations").add_child(actor)
					if entry.has("spawner"):
						var spawner := StationSpawner.new()
						actor.add_child(spawner)
						_nodes[entry.id + "/spawner"] = spawner
				"ship":
					actor = load(StationSpawner.SHIP_SCENES[entry.ship.ship_data_id]).instantiate()
					actor.faction_id = entry.fields.faction_id
					if entry.fleet: actor.add_to_group("player_fleet")
					sector.add_child(actor)
					actor.initialize(GameData.ships[entry.ship.ship_data_id])
					if entry.has("ai"): actor.add_child(AIShipController.new())
					if entry.fleet: PlayerState.fleet_ships.append(actor)
				"asteroid":
					actor = AsteroidInstance.new()
					actor.setup(entry.fields.material_type, entry.fields.size_class, entry.fields.visual_seed)
					sector.get_node("Asteroids").add_child(actor)
				"scaffold":
					actor = preload("res://scripts/ConstructionScaffold.gd").new()
					actor.blueprint=entry.fields.blueprint
					sector.add_child(actor)
				"salvage":
					actor = preload("res://scripts/CargoSalvage.gd").new()
					sector.add_child(actor)
				"satellite":
					actor = load("res://scenes/Satellite.tscn").instantiate()
					sector.add_child(actor)
			_nodes[entry.id] = actor
			pending.append({"node": actor, "entry": entry})
		# Let initialization coroutines finish while simulation remains paused.
		for frame in 4: await get_tree().process_frame
	_load_stage("Restoring actor state")
	for item in pending:
		var actor: Node = item.node
		var entry: Dictionary = item.entry
		if actor is ShipInstance: PlayerState.restore_ship_entry(actor, entry.ship)
		_apply(actor, entry.fields)
		if actor is StationInstance:
			actor.inventory.deserialize(entry.inventory)
			if entry.has("spawner"):
				var spawner: StationSpawner = _nodes[entry.id + "/spawner"]
				_apply(spawner, entry.spawner)
				for ship in spawner._spawned_ships:
					if is_instance_valid(ship) and not ship.ship_destroyed.is_connected(spawner._on_fleet_ship_destroyed): ship.ship_destroyed.connect(spawner._on_fleet_ship_destroyed)
		if entry.has("ai"):
			for child in actor.get_children():
				if child is AIShipController:
					_apply(child, entry.ai)
					if child._state == AIShipController.State.DEFEND and is_instance_valid(child._defend_target) and child._defend_target.has_signal("hull_changed"):
						if not child._defend_target.hull_changed.is_connected(child._on_defend_target_hull_changed): child._defend_target.hull_changed.connect(child._on_defend_target_hull_changed)
	_load_stage("Activating saved sector")
	SectorManager.load_sector(data.sector)
	FactionManager._defeated_factions.clear()
	FactionManager.diplomacy_time=0
	FactionManager.diplomacy_pairs.clear()
	FactionManager.diplomacy_events.clear()
	FactionManager._sector_ownership.clear()
	_load_stage("Restoring faction state")
	_apply(FactionManager, data.factions)
	FactionManager.restore_sector_ownership()
	_load_stage("Restoring player state")
	PlayerState.deserialize(data.player_state)
	if data.has("fleet_settings"):_apply(FleetCommandSystem,data.fleet_settings)
	MapMemory.deserialize(data.map)
	_load_stage("Rebuilding player ship")
	player.initialize(GameData.get_ship(data.player.ship_data_id))
	PlayerState.restore_ship_entry(player, data.player)
	_apply(player, data.flight)
	PlayerState.current_ship = player
	player._is_destroyed = false
	player.show()
	if player.camera: player.camera.reset_smoothing()
	SensorSystem.register_observer(player, SensorSystem.get_radius_for_ship(player))
	for saved in data.get("contacts", []):
		var contact: Dictionary = _decode(saved)
		if is_instance_valid(contact.get("node")): SensorSystem.fog._last_known[contact.node.get_instance_id()] = contact
	_load_stage("Updating sensors")
	SensorSystem._do_sweep()
	if docking and _nodes.has(data.get("docked", "")):
		_nodes[data.docked]._player_in_range = true
		docking._dock(_nodes[data.docked])
	_load_stage("Restoring processing")
	for node in stopped_nodes:
		if is_instance_valid(node):node.process_mode = stopped_nodes[node]
	_post_load_frames = 120
	_post_load_physics = Engine.get_physics_frames()
	_load_stage("Finished")
	loading = false
	restoring_layout.clear()
	last_error = ""
	return true

func _respawn_snapshot()->Dictionary:
	var result:Dictionary={}
	for id in SectorManager._visited_sectors:result[id]=SectorManager._visited_sectors[id].asteroid_respawns.duplicate(true)
	return result
