extends RefCounted
const Policy=preload("res://scripts/FleetAutomation.gd")
const Jobs=preload("res://scripts/FleetJobs.gd")
static func needs(ship:ShipInstance,rounds:int,volleys:int)->Dictionary:
 var desired:Dictionary={}
 for weapon in ship.equipped_weapons:
  if weapon and weapon.uses_ammo and weapon.ammo_item_id!=&"":
   desired[weapon.ammo_item_id]=maxi(int(desired.get(weapon.ammo_item_id,0)),rounds)
 for slot in ship.equipped_missiles.size():
  var missile=ship.equipped_missiles[slot]
  if missile and ship.rack_capacity(slot)>0:
   desired[missile.id]=int(desired.get(missile.id,0))+ship.rack_capacity(slot)*volleys
 return desired
static func supplier_score(cost:int,hops:int,distance:float)->float:
 # Price with a travel penalty: nearby bargains beat tiny savings far away.
 return float(cost)*(1.0+float(hops)*.25+distance/50000.0)+float(hops)*.01+distance*.000001
static func plan(ai:AIShipController)->void:
 if ai.resupply_fleet.is_empty():ai.job_status="Waiting: choose a resupply fleet";return
 var current=preload("res://scripts/StationConstruction.gd").sector_of(ai._ship)
 if ai.automation_home==&"":ai.automation_home=current.sector_data.id
 var allowed=Policy.allowed(ai)
 var members:Array=[]
 for ship in PlayerState.fleet_ships:
  if is_instance_valid(ship) and ship!=ai._ship and not ship._is_destroyed and ship.fleet_name==ai.resupply_fleet:members.append(ship)
 if members.is_empty():ai.job_status="Waiting: fleet has no available ships";return
 var demands:Array=[]
 for ship in members:
  var sector=preload("res://scripts/StationConstruction.gd").sector_of(ship)
  for id in needs(ship,ai.resupply_ammo,ai.resupply_volleys):
   var desired:int=needs(ship,ai.resupply_ammo,ai.resupply_volleys)[id]
   if ship.inventory.get_amount(id)>=desired:continue
   if not sector or Policy.path(current.sector_data.id,sector.sector_data.id,allowed).is_empty():continue
   if Jobs.room(ship.inventory,id)<=0:continue
   demands.append({"ship":ship,"item":id,"amount":desired,"ratio":float(ship.inventory.get_amount(id))/desired})
 if demands.is_empty():
  var missing:=false
  for ship in members:
   var requirements=needs(ship,ai.resupply_ammo,ai.resupply_volleys)
   for id in requirements:
    if ship.inventory.get_amount(id)<requirements[id]:missing=true
  ai.job_status="Waiting: fleet needs supplies but routes or cargo space are blocked" if missing else "Fleet fully supplied"
  ai._ship.velocity=Vector2.ZERO
  return
 demands.sort_custom(func(a,b):return a.ratio<b.ratio)
 # Use cargo already aboard before spending money.
 for demand in demands:
  if ai._ship.inventory.get_amount(demand.item)>0:
   assign(ai,demand,null,"deliver");return
 var suppliers:Array=[]
 var preparing:=false
 for id in allowed:
  var sector=SectorManager._visited_sectors.get(id)
  if not is_instance_valid(sector):preparing=true;SectorManager._initialize_shared_sector.call_deferred(id);continue
  if sector.is_inside_tree() and sector!=SectorManager.current_sector:preparing=true;continue
  suppliers.append_array(SectorManager.get_sector_stations(sector))
 if preparing:ai.job_status="Preparing supply search";return
 for demand in demands:
  if Jobs.room(ai._ship.inventory,demand.item)<=0:continue
  var best:StationInstance
  var best_score:float=INF
  for station in suppliers:
   if not Jobs.station_ok(ai,station) or station.inventory.get_amount(demand.item)<=0:continue
   if station.faction_id!=&"player" and not station._station_sells_item(demand.item):continue
   var sector=preload("res://scripts/StationConstruction.gd").sector_of(station)
   var route=Policy.path(current.sector_data.id,sector.sector_data.id,allowed)
   var delivery=Policy.path(sector.sector_data.id,preload("res://scripts/StationConstruction.gd").sector_of(demand.ship).sector_data.id,allowed)
   if route.is_empty() or delivery.is_empty():continue
   var cost:int=0 if station.faction_id==&"player" else station.get_sell_price(demand.item)
   if cost>PlayerState.credits:continue
   var distance:float=ai._ship.position.distance_to(station.position) if sector==current else 25000.0
   var score:float=supplier_score(cost,route.size()+delivery.size()-2,distance)
   if score<best_score:best=station;best_score=score
  if best:assign(ai,demand,best,"collect");return
 ai.job_status="Waiting: no permitted supplier with affordable ammo or missiles"
static func assign(ai:AIShipController,demand:Dictionary,source:StationInstance,phase:String)->void:
 ai.fleet_job={"kind":"resupply","source":source,"destination":demand.ship,"item":demand.item,"amount":demand.amount,"repeat":false,"automatic":true,"fleet":ai.resupply_fleet,"phase":phase}
 ai.job_status="Supplying "+ai.resupply_fleet+": "+GameData.items[demand.item].display_name
