class_name MapScreen
extends CanvasLayer

## Fullscreen map overlay. Press M to open/close.
## Completely independent from InventoryScreen.

const MAP_SECTOR_SCALE : float = 0.002
const MAP_GALAXY_SCALE : float = 2.0

var _station_inspector: Control
var _player                : Player      = null
var _map_cam_offset        : Vector2     = Vector2.ZERO
var _map_zoom              : float       = 1.0
var _map_zoom_target       : float       = 1.0
var _map_mode              : int         = 0  ## 0=sector 1=galaxy
var _map_waypoints         : Array[Dictionary] = []
var _map_viewing_sector_id : StringName  = &""
var _map_selected_sector_id : StringName = &""
var _zoom_mouse_pos        : Vector2     = Vector2.ZERO
var _zoom_world_anchor     : Vector2     = Vector2.ZERO

@onready var draw_node   : Control = $Background/DrawNode
@onready var sector_label : Label  = $Header/SectorName
@onready var faction_label : Label = $Header/FactionName
@onready var ship_label   : Label  = $Header/ShipName


func _ready() -> void:
	add_to_group("active_sector_map")
	hide()
	var inspection_layer := CanvasLayer.new()
	inspection_layer.layer = 40
	add_child(inspection_layer)
	_station_inspector = preload("res://scripts/StationIdentification.gd").new()
	_station_inspector.map_inspection = true
	inspection_layer.add_child(_station_inspector)
	_station_inspector.hide()



func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("map"):
		get_viewport().set_input_as_handled()
		if visible:
			close()
		else:
			open()
		return
	if not visible: return
	if event is InputEventKey and (event as InputEventKey).pressed:
		if (event as InputEventKey).keycode == KEY_ESCAPE:
			get_viewport().set_input_as_handled()
			close()
			return
		if (event as InputEventKey).keycode == KEY_G:
			get_viewport().set_input_as_handled()
			toggle_map_mode()


func _input(event: InputEvent) -> void:
	if not visible: return
	if _station_inspector.visible and _station_inspector.card.visible and _station_inspector.card.get_global_rect().has_point(get_viewport().get_mouse_position()): return
	var local_pos := draw_node.get_local_mouse_position() if draw_node else Vector2.ZERO
	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		## Scroll wheel fires on pressed=true only — handle separately
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			get_viewport().set_input_as_handled()
			_zoom_toward_mouse(local_pos, 1.15)
			return
		if mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			get_viewport().set_input_as_handled()
			_zoom_toward_mouse(local_pos, 0.87)
			return
		if mb.pressed:
			get_viewport().set_input_as_handled()
			match mb.button_index:
				MOUSE_BUTTON_LEFT:
					_handle_map_click(local_pos)
				MOUSE_BUTTON_RIGHT:
					_handle_map_right_click(local_pos)
	elif event is InputEventMouseMotion:
		if (event as InputEventMouseMotion).button_mask & MOUSE_BUTTON_MASK_MIDDLE:
			get_viewport().set_input_as_handled()
			_map_cam_offset += (event as InputEventMouseMotion).relative / _map_zoom


func _process(delta: float) -> void:
	if not visible: return
	var prev_zoom : float = _map_zoom
	_map_zoom = lerpf(_map_zoom, _map_zoom_target, 12.0 * delta)
	if abs(_map_zoom - prev_zoom) > 0.0001 and _zoom_world_anchor != Vector2.ZERO:
		var center := _map_get_center()
		_map_cam_offset = (_zoom_mouse_pos - center) / _map_zoom - _zoom_world_anchor
	if draw_node:
		draw_node.queue_redraw()


func open() -> void:
	_player = get_tree().get_first_node_in_group("player") as Player
	## Keep zoom and offset from last time
	## Only reset if first open (zoom is still default 1.0)
	var first_open : bool = _map_zoom == 1.0 and _map_cam_offset == Vector2.ZERO
	_map_viewing_sector_id  = SectorManager.current_sector_id
	_map_selected_sector_id = &""
	get_tree().paused = true
	show()
	_populate_header()
	if first_open:
		call_deferred("_center_on_player")


func close() -> void:
	_station_inspector.selected = null
	_station_inspector.hide()
	get_tree().paused = false
	hide()


func _center_on_player() -> void:
	if _player:
		_map_cam_offset = -_player.global_position * MAP_SECTOR_SCALE


func _populate_header() -> void:
	var sd : SectorData = GameData.get_sector(SectorManager.current_sector_id)
	if ship_label and _player and _player.ship_data:
		ship_label.text = _player.ship_data.display_name
	if sector_label:
		sector_label.text = sd.display_name if sd else "Unknown"
	if faction_label:
		var fac : FactionData = GameData.get_faction(sd.controlling_faction_id if sd else &"")
		faction_label.text = fac.display_name if fac else "Unclaimed"


## ---------------------------------------------------------------------------
## Map math
## ---------------------------------------------------------------------------

func _map_get_center() -> Vector2:
	return draw_node.size / 2.0 if draw_node else Vector2(576.0, 324.0)

func _map_world_to_screen(world_pos: Vector2) -> Vector2:
	return _map_get_center() + (world_pos * MAP_SECTOR_SCALE + _map_cam_offset) * _map_zoom

func _map_screen_to_world(screen_pos: Vector2) -> Vector2:
	return ((screen_pos - _map_get_center()) / _map_zoom - _map_cam_offset) / MAP_SECTOR_SCALE

func _map_galaxy_to_screen(map_pos: Vector2) -> Vector2:
	return _map_get_center() + (map_pos * MAP_GALAXY_SCALE + _map_cam_offset) * _map_zoom

func _zoom_toward_mouse(mouse_pos: Vector2, factor: float) -> void:
	var old_zoom : float = _map_zoom
	_zoom_mouse_pos    = mouse_pos
	_zoom_world_anchor = (mouse_pos - _map_get_center()) / old_zoom - _map_cam_offset
	_map_zoom_target   = clampf(_map_zoom_target * factor, 1.3, 20.0)

func toggle_map_mode() -> void:
	_station_inspector.selected = null
	_map_mode = 1 if _map_mode == 0 else 0
	if _map_mode == 0:
		_map_viewing_sector_id = SectorManager.current_sector_id
	_map_cam_offset  = Vector2.ZERO
	_map_zoom        = 1.0
	_map_zoom_target = 1.0


## ---------------------------------------------------------------------------
## Click handling
## ---------------------------------------------------------------------------

func _handle_map_click(screen_pos: Vector2) -> void:
	if _map_mode == 1:
		for sid in GameData.sectors:
			var sd   : SectorData = GameData.sectors[sid]
			var spos := _map_galaxy_to_screen(sd.map_position)
			if screen_pos.distance_to(spos) < 20.0:
				var vis : int = MapMemory.get_visibility(sd.id)
				if vis > 0:
					_map_viewing_sector_id  = sd.id
					_map_mode               = 0
					_map_cam_offset         = Vector2.ZERO
					_map_zoom               = 1.0
					_map_zoom_target        = 1.0
					if sector_label: sector_label.text = sd.display_name
					if faction_label:
						var fac : FactionData = GameData.get_faction(sd.controlling_faction_id)
						faction_label.text = fac.display_name if fac else "Unclaimed"
				return
		_map_selected_sector_id = &""
	else:
		if _map_viewing_sector_id == SectorManager.current_sector_id:
			var station := _station_at_screen(screen_pos)
			if station:
				_station_inspector.selected = station
				_station_inspector._displayed = station
				_station_inspector._active_tab = 0
				_station_inspector._refresh_card(true)
				_station_inspector.show()
				return
			var world_pos := _map_screen_to_world(screen_pos)
			var max_bound : float = SectorInstance.HALF_SIZE * 0.95
			world_pos = world_pos.clamp(Vector2(-max_bound, -max_bound), Vector2(max_bound, max_bound))
			_map_waypoints.append({"pos": world_pos, "label": "WP %d" % (_map_waypoints.size() + 1), "color": Color(1.0, 0.9, 0.2)})

func _handle_map_right_click(screen_pos: Vector2) -> void:
	if _map_mode != 0: return
	var best_idx : int   = -1
	var best_dist : float = 20.0
	for i in _map_waypoints.size():
		var wp_screen := _map_world_to_screen(_map_waypoints[i]["pos"])
		if screen_pos.distance_to(wp_screen) < best_dist:
			best_dist = screen_pos.distance_to(wp_screen)
			best_idx  = i
	if best_idx >= 0:
		_map_waypoints.remove_at(best_idx)


## ---------------------------------------------------------------------------
## Drawing — called by DrawNode._draw()
## ---------------------------------------------------------------------------

func draw_map(dn: Control) -> void:
	if _map_mode == 0:
		_draw_sector_map(dn)
	else:
		_draw_galaxy_map(dn)


func _draw_sector_map(dn: Control) -> void:
	var vp_size    := dn.size
	var center     := vp_size / 2.0
	var font       := ThemeDB.fallback_font
	var sid        := _map_viewing_sector_id
	var vis        : int  = MapMemory.get_visibility(sid) if sid != &"" else 0
	var is_current : bool = sid == SectorManager.current_sector_id

	dn.draw_rect(Rect2(Vector2.ZERO, vp_size), Color(0.03, 0.04, 0.08, 1.0), true)

	## Sector boundary
	var half : float   = SectorInstance.HALF_SIZE * MAP_SECTOR_SCALE * _map_zoom
	var tl   : Vector2 = center + (_map_cam_offset * _map_zoom) + Vector2(-half, -half)
	dn.draw_rect(Rect2(tl, Vector2(half * 2.0, half * 2.0)), Color(0.2, 0.2, 0.4, 0.5), false, 1.5)

	## Sensor circles
	if is_current:
		var circles := SensorSystem.get_sensor_circles()
		for c in circles:
			var spos    := _map_world_to_screen(c["center"])
			var sradius : float = c["radius"] * MAP_SECTOR_SCALE * _map_zoom
			dn.draw_circle(spos, sradius, Color(0.1, 0.15, 0.25, 0.35))
			dn.draw_arc(spos, sradius, 0, TAU, 64, Color(0.2, 0.4, 0.6, 0.4), 1.0)

	## Contacts / memory objects
	if is_current:
		if SensorSystem.fog:
			for contact in _map_contacts():
				_draw_map_contact(dn, contact, font)
	else:
		var dim     : float = 0.35 if vis == 1 else 0.15
		for obj in MapMemory.get_sector_memory(sid):
			_draw_memory_object(dn, obj, font, dim)

	## Satellites
	if is_current:
		for sat in get_tree().get_nodes_in_group("satellites"):
			if sat is Node2D:
				var spos := _map_world_to_screen(sat.global_position)
				dn.draw_circle(spos, 5.0, Color(0.4, 0.9, 1.0))
				dn.draw_string(font, spos + Vector2(7, 4), "SAT", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.4, 0.9, 1.0))

	## Player
	if is_current and _player:
		var ppos := _map_world_to_screen(_player.global_position)
		dn.draw_circle(ppos, 6.0, Color(0.2, 1.0, 0.4))
		var dir := Vector2.RIGHT.rotated(_player.rotation) * 14.0
		dn.draw_line(ppos, ppos + dir, Color(0.2, 1.0, 0.4), 2.0)
		dn.draw_string(font, ppos + Vector2(10, 4), "YOU", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.2, 1.0, 0.4))

	## Waypoints
	if is_current:
		for wp in _map_waypoints:
			var wpos  := _map_world_to_screen(wp["pos"])
			var color : Color = wp["color"]
			var sz    : float = 7.0
			var pts   := PackedVector2Array([
				wpos + Vector2(0, -sz), wpos + Vector2(sz, 0),
				wpos + Vector2(0,  sz), wpos + Vector2(-sz, 0),
			])
			dn.draw_colored_polygon(pts, color)
			dn.draw_string(font, wpos + Vector2(10, 4), wp["label"], HORIZONTAL_ALIGNMENT_LEFT, -1, 11, color)

	## Hints
	dn.draw_string(font, Vector2(10, vp_size.y - 14), "[G] Galaxy  |  Scroll: zoom  |  Middle drag: pan  |  Left-click: waypoint  |  Right-click: remove  |  M or ESC: close", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.4, 0.4, 0.5))


func _draw_memory_object(dn: Control, obj: Dictionary, font: Font, alpha: float) -> void:
	var obj_type  : String    = obj.get("type", "")
	var pos       : Vector2   = obj.get("pos", Vector2.ZERO)
	var label     : String    = obj.get("label", "")
	var fid       : StringName = obj.get("faction_id", &"")
	var spos      := _map_world_to_screen(pos)
	match obj_type:
		"station":
			var faction : FactionData = GameData.get_faction(fid)
			var color   : Color       = Color(faction.color.r, faction.color.g, faction.color.b, alpha) if faction else Color(0.7, 0.7, 0.7, alpha)
			var sz      : float       = 8.0
			dn.draw_rect(Rect2(spos - Vector2(sz/2, sz/2), Vector2(sz, sz)), color, false, 1.5)
			if label != "":
				dn.draw_string(font, spos + Vector2(10, 4), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.9, 0.8, 0.5, alpha))
		"asteroid_field":
			dn.draw_circle(spos, 3.0, Color(0.55, 0.5, 0.45, alpha))
		"jump_gate":
			dn.draw_circle(spos, 7.0, Color(0.2, 0.8, 1.0, alpha))
			if label != "":
				dn.draw_string(font, spos + Vector2(10, 4), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.5, 0.9, 1.0, alpha))
		"poi":
			var pts := PackedVector2Array([spos + Vector2(0,-6), spos + Vector2(6,0), spos + Vector2(0,6), spos + Vector2(-6,0)])
			dn.draw_colored_polygon(pts, Color(1.0, 0.9, 0.2, alpha))
			if label != "":
				dn.draw_string(font, spos + Vector2(8, 4), label, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.9, 0.8, 0.3, alpha))


func _draw_galaxy_map(dn: Control) -> void:
	var vp_size    := dn.size
	var font       := ThemeDB.fallback_font
	var current_id := SectorManager.current_sector_id

	dn.draw_rect(Rect2(Vector2.ZERO, vp_size), Color(0.02, 0.03, 0.06, 1.0), true)

	## Lane lines
	for sid in GameData.sectors:
		var sd   : SectorData = GameData.sectors[sid]
		var from := _map_galaxy_to_screen(sd.map_position)
		for conn_id in sd.connected_sectors:
			var conn_sd : SectorData = GameData.get_sector(conn_id)
			if conn_sd:
				dn.draw_line(from, _map_galaxy_to_screen(conn_sd.map_position), Color(0.25, 0.25, 0.35), 1.0)

	## Sector nodes
	for sid in GameData.sectors:
		var sd         : SectorData  = GameData.sectors[sid]
		var faction    : FactionData = GameData.get_faction(sd.controlling_faction_id)
		var base_color : Color       = faction.color if faction else Color(0.5, 0.5, 0.5)
		var spos       := _map_galaxy_to_screen(sd.map_position)
		var is_current : bool        = sd.id == current_id
		var radius     : float       = 20.0 if is_current else 14.0
		var vis        : int         = MapMemory.get_visibility(sd.id)
		var alpha      : float       = 1.0 if vis == 2 else (0.4 if vis == 1 else 0.12)
		var color      : Color       = Color(base_color.r, base_color.g, base_color.b, alpha)
		if vis == 0:
			dn.draw_circle(spos, radius * 0.6, Color(0.1, 0.1, 0.15, 0.5))
			dn.draw_arc(spos, radius * 0.6, 0, TAU, 16, Color(0.2, 0.2, 0.3, 0.3), 1.0)
			continue
		if is_current:
			dn.draw_circle(spos, radius + 5.0, Color(base_color.r, base_color.g, base_color.b, 0.25))
		dn.draw_circle(spos, radius, color)
		dn.draw_arc(spos, radius, 0, TAU, 32, Color(1, 1, 1, alpha * 0.4), 1.0)
		dn.draw_string(font, spos + Vector2(-30, radius + 14), sd.display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.9, 0.9, 0.9, alpha))
		if faction and vis > 0:
			dn.draw_string(font, spos + Vector2(-30, radius + 26), faction.display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(base_color.r, base_color.g, base_color.b, alpha * 0.8))
		if is_current:
			dn.draw_string(font, spos + Vector2(-24, -radius - 8), "YOU ARE HERE", HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.2, 1.0, 0.4))
		elif vis > 0:
			dn.draw_string(font, spos + Vector2(-20, -radius - 8), "click to view", HORIZONTAL_ALIGNMENT_LEFT, -1, 9, Color(0.5, 0.5, 0.6, alpha))

	## Selected sector info panel
	if _map_selected_sector_id != &"":
		var sel_sd  : SectorData  = GameData.get_sector(_map_selected_sector_id)
		var sel_fac : FactionData = GameData.get_faction(sel_sd.controlling_faction_id if sel_sd else &"")
		if sel_sd:
			var pp : Vector2 = Vector2(vp_size.x - 280, 60)
			dn.draw_rect(Rect2(pp, Vector2(260, 160)), Color(0.05, 0.08, 0.14, 0.95), true)
			dn.draw_rect(Rect2(pp, Vector2(260, 160)), Color(0.3, 0.35, 0.5, 0.8), false, 1.0)
			var tx : Vector2 = pp + Vector2(12, 24)
			dn.draw_string(font, tx, sel_sd.display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 16, Color(1.0, 1.0, 1.0))
			tx.y += 26
			var fn : String = sel_fac.display_name if sel_fac else "Unclaimed"
			var fc : Color  = sel_fac.color if sel_fac else Color(0.5, 0.5, 0.5)
			dn.draw_string(font, tx, "Controlled by: %s" % fn, HORIZONTAL_ALIGNMENT_LEFT, -1, 12, fc)
			tx.y += 20
			dn.draw_string(font, tx, sel_sd.description, HORIZONTAL_ALIGNMENT_LEFT, 240, 11, Color(0.7, 0.7, 0.8))

	## Hints
	dn.draw_string(font, Vector2(10, vp_size.y - 14), "[G] Sector view  |  Scroll: zoom  |  Middle drag: pan  |  Left-click: sector info  |  M or ESC: close", HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.4, 0.4, 0.5))


func _draw_map_contact(dn: Control, contact: Dictionary, font: Font) -> void:
	var ctype      : String     = contact.get("type", "")
	var pos        : Vector2    = contact.get("pos", Vector2.ZERO)
	var live       : bool       = contact.get("live", false)
	var faction_id : StringName = contact.get("faction_id", &"")
	var spos       := _map_world_to_screen(pos)
	var alpha      : float      = 1.0 if live else 0.35
	match ctype:
		"ship":
			var faction : FactionData = GameData.get_faction(faction_id)
			var color   : Color       = Color(faction.color.r, faction.color.g, faction.color.b, alpha) if faction else Color(0.7, 0.7, 0.7, alpha)
			dn.draw_circle(spos, 4.0, color)
		"station":
			var faction : FactionData = GameData.get_faction(faction_id)
			var color   : Color       = Color(faction.color.r, faction.color.g, faction.color.b, alpha) if faction else Color(0.7, 0.7, 0.7, alpha)
			var sz      : float       = 8.0
			dn.draw_rect(Rect2(spos - Vector2(sz/2, sz/2), Vector2(sz, sz)), color, false, 1.5)
			var node = contact.get("node")
			if node and node is StationInstance and node.station_data:
				dn.draw_string(font, spos + Vector2(10, 4), node.station_data.display_name, HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.9, 0.8, 0.5, alpha))
		"asteroids":
			dn.draw_circle(spos, 2.5, Color(0.55, 0.5, 0.45, alpha))
		"derelicts":
			dn.draw_circle(spos, 4.0, Color(0.5, 0.5, 0.6, alpha))
		"poi":
			var pts := PackedVector2Array([spos + Vector2(0,-6), spos + Vector2(6,0), spos + Vector2(0,6), spos + Vector2(-6,0)])
			dn.draw_colored_polygon(pts, Color(1.0, 0.9, 0.2, alpha))
		"hazards":
			dn.draw_circle(spos, 5.0, Color(0.8, 0.2, 0.2, alpha * 0.5))

func _map_contacts() -> Array[Dictionary]:
	var result: Array[Dictionary] = SensorSystem.fog.get_all_contacts_for_map()
	var known: Dictionary = {}
	for contact in result:
		var node = contact.get("node")
		if is_instance_valid(node): known[node.get_instance_id()] = true
	# Neutral/friendly transponders share station locations, not nearby space.
	for station in get_tree().get_nodes_in_group("stations"):
		if not station is StationInstance or not station.station_data or not station.can_share_station_info(): continue
		if known.has(station.get_instance_id()): continue
		result.append({"type": "station", "node": station, "pos": station.global_position, "faction_id": station.faction_id, "live": true, "long_range": not SensorSystem.has_local_contact(station.global_position)})
	return result

func _station_at_screen(position: Vector2) -> StationInstance:
	var nearest: StationInstance
	var best: float = 12.0
	for contact in _map_contacts():
		if contact.get("type") != "station": continue
		var station = contact.get("node")
		if not is_instance_valid(station) or station._is_destroyed: continue
		var distance: float = position.distance_to(_map_world_to_screen(station.global_position))
		if distance < best:
			best = distance
			nearest = station
	return nearest
