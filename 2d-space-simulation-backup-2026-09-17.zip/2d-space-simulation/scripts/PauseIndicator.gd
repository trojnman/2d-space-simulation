extends CanvasLayer
## Independent of menus so a paused load cannot hide the status.
var manual_pause := false
var label: Label
var button: Button
func _ready() -> void:
 process_mode = Node.PROCESS_MODE_ALWAYS
 layer = 120
 label = Label.new()
 label.text = "PAUSED"
 label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
 label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
 label.mouse_filter = Control.MOUSE_FILTER_IGNORE
 label.add_theme_font_size_override("font_size", 36)
 label.add_theme_color_override("font_color", Color("a7f3ff"))
 label.add_theme_color_override("font_outline_color", Color("08111e"))
 label.add_theme_constant_override("outline_size", 10)
 add_child(label)
 label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 button = Button.new()
 button.text = "Pause [P]"
 button.theme = preload("res://scripts/ConsoleTheme.gd").build()
 add_child(button)
 button.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
 button.offset_left = -75
 button.offset_right = 75
 button.offset_top = 12
 button.offset_bottom = 48
 button.pressed.connect(toggle_pause)
 _sync()
func toggle_pause() -> void:
 if SaveManager.loading or SaveManager._load_requested:return
 if get_tree().paused:
  manual_pause = false
  for menu in get_tree().get_nodes_in_group("pause_menu"):
   if menu.visible:menu.close()
  for screen in get_tree().get_nodes_in_group("inventory_screen"):
   if screen.visible:screen.close()
  get_tree().paused = false
 else:
  manual_pause = true
  get_tree().paused = true
 _sync()
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_P:
  get_viewport().set_input_as_handled()
  toggle_pause()
func _notification(what: int) -> void:
 if what == NOTIFICATION_PAUSED or what == NOTIFICATION_UNPAUSED:
  _sync()
func _process(_delta: float) -> void:
 _sync()
func _sync() -> void:
 if is_instance_valid(label) and is_inside_tree():
  if not get_tree().paused:manual_pause=false
  label.visible = get_tree().paused and manual_pause
 if is_instance_valid(button):
  button.text = "Resume [P]" if get_tree().paused else "Pause [P]"
  button.disabled = SaveManager.loading or SaveManager._load_requested
