extends CanvasLayer
var shade: ColorRect
var shader_material: ShaderMaterial
func _ready() -> void:
	layer = 3
	shade = ColorRect.new()
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(shade)
	var shader := Shader.new()
	shader.code = """shader_type canvas_item;
render_mode blend_mul;
uniform int count = 0;
uniform vec4 circles[32];
uniform vec2 viewport_size;
void fragment() {
 vec2 p = SCREEN_UV * viewport_size;
 float fog = 1.0;
 for(int i=0;i<32;i++) {
  if(i>=count) break;
  float d = distance(p,circles[i].xy);
  fog = min(fog,smoothstep(circles[i].z*0.88,circles[i].z,d));
 }
 COLOR=vec4(vec3(1.0 - fog * 0.30),1.0);
}"""
	shader_material = ShaderMaterial.new()
	shader_material.shader = shader
	shade.material = shader_material
func _process(_delta: float) -> void:
	var circles: Array[Dictionary] = SensorSystem.get_sensor_circles()
	var packed := PackedVector4Array()
	var transform: Transform2D = get_viewport().get_canvas_transform()
	for circle in circles.slice(0,32):
		var center: Vector2 = transform * circle["center"]
		packed.append(Vector4(center.x, center.y, circle["radius"] * transform.x.length(), 0))
	var count: int = packed.size()
	packed.resize(32)
	shader_material.set_shader_parameter("count", count)
	shader_material.set_shader_parameter("circles", packed)
	shader_material.set_shader_parameter("viewport_size", get_viewport().get_visible_rect().size)
