extends Area2D
var ship:Node2D
var shape:CircleShape2D
var flash:=0.0
var hit_angle:=0.0
func _ready()->void:
 ship=get_parent() as Node2D
 collision_layer=128
 collision_mask=0
 monitoring=false
 shape=CircleShape2D.new()
 var collider:=CollisionShape2D.new()
 collider.shape=shape
 add_child(collider)
 update_radius()
func update_radius()->void:
 if not shape:return
 var extent:=preload("res://scripts/ShipTactics.gd").radius(ship)
 for child in ship.get_children():
  if child is CollisionPolygon2D:
   for point in child.polygon:extent=maxf(extent,(child.transform*point).length())
 shape.radius=extent+18
func active()->bool:
 return is_instance_valid(ship) and not ship._is_destroyed and (ship is StationInstance or ship.equipped_shield!=null) and ship.shield>0
func _physics_process(delta:float)->void:
 collision_layer=128 if active() else 0
 if flash>0:
  flash=maxf(0,flash-delta)
  queue_redraw()
func struck(point:Vector2)->void:
 hit_angle=to_local(point).angle()
 flash=.18
func _draw()->void:
 if flash<=0:return
 draw_arc(Vector2.ZERO,shape.radius,hit_angle-.45,hit_angle+.45,20,Color(.35,.8,1,flash/.18),3,true)
