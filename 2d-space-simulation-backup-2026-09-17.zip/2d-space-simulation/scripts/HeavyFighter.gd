extends ShipInstance

## Heavy Fighter — Large aggressive warship, sharp angular strike craft. 160px long, 60px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(80,0),Vector2(60,-10),Vector2(40,-20),Vector2(10,-30),Vector2(-50,-28),Vector2(-80,-16),Vector2(-76,0),Vector2(-80,16),Vector2(-50,28),Vector2(10,30),Vector2(40,20),Vector2(60,10)])
	hull.color   = Color(0.15,0.3,0.6)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(60,-4),Vector2(60,4),Vector2(-72,4),Vector2(-72,-4)])
	detail0.color   = Color(0.12,0.2,0.38)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(20,-20),Vector2(-20,-30),Vector2(-50,-28),Vector2(-24,-16)])
	detail1.color   = Color(0.1,0.16,0.32)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(20,20),Vector2(-20,30),Vector2(-50,28),Vector2(-24,16)])
	detail2.color   = Color(0.1,0.16,0.32)
	add_child(detail2)

	var detail3 := Polygon2D.new()
	detail3.polygon = PackedVector2Array([Vector2(60,-8),Vector2(40,-18),Vector2(10,-28),Vector2(10,-18),Vector2(40,-10)])
	detail3.color   = Color(0.15,0.22,0.42)
	add_child(detail3)

	var detail4 := Polygon2D.new()
	detail4.polygon = PackedVector2Array([Vector2(60,8),Vector2(40,18),Vector2(10,28),Vector2(10,18),Vector2(40,10)])
	detail4.color   = Color(0.15,0.22,0.42)
	add_child(detail4)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(70,0),Vector2(52,-7),Vector2(40,0),Vector2(52,7)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-76, -12.8),
		Vector2(-90.4, -8.0),
		Vector2(-76, -3.2),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-76, 3.2),
		Vector2(-90.4, 8.0),
		Vector2(-76, 12.8),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	var eng2 := Polygon2D.new()
	eng2.polygon = PackedVector2Array([
		Vector2(-72, -3.2),
		Vector2(-81.6, 0.0),
		Vector2(-72, 3.2),
	])
	eng2.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng2)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(80,0),Vector2(40,-20),Vector2(-50,-28),Vector2(-80,0),Vector2(-50,28),Vector2(40,20)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(86,0),Vector2(62,-36),Vector2(0,-42),Vector2(-66,-28),Vector2(-86,0),Vector2(-66,28),Vector2(0,42),Vector2(62,36)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(6.0, -31.2),
		Vector2(82.0, -31.2),
		Vector2(82.0, -28.8),
		Vector2(6.0, -28.8),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(82.0, -30.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(6.0, 28.8),
		Vector2(82.0, 28.8),
		Vector2(82.0, 31.2),
		Vector2(6.0, 31.2),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(82.0, 30.0)
	add_child(m1)

	## Weapon barrel 2 — hidden when unequipped
	var wbarrel2 := Polygon2D.new()
	wbarrel2.polygon = PackedVector2Array([
		Vector2(38.0, -15.2),
		Vector2(82.0, -15.2),
		Vector2(82.0, -12.8),
		Vector2(38.0, -12.8),
	])
	wbarrel2.color   = Color(0.95, 0.95, 0.8)
	wbarrel2.visible = false
	add_child(wbarrel2)
	weapon_nodes.append(wbarrel2)

	var m2 := Marker2D.new()
	m2.name     = "Muzzle2"
	m2.position = Vector2(82.0, -14.0)
	add_child(m2)

	## Weapon barrel 3 — hidden when unequipped
	var wbarrel3 := Polygon2D.new()
	wbarrel3.polygon = PackedVector2Array([
		Vector2(38.0, 12.8),
		Vector2(82.0, 12.8),
		Vector2(82.0, 15.2),
		Vector2(38.0, 15.2),
	])
	wbarrel3.color   = Color(0.95, 0.95, 0.8)
	wbarrel3.visible = false
	add_child(wbarrel3)
	weapon_nodes.append(wbarrel3)

	var m3 := Marker2D.new()
	m3.name     = "Muzzle3"
	m3.position = Vector2(82.0, 14.0)
	add_child(m3)

	## Missile pod 0 — always visible
	var mpod0 := Polygon2D.new()
	mpod0.polygon = PackedVector2Array([
		Vector2(-10.0,       -25.5),
		Vector2(20.0, -25.5),
		Vector2(20.0, -18.5),
		Vector2(-10.0,       -18.5),
	])
	mpod0.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod0)
	missile_nodes.append(mpod0)

	var ml0 := Marker2D.new()
	ml0.name     = "MissileLaunch0"
	ml0.position = Vector2(20.0, -22.0)
	add_child(ml0)

	## Missile pod 1 — always visible
	var mpod1 := Polygon2D.new()
	mpod1.polygon = PackedVector2Array([
		Vector2(-10.0,       18.5),
		Vector2(20.0, 18.5),
		Vector2(20.0, 25.5),
		Vector2(-10.0,       25.5),
	])
	mpod1.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod1)
	missile_nodes.append(mpod1)

	var ml1 := Marker2D.new()
	ml1.name     = "MissileLaunch1"
	ml1.position = Vector2(20.0, 22.0)
	add_child(ml1)

	## Missile pod 2 — always visible
	var mpod2 := Polygon2D.new()
	mpod2.polygon = PackedVector2Array([
		Vector2(-30.0,       -3.5),
		Vector2(0.0, -3.5),
		Vector2(0.0, 3.5),
		Vector2(-30.0,       3.5),
	])
	mpod2.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod2)
	missile_nodes.append(mpod2)

	var ml2 := Marker2D.new()
	ml2.name     = "MissileLaunch2"
	ml2.position = Vector2(0.0, 0.0)
	add_child(ml2)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"heavy_fighter", vc)
