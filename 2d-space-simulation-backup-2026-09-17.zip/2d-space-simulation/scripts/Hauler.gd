extends ShipInstance

## Hauler — Small boxy cargo ship. 30px long, 14px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(15,-5),Vector2(15,5),Vector2(10,7),Vector2(-14,7),Vector2(-16,4),Vector2(-16,-4),Vector2(-14,-7),Vector2(10,-7)])
	hull.color   = Color(0.22,0.38,0.28)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(8,-5),Vector2(8,5),Vector2(-12,5),Vector2(-12,-5)])
	detail0.color   = Color(0.18,0.28,0.22)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(-12,-3),Vector2(-12,3),Vector2(-16,3),Vector2(-16,-3)])
	detail1.color   = Color(0.12,0.2,0.16)
	add_child(detail1)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(13,0),Vector2(10,-3),Vector2(7,0),Vector2(10,3)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-16, -2.0),
		Vector2(-22.0, 0.0),
		Vector2(-16, 2.0),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(15,-5),Vector2(15,5),Vector2(-14,7),Vector2(-16,0),Vector2(-14,-7)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(17,0),Vector2(12,-9),Vector2(0,-12),Vector2(-16,-8),Vector2(-19,0),Vector2(-16,8),Vector2(0,12),Vector2(12,9)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(12.0, -0.8),
		Vector2(17.0, -0.8),
		Vector2(17.0, 0.8),
		Vector2(12.0, 0.8),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(17.0, 0.0)
	add_child(m0)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"hauler", vc)
