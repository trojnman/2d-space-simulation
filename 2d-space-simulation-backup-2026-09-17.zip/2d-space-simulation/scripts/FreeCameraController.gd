class_name FreeCameraController
extends Camera2D
## Attach to a Camera2D node in your main scene.
## Press M to toggle free camera mode.
## In free cam: scroll to zoom, middle-drag to pan, WASD to pan.
## ESC or M to return to player.

const PAN_SPEED  : float   = 3000.0
const ZOOM_SPEED : float   = 0.15
const ZOOM_MIN   : Vector2 = Vector2(0.0007, 0.0007)
const ZOOM_MAX   : Vector2 = Vector2(6.0,  6.0)
const ZOOM_LERP  : float   = 10.0

var universe_map:Control
var _free_mode      : bool     = false
var _player         : Node2D   = null
var _zoom_target    : Vector2  = Vector2.ONE
var _player_camera  : Camera2D = null
var _zoom_mouse_pos : Vector2  = Vector2.ZERO


func _ready() -> void:
	await get_tree().process_frame
	_player = get_tree().get_first_node_in_group("player")
	enabled = false
	var remote_layer:=CanvasLayer.new()
	remote_layer.layer=10
	add_child(remote_layer)
	var remote:=preload("res://scripts/UniverseMapOverlay.gd").new()
	universe_map=remote
	remote.camera=self
	remote_layer.add_child(remote)


func _unhandled_input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if event is InputEventMouseButton and event.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
		if preload("res://scripts/UIInput.gd").over_menu(get_viewport()):return
		var player := get_tree().get_first_node_in_group("player")
		var missiles := player.get_node_or_null("MissileSystem") if player else null
		if Input.is_mouse_button_pressed(MOUSE_BUTTON_RIGHT) or (missiles and missiles.is_arm_button_held()): return

	if event.is_action_pressed("map"):
		get_viewport().set_input_as_handled()
		if _free_mode:
			_exit_free_cam()
		else:
			_enter_free_cam()
		return

	if not _free_mode: return

	if event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT:
		if universe_map.handle_click(event.position):
			get_viewport().set_input_as_handled()
			return
		var inspector := get_tree().get_first_node_in_group("station_inspection")
		if inspector and inspector.select_hovered():
			get_viewport().set_input_as_handled()
			return
	## Route input to fleet command system first
	if FleetCommandSystem.handle_input(event, self):
		get_viewport().set_input_as_handled()
		return

	if event.is_action_pressed("ui_cancel"):
		_exit_free_cam()
		return

	if event is InputEventKey or event is InputEventMouseButton or event is InputEventMouseMotion:
		get_viewport().set_input_as_handled()

	if event is InputEventMouseButton:
		var mb := event as InputEventMouseButton
		if mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_zoom_mouse_pos = get_global_mouse_position()
			var new_zoom := clampf(_zoom_target.x * (1.0 + ZOOM_SPEED), ZOOM_MIN.x, ZOOM_MAX.x)
			_zoom_target = Vector2(new_zoom, new_zoom)
		elif mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_zoom_mouse_pos = get_global_mouse_position()
			var new_zoom := clampf(_zoom_target.x * (1.0 - ZOOM_SPEED), ZOOM_MIN.x, ZOOM_MAX.x)
			_zoom_target = Vector2(new_zoom, new_zoom)


func _process(delta: float) -> void:
	if not _free_mode: return
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return

	var dir := Vector2.ZERO
	if Input.is_action_pressed("thrust"):       dir.y -= 1.0
	if Input.is_action_pressed("reverse"):      dir.y += 1.0
	if Input.is_action_pressed("strafe_left"):  dir.x -= 1.0
	if Input.is_action_pressed("strafe_right"): dir.x += 1.0
	if dir != Vector2.ZERO:
		global_position += dir.normalized() * PAN_SPEED * delta / zoom.x

	if Input.is_mouse_button_pressed(MOUSE_BUTTON_MIDDLE) and not preload("res://scripts/UIInput.gd").over_menu(get_viewport()):
		var rel := Input.get_last_mouse_velocity() * delta
		global_position -= rel / zoom.x

	if zoom != _zoom_target:
		var old_zoom := zoom
		zoom = zoom.lerp(_zoom_target, ZOOM_LERP * delta)
		var zoom_delta := 1.0 / old_zoom.x - 1.0 / zoom.x
		global_position += (_zoom_mouse_pos - global_position) * zoom_delta * zoom.x


func _enter_free_cam() -> void:
	_free_mode = true
	_player = get_tree().get_first_node_in_group("player")
	if _player:
		var player_cam := _player.get_node_or_null("Camera2D") as Camera2D
		if player_cam:
			_player_camera = player_cam
			global_position = player_cam.get_screen_center_position()
			zoom         = player_cam.zoom
			_zoom_target = zoom
			player_cam.enabled = false
	enabled = true
	_show_hud_overlay(true)


func _exit_free_cam() -> void:
	_free_mode = false
	## Deselect all fleet ships when leaving free cam
	FleetCommandSystem.deselect_all()
	if _player_camera:
		_player_camera.enabled = true
	enabled = false
	_show_hud_overlay(false)


func _show_hud_overlay(show_mode: bool) -> void:
	var hud := get_tree().get_first_node_in_group("hud")
	if hud and hud.has_method("show_free_cam_mode"):
		hud.show_free_cam_mode(show_mode)


func is_free_mode() -> bool:
	return _free_mode
