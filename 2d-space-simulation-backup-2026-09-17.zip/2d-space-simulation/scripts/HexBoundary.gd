class_name HexBoundary
extends Node2D

## Draws the sector hex boundary and damages ships outside it.
## Attach as child of SectorInstance.

## Hex radius in world units — slightly less than HALF_SIZE
const HEX_RADIUS       : float = 44000.0
const DAMAGE_START     : float = 2.0    ## HP/s at boundary edge
const DAMAGE_RAMP      : float = 0.5    ## extra HP/s per 1000 units outside
const DAMAGE_INTERVAL  : float = 0.5    ## how often to apply damage
const WARN_DISTANCE    : float = 2000.0 ## show warning this far from edge

## Hex corner angles (flat-top hexagon)
const HEX_ANGLES : Array[float] = [0.0, 60.0, 120.0, 180.0, 240.0, 300.0]

var _damage_timer : float = 0.0
var _sector       : Node  = null


func _ready() -> void:
	_sector = get_parent()
	queue_redraw()


func _process(_delta: float) -> void:
	# The continuous map supplies one consistent outline for every sector.
	# Keep the physical boundary and its damage active while hiding its artwork.
	var camera := get_viewport().get_camera_2d()
	visible = not (camera is FreeCameraController and camera.is_free_mode())


func _draw() -> void:
	## Draw hex outline
	var pts := _get_hex_points()
	for i in pts.size():
		var a := pts[i]
		var b := pts[(i + 1) % pts.size()]
		draw_line(a, b, Color(0.3, 0.5, 0.9, 0.25), 80.0)
	## Inner warning ring — slightly inside boundary
	for i in pts.size():
		var a := _hex_point(HEX_RADIUS - WARN_DISTANCE, HEX_ANGLES[i])
		var b := _hex_point(HEX_RADIUS - WARN_DISTANCE, HEX_ANGLES[(i + 1) % pts.size()])
		draw_line(a, b, Color(0.9, 0.4, 0.1, 0.12), 40.0)


func _physics_process(delta: float) -> void:
	_damage_timer += delta
	if _damage_timer < DAMAGE_INTERVAL: return
	_damage_timer = 0.0
	_apply_boundary_damage()


func _apply_boundary_damage() -> void:
	for ship in get_tree().get_nodes_in_group("ships"):
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		var dist_outside := _distance_outside_hex(ship.global_position)
		if dist_outside <= 0.0: continue
		var damage : float = (DAMAGE_START + (dist_outside / 1000.0) * DAMAGE_RAMP) * DAMAGE_INTERVAL
		ship.take_damage(damage, 0.0)
		## Notify player HUD if it's the player
		if ship.is_in_group("player"):
			var hud := get_tree().get_first_node_in_group("hud")
			if hud and hud.has_method("show_boundary_warning"):
				hud.show_boundary_warning(dist_outside)


func is_inside_hex(world_pos: Vector2) -> bool:
	return _distance_outside_hex(world_pos) <= 0.0


func _distance_outside_hex(world_pos: Vector2) -> float:
	## For a flat-top regular hexagon, check distance outside each edge
	var max_outside : float = -INF
	var pts := _get_hex_points()
	for i in pts.size():
		var a   := pts[i]
		var b   := pts[(i + 1) % pts.size()]
		var edge_normal := (b - a).rotated(-PI / 2.0).normalized()
		var d   := edge_normal.dot(world_pos - a)
		if d > max_outside:
			max_outside = d
	return max_outside


func get_hex_points_world() -> Array[Vector2]:
	return _get_hex_points()


func _get_hex_points() -> Array[Vector2]:
	var pts : Array[Vector2] = []
	for angle_deg in HEX_ANGLES:
		pts.append(_hex_point(HEX_RADIUS, angle_deg))
	return pts


func _hex_point(radius: float, angle_deg: float) -> Vector2:
	var angle_rad : float = deg_to_rad(angle_deg)
	return Vector2(cos(angle_rad), sin(angle_rad)) * radius


func get_gate_positions() -> Array[Vector2]:
	## Returns the midpoint of each hex edge — ideal jump gate positions
	var pts  := _get_hex_points()
	var mids : Array[Vector2] = []
	for i in pts.size():
		var a := pts[i]
		var b := pts[(i + 1) % pts.size()]
		mids.append((a + b) / 2.0)
	return mids
