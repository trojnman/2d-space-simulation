class_name ShipInstance
extends CharacterBody2D
var fleet_name: String = ""


## Runtime ship node. Works for both player and AI ships.

signal hull_changed(current: float, maximum: float)
signal shield_changed(current: float, maximum: float)
signal energy_changed(current: float, maximum: float)
signal ship_destroyed(ship: ShipInstance, killer: Node)
signal weapon_fired(weapon_data: WeaponData, origin: Vector2, direction: Vector2)
signal equipment_changed()

@export var ship_data  : ShipData   = null
@export var faction_id : StringName = &""

var equipped_weapons    : Array[WeaponData]  = []
var equipped_shield     : ShieldData         = null
var equipped_missiles   : Array[MissileData] = []
var inventory           : InventoryData      = InventoryData.new()
var weapon_fire_groups  : Array[int]         = []  ## 1 or 2 per slot

var hull         : float = 100.0
var max_hull     : float = 100.0
var shield       : float = 0.0
var max_shield   : float = 0.0
var energy       : float = 100.0
var max_energy   : float = 100.0

const ENERGY_RECHARGE_DELAY : float = 2.0

var _weapon_cooldowns      : Array[float] = []
var _shield_delay_timer    : float        = 0.0
var _energy_delay_timer    : float        = 0.0
var _is_destroyed          : bool         = false
var _runtime_initialized := false
var turret_order: int = 0
var turret_threats: Array = []
var turret_targets: Array = []
var turret_angles: Array[float] = []
var muzzle_points          : Array[Marker2D] = []


func _ready() -> void:
	add_to_group("ships")
	var shield_hitbox=preload("res://scripts/ShieldHitbox.gd").new()
	shield_hitbox.name="ShieldHitbox"
	add_child(shield_hitbox)
	_collect_muzzle_points()
	if ship_data and not _runtime_initialized:
		initialize(ship_data)


func initialize(data: ShipData) -> void:
	_runtime_initialized=true
	var hitbox=get_node_or_null("ShieldHitbox")
	if hitbox:hitbox.update_radius.call_deferred()
	inventory.capacity = data.cargo_capacity
	ship_data  = data
	max_hull   = data.max_hull
	hull       = max_hull
	max_energy = data.max_energy
	energy     = max_energy
	_weapon_cooldowns.resize(data.weapon_slots)
	_weapon_cooldowns.fill(0.0)
	weapon_fire_groups.resize(data.weapon_slots)
	weapon_fire_groups.fill(1)
	turret_angles.resize(data.weapon_slots)
	for i in data.weapon_slots: turret_angles[i] = data.mount_arc_center(i) if data.mount_kind(i) == "Turret" else 0.0
	_apply_shield()


func _apply_shield() -> void:
	if equipped_shield:
		max_shield = equipped_shield.max_hp
		shield     = max_shield
	else:
		max_shield = 0.0
		shield     = 0.0
	shield_changed.emit(shield, max_shield)
	_refresh_visuals()


func _refresh_visuals() -> void:
	for child in get_children():
		if child.has_method("refresh_equipment"):
			child.refresh_equipment()
			break


# ---------------------------------------------------------------------------
# Per-frame tick
# ---------------------------------------------------------------------------

func tick(delta: float) -> void:
	if not ship_data or _is_destroyed: return
	if ship_data:
		_weapon_cooldowns.resize(ship_data.weapon_slots)
		while weapon_fire_groups.size() < ship_data.weapon_slots: weapon_fire_groups.append(1)
		weapon_fire_groups.resize(ship_data.weapon_slots)
	preload("res://scripts/TurretOrders.gd").select_targets(self, delta)
	_update_mount_aim(delta)
	_regen_energy(delta)
	_regen_shield(delta)
	_regen_hull(delta)
	_tick_weapon_cooldowns(delta)
	_drain_shield_energy(delta)
	preload("res://scripts/TurretOrders.gd").fire(self)

func _regen_energy(delta: float) -> void:
	if not ship_data: return
	if _energy_delay_timer > 0.0:
		_energy_delay_timer -= delta
		energy_changed.emit(energy, max_energy)
		return
	energy = minf(energy + ship_data.energy_recharge_rate * delta, max_energy)
	energy_changed.emit(energy, max_energy)

func _regen_shield(delta: float) -> void:
	if not equipped_shield or max_shield <= 0.0: return
	if _shield_delay_timer > 0.0:
		_shield_delay_timer -= delta
		return
	if shield < max_shield:
		shield = minf(shield + equipped_shield.recharge_rate * delta, max_shield)
		shield_changed.emit(shield, max_shield)

func _regen_hull(delta: float) -> void:
	if not ship_data or ship_data.hull_repair_rate <= 0.0: return
	hull = minf(hull + ship_data.hull_repair_rate * delta, max_hull)
	hull_changed.emit(hull, max_hull)

func _drain_shield_energy(delta: float) -> void:
	if not equipped_shield or shield <= 0.0: return
	energy = maxf(energy - equipped_shield.energy_per_second * delta, 0.0)

func _tick_weapon_cooldowns(delta: float) -> void:
	for i in _weapon_cooldowns.size():
		if _weapon_cooldowns[i] > 0.0:
			_weapon_cooldowns[i] = maxf(_weapon_cooldowns[i] - delta, 0.0)


# ---------------------------------------------------------------------------
# Damage
# ---------------------------------------------------------------------------

func take_damage(shield_dmg: float, hull_dmg: float, _attacker: Node = null) -> void:
	if not PlayerState.combat_damage_allowed(_attacker,self):return
	if _is_destroyed: return
	if shield_dmg > 0 or hull_dmg > 0: preload("res://scripts/TurretOrders.gd").record_attack(self, _attacker)
	if shield_dmg > 0.0:
		var resist : float = equipped_shield.get_resist(GlobalEnums.DamageType.KINETIC) if equipped_shield else 1.0
		var absorbed_damage: float = shield_dmg * resist if shield > 0.0 else shield_dmg
		hull_dmg += maxf(0.0, absorbed_damage - shield)
		shield = maxf(shield - absorbed_damage, 0.0)
		_shield_delay_timer = equipped_shield.recharge_delay if equipped_shield else 0.0
		shield_changed.emit(shield, max_shield)
	if hull_dmg > 0.0:
		hull = maxf(hull - hull_dmg, 0.0)
		hull_changed.emit(hull, max_hull)
	if hull <= 0.0:
		_destroy(_attacker)

func take_damage_from_weapon(weapon: WeaponData, attacker: Node = null) -> void:
	var split := weapon.calc_damage_split(weapon.damage)
	take_damage(split[0], split[1], attacker)

func take_damage_from_missile(missile: MissileData, attacker: Node = null) -> void:
	var split := missile.calc_damage_split(missile.damage)
	take_damage(split[0], split[1], attacker)

func _destroy(killer: Node = null) -> void:
	if _is_destroyed: return
	_is_destroyed = true
	ship_destroyed.emit(self, killer)
	if killer != null and killer.is_in_group("player"):
		if faction_id != &"":
			FactionManager.player_killed_ship(faction_id)
	queue_free()


# ---------------------------------------------------------------------------
# Weapons
# ---------------------------------------------------------------------------

func can_fire(slot: int) -> bool:
	if slot < 0 or slot >= equipped_weapons.size(): return false
	var w := equipped_weapons[slot]
	if w == null or not ship_data.accepts_weapon(slot, w): return false
	if slot >= _weapon_cooldowns.size(): _weapon_cooldowns.resize(ship_data.weapon_slots)
	if w.uses_ammo and not inventory.has_item(w.ammo_item_id, w.ammo_per_shot): return false
	if _weapon_cooldowns[slot] > 0.0: return false
	if w.energy_per_shot > 0.0 and energy < w.energy_per_shot: return false
	return true

func fire_weapon(slot: int, direction: Vector2, show_effects: bool = true) -> bool:
	if not can_fire(slot): return false
	var w := equipped_weapons[slot]
	if w == null: return false
	var forward: float = global_rotation + (PI if self is Player else 0.0)
	if ship_data.mount_kind(slot) == "Turret":
		var local_aim: float = wrapf(direction.angle() - forward, -PI, PI)
		if absf(wrapf(local_aim - ship_data.mount_arc_center(slot), -PI, PI)) > PI/3.0: return false
		if absf(wrapf(local_aim - turret_angles[slot], -PI, PI)) > 0.08: return false
		direction = Vector2.from_angle(forward + turret_angles[slot])
	else:
		if not show_effects and absf(wrapf(direction.angle() - forward, -PI, PI)) > 0.08: return false
		direction = Vector2.from_angle(forward)
	if w.uses_ammo: inventory.remove_item(w.ammo_item_id, w.ammo_per_shot)
	_weapon_cooldowns[slot] = w.get_fire_interval()
	if w.energy_per_shot > 0.0:
		energy = maxf(energy - w.energy_per_shot, 0.0)
		_energy_delay_timer = ENERGY_RECHARGE_DELAY
	if not show_effects: return true
	var origin := _get_muzzle_position(slot)
	var flash := preload("res://scripts/ShotFlash.gd").new()
	flash.position = to_local(origin)
	flash.rotation = direction.angle() - global_rotation
	flash.radius = 1.5 + int(w.equip_size) * 1.2
	flash.tint = preload("res://scripts/WeaponPalette.gd").muzzle_color(w)
	add_child(flash)
	weapon_fired.emit(w, origin, direction)
	return true

func fire_group(group: int, direction: Vector2) -> void:
	## Fire all weapons in the given group simultaneously
	for i in equipped_weapons.size():
		if ship_data.mount_kind(i) == "Turret": continue
		if i >= weapon_fire_groups.size(): continue
		if weapon_fire_groups[i] != group: continue
		fire_weapon(i, direction)

func get_slots_in_group(group: int) -> Array[int]:
	var slots : Array[int] = []
	for i in weapon_fire_groups.size():
		if weapon_fire_groups[i] == group:
			slots.append(i)
	return slots

func set_weapon_fire_group(slot: int, group: int) -> void:
	while weapon_fire_groups.size() <= slot:
		weapon_fire_groups.append(1)
	weapon_fire_groups[slot] = group
	equipment_changed.emit()

func _get_muzzle_position(slot: int) -> Vector2:
	for child in get_children():
		if child is ShipVisualController: child._process(0.0)
	if slot < muzzle_points.size():
		return muzzle_points[slot].global_position
	return global_position

func _collect_muzzle_points() -> void:
	muzzle_points.clear()
	if not ship_data: return
	for i in ship_data.weapon_slots:
		var marker := get_node_or_null("Muzzle%d" % i) as Marker2D
		if marker: muzzle_points.append(marker)


# ---------------------------------------------------------------------------
# Equipment
# ---------------------------------------------------------------------------

func equip_weapon(w: WeaponData, slot: int) -> bool:
	if not ship_data: return false
	if slot < 0 or slot >= ship_data.weapon_slots or w == null: return false
	if not ship_data.accepts_weapon(slot, w): return false
	if slot >= equipped_weapons.size():
		equipped_weapons.resize(slot + 1)
	equipped_weapons[slot] = w
	_weapon_cooldowns.resize(maxi(ship_data.weapon_slots, equipped_weapons.size()))
	## Ensure fire group exists for this slot
	while weapon_fire_groups.size() <= slot:
		weapon_fire_groups.append(1)
	equipment_changed.emit()
	_refresh_visuals()
	return true

func equip_shield(s: ShieldData) -> bool:
	if not ship_data: return false
	if s == null: return false
	if not s.can_equip_on(ship_data.ship_class): return false
	equipped_shield = s
	_apply_shield()
	equipment_changed.emit()
	return true

func equip_missile(m: MissileData, slot: int) -> bool:
	if not ship_data: return false
	if slot < 0 or slot >= ship_data.missile_slots or m == null: return false
	if slot >= ship_data.rack_sizes.size() or int(m.equip_size) > ship_data.rack_sizes[slot]: return false
	if slot >= equipped_missiles.size():
		equipped_missiles.resize(slot + 1)
	equipped_missiles[slot] = m
	equipment_changed.emit()
	_refresh_visuals()
	return true

func can_launch_missile(slot: int) -> bool:
	if slot < 0 or slot >= equipped_missiles.size(): return false
	var m := equipped_missiles[slot]
	if m == null: return false
	return inventory.has_item(m.id)

func get_missile_launch_position(slot: int) -> Vector2:
	var marker := get_node_or_null("MissileLaunch%d" % slot) as Marker2D
	return marker.global_position if marker else global_position


func _update_mount_aim(delta: float) -> void:
	if not ship_data: return
	if turret_angles.size() != ship_data.weapon_slots: turret_angles.resize(ship_data.weapon_slots)
	var forward: float = global_rotation + (PI if self is Player else 0.0)
	var desired: float = forward
	if self is Player: desired = global_position.direction_to(get_global_mouse_position()).angle()
	else:
		for child in get_children():
			if child is AIShipController and is_instance_valid(child._target):
				desired = global_position.direction_to(child._target.global_position).angle()
				break
	for i in ship_data.weapon_slots:
		if ship_data.mount_kind(i) != "Turret": continue
		desired = forward + ship_data.mount_arc_center(i)
		if i < turret_targets.size() and is_instance_valid(turret_targets[i]): desired = global_position.direction_to(preload("res://scripts/TurretOrders.gd").aim_point(self,turret_targets[i],i)).angle()
		var center: float = ship_data.mount_arc_center(i)
		var offset: float = clampf(wrapf(desired-forward-center,-PI,PI),-PI/3.0,PI/3.0)
		var rate: float = [0.0, 3.2, 1.4, 0.45][ship_data.mount_size(i)]
		turret_angles[i] = rotate_toward(turret_angles[i], center+offset, rate*delta)

func rack_capacity(slot: int) -> int:
	if not ship_data or slot < 0 or slot >= ship_data.rack_sizes.size() or slot >= equipped_missiles.size(): return 0
	var missile: MissileData = equipped_missiles[slot]
	if missile == null or int(missile.equip_size) > ship_data.rack_sizes[slot]: return 0
	return int(pow(2, ship_data.rack_sizes[slot]-int(missile.equip_size)))

func weapon_direction(slot: int) -> Vector2:
	var angle: float = global_rotation + (PI if self is Player else 0.0)
	if ship_data and ship_data.mount_kind(slot) == "Turret" and slot < turret_angles.size(): angle += turret_angles[slot]
	return Vector2.from_angle(angle)

func set_turret_order(order: int) -> void:
	turret_order = clampi(order,0,3)
	turret_targets.clear()
