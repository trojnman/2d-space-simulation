class_name ShipInstance
extends CharacterBody2D

## Runtime ship node. Works for both player and AI ships.

signal hull_changed(current: float, maximum: float)
signal shield_changed(current: float, maximum: float)
signal energy_changed(current: float, maximum: float)
signal ship_destroyed(ship: ShipInstance, killer: Node)
signal weapon_fired(weapon_data: WeaponData, origin: Vector2, direction: Vector2)
signal equipment_changed()

@export var ship_data  : ShipData   = null
@export var faction_id : StringName = &""

var equipped_weapons    : Array[WeaponData]  = []
var equipped_shield     : ShieldData         = null
var equipped_missiles   : Array[MissileData] = []
var inventory           : InventoryData      = InventoryData.new()
var weapon_fire_groups  : Array[int]         = []  ## 1 or 2 per slot

var hull         : float = 100.0
var max_hull     : float = 100.0
var shield       : float = 0.0
var max_shield   : float = 0.0
var energy       : float = 100.0
var max_energy   : float = 100.0

const ENERGY_RECHARGE_DELAY : float = 2.0

var _weapon_cooldowns      : Array[float] = []
var _shield_delay_timer    : float        = 0.0
var _energy_delay_timer    : float        = 0.0
var _is_destroyed          : bool         = false
var _runtime_initialized := false
var muzzle_points          : Array[Marker2D] = []


func _ready() -> void:
	add_to_group("ships")
	_collect_muzzle_points()
	if ship_data and not _runtime_initialized:
		initialize(ship_data)


func initialize(data: ShipData) -> void:
	_runtime_initialized=true
	inventory.capacity = data.cargo_capacity
	ship_data  = data
	max_hull   = data.max_hull
	hull       = max_hull
	max_energy = data.max_energy
	energy     = max_energy
	_weapon_cooldowns.resize(data.weapon_slots)
	_weapon_cooldowns.fill(0.0)
	weapon_fire_groups.resize(data.weapon_slots)
	weapon_fire_groups.fill(1)
	_apply_shield()


func _apply_shield() -> void:
	if equipped_shield:
		max_shield = equipped_shield.max_hp
		shield     = max_shield
	else:
		max_shield = 0.0
		shield     = 0.0
	shield_changed.emit(shield, max_shield)
	_refresh_visuals()


func _refresh_visuals() -> void:
	for child in get_children():
		if child.has_method("refresh_equipment"):
			child.refresh_equipment()
			break


# ---------------------------------------------------------------------------
# Per-frame tick
# ---------------------------------------------------------------------------

func tick(delta: float) -> void:
	_regen_energy(delta)
	_regen_shield(delta)
	_regen_hull(delta)
	_tick_weapon_cooldowns(delta)
	_drain_shield_energy(delta)

func _regen_energy(delta: float) -> void:
	if not ship_data: return
	if _energy_delay_timer > 0.0:
		_energy_delay_timer -= delta
		energy_changed.emit(energy, max_energy)
		return
	energy = minf(energy + ship_data.energy_recharge_rate * delta, max_energy)
	energy_changed.emit(energy, max_energy)

func _regen_shield(delta: float) -> void:
	if not equipped_shield or max_shield <= 0.0: return
	if _shield_delay_timer > 0.0:
		_shield_delay_timer -= delta
		return
	if shield < max_shield:
		shield = minf(shield + equipped_shield.recharge_rate * delta, max_shield)
		shield_changed.emit(shield, max_shield)

func _regen_hull(delta: float) -> void:
	if not ship_data or ship_data.hull_repair_rate <= 0.0: return
	hull = minf(hull + ship_data.hull_repair_rate * delta, max_hull)
	hull_changed.emit(hull, max_hull)

func _drain_shield_energy(delta: float) -> void:
	if not equipped_shield or shield <= 0.0: return
	energy = maxf(energy - equipped_shield.energy_per_second * delta, 0.0)

func _tick_weapon_cooldowns(delta: float) -> void:
	for i in _weapon_cooldowns.size():
		if _weapon_cooldowns[i] > 0.0:
			_weapon_cooldowns[i] = maxf(_weapon_cooldowns[i] - delta, 0.0)


# ---------------------------------------------------------------------------
# Damage
# ---------------------------------------------------------------------------

func take_damage(shield_dmg: float, hull_dmg: float, _attacker: Node = null) -> void:
	if not PlayerState.combat_damage_allowed(_attacker,self):return
	if _is_destroyed: return
	if shield_dmg > 0.0:
		var resist : float = equipped_shield.get_resist(GlobalEnums.DamageType.KINETIC) if equipped_shield else 1.0
		var absorbed_damage: float = shield_dmg * resist if shield > 0.0 else shield_dmg
		hull_dmg += maxf(0.0, absorbed_damage - shield)
		shield = maxf(shield - absorbed_damage, 0.0)
		_shield_delay_timer = equipped_shield.recharge_delay if equipped_shield else 0.0
		shield_changed.emit(shield, max_shield)
	if hull_dmg > 0.0:
		hull = maxf(hull - hull_dmg, 0.0)
		hull_changed.emit(hull, max_hull)
	if hull <= 0.0:
		_destroy(_attacker)

func take_damage_from_weapon(weapon: WeaponData, attacker: Node = null) -> void:
	var split := weapon.calc_damage_split(weapon.damage)
	take_damage(split[0], split[1], attacker)

func take_damage_from_missile(missile: MissileData, attacker: Node = null) -> void:
	var split := missile.calc_damage_split(missile.damage)
	take_damage(split[0], split[1], attacker)

func _destroy(killer: Node = null) -> void:
	if _is_destroyed: return
	_is_destroyed = true
	ship_destroyed.emit(self, killer)
	if killer != null and killer.is_in_group("player"):
		if faction_id != &"":
			FactionManager.player_killed_ship(faction_id)
	queue_free()


# ---------------------------------------------------------------------------
# Weapons
# ---------------------------------------------------------------------------

func can_fire(slot: int) -> bool:
	if slot < 0 or slot >= equipped_weapons.size(): return false
	var w := equipped_weapons[slot]
	if w == null: return false
	if w.uses_ammo and not inventory.has_item(w.ammo_item_id, w.ammo_per_shot): return false
	if _weapon_cooldowns[slot] > 0.0: return false
	if w.energy_per_shot > 0.0 and energy < w.energy_per_shot: return false
	return true

func fire_weapon(slot: int, direction: Vector2, show_effects: bool = true) -> bool:
	if not can_fire(slot): return false
	var w := equipped_weapons[slot]
	if w == null: return false
	if w.uses_ammo: inventory.remove_item(w.ammo_item_id, w.ammo_per_shot)
	_weapon_cooldowns[slot] = w.get_fire_interval()
	if w.energy_per_shot > 0.0:
		energy = maxf(energy - w.energy_per_shot, 0.0)
		_energy_delay_timer = ENERGY_RECHARGE_DELAY
	if not show_effects: return true
	var origin := _get_muzzle_position(slot)
	var flash := preload("res://scripts/ShotFlash.gd").new()
	flash.position = to_local(origin)
	flash.rotation = direction.angle() - global_rotation
	flash.radius = 1.5 + int(w.equip_size) * 1.2
	flash.tint = preload("res://scripts/WeaponPalette.gd").muzzle_color(w)
	add_child(flash)
	weapon_fired.emit(w, origin, direction)
	return true

func fire_group(group: int, direction: Vector2) -> void:
	## Fire all weapons in the given group simultaneously
	for i in equipped_weapons.size():
		if i >= weapon_fire_groups.size(): continue
		if weapon_fire_groups[i] != group: continue
		fire_weapon(i, direction)

func get_slots_in_group(group: int) -> Array[int]:
	var slots : Array[int] = []
	for i in weapon_fire_groups.size():
		if weapon_fire_groups[i] == group:
			slots.append(i)
	return slots

func set_weapon_fire_group(slot: int, group: int) -> void:
	while weapon_fire_groups.size() <= slot:
		weapon_fire_groups.append(1)
	weapon_fire_groups[slot] = group
	equipment_changed.emit()

func _get_muzzle_position(slot: int) -> Vector2:
	if slot < muzzle_points.size():
		return muzzle_points[slot].global_position
	return global_position

func _collect_muzzle_points() -> void:
	muzzle_points.clear()
	for child in get_children():
		if child is Marker2D and child.name.begins_with("Muzzle"):
			muzzle_points.append(child)


# ---------------------------------------------------------------------------
# Equipment
# ---------------------------------------------------------------------------

func equip_weapon(w: WeaponData, slot: int) -> bool:
	if not ship_data: return false
	if slot < 0 or slot >= ship_data.weapon_slots or w == null: return false
	if not w.can_equip_on(ship_data.ship_class): return false
	if slot >= equipped_weapons.size():
		equipped_weapons.resize(slot + 1)
	equipped_weapons[slot] = w
	_weapon_cooldowns.resize(maxi(ship_data.weapon_slots, equipped_weapons.size()))
	## Ensure fire group exists for this slot
	while weapon_fire_groups.size() <= slot:
		weapon_fire_groups.append(1)
	equipment_changed.emit()
	_refresh_visuals()
	return true

func equip_shield(s: ShieldData) -> bool:
	if not ship_data: return false
	if s == null: return false
	if not s.can_equip_on(ship_data.ship_class): return false
	equipped_shield = s
	_apply_shield()
	equipment_changed.emit()
	return true

func equip_missile(m: MissileData, slot: int) -> bool:
	if not ship_data: return false
	if slot < 0 or slot >= ship_data.missile_slots or m == null: return false
	if not m.can_equip_on(ship_data.ship_class): return false
	if slot >= equipped_missiles.size():
		equipped_missiles.resize(slot + 1)
	equipped_missiles[slot] = m
	equipment_changed.emit()
	_refresh_visuals()
	return true

func can_launch_missile(slot: int) -> bool:
	if slot < 0 or slot >= equipped_missiles.size(): return false
	var m := equipped_missiles[slot]
	if m == null: return false
	return inventory.has_item(m.id)

func get_missile_launch_position(slot: int) -> Vector2:
	var marker := get_node_or_null("MissileLaunch%d" % slot) as Marker2D
	return marker.global_position if marker else global_position
