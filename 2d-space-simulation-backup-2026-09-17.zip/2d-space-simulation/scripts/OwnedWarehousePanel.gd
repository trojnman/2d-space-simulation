extends ScrollContainer
var station: StationInstance
var player: Player
var _list: VBoxContainer
func _ready() -> void:
	horizontal_scroll_mode=ScrollContainer.SCROLL_MODE_DISABLED
	_list=VBoxContainer.new()
	_list.size_flags_horizontal=Control.SIZE_EXPAND_FILL
	add_child(_list)
	refresh()
func refresh() -> void:
	for child in _list.get_children():
		_list.remove_child(child)
		child.queue_free()
	var title:=Label.new()
	title.text="YOUR STATION WAREHOUSE — transfers are free; production wages use your credits."
	title.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	_list.add_child(title)
	var production := CheckBox.new()
	production.text = "Automatic production (pays wages from your credits)"
	production.button_pressed = station.production_enabled
	production.toggled.connect(func(enabled): station.production_enabled = enabled)
	_list.add_child(production)
	var trading := CheckBox.new()
	trading.text = "Allow visiting traders to buy surplus (income goes to your credits)"
	trading.button_pressed = station.visiting_traders_enabled
	trading.toggled.connect(func(enabled): station.visiting_traders_enabled = enabled)
	_list.add_child(trading)
	var hint := Label.new()
	hint.text = "Stock target: supply haulers fill this amount; exports keep it reserved. Zero uses production needs."
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_list.add_child(hint)
	var ids: Array=GameData.items.keys()
	ids.sort()
	for id in player.inventory.get_all_items():
		if not ids.has(id): ids.append(id)
	for id in ids:
		var row:=HBoxContainer.new()
		_list.add_child(row)
		var label:=Label.new()
		label.text="%s — ship %d / warehouse %d" % [GameData.items[id].display_name,player.inventory.get_amount(id),station.inventory.get_amount(id)]
		label.size_flags_horizontal=Control.SIZE_EXPAND_FILL
		row.add_child(label)
		var target := SpinBox.new()
		target.prefix = "Keep "
		target.min_value = 0
		target.max_value = 1000000
		target.value = station.stock_targets.get(id,0)
		target.tooltip_text = "Minimum warehouse stock; supply ships replenish this without selling it to visitors"
		target.value_changed.connect(func(value): station.set_stock_target(id,int(value)))
		row.add_child(target)
		var quantity:=SpinBox.new()
		quantity.min_value=1
		quantity.max_value=1000000
		quantity.value=1
		row.add_child(quantity)
		for deposit in [true,false]:
			var button:=Button.new()
			button.text="Deposit" if deposit else "Withdraw"
			button.pressed.connect(func():
				station.transfer_owned_warehouse(player,id,int(quantity.value),deposit)
				refresh())
			row.add_child(button)
