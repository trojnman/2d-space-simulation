class_name FleetCommandPanel
extends CanvasLayer
var box:ColorRect
func _ready()->void:
 layer=9
 var root:=Control.new()
 root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 root.mouse_filter=Control.MOUSE_FILTER_IGNORE
 add_child(root)
 box=ColorRect.new()
 box.mouse_filter=Control.MOUSE_FILTER_IGNORE
 box.color=Color(.3,.76,.93,.12)
 root.add_child(box)
 root.add_child(preload("res://scripts/FleetRouteOverlay.gd").new())
func _process(_delta:float)->void:
 var rect:=FleetCommandSystem.get_box_select_rect_screen().abs()
 box.visible=rect.size!=Vector2.ZERO
 box.position=rect.position
 box.size=rect.size
