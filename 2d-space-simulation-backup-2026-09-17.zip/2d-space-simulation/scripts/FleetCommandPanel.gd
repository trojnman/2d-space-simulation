class_name FleetCommandPanel
extends CanvasLayer

## Shows selected fleet ships and their command queues.
## Sits at bottom center of screen.

const PANEL_COLOR  : Color = Color(0.05, 0.07, 0.12, 0.85)
const HEADER_COLOR : Color = Color(0.3,  0.76, 0.93, 1.0)
const CMD_COLOR    : Color = Color(0.7,  0.7,  0.8,  1.0)
const BORDER_COLOR : Color = Color(0.3,  0.35, 0.5,  0.8)

var _root      : Control   = null
var _panel     : PanelContainer = null
var _content   : VBoxContainer  = null
var _box_rect  : ColorRect = null


func _ready() -> void:
	layer = 12

	## Fullscreen root for box select overlay
	_root = Control.new()
	_root.set_anchors_preset(Control.PRESET_FULL_RECT)
	_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_root)

	## Box select overlay
	_box_rect             = ColorRect.new()
	_box_rect.color       = Color(0.3, 0.76, 0.93, 0.1)
	_box_rect.visible     = false
	_box_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_root.add_child(_box_rect)

	## Command panel — bottom center
	_panel = PanelContainer.new()
	_panel.visible = false
	_panel.mouse_filter = Control.MOUSE_FILTER_IGNORE
	var style := StyleBoxFlat.new()
	style.bg_color     = PANEL_COLOR
	style.border_color = BORDER_COLOR
	style.set_border_width_all(1)
	style.set_corner_radius_all(4)
	_panel.add_theme_stylebox_override("panel", style)
	_root.add_child(_panel)

	_content = VBoxContainer.new()
	_content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_panel.add_child(_content)

	FleetCommandSystem.selection_changed.connect(_on_selection_changed)
	get_viewport().size_changed.connect(_reposition)


func _process(_delta: float) -> void:
	## Update box select overlay
	var box_rect := FleetCommandSystem.get_box_select_rect_screen()
	if box_rect.size != Vector2.ZERO:
		_box_rect.visible  = true
		_box_rect.position = box_rect.position
		_box_rect.size     = box_rect.size
	else:
		_box_rect.visible  = false

	for button in get_tree().get_nodes_in_group("boarding_buttons"):
		var target = button.get_meta("boarding_target")
		var problem := PlayerState.boarding_problem(target if is_instance_valid(target) else null)
		button.disabled = problem != ""
		button.tooltip_text = problem if problem != "" else "Pilot this ship; your current ship holds position"
	## Update radius drag overlay
	_draw_radius_overlay()


func _draw_radius_overlay() -> void:
	## Radius drag is drawn via queue_redraw on a separate draw node if needed
	## For now handled by FreeCameraController overlay
	pass


func _on_selection_changed(ships: Array) -> void:
	_rebuild(ships)


func _rebuild(ships: Array) -> void:
	for child in _content.get_children():
		child.queue_free()

	if ships.is_empty():
		_panel.visible = false
		return

	_panel.visible = true

	var header := Label.new()
	header.text = "%d ship%s selected" % [ships.size(), "s" if ships.size() > 1 else ""]
	header.add_theme_color_override("font_color", HEADER_COLOR)
	header.add_theme_font_size_override("font_size", 14)
	header.mouse_filter = Control.MOUSE_FILTER_IGNORE
	_content.add_child(header)

	_content.add_child(HSeparator.new())

	for ship in ships:
		if not is_instance_valid(ship): continue
		var ai := ship.get_node_or_null("AIShipController") as AIShipController
		var ship_row := HBoxContainer.new()
		ship_row.mouse_filter = Control.MOUSE_FILTER_IGNORE

		## Ship name
		var name_lbl := Label.new()
		name_lbl.text = ship.ship_data.display_name if ship.ship_data else "Unknown"
		name_lbl.add_theme_color_override("font_color", Color(0.88, 0.88, 0.95))
		name_lbl.add_theme_font_size_override("font_size", 12)
		name_lbl.custom_minimum_size = Vector2(120, 0)
		name_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ship_row.add_child(name_lbl)

		## Command queue
		var queue_lbl := Label.new()
		var queue_text := ""
		if ai:
			var queue : Array = ai.get_command_queue()
			if queue.is_empty():
				queue_text = _state_label(ai._state)
			else:
				var parts : Array = []
				parts.append(_state_label(ai._state))
				for cmd in queue:
					parts.append(_command_label(cmd))
				queue_text = " → ".join(parts)
		queue_lbl.text = queue_text
		queue_lbl.add_theme_color_override("font_color", CMD_COLOR)
		queue_lbl.add_theme_font_size_override("font_size", 11)
		queue_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		queue_lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		ship_row.add_child(queue_lbl)

		var board := Button.new()
		board.text = "Enter ship"
		board.set_meta("boarding_target", ship)
		board.add_to_group("boarding_buttons")
		board.disabled = PlayerState.boarding_problem(ship) != ""
		board.pressed.connect(func(): PlayerState.board_ship(ship))
		ship_row.add_child(board)

		if ai and ship.ship_data and ("hauler" in str(ship.ship_data.id) or "logistics" in str(ship.ship_data.id)):
			var stations := OptionButton.new()
			for station in get_tree().get_nodes_in_group("stations"):
				if station is StationInstance and station.faction_id == &"player" and not station._is_destroyed:
					stations.add_item(station.station_data.display_name)
					stations.set_item_metadata(stations.item_count-1, station)
			for scaffold in get_tree().get_nodes_in_group("construction_scaffolds"):
				if not scaffold.completed and scaffold.remaining<0:
					stations.add_item("Build: "+GameData.stations[scaffold.blueprint].display_name)
					stations.set_item_metadata(stations.item_count-1,scaffold)
			ship_row.add_child(stations)
			var supply := Button.new()
			supply.text = "Supply station"
			supply.disabled = stations.item_count == 0
			supply.tooltip_text = "Deliver needed inputs; buy missing supplies using your credits. Cancel All stops the assignment."
			supply.pressed.connect(func():
				if stations.selected >= 0:
					var target=stations.get_item_metadata(stations.selected)
					if target is StationInstance:ai.assign_station_supply(target)
					else:ai.assign_scaffold_supply(target))
			ship_row.add_child(supply)

		## Cancel buttons
		var cancel_last := Button.new()
		cancel_last.text = "✕1"
		cancel_last.custom_minimum_size = Vector2(30, 0)
		cancel_last.pressed.connect(func(): FleetCommandSystem._cancel_last_order(ship))
		ship_row.add_child(cancel_last)

		var cancel_all := Button.new()
		cancel_all.text = "✕All"
		cancel_all.custom_minimum_size = Vector2(40, 0)
		cancel_all.pressed.connect(func(): FleetCommandSystem._cancel_all_orders(ship))
		ship_row.add_child(cancel_all)

		_content.add_child(ship_row)

	_reposition()


func _reposition() -> void:
	if not _panel: return
	await get_tree().process_frame
	var sz := get_viewport().get_visible_rect().size
	_panel.position = Vector2(
		sz.x / 2.0 - _panel.size.x / 2.0,
		sz.y - _panel.size.y - 80.0
	)


func _state_label(state: int) -> String:
	match state:
		AIShipController.State.IDLE:         return "Idle"
		AIShipController.State.PATROL:       return "Patrolling"
		AIShipController.State.ATTACK:       return "Attacking"
		AIShipController.State.FOLLOW:       return "Following"
		AIShipController.State.DEFEND:       return "Defending"
		AIShipController.State.PATROL_AREA:  return "Patrol Area"
		AIShipController.State.PATROL_ROUTE: return "Patrol Route"
		AIShipController.State.GO_WAIT:      return "Moving"
		AIShipController.State.STAY:         return "Holding"
		AIShipController.State.FLEE:         return "Fleeing"
		AIShipController.State.MINE:         return "Mining"
		AIShipController.State.HAUL:         return "Hauling"
	return "Unknown"


func _command_label(cmd: Dictionary) -> String:
	match cmd.get("type", -1):
		GlobalEnums.FleetCommand.FOLLOW_SHIP:  return "Follow"
		GlobalEnums.FleetCommand.DEFEND_SHIP:  return "Defend"
		GlobalEnums.FleetCommand.GO_WAIT:      return "Go & Wait"
		GlobalEnums.FleetCommand.PATROL_AREA:  return "Patrol Area"
		GlobalEnums.FleetCommand.PATROL_ROUTE: return "Patrol Route"
		GlobalEnums.FleetCommand.ATTACK_TARGET:return "Attack"
	return "?"
