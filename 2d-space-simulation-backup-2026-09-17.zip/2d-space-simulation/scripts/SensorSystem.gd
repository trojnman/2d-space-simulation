extends Node

## SensorSystem — Autoload singleton.
## Every frame, calculates what each observer can see.
## Observers: player ship, friendly ships, friendly stations, satellites.
## Add to Project → Autoload as "SensorSystem".

## View radii by ship class (in world units)
const RADIUS_SMALL   : float = 2500.0
const RADIUS_MEDIUM  : float = 4000.0
const RADIUS_LARGE   : float = 6000.0
const RADIUS_STATION : float = 30000.0
const RADIUS_SAT     : float = 6000.0

## How often to do a full sensor sweep (seconds)
const SWEEP_INTERVAL : float = 0.25

var _sweep_timer : float = 0.0

## All registered observers: Array of { "node": Node2D, "radius": float }
var _observers : Array[Dictionary] = []

## Reference to fog system
var fog : FogOfWar = null


func _ready() -> void:
	await get_tree().process_frame
	fog = FogOfWar.new()
	add_child(fog)


func _physics_process(delta: float) -> void:
	_sweep_timer -= delta
	if _sweep_timer <= 0.0:
		_sweep_timer = SWEEP_INTERVAL
		_do_sweep()


# ---------------------------------------------------------------------------
# Observer registration
# ---------------------------------------------------------------------------

func register_observer(node: Node2D, radius: float) -> void:
	## Avoid duplicates
	for obs in _observers:
		if obs["node"] == node:
			obs["radius"] = radius
			return
	_observers.append({"node": node, "radius": radius})


func unregister_observer(node: Node2D) -> void:
	for i in range(_observers.size() - 1, -1, -1):
		if _observers[i]["node"] == node:
			_observers.remove_at(i)
			return


func get_radius_for_ship(ship: ShipInstance) -> float:
	if not ship.ship_data: return RADIUS_SMALL
	var base_radius : float
	match ship.ship_data.ship_class:
		GlobalEnums.ShipClass.SMALL:  base_radius = RADIUS_SMALL
		GlobalEnums.ShipClass.MEDIUM: base_radius = RADIUS_MEDIUM
		GlobalEnums.ShipClass.LARGE:  base_radius = RADIUS_LARGE
		_:                            base_radius = RADIUS_SMALL
	return _apply_nebula_penalty(base_radius)


func _apply_nebula_penalty(radius: float) -> float:
	var sd := SectorManager.get_current_sector_data()
	if sd and sd.has_nebula:
		return radius * sd.nebula_sensor_penalty
	return radius


# ---------------------------------------------------------------------------
# Sweep
# ---------------------------------------------------------------------------

func _do_sweep() -> void:
	if fog == null: return

	## Clean up dead observers
	_observers = _observers.filter(func(obs): return is_instance_valid(obs["node"]))

	## Build list of revealed circles this frame
	var revealed_circles: Array[Dictionary] = get_sensor_circles()

	## Tell FogOfWar which circles are live this frame
	fog.update_sensor_coverage(revealed_circles)

	## Scan all trackable objects in the scene
	_scan_ships(revealed_circles)
	_scan_stations(revealed_circles)
	_scan_static_objects(revealed_circles)
	_apply_world_fog()


func _scan_ships(circles: Array[Dictionary]) -> void:
	for ship in get_tree().get_nodes_in_group("ships"):
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		var pos     : Vector2 = ship.global_position
		var in_range: bool    = _is_in_any_circle(pos, circles)
		fog.update_contact(ship.get_instance_id(), {
			"type":       "ship",
			"pos":        pos,
			"faction_id": ship.faction_id,
			"node":       ship,
			"in_range":   in_range,
		})


func _scan_stations(circles: Array[Dictionary]) -> void:
	for station in get_tree().get_nodes_in_group("stations"):
		if not station is StationInstance: continue
		if not is_instance_valid(station): continue
		var pos      : Vector2 = station.global_position
		var in_range : bool    = _is_in_any_circle(pos, circles)
		fog.update_contact(station.get_instance_id(), {
			"type":       "station",
			"pos":        pos,
			"faction_id": station.faction_id,
			"node":       station,
			"in_range":   in_range or has_long_range_contact(pos),
			"long_range": not in_range,
		})


func _scan_static_objects(circles: Array[Dictionary]) -> void:
	## Asteroids, POIs, hazards, derelicts, jump gates
	for group in ["asteroids", "jump_gates", "poi", "derelicts", "hazards"]:
		for obj in get_tree().get_nodes_in_group(group):
			if not obj is Node2D: continue
			if not is_instance_valid(obj): continue
			var pos      : Vector2 = obj.global_position
			var in_range : bool    = _is_in_any_circle(pos, circles)
			fog.update_contact(obj.get_instance_id(), {
				"type":     group,
				"pos":      pos,
				"node":     obj,
				"in_range": in_range,
			})


func _is_in_any_circle(pos: Vector2, circles: Array[Dictionary]) -> bool:
	for c in circles:
		if pos.distance_squared_to(c["center"]) <= c["radius"] * c["radius"]:
			return true
	return false


# ---------------------------------------------------------------------------
# Convenience queries (used by SectorMap)
# ---------------------------------------------------------------------------

func _apply_world_fog() -> void:
	if not fog: return
	for group in ["ships", "stations", "asteroids", "jump_gates", "poi", "derelicts", "hazards", "sensor_entities"]:
		for node in get_tree().get_nodes_in_group(group):
			if node is Node2D and not node.is_in_group("player"):
				node.visible = fog.is_revealed(node.global_position)


func _shares_vision(node: Node) -> bool:
	if node.get("_is_destroyed") or node.is_queued_for_deletion():return false
	if node.is_in_group("player") or node.is_in_group("player_fleet") or node is SatelliteInstance:return true
	if node is StationInstance and node.faction_id==&"player":return true
	return (node is ShipInstance or node is StationInstance) and PlayerState.has_shared_sensors(node.faction_id)

func get_sensor_circles() -> Array[Dictionary]:
	var result: Array[Dictionary]=[]
	for group in ["ships","stations","satellites"]:
		for node in get_tree().get_nodes_in_group(group):
			if not node is Node2D or not _shares_vision(node):continue
			var radius: float=get_radius_for_ship(node) if node is ShipInstance else _apply_nebula_penalty(RADIUS_STATION if node is StationInstance else RADIUS_SAT)
			result.append({"center":node.global_position,"radius":radius})
	return result


func has_local_contact(position: Vector2) -> bool:
	return _is_in_any_circle(position, get_sensor_circles())


func has_long_range_contact(position: Vector2) -> bool:
	for circle in get_sensor_circles():
		if position.distance_to(circle["center"]) <= circle["radius"] * 4.0: return true
	return false


func remote_sector_contacts(id: StringName) -> Dictionary:
	var sector: SectorInstance=SectorManager._visited_sectors.get(id)
	if not is_instance_valid(sector):return {"circles":[],"contacts":[]}
	var circles: Array[Dictionary]=[]
	var contacts: Array=[]
	var nodes=sector.find_children("*","",true,false)
	var penalty: float=sector.sector_data.nebula_sensor_penalty if sector.sector_data.has_nebula else 1.0
	for node in nodes:
		var radius:=0.0
		if node is ShipInstance and _shares_vision(node):
			radius=RADIUS_SMALL
			if node.ship_data and node.ship_data.ship_class==GlobalEnums.ShipClass.MEDIUM:radius=RADIUS_MEDIUM
			elif node.ship_data and node.ship_data.ship_class==GlobalEnums.ShipClass.LARGE:radius=RADIUS_LARGE
		elif node is StationInstance and _shares_vision(node):radius=RADIUS_STATION
		elif node is SatelliteInstance:radius=RADIUS_SAT
		if radius>0:circles.append({"center":node.position,"radius":radius*penalty})
	for node in nodes:
		if not (node is ShipInstance or node is StationInstance or node is SatelliteInstance):continue
		if node.get("_is_destroyed") or node.is_queued_for_deletion():continue
		var seen:=_is_in_any_circle(node.position,circles)
		if not seen and not (node is StationInstance and node.can_share_station_info()):continue
		var label: String=node.ship_data.display_name if node is ShipInstance and node.ship_data else (node.station_data.display_name if node is StationInstance else "Satellite")
		var hostile: bool=PlayerState.is_hostile_to_player(node.faction_id) if node is ShipInstance or node is StationInstance else false
		contacts.append({"position":node.position,"label":label,"hostile":hostile,"station":node is StationInstance,"node":node,"remembered":false})
		if node is StationInstance and seen:
			if not MapMemory.sector_memory.has(id):MapMemory.sector_memory[id]=[]
			var memory: Array=MapMemory.sector_memory[id]
			var existing: Dictionary={}
			for entry in memory:
				if entry.get("type")=="remote_station" and entry.get("pos")==node.position:existing=entry;break
			if existing.is_empty():
				existing={"type":"remote_station","pos":node.position}
				memory.append(existing)
			existing["faction_id"]=node.faction_id
			existing["label"]=label
	for entry in MapMemory.get_sector_memory(id).duplicate():
		if entry.get("type")!="remote_station":continue
		var present:=false
		for contact in contacts:
			if contact.station and contact.position==entry.pos:present=true;break
		if present:continue
		if _is_in_any_circle(entry.pos,circles):
			MapMemory.sector_memory[id].erase(entry)
			continue
		contacts.append({"position":entry.pos,"label":entry.label+" (last known)","hostile":PlayerState.is_hostile_to_player(entry.faction_id),"station":true,"remembered":true})
	return {"circles":circles,"contacts":contacts}
