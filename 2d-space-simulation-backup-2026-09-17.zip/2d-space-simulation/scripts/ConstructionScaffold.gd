extends StaticBody2D
const BUILD = preload("res://scripts/StationConstruction.gd")
var blueprint: StringName = &""
var beneficiary: StringName = &""
var cargo: Dictionary = {}
var remaining: float = -1.0
var completed := false
var hull: float = 500.0
var _is_destroyed := false
var faction_id: StringName:
	get:return beneficiary
var panel: VBoxContainer
var info: Label
func _ready() -> void:
	add_to_group("construction_scaffolds")
	var collision:=CollisionShape2D.new()
	var shape:=CircleShape2D.new()
	shape.radius=76
	collision.shape=shape
	add_child(collision)
	add_to_group("sensor_entities")
	var layer := CanvasLayer.new()
	add_child(layer)
	panel = VBoxContainer.new()
	panel.position = Vector2(24,160)
	layer.add_child(panel)
	info = Label.new()
	panel.add_child(info)
	var button := Button.new()
	button.text = "Deliver required materials from cargo"
	button.pressed.connect(func(): deposit(PlayerState.current_ship as Player))
	panel.add_child(button)
	queue_redraw()
func _draw() -> void:
	for radius in [50.0,75.0]: draw_arc(Vector2.ZERO,radius,0,TAU,8,Color("e8b85a"),4)
	for i in 4:
		var direction := Vector2.from_angle(i*PI/2)
		draw_line(direction*40,direction*90,Color("8ba3b8"),8)
func requirements() -> Dictionary:
	return StationData.BUILD_COSTS[GameData.stations[blueprint].station_type]
func deposit(player: Player) -> int:
	if completed or remaining >= 0 or not is_instance_valid(player) or player._is_docked or global_position.distance_to(player.global_position)>350: return 0
	var moved := 0
	for id in requirements():
		var amount := mini(maxi(0,int(requirements()[id])-int(cargo.get(id,0))),player.inventory.get_amount(id))
		if amount>0:
			player.inventory.remove_item(id,amount)
			cargo[id]=int(cargo.get(id,0))+amount
			moved+=amount
	return moved
func _process(_delta: float) -> void:
	var player = PlayerState.current_ship
	panel.visible = is_instance_valid(player) and player.global_position.distance_to(global_position)<=350 and not player._is_docked
	if not panel.visible: return
	var lines := PackedStringArray([GameData.stations[blueprint].display_name+" construction scaffold", "Hull: %d / 500" % int(hull)])
	if remaining>=0: lines.append("Awaiting territory/build permission" if remaining==0 else "Building: %.1f seconds" % remaining)
	else:
		for id in requirements(): lines.append("%s: %d / %d" % [GameData.items[id].display_name,cargo.get(id,0),requirements()[id]])
	info.text="\n".join(lines)
func _physics_process(delta: float) -> void: advance(delta)
func advance(delta: float) -> void:
	if completed: return
	if remaining<0:
		for id in requirements():
			if int(cargo.get(id,0))<int(requirements()[id]): return
		cargo.clear()
		remaining=BUILD.BUILD_SECONDS
		return
	remaining=maxf(0,remaining-delta)
	if remaining>0:return
	var sector=BUILD.sector_of(self)
	if not sector:return
	var data: StationData=GameData.stations[blueprint]
	if data.station_type==&"claim_beacon" and beneficiary==&"player" and not PlayerState.founded_faction:return
	if data.station_type in [&"headquarters",&"claim_beacon"] and sector.sector_data.controlling_faction_id not in [&"",beneficiary]: return
	completed=true
	if BUILD.limit_problem(sector,data,beneficiary)!="":
		completed=false
		return
	call_deferred("finish")
func finish() -> void:
	if is_queued_for_deletion():return
	var sector=BUILD.sector_of(self)
	var station: StationInstance=load("res://scenes/Station.tscn").instantiate()
	station.constructed=true
	station.blueprint_id=blueprint
	station.runtime_station_id=StringName("built_"+str(Time.get_ticks_usec())+"_"+str(randi()))
	station.station_data=GameData.stations[blueprint].duplicate(true)
	station.station_data.id=station.runtime_station_id
	station.faction_id=beneficiary
	station.claim_faction_id=beneficiary
	station.position=position
	station._local_credits=0
	station._treasury_linked=FactionManager._faction_state.has(beneficiary)
	station.add_to_group("stations")
	station.initialize_runtime()
	sector.get_node("Stations").add_child(station)
	FactionManager.register_station(station)
	var spawner:=StationSpawner.new()
	spawner._station=station
	spawner.max_ships=station.station_data.max_ships
	spawner._initial_ships_spawned=spawner.max_ships
	station.add_child(spawner)
	if not station.is_inside_tree():spawner._build_spawn_pool()
	if station.station_data.station_type in [&"headquarters",&"claim_beacon"]:
		sector.sector_data.controlling_faction_id=beneficiary
		FactionManager._sector_ownership[sector.sector_data.id]=beneficiary
	if station.station_data.station_type==&"headquarters" and beneficiary==&"player": PlayerState.establish_faction(station)
	queue_free()


func take_damage(amount: float, attacker: Node = null) -> void:
	if _is_destroyed or not PlayerState.combat_damage_allowed(attacker,self):return
	hull=maxf(0,hull-maxf(0,amount))
	if hull<=0:
		_is_destroyed=true
		completed=true
		cargo.clear()
		queue_free()
