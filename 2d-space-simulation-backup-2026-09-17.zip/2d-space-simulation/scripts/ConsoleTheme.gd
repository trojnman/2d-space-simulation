extends RefCounted

static func box(background: Color, border: Color, width: int = 1) -> StyleBoxFlat:
	var style := StyleBoxFlat.new()
	style.bg_color = background
	style.border_color = border
	style.set_border_width_all(width)
	style.set_corner_radius_all(3)
	style.content_margin_left = 14
	style.content_margin_right = 14
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	return style

static func build() -> Theme:
	var theme := Theme.new()
	theme.default_font_size = 16
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Bahnschrift", "Segoe UI"])
	theme.default_font = font
	var ink := Color("d8eaf2")
	var cyan := Color("56dfeb")
	var edge := Color("294957")
	var base := Color("0a1420")
	for type in ["Label", "Button", "TabContainer", "RichTextLabel"]:
		theme.set_color("font_color", type, ink)
	theme.set_color("default_color", "RichTextLabel", ink)
	theme.set_stylebox("panel", "PanelContainer", box(base, edge))
	theme.set_stylebox("panel", "TabContainer", box(Color("0c1926"), edge))
	for type in ["Button", "TabContainer"]:
		var normal := box(Color("112333"), edge)
		var active := box(Color("164252"), cyan)
		var hover := box(Color("1c3648"), cyan)
		if type == "Button":
			theme.set_stylebox("normal", type, normal)
			theme.set_stylebox("hover", type, hover)
			theme.set_stylebox("pressed", type, active)
			theme.set_stylebox("disabled", type, box(Color("0d1b27"), Color("1c303b")))
			theme.set_stylebox("focus", type, box(Color(0,0,0,0), cyan, 2))
			theme.set_color("font_disabled_color", type, Color("58717d"))
			theme.set_color("font_hover_color", type, Color.WHITE)
		else:
			theme.set_stylebox("tab_unselected", type, normal)
			theme.set_stylebox("tab_selected", type, active)
			theme.set_stylebox("tab_hovered", type, hover)
			theme.set_color("font_selected_color", type, cyan)
			theme.set_color("font_unselected_color", type, Color("8faab7"))
	for type in ["VScrollBar", "HScrollBar"]:
		theme.set_stylebox("scroll", type, box(Color("08111b"), Color("08111b"), 0))
		theme.set_stylebox("grabber", type, box(Color("285565"), edge, 0))
		theme.set_stylebox("grabber_highlight", type, box(cyan, cyan, 0))
	var popup := box(Color("0a1624"), Color("315766"))
	popup.set_corner_radius_all(12)
	popup.content_margin_left=10
	popup.content_margin_right=10
	popup.content_margin_top=10
	popup.content_margin_bottom=10
	popup.shadow_color=Color(0,0,0,.4)
	popup.shadow_size=6
	theme.set_stylebox("panel","PopupMenu",popup)
	var highlight := box(Color("164252"),cyan)
	highlight.set_corner_radius_all(6)
	highlight.content_margin_top=5
	highlight.content_margin_bottom=5
	theme.set_stylebox("hover","PopupMenu",highlight)
	var separator := StyleBoxLine.new()
	separator.color=edge
	separator.thickness=1
	separator.grow_begin=-6
	separator.grow_end=-6
	theme.set_stylebox("separator","PopupMenu",separator)
	theme.set_color("font_color","PopupMenu",ink)
	theme.set_color("font_hover_color","PopupMenu",cyan)
	theme.set_color("font_disabled_color","PopupMenu",Color("58717d"))
	theme.set_color("font_separator_color","PopupMenu",Color("8faab7"))
	theme.set_font_size("font_size","PopupMenu",14)
	theme.set_constant("v_separation","PopupMenu",12)
	theme.set_constant("h_separation","PopupMenu",12)
	theme.set_constant("item_start_padding","PopupMenu",8)
	theme.set_constant("item_end_padding","PopupMenu",8)
	theme.set_constant("separation", "VBoxContainer", 8)
	theme.set_constant("separation", "HBoxContainer", 10)
	return theme

static func apply_to(root: Node) -> void:
	var theme := build()
	for child in root.get_children():
		if child is Control: child.theme = theme

static func compact() -> Theme:
	var result:=build()
	result.default_font_size=12
	for type in ["Button","OptionButton","LineEdit","PanelContainer"]:
		for state in ["normal","hover","pressed","disabled","focus","panel"]:
			if not result.has_stylebox(state,type):continue
			var style=result.get_stylebox(state,type).duplicate()
			style.content_margin_top=3
			style.content_margin_bottom=3
			style.content_margin_left=7
			style.content_margin_right=7
			result.set_stylebox(state,type,style)
	result.set_constant("separation","VBoxContainer",3)
	result.set_constant("separation","HBoxContainer",5)
	return result
