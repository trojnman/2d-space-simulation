extends Control
## Chart overlay in the same camera coordinates as the local tactical map.
var camera:FreeCameraController
var snapshots:Dictionary={}
var timer:float=0
var inspector:Control
func _ready()->void:
 hide()
 mouse_filter=Control.MOUSE_FILTER_IGNORE
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 inspector=preload("res://scripts/StationIdentification.gd").new()
 inspector.map_inspection=true
 inspector.remote_inspection=true
 add_child(inspector)
 inspector.hide()
func origin(id:StringName)->Vector2:
 return (GameData.sectors[id].map_position-GameData.sectors[SectorManager.current_sector_id].map_position)*1000.0
func screen(world:Vector2)->Vector2:
 return get_viewport().get_canvas_transform()*world
func _process(delta:float)->void:
 visible=is_instance_valid(camera) and camera.is_free_mode()
 if not visible:return
 timer-=delta
 if timer<=0:
  timer=0.5
  snapshots.clear()
  for id in GameData.sectors:
   if id!=SectorManager.current_sector_id:snapshots[id]=SensorSystem.remote_sector_contacts(id)
 queue_redraw()
func _draw()->void:
 if not visible or not GameData.sectors.has(SectorManager.current_sector_id):return
 var font:Font=ThemeDB.fallback_font
 for id in GameData.sectors:
  var data:SectorData=GameData.sectors[id]
  var base:Vector2=origin(id)
  var center:Vector2=screen(base)
  var radius:float=HexBoundary.HEX_RADIUS*camera.zoom.x
  if not Rect2(Vector2.ZERO,get_viewport_rect().size).grow(radius+80).has_point(center):continue
  if camera.zoom.x<0.008:
   for other in data.connected_sectors:
    draw_line(center,screen(origin(other)),Color(0.2,0.4,0.5,0.5),1)
  var corners:PackedVector2Array=[]
  for i in 7:corners.append(screen(base+Vector2.from_angle(i*PI/3.0)*HexBoundary.HEX_RADIUS))
  draw_polyline(corners,Color("446980"),1.5)
  draw_string(font,center+Vector2(-65,-radius-12),data.display_name,HORIZONTAL_ALIGNMENT_LEFT,220,15,Color("c3e5fa"))
  for i in data.connected_sectors.size():
   var angle:float=i*PI/3.0
   var pos:Vector2=screen(base+(Vector2.from_angle(angle)+Vector2.from_angle(angle+PI/3))*HexBoundary.HEX_RADIUS/2)
   draw_rect(Rect2(pos-Vector2(4,4),Vector2(8,8)),Color("72e0ee"),false,2)
   if camera.zoom.x>=0.002:draw_string(font,pos+Vector2(7,-7),GameData.sectors[data.connected_sectors[i]].display_name,HORIZONTAL_ALIGNMENT_LEFT,180,11,Color("a6e7ef"))
  if id==SectorManager.current_sector_id:continue
  var snapshot:Dictionary=snapshots.get(id,{"circles":[],"contacts":[]})
  for circle in snapshot.circles:draw_circle(screen(base+circle.center),circle.radius*camera.zoom.x,Color(0.12,0.3,0.4,0.2))
  for contact in snapshot.contacts:
   var point:Vector2=screen(base+contact.position)
   draw_circle(point,4 if contact.station else 2,Color("ff6655") if contact.hostile else Color("69dfd3"))
   if contact.station and camera.zoom.x>=0.002:draw_string(font,point+Vector2(6,-5),contact.label,HORIZONTAL_ALIGNMENT_LEFT,180,11,Color("c3e5fa"))
func handle_click(point:Vector2)->bool:
 if preload("res://scripts/UIInput.gd").over_menu(get_viewport()):return false
 for id in snapshots:
  for contact in snapshots[id].contacts:
   if not contact.station or point.distance_to(screen(origin(id)+contact.position))>10:continue
   var station=contact.get("node")
   if is_instance_valid(station) and station.can_share_station_info():
    inspector.selected=station
    inspector._displayed=station
    inspector._refresh_card(true)
    return true
 return false
