class_name ShipVisualController
extends Node2D

## Add as child of any ShipInstance.
## Holds references to all visual nodes and refreshes them when equipment changes.
## Each ship script calls setup() with its visual node references.

## Weapon barrel nodes — one per weapon slot. Hidden when slot empty.
var weapon_visuals   : Array[Node2D] = []

## Shield ring node — always visible, color changes.
var shield_visual    : Node2D        = null

## Missile pod nodes — one per missile slot. Always visible, color changes.
var missile_visuals  : Array[Node2D] = []

## Colors
const WEAPON_COLOR   : Color = Color(0.95, 0.95, 0.8,  1.0)  ## bright barrel
const SHIELD_ON      : Color = Color(0.3,  0.6,  1.0,  0.35) ## active shield glow
const SHIELD_OFF     : Color = Color(0.25, 0.25, 0.3,  0.2)  ## empty shield slot
const MISSILE_ON     : Color = Color(0.4,  0.8,  0.3,  1.0)  ## loaded missile
const MISSILE_OFF    : Color = Color(0.25, 0.28, 0.25, 0.7)  ## empty missile slot

var _ship : ShipInstance = null


func _ready() -> void:
	_ship = get_parent() as ShipInstance
	if _ship:
		_ship.equipment_changed.connect(refresh_equipment)


func setup(
		p_weapon_visuals:  Array[Node2D],
		p_shield_visual:   Node2D,
		p_missile_visuals: Array[Node2D]
) -> void:
	weapon_visuals  = p_weapon_visuals
	shield_visual   = p_shield_visual
	missile_visuals = p_missile_visuals
	refresh_equipment()


func refresh_equipment() -> void:
	if not _ship: return
	_refresh_weapons()
	_refresh_shield()
	_refresh_missiles()


func _refresh_weapons() -> void:
	for i in weapon_visuals.size():
		var node : Node2D = weapon_visuals[i]
		if not is_instance_valid(node): continue
		var has_weapon : bool = (
			i < _ship.equipped_weapons.size() and
			_ship.equipped_weapons[i] != null
		)
		node.visible = has_weapon
		if has_weapon:
			var w : WeaponData = _ship.equipped_weapons[i]
			## Match the mount accents to the projectile family.
			var col: Color = preload("res://scripts/WeaponPalette.gd").shot_color(w)
			_style_weapon(node, i, w, col)


func _refresh_shield() -> void:
	if not is_instance_valid(shield_visual): return
	if _ship.equipped_shield:
		_set_polygon_color(shield_visual, SHIELD_ON)
	else:
		_set_polygon_color(shield_visual, SHIELD_OFF)


func _refresh_missiles() -> void:
	for i in missile_visuals.size():
		var node : Node2D = missile_visuals[i]
		if not is_instance_valid(node): continue
		var has_missile : bool = (
			i < _ship.equipped_missiles.size() and
			_ship.equipped_missiles[i] != null
		)
		_set_polygon_color(node, MISSILE_ON if has_missile else MISSILE_OFF)
		if node is Polygon2D and has_meta("hull_half_size"):
			var extent: Vector2 = get_meta("hull_half_size")
			var length: float = minf(extent.x * .22, 7.0)
			var width: float = minf(extent.y * .14, 2.3)
			var center := _find_hull_mount(length*.5, width, -1.0 if i % 2 == 0 else 1.0, 2 + i / 2)
			node.polygon = PackedVector2Array([center+Vector2(-length*.5,-width),center+Vector2(length*.5,-width*.6),center+Vector2(length*.5,width*.6),center+Vector2(-length*.5,width)])
			var marker := _ship.get_node_or_null("MissileLaunch%d" % i) as Marker2D
			if marker: marker.position = (center+Vector2(length*.5,0))*Vector2(-1 if _ship is Player else 1,1)


func _set_polygon_color(node: Node2D, color: Color) -> void:
	## Sets color on the node itself if Polygon2D, or first Polygon2D child
	if node is Polygon2D:
		(node as Polygon2D).color = color
		return
	for child in node.get_children():
		if child is Polygon2D:
			(child as Polygon2D).color = color
			return


func _style_weapon(node: Node2D, slot: int, weapon: WeaponData, accent: Color) -> void:
	if not node is Polygon2D or not has_meta("hull_half_size"): return
	var extent: Vector2 = get_meta("hull_half_size")
	var size_factor: float = [1.0, 1.6, 2.4][clampi(int(weapon.equip_size), 0, 2)]
	var length: float = minf(extent.x * 0.36, 4.0 * size_factor)
	var width: float = minf(extent.y * 0.16, 0.65 * size_factor)
	var mining: bool = str(weapon.id).contains("mining")
	var cannon: bool = str(weapon.id).contains("cannon") and not str(weapon.id).contains("autocannon")
	if cannon: width *= 1.25
	var side: float = -1.0 if slot % 2 == 0 else 1.0
	var row: int = slot / 2
	var anchor := _find_hull_mount(length * .225, width, side, row)
	var tip := anchor + Vector2(length * .775, 0)
	var rear := tip.x - length
	node.polygon = PackedVector2Array([Vector2(rear, tip.y-width), Vector2(rear+length*.45, tip.y-width), Vector2(rear+length*.6,tip.y-width*.45), Vector2(tip.x,tip.y-width*.45), Vector2(tip.x,tip.y+width*.45),Vector2(rear+length*.6,tip.y+width*.45),Vector2(rear+length*.45,tip.y+width),Vector2(rear,tip.y+width)])
	node.color = Color("9cabb7") if weapon.weapon_type == GlobalEnums.WeaponType.BALLISTIC else Color("557c8b")
	for child in node.get_children():
		node.remove_child(child)
		child.queue_free()
	var inlay := Line2D.new()
	inlay.points = PackedVector2Array([Vector2(rear+length*.16,tip.y),Vector2(tip.x,tip.y)])
	inlay.width = width * 0.55
	inlay.default_color = accent
	node.add_child(inlay)
	if str(weapon.id).contains("gatling"):
		for offset in [-0.55, 0.55]:
			var barrel := Line2D.new()
			barrel.points = PackedVector2Array([Vector2(rear+length*.4, tip.y+offset*width),Vector2(tip.x,tip.y+offset*width)])
			barrel.width = width * .3
			barrel.default_color = Color("c1ced4")
			node.add_child(barrel)
	var marker := _ship.get_node_or_null("Muzzle%d" % slot) as Marker2D
	if marker: marker.position = tip * Vector2(-1 if _ship is Player else 1, 1)


func _find_hull_mount(half_length: float, half_width: float, side: float, row: int) -> Vector2:
	var art := _ship.get_node_or_null("HullArt") as Node2D
	if not art or art.get_child_count() == 0: return Vector2.ZERO
	var hull: PackedVector2Array = art.get_child(0).polygon
	# Work in the unmirrored ship coordinates used by all weapon geometry.
	for i in hull.size(): hull[i] *= Vector2(absf(art.scale.x), absf(art.scale.y))
	var extent: Vector2 = get_meta("hull_half_size")
	for band in 9:
		var y: float = side * extent.y * maxf(.08, .64-row*.14-band*.06)
		for step in 81:
			var center := Vector2(extent.x*(.75-step*.018)-row*half_length*2.5,y)
			var fits: bool = true
			for corner in [Vector2(-half_length,-half_width),Vector2(half_length,-half_width),Vector2(half_length,half_width),Vector2(-half_length,half_width)]:
				if not Geometry2D.is_point_in_polygon(center+corner*1.08,hull):
					fits = false
					break
			if fits: return center
	return Vector2.ZERO
