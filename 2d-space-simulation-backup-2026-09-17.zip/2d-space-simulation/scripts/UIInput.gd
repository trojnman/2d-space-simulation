extends RefCounted
static func typing(view:Viewport)->bool:
 var focus=view.gui_get_focus_owner()
 if focus is LineEdit or focus is TextEdit:return true
 for window in view.get_tree().get_nodes_in_group("ui_input_windows"):
  if not window.visible:continue
  # Window focus lives in its own viewport, even when embedded in the game.
  var field=window.gui_get_focus_owner()
  if field is LineEdit or field is TextEdit or window.exclusive or window is PopupMenu:return true
 return false
static func over_menu(view:Viewport)->bool:
 for window in view.get_tree().get_nodes_in_group("ui_input_windows"):
  if window.visible:return true
 var control=view.gui_get_hovered_control()
 return control!=null and control.mouse_filter!=Control.MOUSE_FILTER_IGNORE
