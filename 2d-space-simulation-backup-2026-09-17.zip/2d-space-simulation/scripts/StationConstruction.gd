extends RefCounted
## Complete-station construction: paid prefabs assembled and deployed near a yard.
const BUILD_SECONDS := 3.0 # Temporary playtest timing, matching ship manufacturing.
const BLUEPRINTS := [&"sol_prime_manufacturing", &"sol_prime_trade", &"sol_prime_military", &"sol_prime_shipyard", &"sol_prime_capital_shipyard"]

static func sector_of(node: Node) -> SectorInstance:
	var cursor: Node = node
	while cursor and not cursor is SectorInstance: cursor = cursor.get_parent()
	return cursor as SectorInstance

static func labor_cost(blueprint: StationData) -> int:
	var total := 0
	for id in StationData.BUILD_COSTS.get(blueprint.station_type, {}):
		if GameData.items.has(id): total += int(GameData.items[id].base_price * StationData.BUILD_COSTS[blueprint.station_type][id])
	return maxi(1000, int(total * 0.05))

static func problem(yard: StationInstance, blueprint_id: StringName, owner: StringName = &"") -> String:
	if not is_instance_valid(yard) or yard._is_destroyed: return "Yard unavailable"
	if not yard.station_data or yard.station_data.station_type != StationData.TYPE_SHIPYARD: return "Requires shipyard"
	if not GameData.stations.has(blueprint_id) or not BLUEPRINTS.has(blueprint_id): return "Unknown blueprint"
	if not yard._station_build_queue.is_empty(): return "Station build already active"
	var sector := sector_of(yard)
	if not sector: return "Sector unavailable"
	var blueprint: StationData = GameData.stations[blueprint_id]
	var faction: StringName = yard.faction_id if owner == &"" else owner
	if owner == &"player" and not yard.can_share_station_info(): return "Access denied"
	var restriction := limit_problem(sector, blueprint, faction)
	if restriction != "": return restriction
	if owner == &"player":
		if PlayerState.credits < personal_price(yard, blueprint): return "Your funds insufficient"
	elif yard.station_credits < labor_cost(blueprint): return "Faction funds insufficient"
	for id in StationData.BUILD_COSTS[blueprint.station_type]:
		if yard.inventory.get_amount(id) < int(StationData.BUILD_COSTS[blueprint.station_type][id]): return "Needs construction materials"
	if owner != &"player" and deployment_position(yard) == Vector2.INF: return "No clear deployment site"
	return ""

static func deployment_position(yard: StationInstance) -> Vector2:
	var sector := sector_of(yard)
	if not sector: return Vector2.INF
	for ring in [1600.0, 2600.0, 3600.0]:
		for step in 12:
			var point: Vector2 = yard.position + Vector2.from_angle(step * TAU / 12.0) * ring
			if point.length() > SectorInstance.HALF_SIZE * 0.7: continue
			var clear := true
			for station in SectorManager.get_sector_stations(sector):
				if point.distance_to(station.position) < 1000: clear = false
				for job in station._station_build_queue:
					if point.distance_to(job.position) < 1000: clear = false
			for node in sector.find_children("*", "", true, false):
				if node is AsteroidInstance and not node._is_destroyed and point.distance_to(node.position) < 700: clear = false
			if clear: return point
	return Vector2.INF

static func queue(yard: StationInstance, blueprint_id: StringName, owner: StringName = &"", selected_site: Vector2 = Vector2.INF) -> bool:
	if problem(yard, blueprint_id, owner) != "": return false
	if owner == &"player" and not site_clear(sector_of(yard), selected_site): return false
	var blueprint: StationData = GameData.stations[blueprint_id]
	var site := selected_site if owner == &"player" else deployment_position(yard)
	var labor := labor_cost(blueprint)
	for id in StationData.BUILD_COSTS[blueprint.station_type]: yard.inventory.remove_item(id, StationData.BUILD_COSTS[blueprint.station_type][id])
	if owner == &"player":
		var price := personal_price(yard, blueprint)
		PlayerState.spend_credits(price)
		yard._change_station_credits(price-labor, "Player station materials: " + blueprint.display_name, "Player")
	else:
		yard._change_station_credits(-labor, "Station construction: " + blueprint.display_name, "Workers")
	FactionManager.civilian_credits += labor
	yard._station_build_queue.append({"claim_faction": PlayerState.joined_faction if owner == &"player" and blueprint.station_type == StationData.TYPE_DEFENSE_PLATFORM and PlayerState.joined_faction != &"" else (yard.faction_id if owner == &"" else owner), "owner": yard.faction_id if owner == &"" else owner, "blueprint": blueprint_id, "position": site, "remaining": BUILD_SECONDS, "total": BUILD_SECONDS, "id": StringName("built_" + str(Time.get_unix_time_from_system()).replace(".", "_") + "_" + str(randi()))})
	yard.requested_station_blueprint = &""
	return true

static func tick(yard: StationInstance, delta: float) -> void:
	for i in range(yard._station_build_queue.size()-1,-1,-1):
		var job: Dictionary = yard._station_build_queue[i]
		job.remaining -= delta
		if job.remaining > 0: continue
		var sector := sector_of(yard)
		if not sector: continue
		var station: StationInstance = load("res://scenes/Station.tscn").instantiate()
		station.blueprint_id = job.blueprint
		station.runtime_station_id = job.id
		station.constructed = true
		station.station_data = GameData.stations[job.blueprint].duplicate(true)
		station.station_data.id = job.id
		station.station_data.display_name = station.station_data.get_yard_class_name() if station.station_data.station_type == StationData.TYPE_SHIPYARD else str(station.station_data.station_type).capitalize() + " Station"
		station.faction_id = job.get("owner", yard.faction_id)
		station.claim_faction_id = job.get("claim_faction", station.faction_id)
		station._treasury_linked = FactionManager._faction_state.has(station.faction_id)
		station._local_credits = 0
		station.position = job.position
		station.initialize_runtime()
		station.add_to_group("stations")
		FactionManager.register_station(station)
		sector.get_node("Stations").add_child(station)
		if station.faction_id == &"player" and station.station_data.station_type == StationData.TYPE_HEADQUARTERS: PlayerState.establish_faction(station)
		var spawner := StationSpawner.new()
		spawner._station = station
		spawner.max_ships = station.station_data.max_ships
		spawner._initial_ships_spawned = spawner.max_ships # No free starting fleet.
		station.add_child(spawner)
		yard._station_build_queue.remove_at(i)


static func personal_price(yard: StationInstance, blueprint: StationData) -> int:
	var total := labor_cost(blueprint)
	if yard.faction_id != &"player":
		for id in StationData.BUILD_COSTS[blueprint.station_type]: total += yard.get_sell_price(id) * int(StationData.BUILD_COSTS[blueprint.station_type][id])
	return total

static func site_clear(sector: SectorInstance, point: Vector2) -> bool:
	if not sector or not point.is_finite() or point.length() > SectorInstance.HALF_SIZE * 0.85: return false
	for station in SectorManager.get_sector_stations(sector):
		if point.distance_to(station.position) < 1000: return false
		for job in station._station_build_queue:
			if point.distance_to(job.position) < 1000: return false
	for node in sector.find_children("*", "", true, false):
		if node is AsteroidInstance and not node._is_destroyed and point.distance_to(node.position) < 700: return false
		if node is JumpGate and point.distance_to(node.position) < 1000: return false
		if node.get_script() == load("res://scripts/ConstructionScaffold.gd") and point.distance_to(node.position)<1000:return false
	return true


static func _same_category(a: StationData, b: StationData) -> bool:
	return a.station_type == b.station_type and (a.station_type != StationData.TYPE_SHIPYARD or a.capital_yard == b.capital_yard)

static func limit_problem(sector: SectorInstance, blueprint: StationData, faction: StringName) -> String:
	var kind := blueprint.station_type
	if kind in [StationData.TYPE_SHIPYARD, StationData.TYPE_MILITARY, StationData.TYPE_DEFENSE_PLATFORM]:
		var member_defense: bool = faction == &"player" and kind == StationData.TYPE_DEFENSE_PLATFORM and PlayerState.joined_faction != &"" and sector.sector_data.controlling_faction_id == PlayerState.joined_faction
		if not member_defense:
			if faction == &"" or sector.sector_data.controlling_faction_id != faction:
				return "Only the sector owner can build this station type"
			if faction == &"player" and (not PlayerState.founded_faction or PlayerState.joined_faction != &""):
				return "Requires your own independent faction, founded by a headquarters"
	var global_limit := kind == StationData.TYPE_HEADQUARTERS
	var per_faction := global_limit or kind in [StationData.TYPE_TRADE, StationData.TYPE_MANUFACTURING]
	var cap: int = 1 if global_limit or kind in [StationData.TYPE_SHIPYARD, &"claim_beacon"] else int(StationData.SECTOR_CAPS.get(kind, 2))
	var count := 0
	var sectors: Array = SectorManager._visited_sectors.values() if global_limit else [sector]
	if not sectors.has(sector): sectors.append(sector)
	for region in sectors:
		for station in SectorManager.get_sector_stations(region):
			if station._is_destroyed: continue
			if _same_category(station.station_data, blueprint) and (not per_faction or station.faction_id == faction): count += 1
			for job in station._station_build_queue:
				var data: StationData = GameData.stations.get(job.blueprint)
				if data and _same_category(data, blueprint) and (not per_faction or job.get("owner",station.faction_id) == faction): count += 1
	for region in sectors:
		for scaffold in region.find_children("*","",true,false):
			if scaffold.get_script()==load("res://scripts/ConstructionScaffold.gd") and not scaffold.completed:
				if _same_category(GameData.stations[scaffold.blueprint],blueprint) and (not per_faction or scaffold.beneficiary==faction):count+=1
	if global_limit:
		# Unvisited sectors still contain their authored starting stations.
		for id in GameData.sectors:
			if SectorManager._visited_sectors.has(id) or GameData.sectors[id] == sector.sector_data: continue
			for station_id in GameData.sectors[id].starting_stations:
				var data: StationData = GameData.stations.get(station_id)
				if data and data.faction_id == faction and _same_category(data,blueprint): count += 1
	if count >= cap:
		return "Faction command center already exists or is queued" if global_limit else "Station limit reached (%d%s)" % [cap, " per faction" if per_faction else " per sector"]
	return ""


const KIT_BLUEPRINTS := [&"player_headquarters", &"claim_beacon", &"defense_platform", &"sol_prime_manufacturing", &"sol_prime_trade", &"sol_prime_military", &"sol_prime_shipyard", &"sol_prime_capital_shipyard"]
static func buy_kit(yard: StationInstance, player: Player) -> bool:
	if not is_instance_valid(yard) or yard._is_destroyed or not yard.can_share_station_info() or yard.station_data.station_type != &"shipyard": return false
	if player.global_position.distance_to(yard.global_position)>yard.get_docking_range() and not player._is_docked:return false
	if not yard.inventory.has_item(&"hull_parts",1) or not yard.inventory.has_item(&"electronics",1) or not PlayerState.can_afford(1000):return false
	if not player.inventory.add_item(&"construction_kit",1,GameData.items):return false
	yard.inventory.remove_item(&"hull_parts",1)
	yard.inventory.remove_item(&"electronics",1)
	PlayerState.spend_credits(1000)
	yard._change_station_credits(1000,"Construction scaffold kit","Player")
	return true
static func kit_problem(sector: SectorInstance, id: StringName) -> String:
	if not sector or not KIT_BLUEPRINTS.has(id):return "Unknown blueprint"
	var data: StationData=GameData.stations[id]
	var owner: StringName=PlayerState.joined_faction if PlayerState.joined_faction!=&"" else &"player"
	if data.station_type==&"headquarters":
		for scaffold in sector.find_children("*","",true,false):
			if scaffold.get_script()==load("res://scripts/ConstructionScaffold.gd") and GameData.stations[scaffold.blueprint].station_type in [&"claim_beacon",&"headquarters"]:return "Claim construction already reserved"
		owner=&"player"
		if sector.sector_data.controlling_faction_id not in [&"",&"player"]:return "Found your headquarters in an unclaimed sector"
	elif data.station_type==&"claim_beacon":
		var problem:=PlayerState.beacon_claim_problem(sector)
		if problem!="":return problem
		for scaffold in sector.find_children("*","",true,false):
			if scaffold.get_script()==load("res://scripts/ConstructionScaffold.gd") and GameData.stations[scaffold.blueprint].station_type in [&"claim_beacon",&"headquarters"]:return "Claim construction already reserved"
		return ""
	elif PlayerState.joined_faction!=&"" and data.station_type in [&"military",&"shipyard"]:return "Members cannot build military stations or shipyards"
	return limit_problem(sector,data,owner)
static func deploy_kit(player: Player, id: StringName, point: Vector2) -> bool:
	var sector: SectorInstance=SectorManager.current_sector
	if player._is_docked or player._is_destroyed or kit_problem(sector,id)!="" or not site_clear(sector,point):return false
	if player.global_position.distance_to(point)>350 or not player.inventory.has_item(&"construction_kit",1):return false
	var scaffold=load("res://scripts/ConstructionScaffold.gd").new()
	scaffold.blueprint=id
	scaffold.beneficiary=PlayerState.joined_faction if PlayerState.joined_faction!=&"" else &"player"
	if GameData.stations[id].station_type==&"headquarters":scaffold.beneficiary=&"player"
	scaffold.position=point
	player.inventory.remove_item(&"construction_kit",1)
	sector.add_child(scaffold)
	return true
