extends ShipInstance

## Fighter — Small aggressive combat dart. 20px long, 10px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(10,0),Vector2(6,-3),Vector2(2,-4),Vector2(-2,-5),Vector2(-6,-5),Vector2(-9,-3),Vector2(-8,0),Vector2(-9,3),Vector2(-6,5),Vector2(-2,5),Vector2(2,4),Vector2(6,3)])
	hull.color   = Color(0.22,0.42,0.72)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(0,-3),Vector2(-4,-5),Vector2(-9,-3),Vector2(-5,-2)])
	detail0.color   = Color(0.12,0.25,0.5)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(0,3),Vector2(-4,5),Vector2(-9,3),Vector2(-5,2)])
	detail1.color   = Color(0.12,0.25,0.5)
	add_child(detail1)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(7,0),Vector2(5,-2),Vector2(3,0),Vector2(5,2)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-9, -1.4),
		Vector2(-13.2, 0.0),
		Vector2(-9, 1.4),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(10,0),Vector2(2,-4),Vector2(-9,-3),Vector2(-8,0),Vector2(-9,3),Vector2(2,4)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(12,0),Vector2(8,-7),Vector2(0,-11),Vector2(-10,-8),Vector2(-13,0),Vector2(-10,8),Vector2(0,11),Vector2(8,7)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(-2.0, -5.6),
		Vector2(10.0, -5.6),
		Vector2(10.0, -4.4),
		Vector2(-2.0, -4.4),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(10.0, -5.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(-2.0, 4.4),
		Vector2(10.0, 4.4),
		Vector2(10.0, 5.6),
		Vector2(-2.0, 5.6),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(10.0, 5.0)
	add_child(m1)

	## Missile pod 0 — always visible
	var mpod0 := Polygon2D.new()
	mpod0.polygon = PackedVector2Array([
		Vector2(-1.0,       -1.2),
		Vector2(4.0, -1.2),
		Vector2(4.0, 1.2),
		Vector2(-1.0,       1.2),
	])
	mpod0.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod0)
	missile_nodes.append(mpod0)

	var ml0 := Marker2D.new()
	ml0.name     = "MissileLaunch0"
	ml0.position = Vector2(4.0, 0.0)
	add_child(ml0)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"fighter", vc)
