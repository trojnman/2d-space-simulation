extends RefCounted
## Shared, hand-authored vector art. Existing equipment hardpoints remain functional.
static var _profiles: Dictionary = {}
static func profiles() -> Dictionary:
	if _profiles.is_empty():
		_profiles = JSON.parse_string(FileAccess.get_file_as_string("res://data/ship_hull_art.json"))
	return _profiles

static func apply(ship: ShipInstance, id: StringName, controller: ShipVisualController) -> void:
	var profile: Dictionary = profiles().get(str(id), {})
	if profile.is_empty(): return
	for child in ship.get_children():
		if child is Polygon2D and child != controller.shield_visual and not controller.weapon_visuals.has(child) and not controller.missile_visuals.has(child):
			ship.remove_child(child)
			child.free()
	controller.set_meta("hull_half_size", Vector2(profile["half_size"][0], profile["half_size"][1]))
	var art := Node2D.new()
	art.name = "HullArt"
	art.set_meta("design_id", id)
	art.z_index = 1
	ship.add_child(art)
	for layer in profile["layers"]:
		var polygon := Polygon2D.new()
		var points := PackedVector2Array()
		for point in layer["points"]: points.append(Vector2(point[0], point[1]))
		polygon.polygon = points
		polygon.color = Color(layer["color"])
		art.add_child(polygon)
	# The shield sits behind the hull rather than washing out all its details.
	if is_instance_valid(controller.shield_visual): controller.shield_visual.z_index = 0

	for node in controller.weapon_visuals + controller.missile_visuals:
		if is_instance_valid(node): node.z_index = 2

	var size_factor: float = 1.0
	if str(id).begins_with("medium_"): size_factor = 1.25
	elif str(id).begins_with("heavy_") or str(id).begins_with("large_"): size_factor = 1.5
	art.scale = Vector2.ONE * size_factor
	controller.set_meta("hull_half_size", controller.get_meta("hull_half_size") * size_factor)
	for child in ship.get_children():
		if child is Polygon2D or child is CollisionPolygon2D:
			var points: PackedVector2Array = child.polygon
			for i in points.size(): points[i] *= size_factor
			child.polygon = points
		elif child is Marker2D:
			child.position *= size_factor
	controller.refresh_equipment()
