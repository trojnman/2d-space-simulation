extends CanvasLayer

## Read-only overview of production in the currently loaded sector.
var _panel: PanelContainer
var _text: RichTextLabel
var _timer: float = 0.0

func _ready() -> void:
	layer = 20
	_panel = PanelContainer.new()
	_panel.theme = preload("res://scripts/ConsoleTheme.gd").build()
	_panel.position = Vector2(20, 70)
	_panel.size = Vector2(520, 540)
	_panel.visible = false
	add_child(_panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 16)
	_panel.add_child(margin)
	var column := VBoxContainer.new()
	margin.add_child(column)
	var title := Label.new()
	title.text = "SECTOR ECONOMY   ·   B to close"
	title.add_theme_font_size_override("font_size", 20)
	column.add_child(title)
	_text = RichTextLabel.new()
	_text.custom_minimum_size = Vector2(480, 450)
	_text.size_flags_vertical = Control.SIZE_EXPAND_FILL
	_text.bbcode_enabled = true
	_text.add_theme_font_size_override("normal_font_size", 16)
	column.add_child(_text)

func _unhandled_input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_B:
		_panel.visible = not _panel.visible
		_refresh()
		get_viewport().set_input_as_handled()

func _process(delta: float) -> void:
	if not _panel.visible: return
	_timer += delta
	if _timer >= 1.0:
		_timer = 0.0
		_refresh()

func _refresh() -> void:
	var lines: PackedStringArray = []
	var sector: SectorData = SectorManager.get_current_sector_data()
	lines.append("[b]%s[/b]" % (sector.display_name if sector else "No sector"))
	for faction_id in GameData.factions:
		if not PlayerState.is_friendly_to_player(faction_id): continue
		if FactionManager.get_faction_stations(faction_id).any(func(s): return is_instance_valid(s) and s.is_inside_tree()):
			lines.append("%s treasury: $%d" % [GameData.factions[faction_id].display_name, FactionManager.get_faction_credits(faction_id)])
	lines.append("Ships in sector: %d\n" % get_tree().get_nodes_in_group("ships").filter(func(s): return SensorSystem.has_local_contact(s.global_position)).size())
	for station in get_tree().get_nodes_in_group("stations"):
		if not station is StationInstance or not station.station_data: continue
		if station._is_destroyed or not SensorSystem.has_local_contact(station.global_position): continue
		lines.append("[b]%s[/b]" % station.station_data.display_name)
		if not station.can_share_station_info():
			lines.append("Access denied — hostile faction\n")
			continue
		if not station.can_share_internal_info():
			lines.append("Neutral station — public market information only")
			for id in GameData.items:
				if station._station_sells_item(id) or station._station_buys_item(id):
					lines.append("%s: %d" % [GameData.items[id].display_name, station.inventory.get_amount(id)])
			lines.append("")
			continue
		var queue: Array[Dictionary] = station.get_manufacture_queue()
		if queue.is_empty():
			var report: Array[Dictionary] = station.get_production_report()
			var waiting: int = report.filter(func(entry): return entry["state"] == "Waiting for supplies").size()
			var ready: int = report.filter(func(entry): return entry["state"] in ["Ready", "Ready to order"]).size()
			lines.append("Production: %d recipes ready, %d waiting for materials/funds" % [ready, waiting] if not report.is_empty() else "No manufacturing facilities")
			if station.requested_supply_ship != &"":
				for entry in report:
					if entry["id"] == station.requested_supply_ship:
						lines.append("Supply request: %s — %s" % [entry["name"], entry["detail"]])
		for job in queue:
			var output: StringName = job["recipe"].get("output_id", &"")
			var output_name: String = str(output).replace("_", " ").capitalize()
			lines.append("  %s · %ds remaining" % [output_name, ceili(maxf(0.0, job["time_remaining"]))])
		var stock: PackedStringArray = []
		for item_id in station.inventory.get_all_items():
			stock.append("%s: %d" % [str(item_id).replace("_", " "), station.inventory.get_amount(item_id)])
		lines.append("Stock: " + (", ".join(stock) if not stock.is_empty() else "empty"))
		lines.append("")
	_text.text = "\n".join(lines)
