class_name SectorMap
extends CanvasLayer

enum MapMode { SECTOR, GALAXY }

const SECTOR_SCALE : float = 0.002
const GALAXY_SCALE : float = 2.0

var _station_inspector: Control

var _mode        : MapMode = MapMode.SECTOR
var _waypoints   : Array[Dictionary] = []
var _dragging    : bool    = false
var _cam_offset  : Vector2 = Vector2.ZERO
var _zoom        : float   = 1.0
var _zoom_target : float   = 1.0

const ZOOM_MIN : float = 0.1
const ZOOM_MAX : float = 5.0

@onready var sector_name_lbl : Label         = $UI/Header/SectorName
@onready var galaxy_btn      : Button        = $UI/Header/GalaxyButton
@onready var close_btn       : Button        = $UI/Header/CloseButton
@onready var waypoint_list   : VBoxContainer = $UI/WaypointList
@onready var instructions    : Label         = $UI/Instructions
@onready var draw_node       : Node2D        = $DrawNode


func _ready() -> void:
	hide()
	var inspection_layer := CanvasLayer.new()
	inspection_layer.layer = 40
	add_child(inspection_layer)
	_station_inspector = preload("res://scripts/StationIdentification.gd").new()
	_station_inspector.map_inspection = true
	inspection_layer.add_child(_station_inspector)
	_station_inspector.hide()
	close_btn.pressed.connect(_close)
	galaxy_btn.pressed.connect(_toggle_galaxy)


func open() -> void:
	_mode        = MapMode.SECTOR
	_cam_offset  = Vector2.ZERO
	_zoom        = 1.0
	_zoom_target = 1.0
	galaxy_btn.text = "Galaxy View"
	_update_header()
	_update_waypoint_list()
	get_tree().paused = true
	show()
	draw_node.queue_redraw()


func _close() -> void:
	_station_inspector.selected = null
	_station_inspector.hide()
	get_tree().paused = false
	hide()


func _toggle_galaxy() -> void:
	_station_inspector.selected = null
	_mode = MapMode.GALAXY if _mode == MapMode.SECTOR else MapMode.SECTOR
	galaxy_btn.text = "Sector View" if _mode == MapMode.GALAXY else "Galaxy View"
	_cam_offset  = Vector2.ZERO
	_zoom        = 1.0
	_zoom_target = 1.0
	_update_header()
	draw_node.queue_redraw()


func _update_header() -> void:
	var sd := SectorManager.get_current_sector_data()
	if _mode == MapMode.SECTOR:
		sector_name_lbl.text = sd.display_name if sd else "Unknown Sector"
		instructions.text = "Click station: inspect  |  Empty space: waypoint  |  Right click: remove  |  Scroll: zoom  |  Middle drag: pan"
	else:
		sector_name_lbl.text = "Galaxy Map"
		instructions.text = "Click a sector to travel  |  Scroll: zoom  |  Middle drag: pan"


func _unhandled_input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if not visible: return
	if event.is_action_pressed("map") or event.is_action_pressed("ui_cancel"):
		_close()
		return
	if event is InputEventMouseButton:
		if event.pressed:
			match event.button_index:
				MOUSE_BUTTON_WHEEL_UP:
					_zoom_target = clampf(_zoom_target * 1.15, ZOOM_MIN, ZOOM_MAX)
					draw_node.queue_redraw()
				MOUSE_BUTTON_WHEEL_DOWN:
					_zoom_target = clampf(_zoom_target * 0.87, ZOOM_MIN, ZOOM_MAX)
					draw_node.queue_redraw()
				MOUSE_BUTTON_MIDDLE:
					_dragging = true
				MOUSE_BUTTON_LEFT:
					_handle_left_click(event.position)
				MOUSE_BUTTON_RIGHT:
					_handle_right_click(event.position)
		else:
			if event.button_index == MOUSE_BUTTON_MIDDLE:
				_dragging = false
	if event is InputEventMouseMotion and _dragging:
		_cam_offset += event.relative / _zoom
		draw_node.queue_redraw()


func _process(delta: float) -> void:
	if not visible: return
	_zoom = lerpf(_zoom, _zoom_target, 10.0 * delta)
	draw_node.queue_redraw()


func _handle_left_click(screen_pos: Vector2) -> void:
	if _mode == MapMode.GALAXY:
		for sid in GameData.sectors:
			var sd   : SectorData = GameData.sectors[sid]
			var spos := _galaxy_to_screen(sd.map_position)
			if screen_pos.distance_to(spos) < 20.0:
				if sd.id != SectorManager.current_sector_id:
					_travel_to_sector(sd.id)
				return
	else:
		var station: StationInstance = _station_at_screen(screen_pos)
		if station:
			_station_inspector.selected = station
			_station_inspector._displayed = station
			_station_inspector._active_tab = 0
			_station_inspector._refresh_card(true)
			_station_inspector.show()
			return
		var world_pos := _screen_to_world(screen_pos)
		if SensorSystem.fog.is_revealed(world_pos):
			_add_waypoint(world_pos, "WP %d" % (_waypoints.size() + 1), Color(1.0, 0.9, 0.2))
			draw_node.queue_redraw()


func _handle_right_click(screen_pos: Vector2) -> void:
	if _mode != MapMode.SECTOR: return
	var best_idx  : int   = -1
	var best_dist : float = 20.0
	for i in _waypoints.size():
		var wp_screen := _world_to_screen(_waypoints[i]["pos"])
		if screen_pos.distance_to(wp_screen) < best_dist:
			best_dist = screen_pos.distance_to(wp_screen)
			best_idx  = i
	if best_idx >= 0:
		_waypoints.remove_at(best_idx)
		_update_waypoint_list()
		draw_node.queue_redraw()


func _travel_to_sector(sector_id: StringName) -> void:
	_close()
	SectorManager.load_sector(sector_id, Vector2.ZERO)


func _add_waypoint(world_pos: Vector2, label: String, color: Color) -> void:
	_waypoints.append({"pos": world_pos, "label": label, "color": color})
	_update_waypoint_list()


func _update_waypoint_list() -> void:
	for child in waypoint_list.get_children():
		child.queue_free()
	var title := Label.new()
	title.text = "Waypoints"
	title.add_theme_font_size_override("font_size", 14)
	waypoint_list.add_child(title)
	for i in _waypoints.size():
		var wp  : Dictionary = _waypoints[i]
		var row := HBoxContainer.new()
		var lbl := Label.new()
		lbl.text = wp["label"]
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		row.add_child(lbl)
		var del_btn := Button.new()
		del_btn.text = "X"
		del_btn.pressed.connect(_remove_waypoint.bind(i))
		row.add_child(del_btn)
		waypoint_list.add_child(row)


func _remove_waypoint(idx: int) -> void:
	if idx < _waypoints.size():
		_waypoints.remove_at(idx)
	_update_waypoint_list()
	draw_node.queue_redraw()


func clear_waypoints() -> void:
	_waypoints.clear()
	_update_waypoint_list()
	draw_node.queue_redraw()


func _get_center() -> Vector2:
	return get_viewport().get_visible_rect().size / 2.0


func _world_to_screen(world_pos: Vector2) -> Vector2:
	return _get_center() + (world_pos * SECTOR_SCALE + _cam_offset) * _zoom


func _screen_to_world(screen_pos: Vector2) -> Vector2:
	return ((screen_pos - _get_center()) / _zoom - _cam_offset) / SECTOR_SCALE


func _galaxy_to_screen(map_pos: Vector2) -> Vector2:
	return _get_center() + (map_pos * GALAXY_SCALE + _cam_offset) * _zoom


func _draw_map() -> void:
	if _mode == MapMode.SECTOR:
		_draw_sector_view()
	else:
		_draw_galaxy_view()


func _draw_sector_view() -> void:
	var center  := _get_center()
	var vp_size := get_viewport().get_visible_rect().size
	var font    := ThemeDB.fallback_font

	## Full screen dark background
	draw_node.draw_rect(Rect2(Vector2.ZERO, vp_size), Color(0.03, 0.04, 0.08, 1.0), true)
	_draw_grid(vp_size)

	var half : float   = SectorInstance.HALF_SIZE * SECTOR_SCALE * _zoom
	var tl   : Vector2 = center + (_cam_offset * _zoom) + Vector2(-half, -half)
	draw_node.draw_rect(Rect2(tl, Vector2(half * 2.0, half * 2.0)), Color(0.2, 0.2, 0.4, 0.5), false, 1.5)

	var circles := SensorSystem.get_sensor_circles()
	for c in circles:
		var spos    := _world_to_screen(c["center"])
		var sradius : float = c["radius"] * SECTOR_SCALE * _zoom
		draw_node.draw_circle(spos, sradius, Color(0.1, 0.15, 0.25, 0.35))
		draw_node.draw_arc(spos, sradius, 0, TAU, 64, Color(0.2, 0.4, 0.6, 0.4), 1.0)

	var contacts := _map_contacts()
	for contact in contacts:
		_draw_contact(contact, font)


	for sat in get_tree().get_nodes_in_group("satellites"):
		if sat is Node2D:
			var spos := _world_to_screen(sat.global_position)
			draw_node.draw_circle(spos, 5.0, Color(0.4, 0.9, 1.0))
			draw_node.draw_string(font, spos + Vector2(7, 4), "SAT",
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.4, 0.9, 1.0))

	var player := get_tree().get_first_node_in_group("player") as Node2D
	if player:
		var ppos := _world_to_screen(player.global_position)
		draw_node.draw_circle(ppos, 6.0, Color(0.2, 1.0, 0.4))
		var dir  := Vector2.RIGHT.rotated(player.rotation) * 14.0
		draw_node.draw_line(ppos, ppos + dir, Color(0.2, 1.0, 0.4), 2.0)
		draw_node.draw_string(font, ppos + Vector2(10, 4), "YOU",
			HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.2, 1.0, 0.4))

	for wp in _waypoints:
		var wpos  := _world_to_screen(wp["pos"])
		var color : Color = wp["color"]
		var size  : float = 7.0
		var pts   := PackedVector2Array([
			wpos + Vector2(0, -size), wpos + Vector2(size, 0),
			wpos + Vector2(0, size),  wpos + Vector2(-size, 0),
		])
		draw_node.draw_colored_polygon(pts, color)
		draw_node.draw_string(font, wpos + Vector2(10, 4), wp["label"],
			HORIZONTAL_ALIGNMENT_LEFT, -1, 11, color)


func _draw_contact(contact: Dictionary, font: Font) -> void:
	var ctype      : String    = contact.get("type", "")
	var pos        : Vector2   = contact.get("pos", Vector2.ZERO)
	var live       : bool      = contact.get("live", false)
	var faction_id : StringName = contact.get("faction_id", &"")
	var spos       := _world_to_screen(pos)
	var alpha      : float     = 1.0 if live else 0.35

	match ctype:
		"ship":
			var color := _get_faction_color(faction_id, alpha)
			draw_node.draw_circle(spos, 4.0, color)
			if not PlayerState.is_friendly_to_player(faction_id):
				draw_node.draw_line(spos + Vector2(-3, -3), spos + Vector2(3, 3), color, 1.5)
				draw_node.draw_line(spos + Vector2(3, -3), spos + Vector2(-3, 3), color, 1.5)
		"station":
			var color : Color = _get_faction_color(faction_id, alpha)
			var size  : float = 4.0
			draw_node.draw_rect(Rect2(spos - Vector2(size/2, size/2), Vector2(size, size)), color, false, 1.0)
			draw_node.draw_rect(Rect2(spos - Vector2(size/2-1, size/2-1), Vector2(size-2, size-2)),
				Color(color.r, color.g, color.b, 0.3 * alpha), true)
			var node = contact.get("node")
			if is_instance_valid(node) and node is StationInstance and node.station_data:
				draw_node.draw_string(font, spos + Vector2(5, 2), ("[LR] " if contact.get("long_range", false) else "") + node.station_data.display_name,
					HORIZONTAL_ALIGNMENT_LEFT, -1, 6, Color(0.9, 0.8, 0.5, alpha))
		"asteroids":
			draw_node.draw_circle(spos, 2.5, Color(0.55, 0.5, 0.45, alpha))
		"derelicts":
			draw_node.draw_circle(spos, 4.0, Color(0.5, 0.5, 0.6, alpha))
			draw_node.draw_string(font, spos + Vector2(6, 3), "Derelict",
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.6, 0.6, 0.7, alpha))
		"poi":
			var pts := PackedVector2Array([
				spos + Vector2(0, -6), spos + Vector2(6, 0),
				spos + Vector2(0, 6),  spos + Vector2(-6, 0),
			])
			draw_node.draw_colored_polygon(pts, Color(1.0, 0.9, 0.2, alpha))
		"hazards":
			draw_node.draw_circle(spos, 5.0, Color(0.8, 0.2, 0.2, alpha * 0.5))


func _draw_galaxy_view() -> void:
	var vp_size    := get_viewport().get_visible_rect().size
	var font       := ThemeDB.fallback_font
	var current_id := SectorManager.current_sector_id

	draw_node.draw_rect(Rect2(Vector2.ZERO, vp_size), Color(0.02, 0.03, 0.06, 1.0), true)

	for sid in GameData.sectors:
		var sd   : SectorData = GameData.sectors[sid]
		var from := _galaxy_to_screen(sd.map_position)
		for conn_id in sd.connected_sectors:
			var conn_sd : SectorData = GameData.get_sector(conn_id)
			if conn_sd:
				draw_node.draw_line(from, _galaxy_to_screen(conn_sd.map_position), Color(0.25, 0.25, 0.35), 1.0)

	for sid in GameData.sectors:
		var sd         : SectorData  = GameData.sectors[sid]
		var faction    : FactionData = GameData.get_faction(sd.controlling_faction_id)
		var color      : Color       = faction.color if faction else Color(0.5, 0.5, 0.5)
		var spos       := _galaxy_to_screen(sd.map_position)
		var is_current : bool        = sd.id == current_id
		var radius     : float       = 20.0 if is_current else 14.0

		if is_current:
			draw_node.draw_circle(spos, radius + 5.0, Color(color.r, color.g, color.b, 0.25))
		draw_node.draw_circle(spos, radius, color)
		draw_node.draw_arc(spos, radius, 0, TAU, 32, Color(1, 1, 1, 0.3), 1.0)
		draw_node.draw_string(font, spos + Vector2(-30, radius + 14), sd.display_name,
			HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(0.9, 0.9, 0.9))
		if faction:
			draw_node.draw_string(font, spos + Vector2(-30, radius + 26), faction.display_name,
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(color.r, color.g, color.b, 0.7))
		if is_current:
			draw_node.draw_string(font, spos + Vector2(-24, -radius - 8), "YOU ARE HERE",
				HORIZONTAL_ALIGNMENT_LEFT, -1, 10, Color(0.2, 1.0, 0.4))


func _draw_grid(vp_size: Vector2) -> void:
	var grid_world  : float = 10000.0
	var grid_screen : float = grid_world * SECTOR_SCALE * _zoom
	if grid_screen < 15.0: return
	var cx      := _get_center()
	var offset_x := fmod(_cam_offset.x * _zoom + cx.x, grid_screen)
	var offset_y := fmod(_cam_offset.y * _zoom + cx.y, grid_screen)
	var col      := Color(0.12, 0.14, 0.2, 0.5)
	var x := offset_x
	while x < vp_size.x:
		draw_node.draw_line(Vector2(x, 0), Vector2(x, vp_size.y), col, 0.5)
		x += grid_screen
	var y := offset_y
	while y < vp_size.y:
		draw_node.draw_line(Vector2(0, y), Vector2(vp_size.x, y), col, 0.5)
		y += grid_screen


func _get_faction_color(faction_id: StringName, alpha: float) -> Color:
	var faction : FactionData = GameData.get_faction(faction_id)
	if not faction: return Color(0.7, 0.7, 0.7, alpha)
	return Color(faction.color.r, faction.color.g, faction.color.b, alpha)


func _map_contacts() -> Array[Dictionary]:
	var result: Array[Dictionary] = SensorSystem.fog.get_all_contacts_for_map()
	var known: Dictionary = {}
	for contact in result:
		var node = contact.get("node")
		if is_instance_valid(node): known[node.get_instance_id()] = true
	# Neutral/friendly transponders share station locations, not nearby space.
	for station in get_tree().get_nodes_in_group("stations"):
		if not station is StationInstance or not station.station_data or not station.can_share_station_info(): continue
		if known.has(station.get_instance_id()): continue
		result.append({"type": "station", "node": station, "pos": station.global_position, "faction_id": station.faction_id, "live": true, "long_range": not SensorSystem.has_local_contact(station.global_position)})
	return result

func _station_at_screen(position: Vector2) -> StationInstance:
	var nearest: StationInstance
	var best: float = 12.0
	for contact in _map_contacts():
		if contact.get("type") != "station": continue
		var station = contact.get("node")
		if not is_instance_valid(station) or station._is_destroyed: continue
		var distance: float = position.distance_to(_world_to_screen(station.global_position))
		if distance < best:
			best = distance
			nearest = station
	return nearest
