extends VBoxContainer
const BUILD=preload("res://scripts/StationConstruction.gd")
var screen: InventoryScreen
var choice: OptionButton
var info: Label
func _ready() -> void:
	info=Label.new()
	info.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
	add_child(info)
	choice=OptionButton.new()
	for id in BUILD.KIT_BLUEPRINTS:
		choice.add_item(GameData.stations[id].display_name)
		choice.set_item_metadata(choice.item_count-1,id)
	add_child(choice)
	var deploy:=Button.new()
	deploy.text="Deploy scaffold 200 units ahead"
	deploy.pressed.connect(func():
		var player=PlayerState.current_ship as Player
		var id: StringName=choice.get_item_metadata(choice.selected)
		var point: Vector2=player.global_position+Vector2.LEFT.rotated(player.rotation)*200
		if BUILD.deploy_kit(player,id,point):screen.close()
		else:info.text="Cannot deploy: needs a kit, clear space, and construction permission. " + BUILD.kit_problem(SectorManager.current_sector,id))
	add_child(deploy)
	info.text="Buy a scaffold kit at a shipyard's Expansion tab. Fly to clear space, choose a structure and deploy. Approach within 350 units to deliver its materials. Faction-sponsored projects remain with that faction."
