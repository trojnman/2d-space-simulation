class_name JumpGate
extends Area2D

## A jump gate in the world. Player flies into the activation zone and presses
## the dock key (E) to jump to the connected sector.
##
## Scene tree:
##   JumpGate (Area2D + JumpGate.gd)
##     Sprite2D / Polygon2D   (visual ring shape)
##     CollisionShape2D       (CircleShape2D, radius ~120)
##     ActivationZone (Area2D)
##       CollisionShape2D     (CircleShape2D, radius ~200)
##     Label (Label)          (shows destination name)

signal activated(destination_sector_id: StringName)

@export var destination_sector_id : StringName = &""
@export var source_sector_id      : StringName = &""
@export var activation_radius     : float      = 200.0

var _player_in_range : bool = false

@onready var label : Label = $Label if has_node("Label") else null


func _ready() -> void:
	var zone := $ActivationZone if has_node("ActivationZone") else null
	if zone:
		zone.body_entered.connect(_on_body_entered)
		zone.body_exited.connect(_on_body_exited)
	_update_label()


func setup(dest_id: StringName, source_id: StringName) -> void:
	destination_sector_id = dest_id
	source_sector_id      = source_id
	_update_label()


func _update_label() -> void:
	if not label: return
	var dest_data : SectorData = GameData.get_sector(destination_sector_id)
	label.text = "→ %s" % (dest_data.display_name if dest_data else str(destination_sector_id))


func _input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if _player_in_range and event.is_action_pressed("dock"):
		_activate()


func _activate() -> void:
	print("JumpGate: activating jump to '%s'" % destination_sector_id)
	activated.emit(destination_sector_id)


func _on_body_entered(body: Node) -> void:
	if body is Player:
		_player_in_range = true
		if label:
			label.text = "Press E to jump → %s" % _get_dest_name()


func _on_body_exited(body: Node) -> void:
	if body is Player:
		_player_in_range = false
		_update_label()


func _get_dest_name() -> String:
	var dest_data : SectorData = GameData.get_sector(destination_sector_id)
	return dest_data.display_name if dest_data else str(destination_sector_id)
