extends PanelContainer
var heading:Label
var title:Label
var footer:Label
var rows:Dictionary={}
func _ready()->void:
 theme=preload("res://scripts/ConsoleTheme.gd").build()
 mouse_filter=Control.MOUSE_FILTER_IGNORE
 var frame=preload("res://scripts/ConsoleTheme.gd").box(Color("0a1624"),Color("315766"))
 frame.set_corner_radius_all(14)
 frame.shadow_color=Color(0,0,0,0.35)
 frame.shadow_size=6
 frame.content_margin_left=18
 frame.content_margin_right=18
 frame.content_margin_top=14
 frame.content_margin_bottom=14
 add_theme_stylebox_override("panel",frame)
 var column:=VBoxContainer.new()
 column.mouse_filter=Control.MOUSE_FILTER_IGNORE
 column.add_theme_constant_override("separation",7)
 add_child(column)
 heading=Label.new()
 heading.add_theme_font_size_override("font_size",11)
 heading.add_theme_color_override("font_color",Color("67dce8"))
 column.add_child(heading)
 title=Label.new()
 title.add_theme_font_size_override("font_size",19)
 title.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
 title.custom_minimum_size.x=270
 column.add_child(title)
 var separator:=HSeparator.new()
 column.add_child(separator)
 for id in ["Hull","Shields","Energy"]:
  var group:=VBoxContainer.new()
  group.add_theme_constant_override("separation",3)
  column.add_child(group)
  var line:=HBoxContainer.new()
  group.add_child(line)
  var caption:=Label.new()
  caption.text=id.to_upper()
  caption.add_theme_font_size_override("font_size",11)
  caption.add_theme_color_override("font_color",Color("94acba"))
  caption.size_flags_horizontal=Control.SIZE_EXPAND_FILL
  line.add_child(caption)
  var number:=Label.new()
  number.add_theme_font_size_override("font_size",12)
  line.add_child(number)
  var bar:=ProgressBar.new()
  bar.custom_minimum_size.y=5
  bar.show_percentage=false
  bar.mouse_filter=Control.MOUSE_FILTER_IGNORE
  var background:=StyleBoxFlat.new()
  background.bg_color=Color("172c3c")
  background.set_corner_radius_all(3)
  bar.add_theme_stylebox_override("background",background)
  var fill:=background.duplicate()
  fill.bg_color=Color("6addae") if id=="Hull" else (Color("55bde9") if id=="Shields" else Color("e9c77b"))
  bar.add_theme_stylebox_override("fill",fill)
  group.add_child(bar)
  rows[id]={"number":number,"bar":bar,"caption":caption}
 footer=Label.new()
 footer.add_theme_font_size_override("font_size",12)
 footer.add_theme_color_override("font_color",Color("98b4c4"))
 footer.text_overrun_behavior=TextServer.OVERRUN_TRIM_ELLIPSIS
 column.add_child(footer)
 # Decorative telemetry must never swallow combat input.
 for node in find_children("*","Control",true,false):node.mouse_filter=Control.MOUSE_FILTER_IGNORE
func metric(id:String,value:float,maximum:float,caption:String="")->void:
 var row:Dictionary=rows[id]
 row.caption.text=id.to_upper() if caption.is_empty() else caption
 row.number.text="%d / %d" % [value,maximum] if maximum>0 else "—"
 row.bar.max_value=maxf(1,maximum)
 row.bar.value=maxf(0,value)
func place_at(view:Vector2,right_side:bool)->void:
 size=Vector2(320,get_combined_minimum_size().y)
 var factor:=minf(1.0,minf((view.x-48)/640.0,(view.y-32)/size.y))
 scale=Vector2.ONE*maxf(0.1,factor)
 position=Vector2(view.x-16-size.x*scale.x if right_side else 16,view.y-16-size.y*scale.y)
