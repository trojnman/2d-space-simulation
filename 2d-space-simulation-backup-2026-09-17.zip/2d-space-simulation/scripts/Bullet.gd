class_name Bullet
extends Area2D

## Projectile fired by ballistic weapons.
## Scene tree:
##   Bullet (Area2D + Bullet.gd)
##     Sprite2D / Line2D   (visuals)
##     CollisionShape2D    (small CircleShape2D, radius ~4)

var _spent:=false
var _art: Dictionary = {}

var _velocity   : Vector2    = Vector2.ZERO
var _weapon     : WeaponData = null
var _owner_ship : Node       = null
var _age        : float      = 0.0
var _lifetime   : float      = 1.8

func _ready() -> void:
	collision_mask |= 64 | 128
	area_entered.connect(_on_missile_entered)
	body_entered.connect(_on_body_entered)
	for child in get_children():
		if child is Line2D or child is MeshInstance2D: child.hide()
	_art = preload("res://scripts/ProjectileArt.gd").configure(self, _weapon, false)
	preload("res://scripts/ProjectileArt.gd").advance(_art, 0.0)

func launch(vel: Vector2, owner_ship: Node, weapon: WeaponData) -> void:
	_velocity   = vel
	_owner_ship = owner_ship
	_weapon     = weapon
	if weapon:
		preload("res://scripts/TurretOrders.gd").notify_shot(owner_ship, global_position, vel.normalized(), weapon.max_range)
		var spd := vel.length()
		if spd > 0.0:
			_lifetime = weapon.max_range / spd

func _physics_process(delta: float) -> void:
	if _spent:return
	if preload("res://scripts/ProjectileSweep.gd").move(self,_velocity*delta):return
	global_position += _velocity * delta
	preload("res://scripts/ProjectileArt.gd").advance(_art, _velocity.length() * delta)
	_age += delta
	if _age >= _lifetime:
		queue_free()

func _on_body_entered(body: Node) -> void:
	if _spent:return
	if not is_instance_valid(_owner_ship):
		queue_free()
		return
	if body == _owner_ship: return
	_spent=true
	if body is ShipInstance or body is StaticBody2D:
		preload("res://scripts/ProjectileArt.gd").impact(self, _art)
	if body is ShipInstance:
		if _weapon:
			body.take_damage_from_weapon(_weapon, _owner_ship)
		queue_free()
	elif body is StationInstance:
		if _weapon: body.take_damage_from_weapon(_weapon, _owner_ship)
		queue_free()
	elif body.is_in_group("construction_scaffolds"):
		if _weapon: body.take_damage(_weapon.damage, _owner_ship)
		queue_free()
	elif body is StaticBody2D:
		if body.has_meta("asteroid"):
			var asteroid := body.get_meta("asteroid") as AsteroidInstance
			if asteroid:
				asteroid.receive_weapon_hit(_weapon, _owner_ship)
		queue_free()

func _on_missile_entered(area: Area2D) -> void:
	if _spent:return
	if area.get_script()==preload("res://scripts/ShieldHitbox.gd"):
		if area.active() and area.ship!=_owner_ship and PlayerState.combat_damage_allowed(_owner_ship,area.ship):
			area.struck(global_position)
			_on_body_entered(area.ship)
		return
	if area is Missile and is_instance_valid(_owner_ship) and area._owner_ship != _owner_ship:
		if is_instance_valid(area._owner_ship) and not PlayerState.combat_damage_allowed(_owner_ship,area._owner_ship): return
		_spent=true
		area.intercept(_weapon,_owner_ship)
		queue_free()
