extends Node

## SectorManager — Autoload singleton.
## Keeps visited sectors in memory and attaches only the active sector.
## Detached sectors pause; disk saves and distant simulation are separate systems.
## Add to Project -> Autoload as 'SectorManager'.

signal sector_changed(old_id: StringName, new_id: StringName)
signal sector_loaded(sector_id: StringName)

var _sensor_initializing: bool = false

var _background_transport_timer: float = 0.0

var current_sector_id : StringName    = &""
var current_sector    : SectorInstance = null

var _sector_scene_path : String = "res://scenes/Sector.tscn"
var _world_root        : Node2D = null
var _is_transitioning  : bool   = false
var _visited_sectors: Dictionary = {} # StringName -> SectorInstance


func _ready() -> void:
	await get_tree().process_frame
	_world_root = get_tree().get_first_node_in_group("world_root")
	if not _world_root:
		push_warning("SectorManager: no node in group 'world_root' found")


# ---------------------------------------------------------------------------
# Loading
# ---------------------------------------------------------------------------

func load_sector(sector_id: StringName, player_spawn: Vector2 = Vector2.ZERO) -> void:
	if _is_transitioning: return
	if not GameData.sectors.has(sector_id):
		push_warning("SectorManager: unknown sector id '%s'" % sector_id)
		return
	_is_transitioning = true
	var old_id: StringName = current_sector_id
	var sector_data: SectorData = GameData.sectors[sector_id]
	var next_sector: SectorInstance = _visited_sectors.get(sector_id)
	if not is_instance_valid(next_sector):
		if ResourceLoader.exists(_sector_scene_path):
			var packed: PackedScene = load(_sector_scene_path)
			next_sector = packed.instantiate() as SectorInstance
		else:
			next_sector = SectorInstance.new()
			_add_sector_nodes(next_sector)
		next_sector.restore_mode = SaveManager.loading
		next_sector.sector_data = sector_data
		_visited_sectors[sector_id] = next_sector

	var docking := get_tree().get_first_node_in_group("docking_manager")
	if docking: docking.prepare_sector_change()
	FleetCommandSystem.prepare_sector_change()
	if is_instance_valid(current_sector):
		_clear_proximity_flags(current_sector)
		if current_sector != next_sector and current_sector.is_inside_tree():
			current_sector.get_parent().remove_child(current_sector)

	current_sector_id = sector_id
	current_sector = next_sector
	if is_instance_valid(SensorSystem.fog): SensorSystem.fog.clear_sector()
	var player := get_tree().get_first_node_in_group("player") as Player
	if player:
		player.global_position = player_spawn
		player.velocity = Vector2.ZERO
	_world_root = get_tree().get_first_node_in_group("world_root") as Node2D
	if not current_sector.is_inside_tree():
		var parent: Node = _world_root if is_instance_valid(_world_root) else get_tree().current_scene
		parent.add_child(current_sector)
	if not current_sector.jump_gate_activated.is_connected(_on_jump_gate_activated):
		current_sector.jump_gate_activated.connect(_on_jump_gate_activated)
	MapMemory.mark_visited(sector_id)
	sector_loaded.emit(sector_id)
	sector_changed.emit(old_id, sector_id)
	print("SectorManager: activated sector '%s' (visited sectors: %d)" % [sector_data.display_name, _visited_sectors.size()])
	_is_transitioning = false


func add_sector_entity(entity: Node2D) -> void:
	entity.add_to_group("sensor_entities")
	# Satellites, fleet ships and projectiles must remain in the sector they belong to.
	var world_position: Vector2 = entity.position
	var parent: Node = current_sector if is_instance_valid(current_sector) else get_tree().current_scene
	parent.add_child(entity)
	entity.global_position = world_position


func _clear_proximity_flags(node: Node) -> void:
	if node is StationInstance or node is JumpGate:
		node._player_in_range = false
	if node is JumpGate: node._update_label()
	for child in node.get_children(): _clear_proximity_flags(child)


func _exit_tree() -> void:
	# Detached sectors are not freed by SceneTree, so release them explicitly.
	for sector in _visited_sectors.values():
		if is_instance_valid(sector) and sector.get_parent() == null:
			sector.free()
	_visited_sectors.clear()


func _add_sector_nodes(sector: SectorInstance) -> void:
	for node_name in ["Stations", "Asteroids", "JumpGates", "AIShips", "Derelicts", "Hazards", "PointsOfInterest"]:
		var n := Node2D.new()
		n.name = node_name
		sector.add_child(n)


# ---------------------------------------------------------------------------
# Jump gate transition
# ---------------------------------------------------------------------------

func _on_jump_gate_activated(destination_sector_id: StringName) -> void:
	if _is_transitioning: return
	print("SectorManager: jumping to sector '%s'" % destination_sector_id)
	var dest_data : SectorData = GameData.get_sector(destination_sector_id)
	if not dest_data:
		push_warning("SectorManager: destination sector '%s' not found" % destination_sector_id)
		return
	var spawn := _find_return_gate_position(destination_sector_id, current_sector_id)
	# Gate signals may originate during physics/input callbacks.
	load_sector.call_deferred(destination_sector_id, spawn)


func _find_return_gate_position(in_sector_id: StringName, coming_from_id: StringName) -> Vector2:
	var dest_data : SectorData = GameData.get_sector(in_sector_id)
	if not dest_data: return Vector2.ZERO
	var connected := dest_data.connected_sectors
	var idx       := connected.find(coming_from_id)
	if idx < 0:
		return Vector2(SectorInstance.HALF_SIZE * 0.5, 0.0)
	var gate_pos: Vector2
	var cached: SectorInstance = _visited_sectors.get(in_sector_id)
	if is_instance_valid(cached):
		for gate in cached.get_node("JumpGates").get_children():
			if gate is JumpGate and gate.destination_sector_id == coming_from_id:
				gate_pos = gate.position
				break
	if gate_pos == Vector2.ZERO:
		var hex := HexBoundary.new()
		var positions: Array[Vector2] = hex.get_gate_positions()
		hex.free()
		gate_pos = positions[idx % positions.size()]
	return gate_pos - gate_pos.normalized() * 500.0


# ---------------------------------------------------------------------------
# Utility
# ---------------------------------------------------------------------------

func get_current_sector_data() -> SectorData:
	if current_sector_id == &"": return null
	return GameData.get_sector(current_sector_id)


func get_controlling_faction() -> StringName:
	var data := get_current_sector_data()
	if not data: return &""
	return data.controlling_faction_id


func get_sector_stations(sector: Node) -> Array[StationInstance]:
	var result: Array[StationInstance] = []
	for child in sector.get_children():
		if child is StationInstance:
			if not child._is_destroyed: result.append(child)
		elif not child is ShipInstance and not child is AsteroidInstance:
			result.append_array(get_sector_stations(child))
	return result

func _process(delta: float) -> void:
	if SaveManager.loading: return
	_initialize_shared_sector.call_deferred()
	for sector in _visited_sectors.values():
		if is_instance_valid(sector):sector.advance_asteroid_respawns(delta)
	_background_transport_timer += delta
	if _background_transport_timer >= 0.25:
		var step: float = _background_transport_timer
		_background_transport_timer = 0.0
		advance_background_production(step)
		advance_background_transport(step)

func advance_background_production(delta: float) -> void:
	# Detached sectors cannot receive physics callbacks. Advance the same economic
	# timers once, without attaching their collision worlds to the active sector.
	for sector in _visited_sectors.values():
		if not is_instance_valid(sector) or sector == current_sector or sector.is_inside_tree(): continue
		for station in get_sector_stations(sector):
			station._physics_process(delta)
		for node in sector.find_children("*","",true,false):
			if node is StationSpawner:node._physics_process(delta)
			if node.get_script()==preload("res://scripts/ConstructionScaffold.gd"):node.advance(delta)


func advance_background_transport(delta: float) -> void:
	for sector in _visited_sectors.values():
		if not is_instance_valid(sector) or sector == current_sector or sector.is_inside_tree(): continue
		var controllers: Array=[]
		for node in sector.find_children("*", "", true, false):
			if node is AIShipController:controllers.append(node)
		preload("res://scripts/TurretOrders.gd").cache_background_sector(sector)
		var steps:=maxi(1,int(ceil(delta*4.0)))
		for step in steps:
			for controller in controllers:
				if is_instance_valid(controller) and preload("res://scripts/StationConstruction.gd").sector_of(controller)==sector:controller.advance_background_transport(delta/steps)
		preload("res://scripts/TurretOrders.gd").clear_background_cache()

# Initialize licensed territory in an isolated physics world, without moving the
# player or marking the sector as personally visited.
func _initialize_shared_sector(requested: StringName = &"") -> void:
	if _sensor_initializing or SaveManager.loading or _is_transitioning:return
	var candidate: StringName=requested
	if candidate!=&"" and (_visited_sectors.has(candidate) or not GameData.sectors.has(candidate)):return
	for id in GameData.sectors:
		if candidate!=&"":break
		if _visited_sectors.has(id):continue
		var data: SectorData=GameData.sectors[id]
		if data.controlling_faction_id in preload("res://resources/StartingRegion.gd").ACTIVE:
			candidate=id
			break
		for station_id in data.starting_stations:
			var station_data: StationData=GameData.get_station(station_id)
			if station_data and PlayerState.has_shared_sensors(station_data.faction_id):
				candidate=id
				break
		if candidate!=&"":break
	if candidate==&"":return
	_sensor_initializing=true
	var staging:=SubViewport.new()
	staging.world_2d=World2D.new()
	staging.disable_3d=true
	staging.render_target_update_mode=SubViewport.UPDATE_DISABLED
	staging.process_mode=Node.PROCESS_MODE_DISABLED
	add_child(staging)
	var sector: SectorInstance=load(_sector_scene_path).instantiate()
	sector.sector_data=GameData.sectors[candidate]
	_visited_sectors[candidate]=sector
	staging.add_child(sector)
	# Keep the temporary scene out of active-sector group queries during ready.
	var groups: Dictionary={}
	for node in sector.find_children("*","",true,false):
		groups[node]=node.get_groups()
		for group in groups[node]:node.remove_from_group(group)
	for i in 3:await get_tree().process_frame
	if is_instance_valid(sector) and sector.get_parent()==staging:
		staging.remove_child(sector)
	for node in groups:
		if is_instance_valid(node):
			for group in groups[node]:node.add_to_group(group)
	staging.queue_free()
	_sensor_initializing=false

func transfer_job_ship(ship:ShipInstance,destination_id:StringName)->void:
	if not is_instance_valid(ship):return
	var ai=ship.get_node_or_null("AIShipController")
	if not ai or ai.fleet_job.is_empty():return
	ai.fleet_job.erase("jumping")
	var old=preload("res://scripts/StationConstruction.gd").sector_of(ship)
	var destination=_visited_sectors.get(destination_id)
	if not old or not is_instance_valid(destination) or destination_id in ai.no_go_sectors:return
	if destination.is_inside_tree() and destination!=current_sector:return
	var position_at_gate=_find_return_gate_position(destination_id,old.sector_data.id)
	ship.get_parent().remove_child(ship)
	destination.add_child(ship)
	ship.position=position_at_gate
	ship.velocity=Vector2.ZERO
