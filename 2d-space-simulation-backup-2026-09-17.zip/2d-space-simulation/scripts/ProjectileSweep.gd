extends RefCounted
static func move(projectile:Area2D,step:Vector2)->bool:
 if step.length_squared()<.0001:return false
 var excluded:Array[RID]=[projectile.get_rid()]
 var owner=projectile._owner_ship
 if is_instance_valid(owner) and owner is CollisionObject2D:
  excluded.append(owner.get_rid())
  var own_shield=owner.get_node_or_null("ShieldHitbox")
  if own_shield:excluded.append(own_shield.get_rid())
 var query:=PhysicsRayQueryParameters2D.create(projectile.global_position,projectile.global_position+step,projectile.collision_mask,excluded)
 query.collide_with_areas=true
 query.collide_with_bodies=true
 for attempt in 32:
  var hit=projectile.get_world_2d().direct_space_state.intersect_ray(query)
  if hit.is_empty():return false
  var collider=hit.collider
  if collider.get_script()==preload("res://scripts/ShieldHitbox.gd"):
   if not collider.active() or collider.ship==owner or not PlayerState.combat_damage_allowed(owner,collider.ship):
    excluded.append(collider.get_rid())
    query.exclude=excluded
    continue
   projectile.global_position=hit.position
   collider.struck(hit.position)
   projectile._on_body_entered(collider.ship)
   return true
  if collider is Missile:
   if collider._owner_ship==owner or not is_instance_valid(collider._owner_ship) or not PlayerState.combat_damage_allowed(owner,collider._owner_ship):
    excluded.append(collider.get_rid())
    query.exclude=excluded
    continue
   projectile.global_position=hit.position
   if projectile.has_method("_on_missile_entered"):projectile._on_missile_entered(collider)
   return true
  if collider is PhysicsBody2D:
   projectile.global_position=hit.position
   projectile._on_body_entered(collider)
   return true
  excluded.append(collider.get_rid())
  query.exclude=excluded
 return false
