class_name WorldHealthBar
extends Node2D

## Attach as a child of any ShipInstance, StationInstance, or AsteroidInstance.
## Draws hull and shield bars above the unit in world space.
## Only visible when hull or shield is not full.

const BAR_WIDTH    : float = 80.0
const BAR_HEIGHT   : float = 6.0
const BAR_GAP      : float = 4.0
const BAR_OFFSET_Y : float = -60.0

const HULL_FG      : Color = Color(0.0,  1.0,  1.0,  1.0)
const HULL_BG      : Color = Color(0.0,  0.2,  0.2,  0.8)
const SHIELD_FG    : Color = Color(0.31, 0.76, 0.97, 1.0)
const SHIELD_BG    : Color = Color(0.0,  0.05, 0.2,  0.8)

var _hull        : float = 1.0
var _max_hull    : float = 1.0
var _shield      : float = 0.0
var _max_shield  : float = 0.0
var _has_shield  : bool  = false
var _show        : bool  = false

func _ready() -> void:
	var parent := get_parent()
	if parent.has_signal("hull_changed"):
		parent.hull_changed.connect(_on_hull_changed)
	if parent.has_signal("shield_changed"):
		parent.shield_changed.connect(_on_shield_changed)
	if parent is ShipInstance:
		_hull       = parent.hull
		_max_hull   = parent.max_hull
		_shield     = parent.shield
		_max_shield = parent.max_shield
		_has_shield = parent.max_shield > 0.0
	elif parent is AsteroidInstance:
		_hull     = parent.hull
		_max_hull = parent.max_hull
	_update_visibility()

func _on_hull_changed(current: float, maximum: float) -> void:
	_hull     = current
	_max_hull = maximum
	_update_visibility()
	queue_redraw()

func _on_shield_changed(current: float, maximum: float) -> void:
	_shield     = current
	_max_shield = maximum
	_has_shield = maximum > 0.0
	_update_visibility()
	queue_redraw()

func _update_visibility() -> void:
	var hull_full   := _hull >= _max_hull
	var shield_full := not _has_shield or _shield >= _max_shield
	_show   = not hull_full or not shield_full
	visible = _show

func _draw() -> void:
	if not _show: return
	var x := -BAR_WIDTH / 2.0
	var y := BAR_OFFSET_Y
	_draw_bar(x, y, _hull, _max_hull, HULL_FG, HULL_BG)
	if _has_shield:
		_draw_bar(x, y - BAR_HEIGHT - BAR_GAP, _shield, _max_shield, SHIELD_FG, SHIELD_BG)

func _draw_bar(x: float, y: float, current: float, maximum: float, fg: Color, bg: Color) -> void:
	if maximum <= 0.0: return
	draw_rect(Rect2(x, y, BAR_WIDTH, BAR_HEIGHT), bg)
	var fill := (current / maximum) * BAR_WIDTH
	if fill > 0.0:
		draw_rect(Rect2(x, y, fill, BAR_HEIGHT), fg)
