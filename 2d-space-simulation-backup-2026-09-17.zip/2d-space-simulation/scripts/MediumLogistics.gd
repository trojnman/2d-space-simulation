extends ShipInstance

## Medium Logistics Ship — Medium logistics vessel, wide rounded hull. 88px long, 38px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(44,-8),Vector2(44,8),Vector2(36,19),Vector2(-36,19),Vector2(-44,8),Vector2(-44,-8),Vector2(-36,-19),Vector2(36,-19)])
	hull.color   = Color(0.22,0.38,0.34)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(30,-15),Vector2(30,15),Vector2(-32,15),Vector2(-32,-15)])
	detail0.color   = Color(0.22,0.3,0.28)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(-32,-12),Vector2(-32,12),Vector2(-44,8),Vector2(-44,-8)])
	detail1.color   = Color(0.18,0.24,0.22)
	add_child(detail1)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(40,0),Vector2(32,-5),Vector2(26,0),Vector2(32,5)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-44, -8.2),
		Vector2(-53.6, -5.0),
		Vector2(-44, -1.8),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-44, 1.8),
		Vector2(-53.6, 5.0),
		Vector2(-44, 8.2),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(44,-8),Vector2(44,8),Vector2(-36,19),Vector2(-44,0),Vector2(-36,-19)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(48,0),Vector2(34,-23),Vector2(0,-27),Vector2(-40,-21),Vector2(-48,0),Vector2(-40,21),Vector2(0,27),Vector2(34,23)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(40.0, -1.0),
		Vector2(46.0, -1.0),
		Vector2(46.0, 1.0),
		Vector2(40.0, 1.0),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(46.0, 0.0)
	add_child(m0)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"medium_logistics", vc)
