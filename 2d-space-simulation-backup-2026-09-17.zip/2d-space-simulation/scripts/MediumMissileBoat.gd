extends ShipInstance

## Medium Missile Boat — Medium missile platform with quad pod launchers. 75px long, 32px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(37,0),Vector2(26,-6),Vector2(14,-12),Vector2(-28,-14),Vector2(-38,-8),Vector2(-38,8),Vector2(-28,14),Vector2(14,12),Vector2(26,6)])
	hull.color   = Color(0.18,0.22,0.45)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(28,-3),Vector2(28,3),Vector2(-34,3),Vector2(-34,-3)])
	detail0.color   = Color(0.14,0.18,0.38)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(6,-12),Vector2(-10,-14),Vector2(-28,-14),Vector2(-14,-9)])
	detail1.color   = Color(0.12,0.15,0.3)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(6,12),Vector2(-10,14),Vector2(-28,14),Vector2(-14,9)])
	detail2.color   = Color(0.12,0.15,0.3)
	add_child(detail2)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(32,0),Vector2(22,-4),Vector2(16,0),Vector2(22,4)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-38, -6.4),
		Vector2(-45.2, -4.0),
		Vector2(-38, -1.6),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-38, 1.6),
		Vector2(-45.2, 4.0),
		Vector2(-38, 6.4),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(37,0),Vector2(14,-12),Vector2(-38,-8),Vector2(-38,8),Vector2(14,12)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(42,0),Vector2(28,-20),Vector2(0,-22),Vector2(-36,-16),Vector2(-42,0),Vector2(-36,16),Vector2(0,22),Vector2(28,20)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(30.0, -5.0),
		Vector2(40.0, -5.0),
		Vector2(40.0, -3.0),
		Vector2(30.0, -3.0),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(40.0, -4.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(30.0, 3.0),
		Vector2(40.0, 3.0),
		Vector2(40.0, 5.0),
		Vector2(30.0, 5.0),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(40.0, 4.0)
	add_child(m1)

	## Missile pod 0 — always visible
	var mpod0 := Polygon2D.new()
	mpod0.polygon = PackedVector2Array([
		Vector2(-6.0,       -18.5),
		Vector2(12.0, -18.5),
		Vector2(12.0, -13.5),
		Vector2(-6.0,       -13.5),
	])
	mpod0.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod0)
	missile_nodes.append(mpod0)

	var ml0 := Marker2D.new()
	ml0.name     = "MissileLaunch0"
	ml0.position = Vector2(12.0, -16.0)
	add_child(ml0)

	## Missile pod 1 — always visible
	var mpod1 := Polygon2D.new()
	mpod1.polygon = PackedVector2Array([
		Vector2(-6.0,       13.5),
		Vector2(12.0, 13.5),
		Vector2(12.0, 18.5),
		Vector2(-6.0,       18.5),
	])
	mpod1.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod1)
	missile_nodes.append(mpod1)

	var ml1 := Marker2D.new()
	ml1.name     = "MissileLaunch1"
	ml1.position = Vector2(12.0, 16.0)
	add_child(ml1)

	## Missile pod 2 — always visible
	var mpod2 := Polygon2D.new()
	mpod2.polygon = PackedVector2Array([
		Vector2(-20.0,       -18.5),
		Vector2(-2.0, -18.5),
		Vector2(-2.0, -13.5),
		Vector2(-20.0,       -13.5),
	])
	mpod2.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod2)
	missile_nodes.append(mpod2)

	var ml2 := Marker2D.new()
	ml2.name     = "MissileLaunch2"
	ml2.position = Vector2(-2.0, -16.0)
	add_child(ml2)

	## Missile pod 3 — always visible
	var mpod3 := Polygon2D.new()
	mpod3.polygon = PackedVector2Array([
		Vector2(-20.0,       13.5),
		Vector2(-2.0, 13.5),
		Vector2(-2.0, 18.5),
		Vector2(-20.0,       18.5),
	])
	mpod3.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod3)
	missile_nodes.append(mpod3)

	var ml3 := Marker2D.new()
	ml3.name     = "MissileLaunch3"
	ml3.position = Vector2(-2.0, 16.0)
	add_child(ml3)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"medium_missile_boat", vc)
