class_name Missile
extends Area2D

## Homing missile projectile.
## Acquires target on first physics frame once in scene tree.
## If no target found, flies straight and detonates at max range.
##
## Scene tree:
##   Missile (Area2D + Missile.gd)
##     Sprite2D / Polygon2D
##     CollisionShape2D  (CircleShape2D radius ~8)
##
## Connect Area2D body_entered -> _on_body_entered in editor.

var _is_destroyed: bool = false
var interception_hull: float = 5.0
var _velocity       : Vector2     = Vector2.ZERO
var _missile        : MissileData = null
var _owner_ship     : Node        = null
var _target         : Node        = null
var _age            : float       = 0.0
var _target_acquired: bool        = false
var _distance_flown : float       = 0.0
const VOLLEY_SEPARATION_DISTANCE: float = 90.0
const VOLLEY_STRAIGHTEN_DISTANCE: float = 100.0
var _volley_guidance: bool = false
var _volley_aim_angle: float = 0.0
var _volley_launch_angle: float = 0.0

func configure_volley(aim_angle: float, spread: float) -> void:
	_volley_guidance = true
	_volley_aim_angle = aim_angle
	_volley_launch_angle = aim_angle + spread
	rotation = _volley_launch_angle



var _exhaust: Line2D
var _art_scale: float = 1.0
func _ready() -> void:
	add_to_group("missiles")
	collision_layer = 64
	collision_mask |= 128
	area_entered.connect(_on_shield_entered)
	if not body_entered.is_connected(_on_body_entered): body_entered.connect(_on_body_entered)
	_art_scale = [1.0, 1.5, 2.1][clampi(int(_missile.equip_size) if _missile else 0, 0, 2)]
	for child in get_children():
		if child is MeshInstance2D: child.hide()
	var body := Polygon2D.new()
	body.polygon = PackedVector2Array([Vector2(2.5,0),Vector2(.8,-.55),Vector2(-2,-.55),Vector2(-2,.55),Vector2(.8,.55)])
	body.color = Color("d6e4e8")
	body.scale = Vector2.ONE * _art_scale
	add_child(body)
	_exhaust = Line2D.new()
	_exhaust.width = .6 * _art_scale
	_exhaust.default_color = Color("ffb66b")
	add_child(_exhaust)
	z_index = 3


func launch(inherit_vel: Vector2, owner_ship: Node, missile_data: MissileData) -> void:
	## Use rotation for initial direction, add inherited velocity as bonus
	var forward : Vector2 = Vector2.RIGHT.rotated(rotation)
	_velocity   = forward * missile_data.speed + inherit_vel * 0.3
	_owner_ship = owner_ship
	_missile    = missile_data
	interception_hull = [5.0,12.0,25.0][clampi(int(missile_data.equip_size)-1,0,2)]
	## Target acquired on first physics frame once in scene tree


func _physics_process(delta: float) -> void:
	if _is_destroyed:return
	if is_instance_valid(_target) and _target is ShipInstance and _target.ship_data and _target.ship_data.id == &"escape_pod": _target = null
	if _missile == null:
		queue_free()
		return

	## Acquire target on first frame
	if not _target_acquired:
		_target_acquired = true
		_target = _find_target()

	if is_instance_valid(_target) and _target is ShipInstance: preload("res://scripts/TurretOrders.gd").record_attack(_target, _owner_ship)
	_age += delta

	## Detonate at lifetime or max range
	if _age >= _missile.lifetime:
		_detonate(null)
		return

	## Fly toward target if homing and target is valid
	if _missile.is_homing and is_instance_valid(_target):
		_home_toward_target(delta)
	else:
		# Separate first, then settle onto parallel lanes along the original aim.
		if _volley_guidance:
			var blend: float = clampf((_distance_flown - VOLLEY_SEPARATION_DISTANCE) / VOLLEY_STRAIGHTEN_DISTANCE, 0.0, 1.0)
			blend = blend * blend * (3.0 - 2.0 * blend)
			rotation = lerp_angle(_volley_launch_angle, _volley_aim_angle, blend)
		var aim_dir : Vector2 = Vector2.RIGHT.rotated(rotation)
		_velocity = aim_dir * _missile.speed

	var move : Vector2 = _velocity * delta
	_distance_flown += move.length()
	if _exhaust:
		_exhaust.points = PackedVector2Array([Vector2(-2*_art_scale,0),Vector2(-2*_art_scale-minf(_distance_flown,8*_art_scale),0)])
	if preload("res://scripts/ProjectileSweep.gd").move(self,move):return
	global_position += move
	rotation = _velocity.angle()

	## Detonate at max range if no target
	if not is_instance_valid(_target) and _distance_flown >= _missile.lock_on_range:
		_detonate(null)


func _home_toward_target(delta: float) -> void:
	var to_target   : Vector2 = (_target.global_position - global_position).normalized()
	var current_dir : Vector2 = _velocity.normalized()
	var max_turn    : float   = _missile.turn_rate * delta
	var new_dir     : Vector2 = current_dir.rotated(
		clampf(current_dir.angle_to(to_target), -max_turn, max_turn)
	)
	_velocity = new_dir * _missile.speed


func _find_target() -> Node:
	if not _missile: return null
	var closest      : Node  = null
	var closest_dist : float = _missile.lock_on_range

	for ship in get_tree().get_nodes_in_group("ships"):
		if ship is ShipInstance and ship.ship_data and ship.ship_data.id == &"escape_pod": continue
		if ship == _owner_ship: continue
		if not ship is ShipInstance: continue
		if not is_instance_valid(ship): continue
		if is_instance_valid(_owner_ship) and _owner_ship is ShipInstance and not FactionManager.are_at_war(&"player" if _owner_ship.is_in_group("player") or _owner_ship.is_in_group("player_fleet") else _owner_ship.faction_id, &"player" if ship.is_in_group("player") or ship.is_in_group("player_fleet") else ship.faction_id): continue
		var dist : float = global_position.distance_to(ship.global_position)
		if dist < closest_dist:
			closest      = ship
			closest_dist = dist
	return closest


func _on_body_entered(body: Node) -> void:
	if not is_instance_valid(_owner_ship):
		queue_free()
		return
	if body == _owner_ship: return
	_detonate(body)


func _detonate(direct_hit: Node) -> void:
	if _is_destroyed:return
	_is_destroyed=true
	if not is_instance_valid(_owner_ship):
		queue_free()
		return
	if _missile == null:
		queue_free()
		return

	## Direct hit damage
	if direct_hit is ShipInstance or direct_hit is StationInstance:
		direct_hit.take_damage_from_missile(_missile, _owner_ship)

	if is_instance_valid(direct_hit) and direct_hit.is_in_group("construction_scaffolds"):
		direct_hit.take_damage(_missile.damage, _owner_ship)

	## Splash uses station surfaces rather than their distant center points.
	if _missile.blast_radius > 0.0:
		var victims=get_tree().get_nodes_in_group("ships")+get_tree().get_nodes_in_group("stations")
		for victim in victims:
			if not is_instance_valid(victim) or victim == direct_hit or victim == _owner_ship:continue
			if not (victim is ShipInstance or victim is StationInstance):continue
			var distance:=_blast_distance(victim)
			if distance>=_missile.blast_radius:continue
			var falloff:=1.0-distance/_missile.blast_radius
			var split=_missile.calc_damage_split(_missile.damage*falloff)
			if victim is StationInstance:
				victim._take_damage_split(split[0],split[1],_owner_ship)
			else: victim.take_damage(split[0],split[1],_owner_ship)

	var flash := preload("res://scripts/ShotFlash.gd").new()
	flash.impact = true
	flash.tint = Color("ffc078")
	flash.radius = 5.0 * _art_scale
	flash.duration = .22
	get_parent().add_child(flash)
	flash.global_position = global_position

	queue_free()

func threatens(ship: ShipInstance) -> bool:
	if _is_destroyed or _owner_ship == ship or not is_instance_valid(_owner_ship): return false
	if not PlayerState.combat_damage_allowed(_owner_ship,ship): return false
	if _target == ship: return true
	if is_instance_valid(_target): return false
	var offset: Vector2=ship.global_position-global_position
	var direction: Vector2=_velocity.normalized()
	return offset.dot(direction)>0 and absf(offset.cross(direction))<preload("res://scripts/ShipTactics.gd").radius(ship)+30

func intercept(weapon: WeaponData, attacker: Node) -> void:
	if _is_destroyed or not weapon or attacker == _owner_ship: return
	if is_instance_valid(_owner_ship) and not PlayerState.combat_damage_allowed(attacker,_owner_ship): return
	interception_hull -= weapon.damage
	if interception_hull <= 0:
		_is_destroyed=true
		queue_free()

func _on_shield_entered(area:Area2D)->void:
	if area.get_script()==preload("res://scripts/ShieldHitbox.gd") and area.active() and area.ship!=_owner_ship and PlayerState.combat_damage_allowed(_owner_ship,area.ship):
		area.struck(global_position)
		_detonate(area.ship)

func _blast_distance(victim:Node2D)->float:
	var distance:=global_position.distance_to(victim.global_position)
	if not victim is StationInstance:return distance
	var shield= victim.get_node_or_null("ShieldHitbox")
	if shield and shield.active():
		return maxf(0.0,distance-shield.shape.radius*absf(victim.global_scale.x))
	for child in victim.get_children():
		if not child is CollisionPolygon2D:continue
		var point:Vector2=child.to_local(global_position)
		if Geometry2D.is_point_in_polygon(point,child.polygon):return 0.0
		for i in child.polygon.size():
			var closest:=Geometry2D.get_closest_point_to_segment(point,child.polygon[i],child.polygon[(i+1)%child.polygon.size()])
			distance=minf(distance,global_position.distance_to(child.to_global(closest)))
	return distance

