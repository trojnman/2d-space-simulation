extends RefCounted
## Deterministic priorities; execution uses real shipyards and cargo deliveries.
static func choose(faction:StringName, sectors:int, miners:int, haulers:int, combat:int, credits:int, threatened:bool)->Dictionary:
 var mining_goal:int=maxi(3,sectors*2)
 var hauling_goal:int=maxi(2,sectors*2)
 var combat_goal:int=sectors*(3 if faction==&"free_traders_guild" else 6 if faction==&"ash_collective" else 5 if faction==&"iron_corsairs" else 4)
 var role:String=""
 var phase:String="Consolidate"
 var reason:String="Maintain reserves and existing territory"
 if miners<1:role="miner";phase="Rebuild economy";reason="No mining capacity"
 elif haulers<1:role="hauler";phase="Rebuild economy";reason="No cargo delivery capacity"
 elif threatened and combat<combat_goal:role="fighter";phase="Defend";reason="Hostiles present in owned territory"
 elif miners<mining_goal:role="miner";phase="Build economy";reason="Increase raw material supply"
 elif haulers<hauling_goal:role="hauler";phase="Trade and supply";reason="Increase physical cargo delivery capacity"
 elif combat<combat_goal:role="fighter";phase="Build fleet";reason="Build a defense reserve before committing forces"
 elif threatened:phase="Defend";reason="Suspend expansion while territory is threatened"
 elif credits>=50000:phase="Develop territory";reason="Economy and defense established; fund infrastructure"
 return {"phase":phase,"reason":reason,"role":role,"expand":phase=="Develop territory","reserve":10000,"combat_goal":combat_goal}
