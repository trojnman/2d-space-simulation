extends Window

var ships: Array = []
var points: Array[Vector2] = []
var board: Control
var title_input: LineEdit
var presets: OptionButton
var dragging: int = -1
var drag_scale: float = 1.0

func _ready() -> void:
 title = "Fleet formation designer"
 theme=preload("res://scripts/ConsoleTheme.gd").build()
 borderless=true
 size = Vector2i(860,640)
 transient = true
 exclusive = true
 close_requested.connect(hide)
 var frame:=PanelContainer.new()
 frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 var style=preload("res://scripts/ConsoleTheme.gd").box(Color("0a1624"),Color("315766"))
 style.set_corner_radius_all(14)
 style.content_margin_left=22
 style.content_margin_right=22
 style.content_margin_top=18
 style.content_margin_bottom=18
 frame.add_theme_stylebox_override("panel",style)
 add_child(frame)
 var layout := VBoxContainer.new()
 layout.add_theme_constant_override("separation",14)
 frame.add_child(layout)
 var header:=HBoxContainer.new()
 layout.add_child(header)
 var heading:=Label.new()
 heading.text="FLEET / FORMATION DESIGNER"
 heading.add_theme_font_size_override("font_size",20)
 heading.add_theme_color_override("font_color",Color("56dfeb"))
 heading.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 header.add_child(heading)
 var close:=Button.new()
 close.text="✕"
 close.tooltip_text="Close formation designer"
 close.pressed.connect(hide)
 header.add_child(close)
 layout.add_child(HSeparator.new())
 var help := Label.new()
 help.text = "Drag ships to arrange your formation. Forward →"
 help.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
 help.add_theme_color_override("font_color",Color("98afbf"))
 layout.add_child(help)
 var toolbar := HBoxContainer.new()
 layout.add_child(toolbar)
 presets = OptionButton.new()
 presets.custom_minimum_size.x=180
 toolbar.add_child(presets)
 presets.item_selected.connect(_choose)
 title_input = LineEdit.new()
 title_input.placeholder_text = "Formation name"
 title_input.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 toolbar.add_child(title_input)
 var save := Button.new()
 save.text = "Save & use"
 toolbar.add_child(save)
 save.pressed.connect(_save)
 board = Control.new()
 board.size_flags_vertical = Control.SIZE_EXPAND_FILL
 board.mouse_filter = Control.MOUSE_FILTER_STOP
 layout.add_child(board)
 board.draw.connect(_draw_board)
 board.gui_input.connect(_board_input)
 board.resized.connect(func(): board.queue_redraw())
 var done := Button.new()
 done.text = "Done — right-drag on map to move formation"
 done.pressed.connect(hide)
 layout.add_child(done)

func open_selection() -> void:
 ships.clear()
 for ship in FleetCommandSystem.selected_ships:
  if is_instance_valid(ship) and not ship._is_destroyed: ships.append(ship)
 if ships.is_empty(): return
 presets.clear()
 for label in ["Wedge","Line","Column","Box"] + FleetCommandSystem.custom_formations.keys(): presets.add_item(label)
 title_input.text = ""
 points = FleetCommandSystem.formation_offsets(ships.size(),0)
 size=Vector2i(mini(860,get_tree().root.size.x-40),mini(640,get_tree().root.size.y-40))
 popup_centered()
 board.queue_redraw()

func _choose(index: int) -> void:
 FleetCommandSystem.formation_name = presets.get_item_text(index)
 points = FleetCommandSystem.formation_offsets(ships.size(),0)
 title_input.text = FleetCommandSystem.formation_name
 board.queue_redraw()

func _scale_factor() -> float:
 var extent := 1200.0
 for point in points: extent = maxf(extent,maxf(absf(point.x),absf(point.y))+200)
 return minf(board.size.x,board.size.y)*0.45/extent

func _draw_board() -> void:
 var background=preload("res://scripts/ConsoleTheme.gd").box(HUDLayout.palette_color(Color("101c2b")),HUDLayout.palette_color(HUDLayout.palette_color(Color("294353"))))
 background.set_corner_radius_all(10)
 board.draw_style_box(background,Rect2(Vector2.ZERO,board.size))
 for x in range(40,int(board.size.x),40):board.draw_line(Vector2(x,0),Vector2(x,board.size.y),HUDLayout.palette_color(Color(.12,.22,.28,.35)))
 for y in range(40,int(board.size.y),40):board.draw_line(Vector2(0,y),Vector2(board.size.x,y),HUDLayout.palette_color(Color(.12,.22,.28,.35)))
 var center := board.size*0.5
 board.draw_line(Vector2(0,center.y),Vector2(board.size.x,center.y),HUDLayout.palette_color(Color("294353")))
 board.draw_line(Vector2(center.x,0),Vector2(center.x,board.size.y),HUDLayout.palette_color(Color("294353")))
 var font := ThemeDB.fallback_font
 for i in points.size():
  var at := center+points[i]*_scale_factor()
  board.draw_circle(at,15,HUDLayout.palette_color(Color("39b9ce")))
  board.draw_string(font,at+Vector2(-5,5),str(i+1),HORIZONTAL_ALIGNMENT_LEFT,-1,13,Color.BLACK)
  if is_instance_valid(ships[i]): board.draw_string(font,at+Vector2(20,5),ships[i].ship_data.display_name,HORIZONTAL_ALIGNMENT_LEFT,-1,12)

func _board_input(event: InputEvent) -> void:
 if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
  dragging = -1
  if event.pressed:
   for i in points.size():
    if (board.size*0.5+points[i]*_scale_factor()).distance_to(event.position)<22: dragging=i;drag_scale=_scale_factor();break
 if event is InputEventMouseMotion and dragging>=0:
  points[dragging]=(event.position-board.size*0.5)/drag_scale
  board.queue_redraw()

func _save() -> void:
 var label := title_input.text.strip_edges()
 if label.is_empty() or label in ["Wedge","Line","Column","Box"]:
  title_input.placeholder_text = "Enter a unique custom name"
  title_input.text = ""
  return
 var offsets: Array = []
 var center := Vector2.ZERO
 for point in points: center+=point
 center/=maxi(1,points.size())
 for point in points: offsets.append((point-center)/FleetCommandSystem.formation_spacing)
 FleetCommandSystem.custom_formations[label]=offsets
 FleetCommandSystem.formation_name=label
 hide()
