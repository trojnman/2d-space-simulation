extends ShipInstance

## Heavy Miner — Capital mining vessel with massive drill array. 280px long, 80px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(100,-8),Vector2(140,0),Vector2(100,8),Vector2(80,40),Vector2(-120,40),Vector2(-140,25),Vector2(-140,-25),Vector2(-120,-40),Vector2(80,-40)])
	hull.color   = Color(0.28,0.32,0.26)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(100,-8),Vector2(150,-20),Vector2(150,-8),Vector2(100,-3)])
	detail0.color   = Color(0.36,0.32,0.24)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(100,8),Vector2(150,20),Vector2(150,8),Vector2(100,3)])
	detail1.color   = Color(0.36,0.32,0.24)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(90,-8),Vector2(120,-30),Vector2(120,-22),Vector2(90,-4)])
	detail2.color   = Color(0.32,0.28,0.22)
	add_child(detail2)

	var detail3 := Polygon2D.new()
	detail3.polygon = PackedVector2Array([Vector2(90,8),Vector2(120,30),Vector2(120,22),Vector2(90,4)])
	detail3.color   = Color(0.32,0.28,0.22)
	add_child(detail3)

	var detail4 := Polygon2D.new()
	detail4.polygon = PackedVector2Array([Vector2(70,-35),Vector2(70,35),Vector2(-118,35),Vector2(-118,-35)])
	detail4.color   = Color(0.2,0.24,0.2)
	add_child(detail4)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(128,0),Vector2(110,-6),Vector2(96,0),Vector2(110,6)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-140, -17.6),
		Vector2(-156.8, -12.0),
		Vector2(-140, -6.4),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-140, 6.4),
		Vector2(-156.8, 12.0),
		Vector2(-140, 17.6),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(140,0),Vector2(80,-40),Vector2(-140,-25),Vector2(-140,25),Vector2(80,40)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(148,0),Vector2(110,-48),Vector2(0,-52),Vector2(-130,-38),Vector2(-148,0),Vector2(-130,38),Vector2(0,52),Vector2(110,48)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(90.0, -11.2),
		Vector2(142.0, -11.2),
		Vector2(142.0, -8.8),
		Vector2(90.0, -8.8),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(142.0, -10.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(90.0, 8.8),
		Vector2(142.0, 8.8),
		Vector2(142.0, 11.2),
		Vector2(90.0, 11.2),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(142.0, 10.0)
	add_child(m1)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"heavy_miner", vc)
