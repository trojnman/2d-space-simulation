extends ShipInstance

## Medium Hauler — Medium cargo hauler, wide boxy hull. 90px long, 40px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(45,-10),Vector2(45,10),Vector2(35,20),Vector2(-38,20),Vector2(-45,10),Vector2(-45,-10),Vector2(-38,-20),Vector2(35,-20)])
	hull.color   = Color(0.2,0.35,0.25)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(30,-16),Vector2(30,16),Vector2(-34,16),Vector2(-34,-16)])
	detail0.color   = Color(0.18,0.26,0.2)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(-36,-14),Vector2(-36,14),Vector2(-45,10),Vector2(-45,-10)])
	detail1.color   = Color(0.14,0.2,0.16)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(44,-8),Vector2(44,8),Vector2(32,14),Vector2(32,-14)])
	detail2.color   = Color(0.2,0.28,0.22)
	add_child(detail2)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(42,0),Vector2(36,-6),Vector2(30,0),Vector2(36,6)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-44, -11.2),
		Vector2(-53.6, -8.0),
		Vector2(-44, -4.8),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-44, 4.8),
		Vector2(-53.6, 8.0),
		Vector2(-44, 11.2),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(45,-10),Vector2(45,10),Vector2(-38,20),Vector2(-45,0),Vector2(-38,-20)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(50,0),Vector2(36,-24),Vector2(0,-28),Vector2(-40,-22),Vector2(-50,0),Vector2(-40,22),Vector2(0,28),Vector2(36,24)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(40.0, -9.0),
		Vector2(48.0, -9.0),
		Vector2(48.0, -7.0),
		Vector2(40.0, -7.0),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(48.0, -8.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(40.0, 7.0),
		Vector2(48.0, 7.0),
		Vector2(48.0, 9.0),
		Vector2(40.0, 9.0),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(48.0, 8.0)
	add_child(m1)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"medium_hauler", vc)
