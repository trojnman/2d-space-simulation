extends Node2D
var tint := Color("9cf7ff")
var radius: float = 2.0
var duration: float = 0.075
var age: float = 0.0
var impact: bool = false
func _ready() -> void:
	z_index = 3
func _process(delta: float) -> void:
	age += delta
	if age >= duration: queue_free()
	queue_redraw()
func _draw() -> void:
	var fade: float = maxf(0.0, 1.0-age/duration)
	var color := Color(tint, fade)
	if impact:
		for i in 6:
			var direction := Vector2.RIGHT.rotated(i * TAU / 6)
			draw_line(direction*radius*(1.0-fade), direction*radius*(2.0-fade), color, .5)
	else:
		draw_colored_polygon(PackedVector2Array([Vector2.ZERO,Vector2(radius*.45,-radius*.25),Vector2(radius,0),Vector2(radius*.45,radius*.25)]), color)
