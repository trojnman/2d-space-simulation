extends Node2D
## Physical salvage; fly within 100 units to collect what fits.
var cargo: Dictionary = {}
func _ready() -> void:
	add_to_group("cargo_salvage")
	add_to_group("sensor_entities")
	queue_redraw()
func _draw() -> void:
	draw_rect(Rect2(-10,-10,20,20),Color(0.8,0.55,0.15),false,2)
	draw_line(Vector2(-7,-7),Vector2(7,7),Color(1,0.8,0.3),2)
	draw_line(Vector2(-7,7),Vector2(7,-7),Color(1,0.8,0.3),2)
func _physics_process(_delta: float) -> void:
	var player := PlayerState.current_ship as Player
	if is_instance_valid(player): collect(player)
func collect(player: Player) -> int:
	if player._is_docked or player._is_destroyed or player.ship_data.id == &"escape_pod" or global_position.distance_to(player.global_position)>100: return 0
	var total := 0
	for id in cargo.keys():
		var item: ItemData = GameData.items.get(id)
		if not item or item.volume <= 0: continue
		var amount := mini(int(cargo[id]), int(player.inventory.get_free_capacity(GameData.items)/item.volume))
		if amount <= 0 or not player.inventory.add_item(id,amount,GameData.items): continue
		cargo[id] -= amount
		total += amount
		if cargo[id] <= 0: cargo.erase(id)
	if total > 0: SaveManager._message("Recovered %d units of salvage" % total)
	if cargo.is_empty(): queue_free()
	return total
