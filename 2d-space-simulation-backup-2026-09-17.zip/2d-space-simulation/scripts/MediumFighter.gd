extends ShipInstance

## Medium Fighter — Medium combat ship. Sharp angular hull, 3 weapons, 2 missiles. 80px long, 38px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(40,0),Vector2(28,-8),Vector2(18,-14),Vector2(0,-19),Vector2(-30,-16),Vector2(-40,-8),Vector2(-38,0),Vector2(-40,8),Vector2(-30,16),Vector2(0,19),Vector2(18,14),Vector2(28,8)])
	hull.color   = Color(0.18,0.35,0.65)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(30,-3),Vector2(30,3),Vector2(-36,3),Vector2(-36,-3)])
	detail0.color   = Color(0.15,0.22,0.4)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(10,-14),Vector2(-10,-19),Vector2(-30,-16),Vector2(-15,-10)])
	detail1.color   = Color(0.12,0.18,0.35)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(10,14),Vector2(-10,19),Vector2(-30,16),Vector2(-15,10)])
	detail2.color   = Color(0.12,0.18,0.35)
	add_child(detail2)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(34,0),Vector2(24,-5),Vector2(18,0),Vector2(24,5)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-38, -7.8),
		Vector2(-46.4, -5.0),
		Vector2(-38, -2.2),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-38, 2.2),
		Vector2(-46.4, 5.0),
		Vector2(-38, 7.8),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(40,0),Vector2(18,-14),Vector2(-30,-16),Vector2(-40,0),Vector2(-30,16),Vector2(18,14)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(44,0),Vector2(32,-22),Vector2(0,-26),Vector2(-34,-20),Vector2(-44,0),Vector2(-34,20),Vector2(0,26),Vector2(32,22)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(16.0, -20.0),
		Vector2(42.0, -20.0),
		Vector2(42.0, -18.0),
		Vector2(16.0, -18.0),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(42.0, -19.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(16.0, 18.0),
		Vector2(42.0, 18.0),
		Vector2(42.0, 20.0),
		Vector2(16.0, 20.0),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(42.0, 19.0)
	add_child(m1)

	## Weapon barrel 2 — hidden when unequipped
	var wbarrel2 := Polygon2D.new()
	wbarrel2.polygon = PackedVector2Array([
		Vector2(36.0, -1.0),
		Vector2(42.0, -1.0),
		Vector2(42.0, 1.0),
		Vector2(36.0, 1.0),
	])
	wbarrel2.color   = Color(0.95, 0.95, 0.8)
	wbarrel2.visible = false
	add_child(wbarrel2)
	weapon_nodes.append(wbarrel2)

	var m2 := Marker2D.new()
	m2.name     = "Muzzle2"
	m2.position = Vector2(42.0, 0.0)
	add_child(m2)

	## Missile pod 0 — always visible
	var mpod0 := Polygon2D.new()
	mpod0.polygon = PackedVector2Array([
		Vector2(-5.0,       -14.5),
		Vector2(11.0, -14.5),
		Vector2(11.0, -9.5),
		Vector2(-5.0,       -9.5),
	])
	mpod0.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod0)
	missile_nodes.append(mpod0)

	var ml0 := Marker2D.new()
	ml0.name     = "MissileLaunch0"
	ml0.position = Vector2(11.0, -12.0)
	add_child(ml0)

	## Missile pod 1 — always visible
	var mpod1 := Polygon2D.new()
	mpod1.polygon = PackedVector2Array([
		Vector2(-5.0,       9.5),
		Vector2(11.0, 9.5),
		Vector2(11.0, 14.5),
		Vector2(-5.0,       14.5),
	])
	mpod1.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod1)
	missile_nodes.append(mpod1)

	var ml1 := Marker2D.new()
	ml1.name     = "MissileLaunch1"
	ml1.position = Vector2(11.0, 12.0)
	add_child(ml1)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"medium_fighter", vc)
