extends Control
const CYAN := Color("62dce8")
func _ready() -> void:
 mouse_filter=Control.MOUSE_FILTER_IGNORE
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _process(_delta: float) -> void:
 var cam=get_tree().get_first_node_in_group("free_camera")
 visible=cam and cam.is_free_mode()
 if visible:queue_redraw()
func _draw() -> void:
 var accent:Color=HUDLayout.palette_color(CYAN)
 var transform=get_viewport().get_canvas_transform()
 var selected=FleetCommandSystem.selected_ships
 var markers=FleetCommandSystem.waypoint_markers()
 for ship in selected:
  if not is_instance_valid(ship):continue
  var previous:Vector2=transform*ship.global_position
  var number:=0
  for marker in markers:
   if marker.ship!=ship:continue
   number+=1
   var point:Vector2=transform*marker.position
   draw_line(previous,point,Color(accent,0.45),1.5,true)
   _arrow(previous.lerp(point,0.6),previous.direction_to(point),accent)
   draw_circle(point,7,Color("0a1828"))
   draw_arc(point,7,0,TAU,20,accent,1.5,true)
   draw_string(ThemeDB.fallback_font,point+Vector2(10,-8),str(number),HORIZONTAL_ALIGNMENT_LEFT,-1,12,accent)
   previous=point
  if number==0:
   var ai=ship.get_node_or_null("AIShipController")
   if ai:
    var target=ai._target if is_instance_valid(ai._target) else ai._follow_target
    if is_instance_valid(target):draw_dashed_line(previous,transform*target.global_position,Color("e8ab68"),1.5,8,true)
 if FleetCommandSystem._move_drag:
  var system=FleetCommandSystem
  var a:Vector2=transform*system._move_start
  var b:Vector2=transform*system._move_end
  if system._move_draw_path:
   for i in range(1,system._move_path.size()):draw_line(transform*system._move_path[i-1],transform*system._move_path[i],accent,2,true)
  elif system._move_spread:
   draw_line(a,b,accent,2,true)
   for i in selected.size():draw_circle(a.lerp(b,float(i)/maxi(1,selected.size()-1)),5,accent)
  else:
   var heading:float=(system._move_end-system._move_start).angle()
   draw_line(a,b,accent,2,true)
   _arrow(b,a.direction_to(b),accent)
   for offset in system.formation_offsets(selected.size(),heading):draw_arc(transform*(system._move_start+offset),9,0,TAU,20,accent,2,true)
func _arrow(point:Vector2,direction:Vector2,color:Color)->void:
 if direction.length_squared()<0.01:return
 draw_line(point,point-direction.rotated(0.55)*9,color,1.5,true)
 draw_line(point,point-direction.rotated(-0.55)*9,color,1.5,true)
