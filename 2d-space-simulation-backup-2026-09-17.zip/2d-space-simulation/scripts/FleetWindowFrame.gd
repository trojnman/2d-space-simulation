extends RefCounted
static func build(window:Window,caption:String)->VBoxContainer:
 window.borderless=true
 window.transient=true
 window.exclusive=true
 var frame:=PanelContainer.new()
 frame.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 var style=preload("res://scripts/ConsoleTheme.gd").box(Color("0a1624"),Color("315766"))
 style.set_corner_radius_all(14)
 style.content_margin_left=16;style.content_margin_right=16;style.content_margin_top=12;style.content_margin_bottom=12
 frame.add_theme_stylebox_override("panel",style);window.add_child(frame)
 var layout:=VBoxContainer.new();frame.add_child(layout)
 var header:=HBoxContainer.new();layout.add_child(header)
 var title:=Label.new();title.text=caption;title.size_flags_horizontal=Control.SIZE_EXPAND_FILL;header.add_child(title)
 var close:=Button.new();close.text="X";close.pressed.connect(window.queue_free);header.add_child(close)
 layout.add_child(HSeparator.new())
 return layout
