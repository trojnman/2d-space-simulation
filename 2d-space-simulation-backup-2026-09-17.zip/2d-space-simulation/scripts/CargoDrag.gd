extends RefCounted
static func bind(control:Control,payload:Callable,accept:Callable,drop:Callable)->void:
 control.mouse_filter=Control.MOUSE_FILTER_STOP
 control.set_drag_forwarding(func(_at):
  var data=payload.call()
  if data.is_empty() or int(data.get("amount",0))<=0:return null
  control.set_drag_preview(preview(data))
  return data,
  func(_at,data):return accept.call(data),
  func(_at,data):drop.call(data))
 control.gui_input.connect(func(event):
  if event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT and event.shift_pressed:
   var data=payload.call()
   if int(data.get("amount",0))>1:split(control,data)
   control.accept_event())
static func preview(data:Dictionary)->Control:
 var label:=Label.new()
 var item=GameData.items.get(data.get("item_id"))
 label.text="%s ×%d" % [item.display_name if item else str(data.get("item_id")),data.amount]
 return label
static func split(control:Control,data:Dictionary)->void:
 var dialog:=ConfirmationDialog.new()
 dialog.title="Split stack"
 dialog.ok_button_text="Drag selected amount"
 dialog.theme=preload("res://scripts/ConsoleTheme.gd").build()
 var quantity:=SpinBox.new()
 quantity.min_value=1
 quantity.max_value=data.amount
 quantity.value=maxi(1,int(data.amount/2))
 dialog.add_child(quantity)
 control.get_tree().root.add_child(dialog)
 dialog.confirmed.connect(func():
  var part=data.duplicate()
  part.amount=int(quantity.value)
  dialog.hide()
  if is_instance_valid(control):control.force_drag.call_deferred(part,preview(part))
  dialog.queue_free())
 dialog.canceled.connect(dialog.queue_free)
 dialog.popup_centered(Vector2i(340,100))
