extends RefCounted
static func accent(hostile:bool,palette:String)->Color:
 if palette=="Red":return Color("df8cff") if hostile else Color("ffe066")
 if palette in ["Yellow","Orange"]:return Color("ff334d") if hostile else Color("42f5d7")
 return Color("ff5268") if hostile else Color("ffe066")
static func background(hostile:bool,palette:String,time:float)->Color:
 var color:=accent(hostile,palette)
 # One smooth pulse per second, with readable text throughout.
 return Color("10141c").lerp(color,.16+.30*(.5+.5*sin(time*TAU)))
