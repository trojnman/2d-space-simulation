class_name AsteroidInstance
extends Node2D

## Mineable asteroid. Spawned by SectorInstance.
## Only mining weapons (WeaponType.MINING) can damage it.
## All weapons collide with it — useful for cover.
## When destroyed, drops raw materials into the miner's inventory.

signal asteroid_destroyed(asteroid: AsteroidInstance)
signal hull_changed(current: float, maximum: float)

const MATERIAL_COLORS : Dictionary = {
	GlobalEnums.AsteroidMaterial.IRON:    Color(0.55, 0.35, 0.25),
	GlobalEnums.AsteroidMaterial.CARBON:  Color(0.18, 0.18, 0.20),
	GlobalEnums.AsteroidMaterial.SILICON: Color(0.72, 0.65, 0.45),
	GlobalEnums.AsteroidMaterial.ICE:     Color(0.70, 0.88, 0.98),
	GlobalEnums.AsteroidMaterial.GOLD:    Color(0.85, 0.72, 0.15),
}

const MATERIAL_IDS : Dictionary = {
	GlobalEnums.AsteroidMaterial.IRON:    &"iron",
	GlobalEnums.AsteroidMaterial.CARBON:  &"carbon",
	GlobalEnums.AsteroidMaterial.SILICON: &"silicon",
	GlobalEnums.AsteroidMaterial.ICE:     &"ice",
	GlobalEnums.AsteroidMaterial.GOLD:    &"gold",
}

const YIELD_RANGES : Dictionary = {
	GlobalEnums.AsteroidSize.SMALL:  [1,  3],
	GlobalEnums.AsteroidSize.MEDIUM: [3,  8],
	GlobalEnums.AsteroidSize.LARGE:  [8, 20],
}

const HULL_BY_SIZE : Dictionary = {
	GlobalEnums.AsteroidSize.SMALL:  30.0,
	GlobalEnums.AsteroidSize.MEDIUM: 80.0,
	GlobalEnums.AsteroidSize.LARGE:  200.0,
}

const RADIUS_RANGES : Dictionary = {
	GlobalEnums.AsteroidSize.SMALL:  [25.0,  55.0],
	GlobalEnums.AsteroidSize.MEDIUM: [55.0, 100.0],
	GlobalEnums.AsteroidSize.LARGE:  [100.0, 180.0],
}

var material_type : GlobalEnums.AsteroidMaterial = GlobalEnums.AsteroidMaterial.IRON
var size_class    : GlobalEnums.AsteroidSize     = GlobalEnums.AsteroidSize.MEDIUM
var hull          : float = 80.0
var max_hull      : float = 80.0

var initial_yield: int = 0
var visual_seed: int = 0
var _rng          : RandomNumberGenerator = RandomNumberGenerator.new()
var _poly         : Polygon2D             = null
var _body         : StaticBody2D          = null
var _is_destroyed : bool                  = false


func setup(mat: GlobalEnums.AsteroidMaterial, size: GlobalEnums.AsteroidSize, seed: int) -> void:
	material_type = mat
	size_class    = size
	visual_seed = seed
	_rng.seed     = seed
	max_hull      = HULL_BY_SIZE[size]
	hull          = max_hull
	add_to_group("asteroids")
	_build_visuals()
	var deposit_range:Array=YIELD_RANGES[size_class]
	_remaining_yield=_rng.randi_range(deposit_range[0],deposit_range[1])
	initial_yield=_remaining_yield


func _build_visuals() -> void:
	var radius_range : Array = RADIUS_RANGES[size_class]
	var radius       : float = _rng.randf_range(radius_range[0], radius_range[1])
	var sides        : int   = _rng.randi_range(7, 13)
	var pts          := PackedVector2Array()

	for k in sides:
		var angle : float = float(k) / float(sides) * TAU
		var r     : float = radius * _rng.randf_range(0.65, 1.35)
		pts.append(Vector2(cos(angle) * r, sin(angle) * r))

	var base_color : Color = MATERIAL_COLORS[material_type]
	var tint       : Color = Color(
		base_color.r * _rng.randf_range(0.85, 1.15),
		base_color.g * _rng.randf_range(0.85, 1.15),
		base_color.b * _rng.randf_range(0.85, 1.15)
	).clamp()

	_poly         = Polygon2D.new()
	_poly.polygon = pts
	_poly.color   = tint
	add_child(_poly)

	# Faceted rock lighting and inset craters share the collision silhouette.
	for i in pts.size():
		var facet:=Polygon2D.new()
		facet.polygon=PackedVector2Array([Vector2.ZERO,pts[i],pts[(i+1)%pts.size()]])
		var light:float=clampf(0.5-pts[i].normalized().dot(Vector2(0.7,0.7))*0.25,0.15,0.8)
		facet.color=tint.darkened(0.35).lerp(tint.lightened(0.2),light)
		add_child(facet)
	for i in 4:
		var crater:=Polygon2D.new()
		var center:=Vector2.from_angle(_rng.randf()*TAU)*radius*_rng.randf_range(0.12,0.4)
		var crater_points:=PackedVector2Array()
		for k in 9:crater_points.append(center+Vector2.from_angle(k*TAU/9)*radius*_rng.randf_range(0.06,0.12))
		crater.polygon=crater_points
		crater.color=tint.darkened(0.48)
		add_child(crater)
	var vein:=Line2D.new()
	vein.points=PackedVector2Array([Vector2(-0.35,-0.1)*radius,Vector2(-0.1,-0.25)*radius,Vector2(0.08,0.05)*radius,Vector2(0.35,0.12)*radius])
	vein.width=maxf(1,radius*0.02)
	vein.default_color=tint.lightened(0.3)
	add_child(vein)
	var outline     := Polygon2D.new()
	var outline_pts := PackedVector2Array()
	for pt in pts:
		outline_pts.append(pt * 1.04)
	outline.polygon = outline_pts
	outline.color   = tint * Color(0.4, 0.4, 0.4, 1.0)
	outline.z_index = -1
	add_child(outline)

	_body = StaticBody2D.new()
	_body.set_meta("asteroid", self)  ## tag so bullets can find us
	var col     := CollisionPolygon2D.new()
	col.polygon = pts
	_body.add_child(col)
	add_child(_body)

	var health_bar  := WorldHealthBar.new()
	health_bar.name = "HealthBar"
	add_child(health_bar)


func take_mining_damage(damage: float, miner: Node) -> void:
	if _is_destroyed: return
	hull = maxf(hull - damage, 0.0)
	hull_changed.emit(hull, max_hull)
	if hull <= 0.0:
		_destroy(miner)


var _remaining_yield: int = -1


func _destroy(miner: Node) -> void:
	if _is_destroyed: return
	if not is_instance_valid(miner) or miner.get("inventory") == null: return
	if _remaining_yield < 0:
		var yield_range: Array = YIELD_RANGES[size_class]
		_remaining_yield = _rng.randi_range(yield_range[0], yield_range[1])
	var item_id: StringName = MATERIAL_IDS[material_type]
	var item: ItemData = GameData.items.get(item_id)
	if item == null or item.volume <= 0.0: return
	var amount: int = _remaining_yield
	if miner.inventory.capacity > 0.0:
		amount = mini(amount, int(miner.inventory.get_free_capacity(GameData.items) / item.volume))
	if amount <= 0: return
	if not miner.inventory.add_item(item_id, amount, GameData.items): return
	_remaining_yield -= amount
	if miner.is_in_group("player"):
		print("Mined %d x %s" % [amount, item_id])
	# Leave uncollected ore in the asteroid for a later trip.
	if _remaining_yield > 0: return
	_is_destroyed = true
	var sector=preload("res://scripts/StationConstruction.gd").sector_of(self)
	if sector:sector.asteroid_respawns.append({"position":position,"material":material_type,"size":size_class,"seed":visual_seed,"remaining":600.0})
	asteroid_destroyed.emit(self)
	queue_free()


func receive_weapon_hit(weapon: WeaponData, attacker: Node) -> void:
	if weapon == null: return
	if weapon.weapon_type == GlobalEnums.WeaponType.MINING:
		take_mining_damage(weapon.damage, attacker)
	## Non-mining weapons collide but deal no damage — useful for cover
