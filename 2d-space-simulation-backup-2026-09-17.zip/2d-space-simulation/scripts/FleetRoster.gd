extends PanelContainer
var syncing_selection:=false
var minimized:=false
var column:VBoxContainer
var restore:Button
var formation_editor:Window
var command_host: VBoxContainer
var tree: Tree
var name_input: LineEdit
var destination: OptionButton
var timer := 0.0
var signature := ""
var collapsed: Dictionary = {}
func _ready() -> void:
 add_to_group("fleet_sidebar")
 mouse_force_pass_scroll_events=false
 theme=preload("res://scripts/ConsoleTheme.gd").compact()
 column=VBoxContainer.new()
 column.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 add_child(column)
 var title:=Label.new()
 title.text="FLEET MANAGER"
 var header:=HBoxContainer.new()
 column.add_child(header)
 title.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 header.add_child(title)
 var minimize:=Button.new()
 minimize.text="−"
 minimize.tooltip_text="Minimize fleet manager"
 minimize.pressed.connect(func():minimized=true;column.hide();restore.show())
 header.add_child(minimize)
 restore=Button.new()
 restore.text="☰"
 restore.tooltip_text="Fleet manager / ship logic"
 restore.custom_minimum_size=Vector2(34,34)
 var menu:=PopupMenu.new()
 menu.add_item("Fleet manager",0)
 menu.add_item("Ship logic",1)
 add_child(menu)
 menu.id_pressed.connect(func(id):
  if id==0:minimized=false;column.show();restore.hide()
  else:
   var logic=preload("res://scripts/ShipLogicPanel.gd").new()
   add_child(logic);logic.popup_centered())
 restore.pressed.connect(func():menu.position=Vector2i(restore.get_global_rect().end);menu.popup())
 add_child(restore)
 restore.hide()
 formation_editor=preload("res://scripts/FormationEditor.gd").new()
 add_child(formation_editor)
 formation_editor.hide()
 name_input=LineEdit.new()
 name_input.placeholder_text="New fleet name"
 var create_row:=HBoxContainer.new()
 column.add_child(create_row)
 name_input.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 create_row.add_child(name_input)
 var create:=Button.new()
 create.text="Create fleet"
 create.tooltip_text="Create a fleet from selected ships"
 create.pressed.connect(func():_assign(name_input.text.strip_edges()))
 create_row.add_child(create)
 destination=OptionButton.new()
 var assign_row:=HBoxContainer.new()
 column.add_child(assign_row)
 destination.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 assign_row.add_child(destination)
 var assign:=Button.new()
 assign.text="Assign selected"
 assign.pressed.connect(func():
  if destination.selected>=0:_assign(destination.get_item_text(destination.selected)))
 assign_row.add_child(assign)
 var remove:=Button.new()
 remove.text="Remove selected from fleet"
 remove.pressed.connect(func():_assign("",true))
 column.add_child(remove)
 var formation:=Button.new()
 formation.text="Create Formation"
 formation.tooltip_text="Arrange the selected ships and save a formation"
 formation.pressed.connect(formation_editor.open_selection)
 column.add_child(formation)
 tree=Tree.new()
 tree.hide_root=true
 tree.columns=3
 tree.set_column_title(0,"Ships / fleets")
 tree.set_column_title(1,"Ship orders")
 tree.set_column_title(2,"Turret command")
 tree.column_titles_visible=true
 tree.set_column_expand(1,false)
 tree.set_column_expand(2,false)
 tree.set_column_custom_minimum_width(1,130)
 tree.set_column_custom_minimum_width(2,130)
 tree.item_edited.connect(_command_edited)
 tree.custom_minimum_size=Vector2(200,64)
 tree.size_flags_vertical=Control.SIZE_EXPAND_FILL
 tree.select_mode=Tree.SELECT_MULTI
 tree.multi_selected.connect(func(_item,_column,_selected):
  if not syncing_selection:_select.call_deferred())
 tree.set_drag_forwarding(_drag_data,_can_drop,_drop_data)
 tree.item_collapsed.connect(func(item):
  var data=item.get_metadata(0)
  if data is String:collapsed[data]=item.collapsed)
 column.add_child(tree)
 command_host=VBoxContainer.new()
 column.add_child(command_host)
 FleetCommandSystem.selection_changed.connect(_sync_selection)
 _refresh()
func _ships() -> Array:
 var result:Array=[]
 for ship in PlayerState.fleet_ships:
  if is_instance_valid(ship) and not ship._is_destroyed:result.append(ship)
 return result
func _assign(label:String,remove:bool=false)->void:
 if label.is_empty() and not remove:return
 if label=="Unassigned":return
 for ship in FleetCommandSystem.selected_ships:
  if is_instance_valid(ship):ship.fleet_name=label
 signature=""
 _refresh()
func _process(delta:float)->void:
 var cam=get_tree().get_first_node_in_group("free_camera")
 visible=cam and cam.is_free_mode()
 if not visible:return
 position=Vector2(8,8)
 var bottom:float=get_viewport_rect().size.y-16
 var weapons=get_tree().get_first_node_in_group("weapon_control_hud")
 if weapons and weapons.is_visible_in_tree():bottom=weapons.get_global_rect().position.y-10
 size=Vector2(minf(520,get_viewport_rect().size.x*.44),maxf(80,bottom-position.y))
 scale=Vector2.ONE
 HUDLayout.apply_layout("Fleet manager",self)
 if minimized and not HUDLayout.editing:
  scale=Vector2.ONE
  size=Vector2(48,48)
 timer-=delta
 if timer<=0:timer=.5;_refresh()
 _animate_alerts()
func _refresh()->void:
 var groups:Dictionary={"Unassigned":[]}
 var next:=""
 for ship in _ships():
  var label:String=ship.fleet_name if not ship.fleet_name.is_empty() else "Unassigned"
  if not groups.has(label):groups[label]=[]
  groups[label].append(ship)
  var brain=ship.get_node_or_null("AIShipController")
  next+=str(ship.get_instance_id())+label+(str(brain.hostile_alert_seconds>0)+brain.alert_message if brain else "")
 if next==signature:return
 signature=next
 var previous:=destination.get_item_text(destination.selected) if destination.selected>=0 else ""
 destination.clear()
 tree.clear()
 var root=tree.create_item()
 for label in groups:
  if groups[label].is_empty() and label!="Unassigned":continue
  if label!="Unassigned":
   destination.add_item(label)
   if label==previous:destination.select(destination.item_count-1)
  var fleet=tree.create_item(root)
  fleet.set_text(0,"%s  (%d)" % [label,groups[label].size()])
  fleet.set_metadata(0,label)
  fleet.collapsed=collapsed.get(label,false)
  for ship in groups[label]:
   var row=tree.create_item(fleet)
   row.set_text(0,ship.ship_data.display_name)
   row.set_metadata(0,ship)
   var brain=ship.get_node_or_null("AIShipController")
   if brain and (brain.hostile_alert_seconds>0 or not brain.alert_message.is_empty()):
    var danger:bool=brain.hostile_alert_seconds>0
    for cell in 3:
     row.set_custom_bg_color(cell,Color("65252d") if danger else Color("605020"))
     row.set_custom_color(cell,Color("ffb4bb") if danger else Color("ffe390"))
     row.set_tooltip_text(cell,("Under attack" if danger else "Holding: "+brain.alert_message))
   row.set_selectable(1,false)
   row.set_selectable(2,false)
   row.set_cell_mode(1,TreeItem.CELL_MODE_RANGE)
   row.set_text(1,"Choose order,Hold position,Patrol nearby,Follow player,Defend player,Attack current target,Automated job...")
   row.set_range(1,0)
   row.set_editable(1,true)
   if not ship.ship_data.turret_sizes.is_empty():
    row.set_cell_mode(2,TreeItem.CELL_MODE_RANGE)
    row.set_text(2,"Defend,Passive,Attack enemies,Current target")
    row.set_range(2,ship.turret_order)
    row.set_editable(2,true)
   else:row.set_text(2,"Fixed weapons")
 _sync_selection(FleetCommandSystem.selected_ships)
func _sync_selection(ships:Array)->void:
 if not tree or syncing_selection:return
 syncing_selection=true
 tree.deselect_all()
 var root=tree.get_root()
 if root:
  var group=root.get_first_child()
  var first:TreeItem=null
  while group:
   var row=group.get_first_child()
   while row:
    var ship=row.get_metadata(0)
    if is_instance_valid(ship) and ship in ships:
     row.select(0)
     group.collapsed=false
     if first==null:first=row
    row=row.get_next()
   group=group.get_next()
  if first:tree.scroll_to_item(first)
 syncing_selection=false

func _select()->void:
 if syncing_selection:return
 var selected:Array[ShipInstance]=[]
 var item=tree.get_next_selected(null)
 while item:
  var data=item.get_metadata(0)
  for ship in _ships():
   if preload("res://scripts/StationConstruction.gd").sector_of(ship)!=SectorManager.current_sector:continue
   if (data is String and (ship.fleet_name==data or (data=="Unassigned" and ship.fleet_name.is_empty()))) or data==ship:
    if not selected.has(ship):selected.append(ship)
  item=tree.get_next_selected(item)
 FleetCommandSystem.selected_ships=selected
 FleetCommandSystem._refresh_circles()
 syncing_selection=true
 FleetCommandSystem.selection_changed.emit(selected)
 syncing_selection=false

func _drag_data(at:Vector2):
 var row=tree.get_item_at_position(at)
 if not row:return null
 var ships:Array=[]
 var item=tree.get_next_selected(null)
 while item:
  var data=item.get_metadata(0)
  if data is ShipInstance and is_instance_valid(data):ships.append(data)
  item=tree.get_next_selected(item)
 if ships.is_empty():
  var ship=row.get_metadata(0)
  if ship is ShipInstance:ships.append(ship)
 if ships.is_empty():return null
 var preview:=Label.new()
 preview.text="Move %d ship(s) to fleet" % ships.size()
 tree.set_drag_preview(preview)
 return {"kind":"fleet_ships","ships":ships}

func _can_drop(at:Vector2,data)->bool:
 if not data is Dictionary or data.get("kind")!="fleet_ships":return false
 var row=tree.get_item_at_position(at)
 if not row:return false
 return row.get_metadata(0) is String or row.get_metadata(0) is ShipInstance

func _drop_data(at:Vector2,data)->void:
 if not _can_drop(at,data):return
 var row=tree.get_item_at_position(at)
 var target=row.get_metadata(0)
 var label:String=target if target is String else target.fleet_name
 if label=="Unassigned":label=""
 for ship in data.ships:
  if is_instance_valid(ship) and ship in _ships():ship.fleet_name=label
 signature=""
 _refresh()

func _command_edited()->void:
 var row=tree.get_edited()
 if not row:return
 var ship=row.get_metadata(0)
 if not is_instance_valid(ship) or not ship is ShipInstance:return
 if tree.get_edited_column()==2:
  ship.set_turret_order(int(row.get_range(2)))
  return
 var ai=ship.get_node_or_null("AIShipController")
 if not ai:return
 match int(row.get_range(1)):
  1:ai.cancel_all_commands()
  2:ai.set_command_queue([{"type":GlobalEnums.FleetCommand.PATROL_AREA,"position":ship.global_position,"radius":1500.0}])
  3:ai.set_command_queue([{"type":GlobalEnums.FleetCommand.FOLLOW_SHIP,"target":PlayerState.current_ship}])
  4:ai.set_command_queue([{"type":GlobalEnums.FleetCommand.DEFEND_SHIP,"target":PlayerState.current_ship}])
  5:
   var hud=get_tree().get_first_node_in_group("targeting_hud")
   if hud and is_instance_valid(hud.target) and hud.target is ShipInstance and PlayerState.is_hostile_to_player(hud.target.faction_id):
    ai.set_command_queue([{"type":GlobalEnums.FleetCommand.ATTACK_TARGET,"target":hud.target}])
   else:
    row.set_range(1,0)
    row.set_tooltip_text(1,"Select a hostile ship target first")
  6:
   var editor=preload("res://scripts/FleetJobEditor.gd").new()
   editor.ai=ai
   add_child(editor)
   editor.popup_centered()

func _animate_alerts()->void:
 var root=tree.get_root()
 if not root:return
 var group=root.get_first_child()
 var any_hostile:=false
 var any_warning:=false
 var time:float=Time.get_ticks_msec()/1000.0
 while group:
  var row=group.get_first_child()
  while row:
   var ship=row.get_metadata(0)
   var brain=ship.get_node_or_null("AIShipController") if is_instance_valid(ship) else null
   if brain and (brain.hostile_alert_seconds>0 or not brain.alert_message.is_empty()):
    var hostile:bool=brain.hostile_alert_seconds>0
    any_hostile=any_hostile or hostile
    any_warning=any_warning or not brain.alert_message.is_empty()
    for cell in 3:
     row.set_custom_bg_color(cell,preload("res://scripts/FleetAlertStyle.gd").background(hostile,HUDLayout.color_name,time))
     row.set_custom_color(cell,preload("res://scripts/FleetAlertStyle.gd").accent(hostile,HUDLayout.color_name).lightened(.25))
    row.set_text(0,("[ATTACK] " if hostile else "[HOLD] ")+ship.ship_data.display_name)
   row=row.get_next()
  group=group.get_next()
 if any_hostile or any_warning:
  restore.modulate=preload("res://scripts/FleetAlertStyle.gd").accent(any_hostile,HUDLayout.color_name).lerp(Color.WHITE,.5+.5*sin(time*TAU))
 else:restore.modulate=Color.WHITE
