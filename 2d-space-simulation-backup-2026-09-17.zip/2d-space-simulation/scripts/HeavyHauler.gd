extends ShipInstance

## Heavy Hauler — Massive cargo hauler, elongated pill shape. 300px long, 90px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(150,-18),Vector2(150,18),Vector2(120,45),Vector2(-120,45),Vector2(-150,18),Vector2(-150,-18),Vector2(-120,-45),Vector2(120,-45)])
	hull.color   = Color(0.18,0.3,0.22)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(110,-40),Vector2(110,40),Vector2(-110,40),Vector2(-110,-40)])
	detail0.color   = Color(0.16,0.24,0.18)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(-110,-35),Vector2(-110,35),Vector2(-150,18),Vector2(-150,-18)])
	detail1.color   = Color(0.12,0.18,0.14)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(110,-35),Vector2(150,-18),Vector2(150,18),Vector2(110,35)])
	detail2.color   = Color(0.18,0.26,0.2)
	add_child(detail2)

	var detail3 := Polygon2D.new()
	detail3.polygon = PackedVector2Array([Vector2(40,-38),Vector2(40,38),Vector2(34,38),Vector2(34,-38)])
	detail3.color   = Color(0.12,0.18,0.14)
	add_child(detail3)

	var detail4 := Polygon2D.new()
	detail4.polygon = PackedVector2Array([Vector2(-30,-38),Vector2(-30,38),Vector2(-36,38),Vector2(-36,-38)])
	detail4.color   = Color(0.12,0.18,0.14)
	add_child(detail4)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(144,0),Vector2(126,-10),Vector2(112,0),Vector2(126,10)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-150, -20.4),
		Vector2(-169.2, -14.0),
		Vector2(-150, -7.6),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-150, 7.6),
		Vector2(-169.2, 14.0),
		Vector2(-150, 20.4),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(150,-18),Vector2(150,18),Vector2(-120,45),Vector2(-150,0),Vector2(-120,-45)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(160,0),Vector2(120,-52),Vector2(0,-58),Vector2(-130,-46),Vector2(-160,0),Vector2(-130,46),Vector2(0,58),Vector2(120,52)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(140.0, -13.5),
		Vector2(154.0, -13.5),
		Vector2(154.0, -10.5),
		Vector2(140.0, -10.5),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(154.0, -12.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(140.0, 10.5),
		Vector2(154.0, 10.5),
		Vector2(154.0, 13.5),
		Vector2(140.0, 13.5),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(154.0, 12.0)
	add_child(m1)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"heavy_hauler", vc)
