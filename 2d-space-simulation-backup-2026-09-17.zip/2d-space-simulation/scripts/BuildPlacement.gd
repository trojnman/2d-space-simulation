extends Node2D
const BUILD = preload("res://scripts/StationConstruction.gd")
var active := false
var yard: StationInstance
var blueprint: StringName
var _point := Vector2.ZERO
var _valid := false
var _label: Label
func _ready() -> void:
	var layer := CanvasLayer.new()
	layer.layer=99
	add_child(layer)
	_label=Label.new()
	_label.position=Vector2(24,105)
	_label.add_theme_color_override("font_color",Color("66e8dc"))
	_label.add_theme_color_override("font_shadow_color",Color.BLACK)
	_label.add_theme_constant_override("shadow_outline_size",6)
	layer.add_child(_label)
	_label.hide()
func begin(builder: StationInstance, id: StringName) -> void:
	if BUILD.problem(builder,id,&"player")!="": return
	yard=builder
	blueprint=id
	var docking=get_tree().get_first_node_in_group("docking_manager")
	if docking and docking.current_station: docking._undock()
	var camera=get_tree().get_first_node_in_group("free_camera")
	if camera and not camera.is_free_mode(): camera._enter_free_cam()
	active=true
	_label.show()
func cancel() -> void:
	active=false
	yard=null
	if _label: _label.hide()
	queue_redraw()
func _process(_delta: float) -> void:
	if not active: return
	if not is_instance_valid(yard) or BUILD.sector_of(yard)!=SectorManager.current_sector:
		cancel()
		return
	_point=get_global_mouse_position()
	_valid=BUILD.site_clear(SectorManager.current_sector,_point)
	_label.text="PLACE YOUR STATION — left-click to build • Esc/right-click to cancel\n%s | %s | $%d" % [GameData.stations[blueprint].display_name,"Clear site" if _valid else "Blocked or outside sector",BUILD.personal_price(yard,GameData.stations[blueprint])]
	queue_redraw()
func _input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if not active: return
	if event.is_action_pressed("ui_cancel") or (event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_RIGHT):
		get_viewport().set_input_as_handled()
		cancel()
	elif event is InputEventMouseButton and event.pressed and event.button_index==MOUSE_BUTTON_LEFT:
		get_viewport().set_input_as_handled()
		# Revalidate the live pointer, stock and funds at the moment of commitment.
		if BUILD.queue(yard,blueprint,&"player",get_global_mouse_position()): cancel()
func _draw() -> void:
	if not active: return
	var tint := Color(0.2,0.9,0.65,0.65) if _valid else Color(1.0,0.25,0.2,0.65)
	draw_circle(_point,300,tint,false,4)
	draw_line(_point-Vector2(340,0),_point+Vector2(340,0),tint,2)
	draw_line(_point-Vector2(0,340),_point+Vector2(0,340),tint,2)
