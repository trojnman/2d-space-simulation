extends ScrollContainer
var station: StationInstance
var _content: VBoxContainer
var _timer := 0.0
func _ready() -> void:
	horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	_content = VBoxContainer.new()
	_content.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_content.add_theme_constant_override("separation", 12)
	add_child(_content)
	refresh()
func _process(delta: float) -> void:
	_timer += delta
	if _timer >= 0.5:
		_timer = 0
		refresh()
func _label(text: String) -> void:
	var label := Label.new()
	label.text = text
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_content.add_child(label)
func refresh() -> void:
	if not _content or not is_instance_valid(station): return
	for child in _content.get_children():
		_content.remove_child(child)
		child.queue_free()
	if not station.can_share_station_info():
		_label("Construction access denied.")
		return
	var kit:=Button.new()
	kit.text="Buy construction scaffold kit - $1000 (uses 1 hull part + 1 electronics)"
	kit.pressed.connect(func():
		preload("res://scripts/StationConstruction.gd").buy_kit(station,PlayerState.current_ship as Player)
		refresh())
	_content.add_child(kit)
	_label("Deploy kits from your inventory Construction tab; deliver materials at the scaffold.")
	_label("COMPLETE STATION CONSTRUCTION")
	_label("Your builds use cargo kits and material delivery. Faction builds use faction funds and deploy nearby. All new stations start empty, with no free fleet. Test build time: 3 seconds.")
	_label("Your funds: $%d" % PlayerState.credits)
	if station.can_share_internal_info(): _label("Faction funds: $%d" % station.station_credits)
	var construction = preload("res://scripts/StationConstruction.gd")
	for job in station._station_build_queue:
		if job.get("owner", station.faction_id) != &"player" and not station.can_share_internal_info(): continue
		_label("BUILDING: %s — %.1fs remaining" % [GameData.stations[job.blueprint].display_name, maxf(0,job.remaining)])
	for id in construction.BLUEPRINTS:
		var blueprint: StationData = GameData.stations[id]
		_content.add_child(HSeparator.new())
		_label(blueprint.get_yard_class_name() if blueprint.station_type == StationData.TYPE_SHIPYARD else str(blueprint.station_type).capitalize() + " Station")
		var items := PackedStringArray()
		for item_id in StationData.BUILD_COSTS[blueprint.station_type]:
			items.append("%s %d / %d" % [GameData.items[item_id].display_name, station.inventory.get_amount(item_id), StationData.BUILD_COSTS[blueprint.station_type][item_id]])
		_label("Warehouse / required: " + "; ".join(items))
		_label("Construction wages: $%d" % construction.labor_cost(blueprint))
		var button := Button.new()
		var problem: String = construction.problem(station,id)
		button.text = ("Build station for faction" if problem == "" else problem) if station.can_share_internal_info() else "Faction expansion requires friendly relations"
		button.disabled = problem != "" or not station.can_share_internal_info()
		button.pressed.connect(func():
			if station.can_share_internal_info(): construction.queue(station,id)
			refresh())
		_content.add_child(button)
		var supplies := Button.new()
		supplies.text = "Cancel material request" if station.requested_station_blueprint == id else "Request construction materials"
		supplies.disabled = not station._station_build_queue.is_empty()
		supplies.pressed.connect(func():
			if station.can_share_station_info(): station.requested_station_blueprint = &"" if station.requested_station_blueprint == id else id
			refresh())
		_content.add_child(supplies)
