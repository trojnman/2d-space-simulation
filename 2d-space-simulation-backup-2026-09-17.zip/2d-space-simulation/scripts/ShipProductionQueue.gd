extends PanelContainer
## Shared queue panel for both yard classes. Personal orders remain visible at neutral yards.
var station: StationInstance
var _rows: VBoxContainer
var _signature := ""
var _timer := 0.0
var _bars: Array[ProgressBar] = []
var _labels: Array[Label] = []

func _ready() -> void:
	_rows = VBoxContainer.new()
	_rows.add_theme_constant_override("separation", 5)
	add_child(_rows)
	var style := StyleBoxFlat.new()
	style.bg_color = Color("102733")
	style.border_color = Color("388997")
	style.set_border_width_all(1)
	style.content_margin_left = 12
	style.content_margin_right = 12
	style.content_margin_top = 10
	style.content_margin_bottom = 10
	add_theme_stylebox_override("panel", style)
	size_flags_horizontal = Control.SIZE_EXPAND_FILL
	refresh()

func _process(delta: float) -> void:
	_timer += delta
	if _timer < 0.1: return
	_timer = 0.0
	refresh()

func refresh() -> void:
	if not is_instance_valid(station) or not _rows: return
	var orders := station.get_visible_ship_orders()
	var names := PackedStringArray()
	for order in orders: names.append(order.name + order.owner)
	var stored := PlayerState.get_station_hangar(station.station_data.id).size()
	var signature := str(names) + str(stored) + str(station._manufacture_queue.is_empty()) + str(station.can_share_internal_info())
	if signature != _signature:
		_signature = signature
		for child in _rows.get_children():
			_rows.remove_child(child)
			child.queue_free()
		_bars.clear()
		_labels.clear()
		var title := Label.new()
		title.text = "CONSTRUCTION QUEUE"
		title.add_theme_color_override("font_color", Color("56dfeb"))
		_rows.add_child(title)
		if orders.is_empty():
			var empty := Label.new()
			empty.text = "No active builds" if station._manufacture_queue.is_empty() else "Construction dock occupied — faction order details are private"
			empty.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			_rows.add_child(empty)
		for order in orders:
			var label := Label.new()
			label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
			_rows.add_child(label)
			_labels.append(label)
			var bar := ProgressBar.new()
			bar.custom_minimum_size.y = 10
			bar.show_percentage = false
			_rows.add_child(bar)
			_bars.append(bar)
		var hint := Label.new()
		hint.text = "Your completed ships: %d — collect in Hangar" % stored
		hint.add_theme_font_size_override("font_size", 12)
		_rows.add_child(hint)
	for i in orders.size():
		var order: Dictionary = orders[i]
		_labels[i].text = "%s  |  %s  |  %.1fs remaining" % [order.name, order.owner, order.remaining]
		_bars[i].value = order.progress * 100.0
