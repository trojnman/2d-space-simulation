class_name StationVisuals
extends Node2D

## Attach as child of StationInstance.
## Builds station geometry, turrets, and docking zone at runtime.
## Station types: headquarters, military, trade, mining

const TURRET_COUNTS := {
	"military":     {"guns": 6, "missiles": 2},
	"headquarters": {"guns": 4, "missiles": 2},
	"trade":        {"guns": 2, "missiles": 1},
	"mining":       {"guns": 1, "missiles": 0},
}

const FACTION_WEAPON := {
	&"terran_republic":     &"ballistic_autocannon_s2",
	&"iron_corsairs":       &"ballistic_cannon_s2",
	&"void_syndicate":      &"laser_gatling_s2",
	&"axiom_corporation":   &"laser_autocannon_s2",
	&"stellar_covenant":    &"laser_cannon_s2",
	&"free_traders_guild":  &"ballistic_gatling_s2",
	&"frontier_collective": &"ballistic_autocannon_s2",
	&"nova_guard":          &"laser_autocannon_s2",
	&"reclaimers":          &"ballistic_cannon_s2",
	&"ash_collective":      &"laser_gatling_s2",
}

const FACTION_COLORS := {
	&"terran_republic":     Color(0.25, 0.45, 0.75),
	&"free_traders_guild":  Color(0.6,  0.55, 0.2 ),
	&"iron_corsairs":       Color(0.65, 0.15, 0.15),
	&"frontier_collective": Color(0.2,  0.6,  0.3 ),
	&"void_syndicate":      Color(0.4,  0.1,  0.6 ),
	&"axiom_corporation":   Color(0.3,  0.6,  0.6 ),
	&"stellar_covenant":    Color(0.7,  0.6,  0.15),
	&"reclaimers":          Color(0.5,  0.35, 0.2 ),
	&"nova_guard":          Color(0.15, 0.5,  0.55),
	&"ash_collective":      Color(0.4,  0.4,  0.45),
}
const DEFAULT_COLOR : Color = Color(0.4, 0.4, 0.45)

var _hull_colliders: Array[CollisionPolygon2D] = []

var _station        : StationInstance = null
var _turrets        : Array[Node2D]   = []
var _rotation_speed : float           = 0.05


func _ready() -> void:
	_station = get_parent() as StationInstance
	await get_tree().process_frame
	build()


func _physics_process(delta: float) -> void:
	rotation += _rotation_speed * delta
	for collider in _hull_colliders:
		collider.rotation = rotation


func build() -> void:
	if not _station or not _station.station_data: return
	var sd    : StationData = _station.station_data
	var color : Color       = FACTION_COLORS.get(_station.faction_id, DEFAULT_COLOR)
	z_index = 1
	scale = Vector2.ONE * StationInstance.STATION_SIZE_MULTIPLIER
	_rotation_speed = 0.0
	match sd.station_type:
		"claim_beacon":
			_add_ring(35,45,8,color)
			_add_ring(70,76,8,color.lightened(0.3))
			for i in 4: _add_spoke(i*PI/2,10,85,8,color)
		"headquarters": _command_hub(color)
		"military": _bastion(color)
		"defense_platform": _defense_array(color)
		"trade": _cargo_exchange(color)
		"mining": _ore_refinery(color)
		"manufacturing": _fabrication_plant(color)
		"shipyard": _construction_dock(color, sd.capital_yard)
		_: _cargo_exchange(color)
	_build_collision(sd.station_type)
	_build_turrets(sd.station_type, color)
	_build_docking_zone(_station.get_docking_range())


# ---------------------------------------------------------------------------
# Station shapes
# ---------------------------------------------------------------------------

func _build_military(color: Color) -> void:
	_add_ring(120, 140, 12, color.darkened(0.2))
	_add_ring(60,  80,  12, color)
	_add_ring(20,  30,  8,  color.lightened(0.1))
	for i in 6:
		var angle : float = float(i) / 6.0 * TAU
		_add_spoke(angle, 80, 140, 8, color.darkened(0.15))
	for i in 6:
		var angle : float = float(i) / 6.0 * TAU + TAU / 12.0
		_add_light(Vector2(cos(angle), sin(angle)) * 130, 6, Color(1.0, 0.3, 0.2, 0.9))


func _build_headquarters(color: Color) -> void:
	_add_ring(160, 190, 16, color.darkened(0.2))
	_add_ring(80,  100, 16, color)
	_add_ring(30,  50,  12, color.lightened(0.15))
	for i in 4:
		var angle : float = float(i) / 4.0 * TAU
		_add_spoke(angle, 100, 160, 14, color.darkened(0.1))
		var pad_pos : Vector2 = Vector2(cos(angle), sin(angle)) * 170
		_add_box(pad_pos, Vector2(30, 20), angle, color.lightened(0.1))
	for i in 8:
		var angle : float = float(i) / 8.0 * TAU
		_add_light(Vector2(cos(angle), sin(angle)) * 175, 5, Color(0.3, 0.6, 1.0, 0.9))


func _build_trade(color: Color) -> void:
	_add_box(Vector2.ZERO, Vector2(300, 60), 0, color.darkened(0.1))
	_add_box(Vector2.ZERO, Vector2(80, 180), 0, color)
	_add_ring(30, 50, 10, color.lightened(0.15))
	_add_box(Vector2(160, 0),  Vector2(40, 80), 0, color.darkened(0.05))
	_add_box(Vector2(-160, 0), Vector2(40, 80), 0, color.darkened(0.05))
	for i in 4:
		var x : float = [-160.0, -80.0, 80.0, 160.0][i]
		_add_light(Vector2(x,  45), 5, Color(0.3, 1.0, 0.4, 0.9))
		_add_light(Vector2(x, -45), 5, Color(0.3, 1.0, 0.4, 0.9))


func _build_mining(color: Color) -> void:
	_add_box(Vector2.ZERO, Vector2(160, 80), 0, color.darkened(0.1))
	_add_ring(20, 40, 8, color.lightened(0.1))
	for i in 3:
		var angle : float = float(i) / 3.0 * TAU
		_add_spoke(angle, 40, 120, 10, color.darkened(0.2))
		var tip : Vector2 = Vector2(cos(angle), sin(angle)) * 130
		_add_drill_head(tip, angle, color.darkened(0.1))
	_add_box(Vector2( 90, 0), Vector2(50, 50), 0, color.darkened(0.05))
	_add_box(Vector2(-90, 0), Vector2(50, 50), 0, color.darkened(0.05))
	for i in 3:
		var angle : float = float(i) / 3.0 * TAU + TAU / 6.0
		_add_light(Vector2(cos(angle), sin(angle)) * 80, 6, Color(1.0, 0.6, 0.1, 0.9))


# ---------------------------------------------------------------------------
# Turrets
# ---------------------------------------------------------------------------

func _build_turrets(station_type: String, color: Color) -> void:
	if station_type=="defense_platform":
		for mount in preload("res://scripts/PlatformBattery.gd").mounts():
			var turret:Node2D=_make_missile_turret(mount.position,0,color) if mount.missile else _make_gun_turret(mount.position,0,true,color)
			turret.scale=Vector2.ONE*(0.85 if mount.size==3 else 0.5)
			add_child(turret)
			_turrets.append(turret)
		return
	var counts : Dictionary = TURRET_COUNTS.get(station_type, {"guns": 1, "missiles": 0})
	var n_guns : int        = counts.get("guns", 0)
	var n_miss : int        = counts.get("missiles", 0)
	var total  : int        = n_guns + n_miss
	if total == 0: return

	var turret_radius : float
	match station_type:
		"military":     turret_radius = 130.0
		"headquarters": turret_radius = 175.0
		"trade":        turret_radius = 90.0
		"mining":       turret_radius = 70.0
		_:              turret_radius = 100.0

	var faction_weapon_id : StringName = FACTION_WEAPON.get(
		_station.faction_id if _station else &"", &"ballistic_autocannon_s2"
	)
	var is_laser : bool = faction_weapon_id.begins_with("laser")

	for i in n_guns:
		var angle  : float   = float(i) / float(total) * TAU
		var tpos   : Vector2 = Vector2(cos(angle), sin(angle)) * turret_radius
		var turret := _make_gun_turret(tpos, angle, is_laser, color)
		add_child(turret)
		_turrets.append(turret)

	for i in n_miss:
		var angle  : float   = float(n_guns + i) / float(total) * TAU
		var tpos   : Vector2 = Vector2(cos(angle), sin(angle)) * turret_radius
		var turret := _make_missile_turret(tpos, angle, color)
		add_child(turret)
		_turrets.append(turret)


func _make_gun_turret(pos: Vector2, base_angle: float, is_laser: bool, color: Color) -> Node2D:
	var node := Node2D.new()
	node.position = pos
	node.add_to_group("station_turrets")
	var base     := Polygon2D.new()
	base.polygon  = PackedVector2Array([
		Vector2(-8, -8), Vector2(8, -8),
		Vector2(8,   8), Vector2(-8, 8),
	])
	base.color = color.darkened(0.3)
	node.add_child(base)
	var barrel     := Polygon2D.new()
	barrel.polygon  = PackedVector2Array([
		Vector2( 0, -2), Vector2(18, -2),
		Vector2(18,  2), Vector2( 0,  2),
	])
	barrel.color = Color(0.3, 1.0, 0.9) if is_laser else Color(0.8, 0.8, 0.7)
	node.add_child(barrel)
	node.rotation = base_angle
	return node


func _make_missile_turret(pos: Vector2, base_angle: float, color: Color) -> Node2D:
	var node := Node2D.new()
	node.position = pos
	node.add_to_group("station_turrets")
	var base     := Polygon2D.new()
	base.polygon  = PackedVector2Array([
		Vector2(-8, -8), Vector2(8, -8),
		Vector2(8,   8), Vector2(-8, 8),
	])
	base.color = color.darkened(0.4)
	node.add_child(base)
	for y in [-5.0, 5.0]:
		var pod     := Polygon2D.new()
		pod.polygon  = PackedVector2Array([
			Vector2(0,  y - 3), Vector2(14, y - 3),
			Vector2(14, y + 3), Vector2(0,  y + 3),
		])
		pod.color = Color(0.4, 0.8, 0.3)
		node.add_child(pod)
	node.rotation = base_angle
	return node


# ---------------------------------------------------------------------------
# Collision + docking zone
# ---------------------------------------------------------------------------

func _build_collision(_station_type: String) -> void:
	# Copy structural polygons into the StaticBody's local space, including the
	# visual scale. Separate shapes preserve openings in rings and shipyards.
	for old in _hull_colliders:
		_station.remove_child(old)
		old.queue_free()
	_hull_colliders.clear()
	for visual in get_children():
		if not visual is Polygon2D: continue
		var points := PackedVector2Array()
		for point in visual.polygon:
			points.append((visual.transform * point) * scale)
		if points.size() < 3: continue
		var collider := CollisionPolygon2D.new()
		collider.name = "StationHullCollision"
		collider.polygon = points
		collider.position = position
		collider.rotation = rotation
		_station.add_child(collider)
		_hull_colliders.append(collider)


func _build_docking_zone(docking_range: float) -> void:
	var zone  := Area2D.new()
	zone.name  = "DockingZone"
	zone.add_to_group("docking_zones")
	var shape  := CollisionShape2D.new()
	var circle := CircleShape2D.new()
	circle.radius = docking_range
	shape.shape   = circle
	zone.add_child(shape)
	var ring_pts := PackedVector2Array()
	var outer    := docking_range
	var inner    := docking_range - 8.0
	var segs     : int = 32
	for i in segs:
		var a1 : float = float(i)     / float(segs) * TAU
		var a2 : float = float(i + 1) / float(segs) * TAU
		ring_pts.append(Vector2(cos(a1), sin(a1)) * outer)
		ring_pts.append(Vector2(cos(a2), sin(a2)) * outer)
		ring_pts.append(Vector2(cos(a2), sin(a2)) * inner)
		ring_pts.append(Vector2(cos(a1), sin(a1)) * inner)
	var ring     := Polygon2D.new()
	ring.polygon  = ring_pts
	ring.color    = Color(0.3, 0.6, 1.0, 0.15)
	zone.add_child(ring)
	get_parent().add_child(zone)


# ---------------------------------------------------------------------------
# Drawing helpers
# ---------------------------------------------------------------------------

func _add_ring(inner: float, outer: float, segments: int, color: Color) -> void:
	for i in segments:
		var a: Vector2 = Vector2.from_angle(float(i) / segments * TAU)
		var b: Vector2 = Vector2.from_angle(float(i+1) / segments * TAU)
		var poly := Polygon2D.new()
		poly.polygon = PackedVector2Array([a*outer,b*outer,b*inner,a*inner]) if inner > 0 else PackedVector2Array([Vector2.ZERO,a*outer,b*outer])
		poly.color = color
		add_child(poly)


func _add_spoke(angle: float, inner: float, outer: float, width: float, color: Color) -> void:
	var perp  : Vector2 = Vector2(-sin(angle), cos(angle)) * width * 0.5
	var start : Vector2 = Vector2(cos(angle), sin(angle)) * inner
	var end_v : Vector2 = Vector2(cos(angle), sin(angle)) * outer
	var poly     := Polygon2D.new()
	poly.polygon  = PackedVector2Array([
		start - perp, start + perp,
		end_v + perp, end_v - perp,
	])
	poly.color = color
	add_child(poly)


func _add_box(center: Vector2, size: Vector2, angle: float, color: Color) -> void:
	var hw : float = size.x * 0.5
	var hh : float = size.y * 0.5
	var pts := PackedVector2Array([
		Vector2(-hw, -hh), Vector2( hw, -hh),
		Vector2( hw,  hh), Vector2(-hw,  hh),
	])
	var poly      := Polygon2D.new()
	poly.polygon   = pts
	poly.color     = color
	poly.position  = center
	poly.rotation  = angle
	add_child(poly)


func _add_light(pos: Vector2, radius: float, color: Color) -> void:
	var pts := PackedVector2Array()
	for i in 8:
		var angle : float = float(i) / 8.0 * TAU
		pts.append(Vector2(cos(angle), sin(angle)) * radius)
	var poly     := Polygon2D.new()
	poly.polygon  = pts
	poly.color    = color
	poly.position = pos
	add_child(poly)


func _add_drill_head(pos: Vector2, angle: float, color: Color) -> void:
	var forward : Vector2 = Vector2(cos(angle), sin(angle))
	var perp    : Vector2 = Vector2(-sin(angle), cos(angle))
	var poly     := Polygon2D.new()
	poly.polygon  = PackedVector2Array([
		pos + forward * 20,
		pos + perp    * 12,
		pos - forward * 10,
		pos - perp    * 12,
	])
	poly.color = color.darkened(0.2)
	add_child(poly)


func _command_hub(color: Color) -> void:
	_rotation_speed = .008
	_add_ring(145,175,32,color.darkened(.2))
	_add_ring(160,163,32,Color("83d8ed"))
	for i in 4:
		var a: float = i*TAU/4
		_add_spoke(a,25,164,18,color)
		_add_box(Vector2.from_angle(a)*145,Vector2(50,36),a,color.lightened(.2))
		_add_box(Vector2.from_angle(a)*148,Vector2(28,8),a,Color("96e7ef"))
	_add_ring(0,56,8,color.lightened(.1))
	_add_ring(26,31,16,Color("83d8ed"))
	_add_box(Vector2.ZERO,Vector2(22,22),PI/4,Color("d2eff6"))

func _bastion(color: Color) -> void:
	_add_ring(0,78,6,color.darkened(.2))
	for i in 6:
		var a: float = i*TAU/6
		_add_spoke(a,50,110,24,color)
		_add_box(Vector2.from_angle(a)*115,Vector2(42,54),a,color.lightened(.1))
		_add_box(Vector2.from_angle(a)*132,Vector2(5,36),a,Color("df7762"))
	_add_ring(43,49,6,Color("daaa77"))
	_add_ring(0,24,6,color.lightened(.3))

func _defense_array(color: Color) -> void:
	_add_box(Vector2.ZERO,Vector2(190,32),0,color)
	_add_box(Vector2.ZERO,Vector2(190,32),PI/2,color)
	for i in 4:
		var a: float = i*TAU/4
		_add_box(Vector2.from_angle(a)*95,Vector2(48,52),a,color.darkened(.2))
		_add_box(Vector2.from_angle(a)*112,Vector2(10,32),a,Color("e18d73"))
	_add_ring(0,42,8,color.lightened(.2))
	_add_ring(20,25,8,Color("f0c384"))

func _cargo_exchange(color: Color) -> void:
	_add_box(Vector2.ZERO,Vector2(300,30),0,color.darkened(.2))
	_add_ring(36,61,16,color)
	for side in [-1,1]:
		for x in [-120,-70,70,120]:
			_add_box(Vector2(x,side*48),Vector2(36,48),0,color.lightened(.15))
			_add_box(Vector2(x,side*48),Vector2(25,6),0,Color("6ed8b2"))
		_add_box(Vector2(side*162,0),Vector2(22,88),0,color)
		_add_light(Vector2(side*165,32),4,Color("7ce4c0"))
	_add_ring(0,23,8,Color("668f9b"))

func _ore_refinery(color: Color) -> void:
	_add_ring(0,56,8,color.darkened(.2))
	for i in 3:
		var a: float = i*TAU/3
		_add_spoke(a,35,115,24,Color("887247"))
		_add_drill_head(Vector2.from_angle(a)*120,a,Color("c29a50"))
		_add_box(Vector2.from_angle(a+.4)*75,Vector2(34,34),a,color)
	_add_ring(22,37,12,Color("d1a34d"))
	_add_light(Vector2.ZERO,12,Color("b9e6bc"))

func _fabrication_plant(color: Color) -> void:
	_add_box(Vector2.ZERO,Vector2(270,30),0,color.darkened(.3))
	for side in [-1,1]:
		for x in [-85,0,85]:
			_add_box(Vector2(x,side*56),Vector2(65,74),0,color)
			_add_box(Vector2(x,side*56),Vector2(49,48),0,Color("364650"))
			for offset in [-15,0,15]: _add_box(Vector2(x+offset,side*56),Vector2(5,36),0,Color("d7b364"))
	_add_box(Vector2(-148,0),Vector2(28,64),0,color.lightened(.2))
	_add_box(Vector2(148,0),Vector2(28,64),0,color.lightened(.2))

func _construction_dock(color: Color, capital: bool) -> void:
	var length: float = 170 if capital else 130
	var span: float = 96 if capital else 65
	_add_box(Vector2(-length+12,0),Vector2(42,span*2+40),0,color)
	for side in [-1,1]:
		_add_box(Vector2(0,side*span),Vector2(length*2,26 if capital else 20),0,color.lightened(.1))
		_add_box(Vector2(12,side*(span-9)),Vector2(length*1.7,3),0,Color("65dcd9"))
		for i in (5 if capital else 3):
			var x: float = -length+55+i*(52 if capital else 60.0)
			_add_box(Vector2(x,side*(span+18)),Vector2(26,28),0,color.darkened(.2))
			_add_box(Vector2(x,side*(span-17)),Vector2(9,28),0,Color("879ca5"))
		_add_light(Vector2(length,side*span),5,Color("8ef0dc"))
	_add_ring(0,22,8,color.lightened(.3))
	if capital:
		_add_box(Vector2(-length-16,0),Vector2(24,90),0,Color("d6b970"))
	else:
		_add_box(Vector2(-length+12,0),Vector2(20,38),0,Color("79bdc9"))
