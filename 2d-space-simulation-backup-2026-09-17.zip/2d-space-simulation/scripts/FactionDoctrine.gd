extends RefCounted
static func profile(id:StringName)->Dictionary:
 match id:
  &"ash_collective":return {"radius":14000.0,"pursuit":35.0,"attack_group":3,"war_delay":300.0,"advantage":1.1,"defensive":false}
  &"iron_corsairs":return {"radius":11000.0,"pursuit":25.0,"attack_group":2,"war_delay":0.0,"advantage":1.0,"defensive":false}
  &"free_traders_guild":return {"radius":3500.0,"pursuit":8.0,"attack_group":0,"war_delay":INF,"advantage":INF,"defensive":true}
  _:return {"radius":8000.0,"pursuit":15.0,"attack_group":5,"war_delay":600.0,"advantage":1.5,"defensive":false}
static func can_patrol_engage(ai:AIShipController,target:ShipInstance)->bool:
 if ai._is_fleet_ship or not profile(ai._ship.faction_id).defensive:return true
 for threat in ai._ship.turret_threats:
  if threat.target==target:return true
 for ally in ai._local_nodes("ships"):
  if ally is ShipInstance and ai._is_friendly(ally) and ally.position.distance_to(target.position)<3500:
   for threat in ally.turret_threats:
    if threat.target==target:return true
 for station in ai._local_nodes("stations"):
  if station.faction_id==ai._ship.faction_id and station.position.distance_to(target.position)<3500:return true
 return false
