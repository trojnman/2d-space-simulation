class_name StationInstance
extends StaticBody2D

## A station in the game world.
## StationVisuals child builds polygon, collision, and docking zone at runtime.

signal player_in_range(station: StationInstance)
signal player_out_of_range(station: StationInstance)
signal station_destroyed(station: StationInstance)
signal shield_changed(current: float, maximum: float)
signal hull_changed(current: float, maximum: float)

@export var station_data : StationData = null
@export var faction_id   : StringName  = &""

var requested_station_blueprint: StringName = &""
var production_enabled: bool = true
var visiting_traders_enabled: bool = false
var stock_targets: Dictionary = {}
# Territory defended by this asset, independent of its personal owner.
var claim_faction_id: StringName = &""
var _rogue_fire_timer: float = 0.0
var defense_cooldowns: Array[float] = []
var defense_energy: float = 100.0
var _runtime_initialized: bool = false
var constructed: bool = false
var blueprint_id: StringName = &""
var runtime_station_id: StringName = &""
var _station_build_queue: Array[Dictionary] = []

var inventory       : InventoryData    = InventoryData.new()
var _local_credits: int = 20000
var _treasury_linked: bool = false
var station_credits: int:
	get:
		return PlayerState.credits if faction_id == &"player" else (FactionManager.get_faction_credits(faction_id) if _treasury_linked else _local_credits)
	set(value):
		if faction_id == &"player":
			PlayerState.credits = maxi(0, value)
			PlayerState.credits_changed.emit(PlayerState.credits)
		elif _treasury_linked: FactionManager._faction_state[faction_id]["credits"] = maxi(0, value)
		else: _local_credits = maxi(0, value)
var hull            : float            = 1000.0
var max_hull        : float            = 1000.0
var shield: float = 0.0
var max_shield: float = 0.0
var _shield_delay_timer: float = 0.0

var _manufacture_queue    : Array[Dictionary] = []
var _player_in_range      : bool             = false
var _docking_zone         : Area2D           = null
var _is_destroyed         : bool             = false

# Temporary playtest override. Set to 0.0 to restore each recipe's normal duration.
const PLAYTEST_MANUFACTURE_SECONDS: float = 0.0
# Temporary initial stock only; set to 0 to disable. No automatic replenishment.
const PLAYTEST_SHIPYARD_BUILDS_PER_TYPE: int = 0
const AUTO_MANUFACTURE_INTERVAL : float = 10.0
var _auto_manufacture_timer : float = 0.0
var _recipe_cursor: int = 0
var _civilian_timer: float = 0.0
var requested_supply_ship: StringName = &""
var replacement_supply_ship: StringName = &""


func _ready() -> void:
	add_to_group("stations")
	var hitbox=preload("res://scripts/ShieldHitbox.gd").new()
	hitbox.name="ShieldHitbox"
	add_child(hitbox)
	if station_data:
		_do_initialize()


func initialize_runtime() -> void:
	if _runtime_initialized:return
	_runtime_initialized=true
	if faction_id == &"" and station_data.get("faction_id") != null:
		faction_id = station_data.faction_id
	if station_data.get("max_hull") != null:
		max_hull = station_data.max_hull
		hull     = max_hull
	max_shield = max_hull * station_data.shield_capacity_ratio
	shield = max_shield
	if not constructed: _seed_starting_inventory()

func _do_initialize() -> void:
	initialize_runtime()
	var scene_tree := get_tree()
	await scene_tree.process_frame
	await scene_tree.process_frame
	_connect_docking_zone()
	FactionManager.register_station(self)
	if not _treasury_linked and FactionManager._faction_state.has(faction_id):
		_local_credits = 0
		_treasury_linked = true


func _seed_starting_inventory() -> void:
	# Fresh stations start empty. Mining and trade supply every production chain.
	pass


func _connect_docking_zone() -> void:
	_docking_zone = get_node_or_null("DockingZone") as Area2D
	if _docking_zone:
		_docking_zone.body_entered.connect(_on_body_entered_dock_zone)
		_docking_zone.body_exited.connect(_on_body_exited_dock_zone)
	else:
		push_warning("StationInstance: DockingZone not found on %s" % name)


func _physics_process(delta: float) -> void:
	if _is_destroyed: return
	_regen_shield(delta)
	_defense_tick(delta)
	if faction_id == &"rogue":return
	preload("res://scripts/StationConstruction.gd").tick(self, delta)
	_process_manufacturing(delta)
	_process_civilian_demand(delta)
	_auto_manufacture_timer += delta
	if _auto_manufacture_timer >= AUTO_MANUFACTURE_INTERVAL:
		_auto_manufacture_timer = 0.0
		_auto_queue_recipes()


func can_dock() -> bool:
	return _player_in_range and station_data != null


func _on_body_entered_dock_zone(body: Node) -> void:
	if body is Player:
		_player_in_range = true
		player_in_range.emit(self)


func _on_body_exited_dock_zone(body: Node) -> void:
	if body is Player:
		_player_in_range = false
		player_out_of_range.emit(self)


# ---------------------------------------------------------------------------
# Pricing
# ---------------------------------------------------------------------------

func get_buy_price(item_id: StringName) -> int:
	var item := GameData.get_item(item_id)
	if not item: return 0
	if item.base_price>0 and item.is_component and station_data:
		# Consumers pay more than producers; hubs keep a two-sided spread.
		var factor:float=1.25 if station_data.station_type==StationData.TYPE_SHIPYARD else 1.0
		return maxi(1,int(round(item.base_price*factor)))
	return maxi(1, StationData.calc_player_sell_price(item.base_price)) if item.base_price > 0 else 0


func get_sell_price(item_id: StringName) -> int:
	var item := GameData.get_item(item_id)
	if not item: return 0
	if item.base_price>0 and item.is_component and station_data:
		var factor:float=.9 if station_data.station_type==StationData.TYPE_MANUFACTURING else 1.15
		return maxi(1,int(ceil(item.base_price*factor)))
	return StationData.calc_sell_price(item.base_price)


# ---------------------------------------------------------------------------
# Trade
# ---------------------------------------------------------------------------

func _can_receive_trade(target: InventoryData, item_id: StringName, amount: int) -> bool:
	if target == null or amount <= 0: return false
	var item: ItemData = GameData.get_item(item_id)
	if item == null: return false
	return target.get_free_capacity(GameData.items) >= item.volume * amount


func player_sell_item(item_id: StringName, amount: int, player_inv: InventoryData, _player_credits: int) -> int:
	if _is_destroyed or not station_data or player_inv == null or player_inv == inventory: return 0
	if amount <= 0 or not _station_buys_item(item_id): return 0
	if not player_inv.has_item(item_id, amount): return 0
	if not _can_receive_trade(inventory, item_id, amount): return 0
	var unit_price: int = get_buy_price(item_id)
	if unit_price <= 0 or amount > station_credits / unit_price: return 0
	var price: int = unit_price * amount
	player_inv.remove_item(item_id, amount)
	inventory.add_item(item_id, amount, GameData.items)
	_change_station_credits(-price, "Bought %d × %s" % [amount, GameData.items[item_id].display_name], "Player")
	PlayerState.add_credits(price)
	return price


func player_buy_item(item_id: StringName, amount: int, player_inv: InventoryData) -> bool:
	if _is_destroyed or not station_data or player_inv == null or player_inv == inventory: return false
	if amount <= 0 or not _station_sells_item(item_id): return false
	if not inventory.has_item(item_id, amount): return false
	if not _can_receive_trade(player_inv, item_id, amount): return false
	var unit_price: int = get_sell_price(item_id)
	if unit_price <= 0 or amount > PlayerState.credits / unit_price: return false
	var price: int = unit_price * amount
	inventory.remove_item(item_id, amount)
	player_inv.add_item(item_id, amount, GameData.items)
	_change_station_credits(price, "Sold %d × %s" % [amount, GameData.items[item_id].display_name], "Player")
	PlayerState.spend_credits(price)
	return true


func _station_buys_item(item_id: StringName) -> bool:
	if not station_data: return false
	var item : ItemData = GameData.get_item(item_id)
	if not item: return false
	match station_data.station_type:
		StationData.TYPE_DEFENSE_PLATFORM:
			return item_id in [&"missile_s1", &"missile_s3"]
		StationData.TYPE_MANUFACTURING:
			return item.is_raw_material
		StationData.TYPE_TRADE:
			return item.is_component
		StationData.TYPE_MILITARY, StationData.TYPE_HEADQUARTERS:
			return GameData.weapons.has(item_id) or GameData.shields.has(item_id) or GameData.missiles.has(item_id) or item_id == &"ballistic_ammo"
		StationData.TYPE_SHIPYARD:
			return item.is_component
	return false


func can_export_to_traders(item_id: StringName) -> bool:
	return (faction_id != &"player" or visiting_traders_enabled) and _station_sells_item(item_id)

func _station_sells_item(item_id: StringName) -> bool:
	if not station_data: return false
	var item : ItemData = GameData.get_item(item_id)
	if not item: return false
	match station_data.station_type:
		StationData.TYPE_MANUFACTURING:
			return item.is_component or (not item.is_raw_material)
		StationData.TYPE_TRADE:
			return item.is_component
		StationData.TYPE_MILITARY, StationData.TYPE_HEADQUARTERS:
			return GameData.weapons.has(item_id) or GameData.shields.has(item_id) or GameData.missiles.has(item_id) or item_id == &"ballistic_ammo"
		StationData.TYPE_SHIPYARD:
			return GameData.ships.has(item_id)
	return false


func get_items_for_sale() -> Array[StringName]:
	var result : Array[StringName] = []
	for item_id in inventory.get_all_items():
		if _station_sells_item(item_id):
			result.append(item_id)
	return result


# ---------------------------------------------------------------------------
# Repairs
# ---------------------------------------------------------------------------

func get_repair_cost(ship: ShipInstance) -> int:
	if not station_data or not station_data.offers_repairs: return 0
	var missing : float = ship.max_hull - ship.hull
	var rate    : float = 2.0
	return ceili(maxf(0, missing) / rate)


func repair_ship(ship: ShipInstance) -> int:
	if _is_destroyed or not station_data or not station_data.offers_repairs or not is_instance_valid(ship): return 0
	var cost: int = get_repair_cost(ship)
	var parts: int = ceili(maxf(0, ship.max_hull - ship.hull) / 10.0)
	if cost <= 0 or not PlayerState.can_afford(cost) or not inventory.has_item(&"hull_parts", parts): return 0
	inventory.remove_item(&"hull_parts", parts)
	_change_station_credits(cost, "Hull repair", "Player")
	PlayerState.spend_credits(cost)
	ship.hull = ship.max_hull
	ship.hull_changed.emit(ship.hull, ship.max_hull)
	return cost


# ---------------------------------------------------------------------------
# Manufacturing
# ---------------------------------------------------------------------------

func queue_manufacture(recipe: Dictionary, player_order: bool = false) -> bool:
	if _is_destroyed or not station_data: return false
	if not station_data.get_recipes().has(recipe): return false
	var output: StringName = recipe.get("output_id", &"")
	if output == &"" or int(recipe.get("output_amount", 0)) <= 0: return false
	if station_data.station_type == StationData.TYPE_SHIPYARD:
		if not _manufacture_queue.is_empty(): return false
		if not GameData.ships.has(output) or not StationSpawner.SHIP_SCENES.has(output): return false
	else:
		for job in _manufacture_queue:
			if job["recipe"].get("output_id") == output: return false
	if GameData.ships.has(output) and not FactionManager.can_add_npc_ship(&"player" if player_order else faction_id,GameData.ships[output],int(recipe.get("output_amount",1))):return false
	var inputs : Dictionary = recipe.get("inputs", {})
	for item_id in inputs:
		if int(inputs[item_id]) <= 0 or not inventory.has_item(item_id, inputs[item_id]):
			return false
	var labor: int = get_production_cost(recipe)
	if station_credits < labor: return false
	_change_station_credits(-labor, "Production wages: " + str(output).replace("_", " "), "Workers")
	FactionManager.civilian_credits += labor
	for item_id in inputs:
		inventory.remove_item(item_id, inputs[item_id])
	_manufacture_queue.append({
		"recipe":         recipe.duplicate(true),
		"player_order": player_order,
		"time_total": GameData.ships[output].manufacture_time if GameData.ships.has(output) else recipe.get("time", 30.0),
		"time_remaining": GameData.ships[output].manufacture_time if GameData.ships.has(output) else recipe.get("time", 30.0)
	})
	return true


func _auto_queue_recipes() -> void:
	if not production_enabled: return
	if not station_data: return
	if station_data.station_type == StationData.TYPE_SHIPYARD: return
	var recipes : Array = station_data.get_recipes()
	if recipes.is_empty(): return
	# Requested goods get first use of scarce inputs; retain round-robin order
	# within each tier so one recipe cannot permanently monopolize production.
	var demand: Dictionary = get_faction_supply_request()
	var ordered: Array = []
	for priority in [true, false]:
		for offset in recipes.size():
			var candidate: Dictionary = recipes[(_recipe_cursor + offset) % recipes.size()]
			var requested: bool = int(demand.get(candidate["output_id"], 0)) > 0
			if requested == priority: ordered.append(candidate)
	for recipe in ordered:
		if _manufacture_queue.size() >= 2: break
		if inventory.get_amount(recipe["output_id"]) >= get_output_target(recipe["output_id"]): continue
		var out_id         : StringName = recipe.get("output_id", &"")
		var already_queued : bool       = false
		for job in _manufacture_queue:
			if job.get("recipe", {}).get("output_id", &"") == out_id:
				already_queued = true
				break
		if already_queued: continue
		queue_manufacture(recipe)
	_recipe_cursor = (_recipe_cursor + 1) % recipes.size()


func _process_manufacturing(delta: float) -> void:
	for i in range(_manufacture_queue.size() - 1, -1, -1):
		var job : Dictionary = _manufacture_queue[i]
		job["time_remaining"] -= delta
		if job["time_remaining"] <= 0.0:
			var recipe  : Dictionary = job["recipe"]
			var out_id  : StringName = recipe.get("output_id", &"")
			var out_amt : int        = recipe.get("output_amount", 1)
			if station_data.station_type == StationData.TYPE_SHIPYARD and job.get("player_order", false):
				PlayerState.hangar_add_ship(station_data.id, out_id)
				SaveManager._message("Ship ready: %s at %s" % [GameData.ships[out_id].display_name, station_data.display_name])
				var entry: Dictionary = PlayerState.station_hangar[station_data.id].back()
				for equipment_id in StationData.get_ship_loadout(out_id):
					if GameData.weapons.has(equipment_id): entry["equipped_weapons"] = [equipment_id]
					elif GameData.shields.has(equipment_id): entry["equipped_shield"] = equipment_id
					elif GameData.missiles.has(equipment_id):
						entry["equipped_missiles"] = [equipment_id]
						entry["inventory"][equipment_id] = StationData.get_ship_loadout(out_id)[equipment_id] - 1
					else: entry["inventory"][equipment_id] = StationData.get_ship_loadout(out_id)[equipment_id]
			elif station_data.station_type == StationData.TYPE_SHIPYARD:
				var spawner: StationSpawner = null
				for child in get_children():
					if child is StationSpawner:
						spawner = child
						break
				if spawner == null: continue
				var completed_ship: ShipInstance = spawner.build_completed_ship(out_id)
				if completed_ship == null:
					continue # Keep paid work queued if launching is temporarily unavailable.
				# Equipment was reserved along with hull materials when this job began.
				spawner._equip_ship(completed_ship, completed_ship.ship_data)
				var recipient = job.get("replacement_owner")
				if is_instance_valid(recipient) and is_instance_valid(recipient._station) and not recipient._station._is_destroyed:
					recipient.accept_replacement(completed_ship, spawner)
			elif out_id != &"":
				inventory.add_item(out_id, out_amt)
				print("StationInstance [%s]: manufactured %d x %s" % [name, out_amt, out_id])
			_manufacture_queue.remove_at(i)


func get_manufacture_queue() -> Array[Dictionary]:
	return _manufacture_queue


# ---------------------------------------------------------------------------
# Damage / Destruction
# ---------------------------------------------------------------------------

func _regen_shield(delta: float) -> void:
	if not station_data or _is_destroyed:return
	var recharge_delta:=maxf(0.0,delta-_shield_delay_timer)
	_shield_delay_timer=maxf(0.0,_shield_delay_timer-delta)
	if recharge_delta>0 and shield<max_shield:
		shield=minf(max_shield,shield+max_shield/maxf(1.0,station_data.shield_recharge_seconds)*recharge_delta)
		shield_changed.emit(shield,max_shield)

func take_damage_from_weapon(weapon:WeaponData,attacker:Node=null)->void:
	var split=weapon.calc_damage_split(weapon.damage)
	_take_damage_split(split[0],split[1],attacker)

func take_damage_from_missile(missile:MissileData,attacker:Node=null)->void:
	var split=missile.calc_damage_split(missile.damage)
	_take_damage_split(split[0],split[1],attacker)

func take_damage(amount: float, attacker: Node = null) -> void:
	_take_damage_split(amount,0.0,attacker)

func _take_damage_split(shield_damage:float,hull_damage:float,attacker:Node=null)->void:
	if not PlayerState.combat_damage_allowed(attacker,self):return
	if _is_destroyed: return
	var absorbed:=minf(shield,maxf(0.0,shield_damage))
	shield-=absorbed
	_shield_delay_timer=station_data.shield_recharge_delay if station_data else 8.0
	shield_changed.emit(shield,max_shield)
	hull = maxf(hull - hull_damage - maxf(0.0,shield_damage-absorbed), 0.0)
	hull_changed.emit(hull, max_hull)
	if hull <= 0.0:
		_destroy(attacker)


func _destroy(killer: Node = null) -> void:
	if _is_destroyed: return
	_is_destroyed = true
	var remains: Dictionary = {}
	for id in inventory.get_all_items(): remains[id] = int(inventory.get_amount(id) * 0.25)
	for id in PlayerState.get_station_storage(station_data.id):
		remains[id] = int(remains.get(id,0)) + int(PlayerState.station_storage[station_data.id][id] * 0.25)
	PlayerState.station_hangar.erase(station_data.id)
	PlayerState.station_storage.erase(station_data.id)
	for id in remains.keys():
		if remains[id] <= 0: remains.erase(id)
	if not remains.is_empty():
		var debris := preload("res://scripts/CargoSalvage.gd").new()
		debris.cargo = remains
		debris.position = position
		get_parent().add_child.call_deferred(debris)
	if is_inside_tree():
		var docking := get_tree().get_first_node_in_group("docking_manager")
		if docking and docking.current_station == self:
			docking._undock()
			var player := PlayerState.current_ship as Player
			if player: player._destroy(killer)
	station_destroyed.emit(self)
	FactionManager.on_station_destroyed(self, killer)
	queue_free()


# ---------------------------------------------------------------------------
# Faction economy helpers
# ---------------------------------------------------------------------------

func faction_buy_item(item_id: StringName, amount: int, buyer_credits: int) -> int:
	if not inventory.has_item(item_id, amount): return 0
	var price : int = get_sell_price(item_id) * amount
	if buyer_credits < price: return 0
	inventory.remove_item(item_id, amount)
	_change_station_credits(price, "Goods sold to faction buyer", "Faction trade")
	return price


func faction_sell_item(item_id: StringName, amount: int, buyer_station: StationInstance) -> bool:
	if not inventory.has_item(item_id, amount): return false
	var price : int = get_buy_price(item_id) * amount
	if buyer_station.station_credits < price: return false
	inventory.remove_item(item_id, amount)
	buyer_station.inventory.add_item(item_id, amount)
	buyer_station._change_station_credits(-price, "Goods purchased", station_data.display_name)
	_change_station_credits(price, "Goods sold", buyer_station.station_data.display_name)
	return true


func get_production_cost(recipe: Dictionary) -> int:
	# Provisional worker payment; transferred to civilian economy, never deleted.
	return maxi(1, int(ceil(float(recipe.get("time", 30.0)) / 10.0)))


func get_ship_recipe(ship_id: StringName) -> Dictionary:
	if not station_data or station_data.station_type != StationData.TYPE_SHIPYARD: return {}
	for recipe in station_data.get_recipes():
		if recipe["output_id"] == ship_id: return recipe
	return {}


func get_ship_order_price(ship_id: StringName) -> int:
	var recipe: Dictionary = get_ship_recipe(ship_id)
	if recipe.is_empty(): return 0
	var cost: int = get_production_cost(recipe)
	for item_id in recipe["inputs"]:
		var item: ItemData = GameData.items.get(item_id)
		if not item: return 0
		cost += item.base_price * int(recipe["inputs"][item_id])
	return maxi(int(cost * 1.25), GameData.ships[ship_id].base_price)


func get_ship_order_problem(ship_id: StringName) -> String:
	var recipe: Dictionary = get_ship_recipe(ship_id)
	if recipe.is_empty() or not StationSpawner.SHIP_SCENES.has(ship_id): return "Unavailable here"
	if _is_destroyed: return "Station destroyed"
	if not _manufacture_queue.is_empty(): return "Shipyard busy"
	if not PlayerState.can_afford(get_ship_order_price(ship_id)): return "Insufficient credits"
	for item_id in recipe["inputs"]:
		if not inventory.has_item(item_id, recipe["inputs"][item_id]):
			return "Needs %s (%d/%d)" % [GameData.items[item_id].display_name, inventory.get_amount(item_id), recipe["inputs"][item_id]]
	return ""


func order_player_ship(ship_id: StringName) -> bool:
	if get_ship_order_problem(ship_id) != "": return false
	var price: int = get_ship_order_price(ship_id)
	# Apply payment before funding worker costs; roll back if queue validation fails.
	_change_station_credits(price, "Ship order: " + GameData.ships[ship_id].display_name, "Player")
	if not queue_manufacture(get_ship_recipe(ship_id), true):
		_change_station_credits(-price, "Cancelled ship order refund", "Player")
		return false
	PlayerState.spend_credits(price)
	if requested_supply_ship == ship_id: requested_supply_ship = &""
	return true


func request_ship_supplies(ship_id: StringName) -> bool:
	if _is_destroyed or get_ship_recipe(ship_id).is_empty() or not StationSpawner.SHIP_SCENES.has(ship_id): return false
	requested_supply_ship = ship_id
	return true


func get_faction_supply_request() -> Dictionary:
	# Aggregate selected construction and ship builds across this sector.
	var needs: Dictionary = {}
	for station in _economy_stations():
		if not station is StationInstance or station._is_destroyed or station.faction_id != faction_id: continue
		if station.station_data and station.station_data.station_type==StationData.TYPE_DEFENSE_PLATFORM:
			for missile_id in [&"missile_s1", &"missile_s3"]:
				var missing:int=maxi(0,60-station.inventory.get_amount(missile_id))
				if missing>0:needs[missile_id]=int(needs.get(missile_id,0))+missing
		if GameData.stations.has(station.requested_station_blueprint):
			for material in StationData.BUILD_COSTS.get(GameData.stations[station.requested_station_blueprint].station_type, {}):
				needs[material] = int(needs.get(material, 0)) + int(StationData.BUILD_COSTS[GameData.stations[station.requested_station_blueprint].station_type][material])
		var recipe: Dictionary = station.get_ship_recipe(station.requested_supply_ship if station.requested_supply_ship != &"" else station.replacement_supply_ship)
		for item_id in recipe.get("inputs", {}):
			needs[item_id] = int(needs.get(item_id, 0)) + int(recipe["inputs"][item_id])
	return needs


func get_output_target(item_id: StringName) -> int:
	var target: int = 20
	if item_id == &"ballistic_ammo": target = 400
	elif GameData.weapons.has(item_id) or GameData.shields.has(item_id):
		target = 4 if item_id in [&"ballistic_gatling_s1", &"mining_laser_s1", &"shield_s1_average"] else 1
	elif GameData.missiles.has(item_id): target = 10 if item_id == &"missile_s1" else 1
	for station in _economy_stations():
		if station is StationInstance and not station._is_destroyed and station.faction_id == faction_id:
			target = maxi(target, station.get_input_reserve(item_id) * 2)
	return target


func set_stock_target(item_id: StringName, amount: int) -> void:
	if faction_id != &"player" or not GameData.items.has(item_id): return
	if amount <= 0: stock_targets.erase(item_id)
	else: stock_targets[item_id] = mini(amount, 1000000)

func get_supply_target(item_id: StringName) -> int:
	var target: int = maxi(get_input_reserve(item_id) * 2, int(stock_targets.get(item_id, 0)) if faction_id == &"player" else 0)
	if station_data and station_data.station_type == StationData.TYPE_TRADE and item_id == &"water": target = maxi(target, 20)
	return target

func get_export_reserve(item_id: StringName) -> int:
	return maxi(get_input_reserve(item_id), int(stock_targets.get(item_id, 0)) if faction_id == &"player" else 0)

func get_input_reserve(item_id: StringName) -> int:
	if not station_data: return 0
	if station_data.station_type==StationData.TYPE_DEFENSE_PLATFORM and item_id in [&"missile_s1", &"missile_s3"]:return 30
	var needed: int = 2 if item_id == &"hull_parts" and station_data.offers_repairs else 0
	if GameData.stations.has(requested_station_blueprint):
		needed = maxi(needed, int(StationData.BUILD_COSTS.get(GameData.stations[requested_station_blueprint].station_type, {}).get(item_id, 0)))
	var requested: Dictionary = get_faction_supply_request()
	var selected_recipe := get_ship_recipe(requested_supply_ship if requested_supply_ship != &"" else replacement_supply_ship)
	needed = maxi(needed, int(selected_recipe.get("inputs", {}).get(item_id, 0)))
	for recipe in station_data.get_recipes():
		var output: String = str(recipe["output_id"])
		var large_optional: bool = output.contains("_s2") or output.contains("_s3") or output.begins_with("medium_") or output.begins_with("heavy_") or output.begins_with("large_") or output == "construction_ship"
		# Only hold larger equipment inputs when a yard has explicitly requested them.
		if large_optional and not requested.has(recipe["output_id"]): continue
		needed = maxi(needed, int(recipe["inputs"].get(item_id, 0)))
	return needed


func get_production_report() -> Array[Dictionary]:
	# Read-only view of the same requirements used by the production scheduler.
	var report: Array[Dictionary] = []
	if not station_data: return report
	for recipe in station_data.get_recipes():
		var id: StringName = recipe["output_id"]
		var display: String = GameData.items[id].display_name if GameData.items.has(id) else str(id).replace("_", " ").capitalize()
		if GameData.ships.has(id): display = GameData.ships[id].display_name
		var target: int = get_output_target(id) if station_data.station_type != StationData.TYPE_SHIPYARD else 0
		var stock: int = inventory.get_amount(id)
		var reasons := PackedStringArray()
		for input_id in recipe["inputs"]:
			var required: int = recipe["inputs"][input_id]
			var available: int = inventory.get_amount(input_id)
			if available < required:
				reasons.append("%s %d/%d" % [GameData.items[input_id].display_name, available, required])
		var labor: int = get_production_cost(recipe)
		if station_credits < labor: reasons.append("Worker payment $%d / $%d" % [station_credits, labor])
		var state := "Ready"
		var detail := "Waiting for next production cycle"
		var remaining: float = -1.0
		var replacement: bool = false
		for job in _manufacture_queue:
			if job["recipe"]["output_id"] == id:
				remaining = job["time_remaining"]
				replacement = job.has("replacement_owner")
				break
		if _is_destroyed:
			state = "Stopped"
			detail = "Station destroyed"
		elif remaining >= 0.0:
			state = "Producing"
			detail = ("Faction replacement • " if replacement else "") + "%ds remaining" % ceili(maxf(0.0, remaining))
		elif target > 0 and stock >= target:
			state = "Stocked"
			detail = "Stock target reached"
		elif not reasons.is_empty():
			state = "Waiting for supplies"
			detail = "; ".join(reasons)
		elif station_data.station_type == StationData.TYPE_SHIPYARD:
			state = "Ready to order"
			detail = "Place a paid order in the Shipyard tab"
		elif _manufacture_queue.size() >= 2:
			state = "Queued behind other work"
			detail = "Both production slots are occupied"
		report.append({"id": id, "name": display, "state": state, "detail": detail, "stock": stock, "target": target, "labor": labor})
	return report


func can_share_station_info() -> bool:
	return not _is_destroyed and not PlayerState.is_hostile_to_player(faction_id)

func can_share_internal_info() -> bool:
	return can_share_station_info() and PlayerState.is_friendly_to_player(faction_id)

func get_public_station_details() -> String:
	if not can_share_station_info(): return "ACCESS DENIED — hostile faction. Internal station information is unavailable."
	var lines := PackedStringArray()
	if can_share_internal_info():
		lines.append("Hull: %d / %d" % [hull, max_hull])
		lines.append("Shared faction treasury: $%d" % station_credits)
	lines.append("Docking range: %d" % get_docking_range())
	lines.append("Repairs: " + ("Available" if station_data.offers_repairs else "Unavailable"))
	if can_share_internal_info() and requested_supply_ship != &"": lines.append("Supply request: " + GameData.ships[requested_supply_ship].display_name)
	lines.append("\nMARKET / INVENTORY")
	for id in GameData.items:
		var sells: bool = _station_sells_item(id)
		var buys: bool = _station_buys_item(id)
		var amount: int = inventory.get_amount(id)
		if not sells and not buys and (amount == 0 or not can_share_internal_info()): continue
		lines.append("%s: %d | Buy %s | Sell %s" % [GameData.items[id].display_name, amount, "$%d" % get_sell_price(id) if sells else "—", "$%d" % get_buy_price(id) if buys else "—"])
	if not can_share_internal_info(): return "\n".join(lines)
	lines.append("\nPRODUCTION")
	var report := get_production_report()
	if report.is_empty(): lines.append("No manufacturing facilities")
	for entry in report:
		lines.append("%s — %s\n%s" % [entry["name"], entry["state"], entry["detail"]])
	return "\n".join(lines)


func _change_station_credits(delta: int, reason: String, counterparty: String) -> void:
	var before: int = station_credits
	station_credits += delta
	if _treasury_linked or faction_id == &"player":
		FactionManager.record_treasury_change(faction_id, station_credits-before, reason, station_data.display_name if station_data else name, counterparty)


func get_ship_sale_catalog() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if not can_share_station_info() or station_data.station_type != StationData.TYPE_SHIPYARD: return result
	for recipe in station_data.get_recipes():
		var id: StringName = recipe["output_id"]
		if not StationSpawner.SHIP_SCENES.has(id): continue
		var stocked: bool = true
		for item_id in recipe["inputs"]:
			if not inventory.has_item(item_id, recipe["inputs"][item_id]): stocked = false
		result.append({"id": id, "name": GameData.ships[id].display_name, "price": get_ship_order_price(id), "stocked": stocked, "busy": not _manufacture_queue.is_empty()})
	return result

const STATION_SIZE_MULTIPLIER: float = 1.5
func get_docking_range() -> float:
	return station_data.docking_range * STATION_SIZE_MULTIPLIER if station_data else 450.0


func get_visible_ship_orders() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	if not can_share_station_info(): return result
	for job in _manufacture_queue:
		if not job.get("player_order", false) and not can_share_internal_info(): continue
		var id: StringName = job["recipe"].get("output_id", &"")
		if not GameData.ships.has(id): continue
		var total: float = job.get("time_total", PLAYTEST_MANUFACTURE_SECONDS if PLAYTEST_MANUFACTURE_SECONDS > 0.0 else job["recipe"].get("time", 30.0))
		var remaining: float = maxf(0.0, job["time_remaining"])
		result.append({"name": GameData.ships[id].display_name, "owner": "Your order" if job.get("player_order", false) else ("Fleet replacement" if job.has("replacement_owner") else "Faction order"), "remaining": remaining, "progress": clampf(1.0 - remaining / maxf(total, 0.001), 0.0, 1.0)})
	return result


func _economy_stations() -> Array:
	if is_inside_tree(): return get_tree().get_nodes_in_group("stations")
	var sector: Node = get_parent()
	while sector and not sector is SectorInstance: sector = sector.get_parent()
	return SectorManager.get_sector_stations(sector) if sector else []


func transfer_owned_warehouse(ship: ShipInstance, item_id: StringName, amount: int, deposit: bool) -> bool:
	if faction_id != &"player" or _is_destroyed or not is_instance_valid(ship) or not ship.is_in_group("player"): return false
	if amount <= 0 or ship.global_position.distance_to(global_position) > get_docking_range(): return false
	var source: InventoryData = ship.inventory if deposit else inventory
	var target: InventoryData = inventory if deposit else ship.inventory
	if not source.has_item(item_id, amount) or not target.add_item(item_id, amount, GameData.items): return false
	source.remove_item(item_id, amount)
	return true


func _rogue_defense_tick(delta: float) -> void:
	_regen_shield(delta)
	_defense_tick(delta)

func _defense_tick(delta: float) -> void:
	if not _is_destroyed and station_data and station_data.station_type==&"defense_platform":
		preload("res://scripts/PlatformBattery.gd").tick(self,delta)
		return
	if _is_destroyed or not station_data or station_data.station_type not in [&"defense_platform", &"military"]:return
	defense_energy=minf(100.0,defense_energy+10.0*delta)
	_rogue_fire_timer=maxf(0,_rogue_fire_timer-delta)
	if _rogue_fire_timer>0:return
	var weapon: WeaponData=GameData.weapons.get(&"laser_autocannon_s2")
	if not weapon or defense_energy<weapon.energy_per_shot:return
	var sector=preload("res://scripts/StationConstruction.gd").sector_of(self)
	if not sector:return
	var candidates: Array=[]
	if is_inside_tree():candidates=get_tree().get_nodes_in_group("ships")
	else:candidates=sector.find_children("*","",true,false)
	var target: ShipInstance
	var distance:=weapon.max_range
	for ship in candidates:
		if not ship is ShipInstance or ship._is_destroyed or ship.is_queued_for_deletion() or not ship.ship_data or ship.ship_data.id==&"escape_pod":continue
		var enemy_faction: StringName=&"player" if ship.is_in_group("player") or ship.is_in_group("player_fleet") else ship.faction_id
		if not FactionManager.are_at_war(faction_id,enemy_faction):continue
		var d:=position.distance_to(ship.position)
		if d<distance:target=ship;distance=d
	if not target:return
	if is_inside_tree():
		var direction:=global_position.direction_to(target.global_position)
		var shot=load("res://scenes/Bullet.tscn").instantiate()
		shot.position=global_position+direction*200
		shot.launch(direction*weapon.projectile_speed,self,weapon)
		sector.add_child(shot)
	else:
		target.take_damage_from_weapon(weapon,self)
	defense_energy-=weapon.energy_per_shot
	_rogue_fire_timer=60.0/maxf(1,weapon.fire_rate_rpm)


func _process_civilian_demand(delta: float) -> void:
	if _is_destroyed or not station_data or station_data.station_type != StationData.TYPE_TRADE or faction_id == &"rogue": return
	_civilian_timer += delta
	if _civilian_timer < 60.0: return
	var periods: int = int(_civilian_timer / 60.0)
	_civilian_timer = fmod(_civilian_timer, 60.0)
	var price: int = get_sell_price(&"water")
	if price <= 0: return
	var amount: int = mini(periods * 2, inventory.get_amount(&"water"))
	amount = mini(amount, int(FactionManager.civilian_credits / price))
	if amount <= 0: return
	inventory.remove_item(&"water", amount)
	FactionManager.civilian_credits -= amount * price
	_change_station_credits(amount * price, "Civilian water purchases", "Civilians")
