class_name FogOfWar
extends Node

## Tracks everything the player has ever seen.
## Live contacts = currently in sensor range.
## Last-known contacts = seen before but now out of range.

## contact_id (instance id) → contact dict
var _live_contacts      : Dictionary = {}
var _last_known         : Dictionary = {}

## Current sensor coverage circles this frame
var _sensor_circles : Array[Dictionary] = []


func update_sensor_coverage(circles: Array[Dictionary]) -> void:
	_sensor_circles = circles


func update_contact(contact_id: int, data: Dictionary) -> void:
	if data.get("in_range", false):
		_live_contacts[contact_id] = data.duplicate()
		## Also update last known when in range
		_last_known[contact_id] = data.duplicate()
	else:
		## Out of range — move to last known if we've seen it
		_live_contacts.erase(contact_id)
		## Last known stays as-is (position frozen at last seen)


func is_revealed(world_pos: Vector2) -> bool:
	for c in _sensor_circles:
		if world_pos.distance_squared_to(c["center"]) <= c["radius"] * c["radius"]:
			return true
	return false


func get_live_contacts() -> Dictionary:
	return _live_contacts


func get_last_known_contacts() -> Dictionary:
	return _last_known


func get_all_contacts_for_map() -> Array[Dictionary]:
	## Returns all contacts for map drawing
	## Live contacts have "live": true, last known have "live": false
	var result : Array[Dictionary] = []

	for id in _last_known:
		var contact : Dictionary = _last_known[id].duplicate()
		if not _live_contacts.has(id) and contact.get("type") != "station": continue
		if not is_instance_valid(contact.get("node")): continue
		contact["live"] = _live_contacts.has(id)
		result.append(contact)

	return result


func clear_sector() -> void:
	## Call when jumping to a new sector
	_live_contacts.clear()
	_last_known.clear()
	_sensor_circles.clear()
