extends CanvasLayer
var panel: PanelContainer
func _ready() -> void:
	layer = 40
	process_mode = Node.PROCESS_MODE_ALWAYS
	panel = PanelContainer.new()
	panel.theme = preload("res://scripts/ConsoleTheme.gd").build()
	panel.position = Vector2(24, 70)
	panel.size = Vector2(610, 390)
	add_child(panel)
	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]: margin.add_theme_constant_override("margin_" + side, 18)
	panel.add_child(margin)
	var box := VBoxContainer.new()
	margin.add_child(box)
	var label := Label.new()
	label.text = "SOL PRIME — FIRST PLAYTEST\n\nWASD: move    Shift: brake    Mouse: aim\nLeft-click: fire    1 / 2: weapon groups\nRight-click: select missiles; release to arm; click again to fire\nHover stations: info    T: pin info    Esc: clear\nI: inventory    Tab: target    X: clear targets    M: map    E: dock near a station\nB: economy / production / faction funds    F1: this guide\n\nTry docking at Terran Shipyard and ordering a small ship.\nMaterials and gear must arrive before an order is available.\nBuilds take time, then appear in that station's Hangar tab.\nDocking and map keep the economy running; inventory pauses it.\n\nL: long-range scanner ping (60-second contact markers)\nF5: quicksave    F9: load checkpoint (replaces current progress).\nAfter restarting, press F9 to continue your saved game.\nStay in Sol Prime for this first test."
	label.add_theme_font_size_override("font_size", 16)
	box.add_child(label)
	var close := Button.new()
	close.text = "Begin — F1 reopens this guide"
	close.pressed.connect(func(): panel.hide())
	box.add_child(close)
func _unhandled_input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if event is InputEventKey and event.pressed and not event.echo and event.physical_keycode == KEY_F1:
		panel.visible = not panel.visible
		get_viewport().set_input_as_handled()
