class_name MissileSystem
extends Node

## Handles the missile arming and firing flow.
## Attach to the Player node as a child named 'MissileSystem'.
## States: IDLE -> SELECTING -> ARMING -> ARMED

enum State { IDLE, SELECTING, ARMING, ARMED }

var _arm_button_held: bool = false

const ARM_TIME := { 1: 1.0, 2: 2.0, 3: 3.0 }

signal state_changed(state: State)
signal armed_count_changed(count: int, max_count: int)
signal arm_progress_changed(progress: float)
signal missiles_fired(count: int)

var _state          : State  = State.IDLE
var _player         : Player = null
var _selected_count : int    = 0
var _armed_count    : int    = 0
var _arm_timer      : float  = 0.0
var _arm_total      : float  = 0.0
var _arming_index   : int    = 0


func _ready() -> void:
	_player = get_parent() as Player


func _process(delta: float) -> void:
	if _state == State.ARMING:
		_arm_timer -= delta
		var progress : float = 1.0 - (_arm_timer / _arm_total) if _arm_total > 0.0 else 1.0
		arm_progress_changed.emit(progress)
		if _arm_timer <= 0.0:
			_arming_index += 1
			if _arming_index >= _selected_count:
				_armed_count = _selected_count
				_set_state(State.ARMED)
			else:
				_start_next_arm()


func _input(event: InputEvent) -> void:
	if BuildPlacement.active: return
	if _player == null or _player._is_docked: return
	## Block input when inventory or map is open
	if get_tree().paused: return
	if not event is InputEventMouseButton: return
	var mb := event as InputEventMouseButton
	if mb.button_index == MOUSE_BUTTON_RIGHT:
		_arm_button_held = mb.pressed
		get_viewport().set_input_as_handled()
		if mb.pressed:
			_on_right_press()
		else:
			_on_right_release()
	elif _arm_button_held and mb.pressed and mb.button_index in [MOUSE_BUTTON_WHEEL_UP, MOUSE_BUTTON_WHEEL_DOWN]:
		get_viewport().set_input_as_handled()
		if _state != State.SELECTING: return
		if mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_UP:
			_change_selection(1)
		elif mb.pressed and mb.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			_change_selection(-1)


func _on_right_press() -> void:
	match _state:
		State.IDLE:
			if _get_max_missiles() == 0: return
			_selected_count = 1
			_set_state(State.SELECTING)
			armed_count_changed.emit(_selected_count, _get_max_missiles())
		State.ARMED:
			_fire_armed()


func _on_right_release() -> void:
	if _state == State.SELECTING:
		_selected_count = mini(_selected_count, _get_max_missiles())
		if _selected_count > 0 and _has_missiles():
			_arming_index = 0
			_start_next_arm()
			_set_state(State.ARMING)
		else:
			_set_state(State.IDLE)


func _change_selection(delta: int) -> void:
	var max_count : int = _get_max_missiles()
	if max_count <= 0:
		cancel()
		return
	_selected_count = clampi(_selected_count + delta, 1, max_count)
	armed_count_changed.emit(_selected_count, max_count)


func _get_max_missiles() -> int:
	if not _player or not _player.ship_data: return 0
	if _player.ship_data.missile_slots <= 0: return 0
	var size: int = clampi(int(_player.ship_data.ship_class), 0, 2)
	var slot_count: int = [6, 12, 18][size] if str(_player.ship_data.id).contains("missile_boat") else [2, 4, 6][size]
	var m := _get_equipped_missile()
	if m == null: return 0
	var mid : StringName = _resolve_missile_id(m)
	if mid == &"": return 0
	var inv_count : int = _player.inventory.get_amount(mid)
	return mini(slot_count, inv_count)


func _has_missiles() -> bool:
	return _get_max_missiles() > 0


func _get_equipped_missile() -> MissileData:
	if not _player: return null
	for m in _player.equipped_missiles:
		if m != null: return m
	return null


func _resolve_missile_id(m: MissileData) -> StringName:
	if m == null: return &""
	if m.get("id") != null and m.id != &"":
		return m.id
	for mid in GameData.missiles:
		if GameData.missiles[mid] == m:
			return mid
	return &""


func _get_arm_time() -> float:
	var m := _get_equipped_missile()
	if m == null: return 1.0
	var size : int = m.equip_size if m.get("equip_size") != null else 1
	return ARM_TIME.get(size, 1.0)


func _start_next_arm() -> void:
	_arm_total = _get_arm_time()
	_arm_timer = _arm_total
	arm_progress_changed.emit(0.0)


func _fire_armed() -> void:
	if _armed_count <= 0:
		_set_state(State.IDLE)
		return
	var m := _get_equipped_missile()
	if m == null:
		_set_state(State.IDLE)
		return
	var scene : PackedScene = _player.missile_scene
	if m.get("scene") != null and m.scene != null:
		scene = m.scene
	if scene == null:
		push_warning("MissileSystem: no missile scene")
		_set_state(State.IDLE)
		return
	var missile_id : StringName = _resolve_missile_id(m)
	## Aim toward mouse, not ship rotation
	var mouse_pos   : Vector2 = _player.get_global_mouse_position()
	var aim_dir     : Vector2 = _player.global_position.direction_to(mouse_pos)
	var aim_angle   : float   = aim_dir.angle()
	var targeting=get_tree().get_first_node_in_group("targeting_hud")
	var locked:Node2D=targeting.missile_lock() if targeting else null
	if is_instance_valid(locked):
		aim_angle=_player.global_position.direction_to(locked.global_position).angle()
	var fired : int = 0
	for i in _armed_count:
		if missile_id != &"" and not _player.inventory.has_item(missile_id, 1):
			break
		if missile_id != &"":
			_player.inventory.remove_item(missile_id, 1)
		var proj : Node2D = scene.instantiate()
		proj.global_position = _player.get_missile_launch_position(0)
		proj.rotation        = aim_angle
		if _armed_count > 1:
			var spread: float = deg_to_rad((float(i) / float(_armed_count - 1) - 0.5) * 24.0)
			if proj.has_method("configure_volley"):
				proj.configure_volley(aim_angle, spread)
			else:
				proj.rotation += spread
		if proj.has_method("launch"):
			proj.launch(_player.velocity, _player, m)
		if is_instance_valid(locked):
			proj._target=locked
			proj._target_acquired=true
		SectorManager.add_sector_entity(proj)
		fired += 1
	missiles_fired.emit(fired)
	_armed_count   = 0
	_selected_count = 0
	_set_state(State.IDLE)


func cancel() -> void:
	_arm_button_held = false
	_armed_count    = 0
	_selected_count = 0
	_arm_timer      = 0.0
	_set_state(State.IDLE)


func _set_state(new_state: State) -> void:
	_state = new_state
	state_changed.emit(new_state)


func get_state() -> State:
	return _state

func get_selected_count() -> int:
	return _selected_count

func get_armed_count() -> int:
	return _armed_count

func is_arm_button_held() -> bool:
	return _arm_button_held
