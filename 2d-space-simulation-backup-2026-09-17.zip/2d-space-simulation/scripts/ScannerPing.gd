extends Control
## Snapshot intelligence: never grants live vision or updates unseen positions.
const DURATION:float=60.0
const FADE:float=5.0
const SWEEP_SECONDS:float=5.0
const GROUPS:Array[String]=["ships","stations","asteroids","jump_gates","derelicts","hazards","points_of_interest","satellites","salvage"]
var scans:Dictionary={}
func _ready()->void:
 mouse_filter=Control.MOUSE_FILTER_IGNORE
 set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
func _input(event:InputEvent)->void:
 if get_tree().paused or preload("res://scripts/UIInput.gd").typing(get_viewport()):return
 if event is InputEventKey and event.pressed and not event.echo and event.keycode==KEY_L:
  ping()
  get_viewport().set_input_as_handled()
func ping()->void:
 var sector:SectorInstance=SectorManager.current_sector
 if not is_instance_valid(sector) or not is_instance_valid(PlayerState.current_ship):return
 var source:Vector2=sector.to_local(PlayerState.current_ship.global_position)
 var reach:float=1.0
 for i in 6:reach=maxf(reach,source.distance_to(Vector2.from_angle(i*PI/3)*HexBoundary.HEX_RADIUS))
 var contacts:Array=[]
 for node in sector.find_children("*","",true,false):
  if not node is Node2D or node.is_queued_for_deletion() or node==PlayerState.current_ship:continue
  for group in GROUPS:
   if not node.is_in_group(group):continue
   var label:String=group.replace("_"," ").capitalize().trim_suffix("s")
   if node is StationInstance and node.station_data:label=node.station_data.display_name
   elif node is ShipInstance and node.ship_data:label=node.ship_data.display_name
   contacts.append({"position":sector.to_local(node.global_position),"label":label,"station":node is StationInstance})
   break
 for contact in contacts:reach=maxf(reach,source.distance_to(contact.position))
 for contact in contacts:contact["arrival"]=source.distance_to(contact.position)/reach*SWEEP_SECONDS
 scans[SectorManager.current_sector_id]={"elapsed":0.0,"source":source,"reach":reach,"contacts":contacts}
 SaveManager._message("Long-range scanner sweeping sector [L]")
 queue_redraw()
func advance(delta:float)->void:
 for id in scans.keys():
  scans[id].elapsed+=maxf(0,delta)
  if scans[id].elapsed>=SWEEP_SECONDS+DURATION+FADE:scans.erase(id)
func _process(delta:float)->void:
 advance(delta)
 queue_redraw()
func _draw()->void:
 var camera:Camera2D=get_viewport().get_camera_2d()
 if not camera or not GameData.sectors.has(SectorManager.current_sector_id):return
 var map_mode:bool=camera is FreeCameraController and camera.is_free_mode()
 for id in scans:
  if id!=SectorManager.current_sector_id and not map_mode:continue
  var offset:Vector2=Vector2.ZERO
  if map_mode:offset=(GameData.sectors[id].map_position-GameData.sectors[SectorManager.current_sector_id].map_position)*1000
  var scan:Dictionary=scans[id]
  if scan.elapsed<SWEEP_SECONDS:
   var ring_center:Vector2=get_viewport().get_canvas_transform()*(scan.source+offset)
   var radius:float=scan.reach*scan.elapsed/SWEEP_SECONDS*camera.zoom.x
   var strength:float=minf(1.0,(SWEEP_SECONDS-scan.elapsed)/0.6)
   draw_arc(ring_center,radius,0,TAU,256,Color(0.25,0.7,1.0,0.12*strength),12,true)
   draw_arc(ring_center,radius,0,TAU,256,Color(0.45,0.9,1.0,0.8*strength),2,true)
  for contact in scan.contacts:
   var age:float=scan.elapsed-contact.arrival
   if age<0 or age>=DURATION+FADE:continue
   var alpha:float=clampf((DURATION+FADE-age)/FADE,0,1)
   var point:Vector2=get_viewport().get_canvas_transform()*(contact.position+offset)
   if not get_viewport_rect().grow(20).has_point(point):continue
   var color:Color=Color(0.5,0.85,1.0,alpha*0.85)
   draw_arc(point,5,0,TAU,12,color,1)
   if age<0.6:draw_arc(point,5+age*18,0,TAU,24,Color(0.6,0.95,1.0,(1-age/0.6)*0.7),1.5,true)
   if camera.zoom.x>0.003:draw_string(ThemeDB.fallback_font,point+Vector2(8,12),contact.label+" [scan]",HORIZONTAL_ALIGNMENT_LEFT,180,10,color)
