extends "res://resources/GlobalEnums.gd"

## Compatibility path; the global class is defined in resources/GlobalEnums.gd.
