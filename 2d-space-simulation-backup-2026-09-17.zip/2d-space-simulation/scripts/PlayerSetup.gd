extends Node
## Drop this script on a Node in your main scene.
## Bootstraps the player loadout and loads the starting sector.

const DEFENSE_PLAYTEST := false
const FLEET_PLAYTEST := true

const STARTING_SHIP_ID     : StringName = &"fighter"
const STARTING_WEAPON_ID   : StringName = &"laser_autocannon_s1"
const STARTING_SHIELD_ID   : StringName = &"shield_s1_average"
const STARTING_MISSILE_ID  : StringName = &"missile_s1"
const STARTING_SECTOR_ID   : StringName = &"sol_prime"
const STARTING_CREDITS     : int        = 1000000

@onready var sector_map : Node = get_node_or_null("../SectorMap")

func _ready() -> void:
	await get_tree().process_frame
	await get_tree().process_frame
	_setup_player()
	_load_starting_sector()

func _input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if event.is_action_pressed("map"):
		if get_tree().paused: return
		var sm := get_tree().get_first_node_in_group("sector_map")
		if sm == null: return
		if sm.visible:
			sm._close()
		else:
			sm.open()

func _setup_player() -> void:
	var player := get_tree().get_first_node_in_group("player") as Player
	if not player:
		push_warning("PlayerSetup: no node in group 'player' found")
		return

	PlayerState.credits = STARTING_CREDITS
	PlayerState.credits_changed.emit(PlayerState.credits)

	var ship_data : ShipData = GameData.get_ship(STARTING_SHIP_ID)
	if ship_data:
		player.initialize(ship_data)

	## Equip two laser autocannons
	var weapon : WeaponData = GameData.get_weapon(STARTING_WEAPON_ID)
	if weapon:
		player.equip_weapon(weapon, 0)
		player.equip_weapon(weapon, 1)
	else:
		push_warning("PlayerSetup: weapon '%s' not found" % STARTING_WEAPON_ID)

	var shield : ShieldData = GameData.get_shield(STARTING_SHIELD_ID)
	if shield:
		player.equip_shield(shield)

	var missile : MissileData = GameData.get_missile(STARTING_MISSILE_ID)
	if missile:
		player.equip_missile(missile, 0)
		player.inventory.add_item(STARTING_MISSILE_ID, 20, GameData.items)

	player.inventory.add_item(&"satellite", 3, GameData.items)
	SensorSystem.register_observer(player, SensorSystem.get_radius_for_ship(player))
	print("PlayerSetup: player initialized as '%s'" % STARTING_SHIP_ID)

func _load_starting_sector() -> void:
	SectorManager.load_sector(STARTING_SECTOR_ID, Vector2.ZERO)
	var player := get_tree().get_first_node_in_group("player") as Player
	for station in get_tree().get_nodes_in_group("stations"):
		if station is StationInstance and station.station_data and station.station_data.id == &"sol_prime_shipyard":
			if player:
				player.global_position = station.global_position + Vector2(station.get_docking_range() + 100.0, 0)
				player.velocity = Vector2.ZERO
				if player.camera: player.camera.reset_smoothing()
			break
	if DEFENSE_PLAYTEST:_setup_defense_playtest()
	if FLEET_PLAYTEST:_setup_fleet_playtest()
	print("PlayerSetup: loading sector '%s'" % STARTING_SECTOR_ID)

func _setup_defense_playtest() -> void:
	var platform: StationInstance=load("res://scenes/Station.tscn").instantiate()
	platform.station_data=GameData.stations[&"defense_platform"].duplicate(true)
	platform.station_data.display_name="Defense Test Platform"
	platform.blueprint_id=&"defense_platform"
	platform.runtime_station_id=&"defense_playtest_platform"
	platform.station_data.id=platform.runtime_station_id
	platform.constructed=true
	platform.faction_id=&"terran_republic"
	platform.defense_energy=2000
	platform.inventory.add_item(&"missile_s1",60)
	platform.inventory.add_item(&"missile_s3",60)
	platform.position=Vector2(12000,12000)
	SectorManager.current_sector.get_node("Stations").add_child(platform)
	var player:Player=PlayerState.current_ship
	player.position=platform.position+Vector2(-650,0)
	player.velocity=Vector2.ZERO
	if player.camera:player.camera.reset_smoothing()
	for offset in [Vector2(1000,-350),Vector2(1100,350)]:
		var enemy:ShipInstance=load("res://scenes/Heavyfighter.tscn").instantiate()
		enemy.faction_id=&"rogue"
		enemy.position=platform.position+offset
		SectorManager.current_sector.add_child(enemy)
		enemy.initialize(GameData.ships[&"heavy_fighter"])
		enemy.equip_weapon(GameData.weapons[&"laser_autocannon_s3"],0)
		enemy.equip_shield(GameData.shields[&"shield_s3_average"])
		var ai:=AIShipController.new()
		ai._background_initialized=true
		enemy.add_child(ai)
		ai._is_combat_ship=true
		ai._target=platform
		ai._state=AIShipController.State.ATTACK


func _setup_fleet_playtest() -> void:
	var player: Player = PlayerState.current_ship
	if not is_instance_valid(player): return
	var roster: Array[StringName] = [&"hauler", &"miner"]
	for i in roster.size():
		var ship: ShipInstance = load(StationSpawner.SHIP_SCENES[roster[i]]).instantiate()
		ship.faction_id = player.faction_id
		ship.add_to_group("player_fleet")
		SectorManager.add_sector_entity(ship)
		ship.initialize(GameData.ships[roster[i]])
		var desired := player.global_position + Vector2(700,(-1 if i==0 else 1)*450)
		for attempt in 80:
			var clear := true
			for group in [&"stations", &"ships", &"asteroids"]:
				for other in get_tree().get_nodes_in_group(group):
					if other == ship or not other is Node2D: continue
					if desired.distance_to(other.global_position) < preload("res://scripts/ShipTactics.gd").radius(ship)+preload("res://scripts/ShipTactics.gd").radius(other)+180:
						clear = false
			if clear: break
			desired += Vector2(250,100)
		ship.global_position = desired
		for slot in ship.ship_data.weapon_slots:
			for weapon in GameData.weapons.values():
				if ship.ship_data.accepts_weapon(slot,weapon) and (ship.ship_data.mount_kind(slot)=="Mining" or String(weapon.id).begins_with("laser_autocannon")):
					ship.equip_weapon(weapon,slot)
					break
		var size: int = ship.ship_data.ship_class+1
		ship.equip_shield(GameData.shields[StringName("shield_s%d_average" % size)])
		for rack in ship.ship_data.rack_sizes.size():
			var missile_id := StringName("missile_s%d" % ship.ship_data.rack_sizes[rack])
			ship.equip_missile(GameData.missiles[missile_id],rack)
			ship.inventory.add_item(missile_id,20,GameData.items)
		var ai := AIShipController.new()
		ship.add_child(ai)
		PlayerState.fleet_ships.append(ship)
		SensorSystem.register_observer(ship,SensorSystem.get_radius_for_ship(ship))
	print("Starting fleet: small fighter (player), small hauler and small miner")
