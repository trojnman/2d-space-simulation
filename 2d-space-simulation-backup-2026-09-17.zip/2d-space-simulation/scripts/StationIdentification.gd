extends Control

# Screen-space labels remain readable at every camera zoom.
const TYPES := {"headquarters": "Headquarters", "military": "Military / Equipment", "trade": "Trading Station", "manufacturing": "Factory", "shipyard": "Shipyard", "mining": "Mining Station", "defense_platform": "Defense Platform"}
var map_inspection: bool = false
var remote_inspection: bool = false
var hovered: StationInstance
var selected: StationInstance
var card: PanelContainer
var details: RichTextLabel
var contacts: Array[Dictionary] = []
var _title: Label
var _subtitle: Label
var _footer: Label
var _tabs: HBoxContainer
var _active_tab: int = 0
var _displayed: StationInstance
var _refresh_time: float = 0.0
var _access_allowed: bool = false
var _was_selected: bool = false


func _ready() -> void:
	var indicator_layer=preload("res://scripts/WorldIndicatorLayer.gd").new()
	indicator_layer.provider=self
	add_child(indicator_layer)
	if not map_inspection: add_to_group("station_inspection")
	mouse_filter = Control.MOUSE_FILTER_IGNORE
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	card = PanelContainer.new()
	card.theme = preload("res://scripts/ConsoleTheme.gd").build()
	card.mouse_filter = Control.MOUSE_FILTER_STOP
	add_child(card)
	var margin := MarginContainer.new()
	margin.mouse_filter = Control.MOUSE_FILTER_IGNORE
	for side in ["left", "right", "top", "bottom"]: margin.add_theme_constant_override("margin_" + side, 12)
	card.add_child(margin)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 12)
	margin.add_child(column)
	var header := HBoxContainer.new()
	column.add_child(header)
	_title = Label.new()
	_title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	_title.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_title.add_theme_font_size_override("font_size", 19)
	_title.add_theme_color_override("font_color", Color("56dfeb"))
	header.add_child(_title)
	var close := Button.new()
	close.text = "×"
	close.tooltip_text = "Close inspection (Esc)"
	close.pressed.connect(func(): selected = null; hovered = null; card.hide(); _displayed = null)
	header.add_child(close)
	_subtitle = Label.new()
	_subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_subtitle.add_theme_font_size_override("font_size", 13)
	_subtitle.add_theme_color_override("font_color", Color("98afbf"))
	column.add_child(_subtitle)
	_tabs = HBoxContainer.new()
	column.add_child(_tabs)
	for i in 5:
		var button := Button.new()
		button.text = ["Overview", "Market", "Production", "Finance", "Ships"][i]
		button.toggle_mode = true
		button.add_theme_font_size_override("font_size", 12)
		button.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		button.pressed.connect(_select_tab.bind(i))
		_tabs.add_child(button)
	column.add_child(HSeparator.new())
	details = RichTextLabel.new()
	details.mouse_filter = Control.MOUSE_FILTER_STOP
	details.custom_minimum_size = Vector2(0, 290)
	details.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	details.scroll_active = true
	details.bbcode_enabled = true
	details.add_theme_font_size_override("normal_font_size", 14)
	details.add_theme_constant_override("line_separation", 5)
	details.add_theme_constant_override("table_h_separation", 14)
	details.add_theme_constant_override("table_v_separation", 10)
	column.add_child(details)
	column.add_child(HSeparator.new())
	_footer = Label.new()
	_footer.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_footer.add_theme_font_size_override("font_size", 12)
	_footer.add_theme_color_override("font_color", Color("98afbf"))
	column.add_child(_footer)
	card.hide()

func is_map_open() -> bool:
	var camera := get_viewport().get_camera_2d()
	return camera is FreeCameraController and camera.is_free_mode()

func station_marker_available(station: StationInstance) -> bool:
	if SensorSystem.has_local_contact(station.global_position): return true
	if not is_map_open(): return false
	return station.can_share_station_info() or SensorSystem.fog.get_last_known_contacts().has(station.get_instance_id())

func select_hovered() -> bool:
	if not valid_station(hovered): return false
	selected = hovered
	details.scroll_to_line(0)
	return true

func valid_station(station: StationInstance) -> bool:
	return is_instance_valid(station) and (station.is_inside_tree() or remote_inspection) and not station.is_queued_for_deletion() and not station._is_destroyed and station.station_data != null

func station_text(station: StationInstance) -> String:
	var data: StationData = station.station_data
	if not SensorSystem.has_local_contact(station.global_position):
		return "%s\nLONG-RANGE STATION CONTACT\n\nApproach within local sensor range to scan this station.\nT: pin contact | Esc: clear" % data.display_name
	var faction: FactionData = GameData.factions.get(station.faction_id)
	var text: String = "%s\n%s | %s\n\n%s" % [data.display_name, TYPES.get(str(data.station_type), str(data.station_type).capitalize()), faction.display_name if faction else "Independent", data.description]
	var player: Node2D = get_tree().get_first_node_in_group("player")
	if player: text += "\n\nDistance: %d" % int(player.global_position.distance_to(station.global_position))
	text += "\nE: dock" if station.can_dock() else "\nMove closer, then E to dock"
	if not station.can_share_station_info():
		text += "\n\n" + station.get_public_station_details()
	elif station == selected:
		text += "\n\n" + station.get_public_station_details()
	text += "\n\nClick station / T: inspect | Esc: close"
	return text

func _process(_delta: float) -> void:
	_refresh_time += _delta
	if map_inspection:
		visible = valid_station(selected)
		card.visible = visible
		if visible:
			_displayed = selected
			if _refresh_time >= 1.0:
				_refresh_card()
				_refresh_time = 0.0
			var view := get_viewport_rect()
			_fit_card(view.size)
		return
	var player: Player = get_tree().get_first_node_in_group("player")
	visible = not get_tree().paused and is_instance_valid(player) and not player._is_docked
	if not visible: return
	if not valid_station(selected): selected = null
	hovered = null
	contacts.clear()
	var closest: float = INF
	var view: Rect2 = get_viewport_rect()
	var mouse: Vector2 = get_local_mouse_position()
	for station in get_tree().get_nodes_in_group("stations"):
		if not valid_station(station) or not station_marker_available(station): continue
		var transform: Transform2D = station.get_global_transform_with_canvas()
		var center: Vector2 = transform.origin
		if not view.has_point(center): continue
		var radius: float = maxf(22, 200 * StationInstance.STATION_SIZE_MULTIPLIER * transform.x.length())
		var label_pos: Vector2 = center + Vector2(0, radius + 10)
		contacts.append({"station": station, "center": center, "radius": radius, "label": label_pos})
		var distance: float = mouse.distance_to(center)
		if distance <= radius and distance < closest and not preload("res://scripts/UIInput.gd").over_menu(get_viewport()):
			closest = distance
			hovered = station
	var focus: StationInstance = selected if valid_station(selected) else hovered
	card.visible = valid_station(focus) and station_marker_available(focus)
	if card.visible:
		var allowed: bool = focus.can_share_station_info()
		if _displayed != focus or _access_allowed != allowed or _was_selected != (focus == selected) or _refresh_time >= 1.0:
			var changed: bool = _displayed != focus
			_displayed = focus
			_access_allowed = allowed
			_was_selected = focus == selected
			if changed: _active_tab = 0
			_refresh_card(changed)
			_refresh_time = 0.0
		_fit_card(view.size)
	queue_redraw()

func _fit_card(view_size: Vector2) -> void:
	var top := minf(70.0, view_size.y * 0.1)
	var available := Vector2(maxf(1,view_size.x-32),maxf(1,view_size.y-top-16))
	card.scale = Vector2.ONE
	card.size.x = minf(490,available.x)
	# Measure the header, tabs and footer rather than assuming their height.
	details.custom_minimum_size.y = 0
	var chrome := card.get_combined_minimum_size().y
	details.custom_minimum_size.y = clampf(available.y-chrome,60,430)
	card.size = Vector2(minf(490,available.x),card.get_combined_minimum_size().y)
	var factor := minf(1,minf(available.x/card.size.x,available.y/card.size.y))
	card.scale = Vector2.ONE * factor
	card.position = Vector2(maxf(16,view_size.x-card.size.x*factor-16),top)

func _draw_world(canvas:Control) -> void:
	if map_inspection: return
	var font: Font = ThemeDB.fallback_font
	for contact in contacts:
		var station: StationInstance = contact["station"]
		if not valid_station(station): continue
		var data: StationData = station.station_data
		var stale: bool = not station.can_share_station_info() and not SensorSystem.has_local_contact(station.global_position)
		var title: String = ("[LAST KNOWN] " if stale else "") + data.display_name + "  [" + TYPES.get(str(data.station_type), str(data.station_type).capitalize()) + "]"
		var width: float = font.get_string_size(title, HORIZONTAL_ALIGNMENT_LEFT, -1, 8).x
		var position: Vector2 = contact["label"] - Vector2(width / 2, 0)
		position.x = clampf(position.x, 4, maxf(4, get_viewport_rect().size.x - width - 4))
		canvas.draw_rect(Rect2(position - Vector2(2.5, 9), Vector2(width + 5, 12.5)), Color(0.02, 0.03, 0.06, 0.85))
		canvas.draw_string(font, position, title, HORIZONTAL_ALIGNMENT_LEFT, -1, 8, Color(0.8, 0.65, 0.65, 0.65) if stale else Color(0.8, 0.92, 1))
		if is_map_open():
			canvas.draw_rect(Rect2(contact["center"] - Vector2(3,3), Vector2(6,6)), Color("c88383") if not station.can_share_station_info() else Color("74cedb"), false, 1.0)
		if station == hovered or station == selected:
			canvas.draw_arc(contact["center"], contact["radius"] * 0.5, 0, TAU, 48, Color(0.4, 0.85, 1), 1)

func blocks_primary_fire() -> bool:
	return visible and (valid_station(hovered) or (card.visible and card.get_global_rect().has_point(get_global_mouse_position())))

func _unhandled_input(event: InputEvent) -> void:
	if preload("res://scripts/UIInput.gd").typing(get_viewport()):return
	if visible and event is InputEventMouseButton and event.pressed and event.button_index == MOUSE_BUTTON_LEFT and valid_station(hovered):
		selected = hovered
		details.scroll_to_line(0)
		get_viewport().set_input_as_handled()
		return
	if not visible or not event is InputEventKey or not event.pressed or event.echo: return
	if event.physical_keycode == KEY_T and valid_station(hovered):
		selected = hovered
		get_viewport().set_input_as_handled()
	elif event.physical_keycode == KEY_ESCAPE and is_instance_valid(selected):
		selected = null
		get_viewport().set_input_as_handled()


func _select_tab(index: int) -> void:
	_active_tab = index
	_refresh_card(true)

func _heading(text: String) -> void:
	details.push_color(HUDLayout.palette_color(Color("56dfeb")))
	details.push_bold()
	details.add_text(text + "\n")
	details.pop()
	details.pop()

func _cell(text: String, right: bool = false, muted: bool = false) -> void:
	details.push_cell()
	details.push_paragraph(HORIZONTAL_ALIGNMENT_RIGHT if right else HORIZONTAL_ALIGNMENT_LEFT)
	if muted: details.push_color(HUDLayout.palette_color(Color("98afbf")))
	details.add_text(text)
	if muted: details.pop()
	details.pop()
	details.pop()

func _refresh_card(reset_scroll: bool = false) -> void:
	if not valid_station(_displayed): return
	var station := _displayed
	var scroll: float = details.get_v_scroll_bar().value
	_title.text = station.station_data.display_name
	var faction: FactionData = GameData.factions.get(station.faction_id)
	_subtitle.text = "%s  •  %s" % [TYPES.get(str(station.station_data.station_type), "Station"), faction.display_name if faction else "Independent"]
	var allowed: bool = station.can_share_station_info() and (map_inspection or is_map_open() or SensorSystem.has_local_contact(station.global_position))
	var internal: bool = allowed and station.can_share_internal_info()
	if not internal and _active_tab in [2, 3]: _active_tab = 0
	_tabs.get_child(2).visible = internal
	_tabs.get_child(3).visible = internal
	_tabs.get_child(4).visible = allowed and station.station_data.station_type == StationData.TYPE_SHIPYARD
	if _active_tab == 4 and not _tabs.get_child(4).visible: _active_tab = 0
	_tabs.visible = allowed and station == selected
	for i in _tabs.get_child_count(): _tabs.get_child(i).set_pressed_no_signal(i == _active_tab)
	_footer.text = "E: dock  •  Esc: close" if station.can_dock() else "Approach to dock  •  Esc: close"
	if remote_inspection:_footer.text = "Remote station information • Esc: close"
	details.clear()
	if not allowed:
		_heading("ACCESS RESTRICTED")
		details.add_text("This faction does not share internal station information." if PlayerState.is_hostile_to_player(station.faction_id) else "Move within local sensor range to inspect this station.")
	elif station != selected or _active_tab == 0:
		_heading("STATION OVERVIEW")
		details.add_text(station.station_data.description + "\n\n")
		details.push_table(2)
		details.set_table_column_expand(0, true, 1)
		details.set_table_column_expand(1, true, 2)
		if internal:
			_cell("Hull", false, true); _cell("%d / %d" % [station.hull, station.max_hull], true)
			_cell("Shields", false, true); _cell("%d / %d" % [station.shield, station.max_shield], true)
		if internal: _cell("Faction funds", false, true); _cell("$%d" % station.station_credits, true)
		_cell("Docking range", false, true); _cell("%d" % station.get_docking_range(), true)
		_cell("Repair service", false, true); _cell("Available" if station.station_data.offers_repairs else "Unavailable", true)
		if internal: _cell("Active jobs", false, true); _cell(str(station.get_manufacture_queue().size()), true)
		details.pop()
		if internal and station.requested_supply_ship != &"":
			details.add_text("\n\n")
			_heading("SUPPLY REQUEST")
			details.add_text(GameData.ships[station.requested_supply_ship].display_name)
		if station != selected: _footer.text = "Click station or T for full inspection"
	elif _active_tab == 1:
		_heading("MARKET & STOCK")
		details.add_text("Unit prices • Buy from / sell to this station\n\n")
		details.push_table(4)
		for i in 4: details.set_table_column_expand(i, true, 4 if i == 0 else 2)
		_cell("ITEM", false, true); _cell("STOCK", true, true); _cell("BUY", true, true); _cell("SELL", true, true)
		for id in GameData.items:
			var sells: bool = station._station_sells_item(id)
			var buys: bool = station._station_buys_item(id)
			var amount: int = station.inventory.get_amount(id)
			if not sells and not buys and (amount == 0 or not internal): continue
			_cell(GameData.items[id].display_name)
			_cell(str(amount), true)
			_cell("$%d" % station.get_sell_price(id) if sells else "—", true)
			_cell("$%d" % station.get_buy_price(id) if buys else "—", true)
		details.pop()
	elif _active_tab == 2:
		_heading("PRODUCTION STATUS")
		var report := station.get_production_report()
		if report.is_empty(): details.add_text("No manufacturing facilities.")
		for entry in report:
			details.add_text("\n")
			details.push_bold(); details.add_text(entry["name"] + "\n"); details.pop()
			details.push_color(Color("91d9ac") if entry["state"] in ["Producing", "Ready", "Ready to order", "Stocked"] else Color("e9c17b"))
			details.add_text(entry["state"] + "\n"); details.pop()
			details.add_text(entry["detail"] + "\n")
			if entry["target"] > 0: details.add_text("Stock %d / target %d\n" % [entry["stock"], entry["target"]])
			details.add_text("Worker cost: $%d\n" % entry["labor"])
	elif _active_tab == 3:
		_heading("FACTION TRANSACTIONS")
		details.add_text("Shared treasury: $%d\nLatest 200 transactions • newest first\n\n" % station.station_credits)
		var entries: Array = FactionManager.get_treasury_history(station.faction_id)
		entries.reverse()
		if entries.is_empty(): details.add_text("No transactions recorded this session.")
		for entry in entries:
			details.push_color(Color("91d9ac") if entry["delta"] > 0 else Color("e9a18a"))
			details.push_bold()
			details.add_text("%s$%d  •  Balance $%d\n" % ["+" if entry["delta"] > 0 else "−", absi(entry["delta"]), entry["balance"]])
			details.pop(); details.pop()
			details.add_text(entry["reason"] + "\n")
			details.push_color(HUDLayout.palette_color(Color("98afbf")))
			details.add_text("%s%s\n\n" % [entry["station"], " • " + entry["counterparty"] if entry["counterparty"] != "" else ""])
			details.pop()
	else:
		_heading(station.station_data.get_yard_class_name().to_upper())
		details.add_text("Construction offers • dock here to place an order\n\n")
		details.push_table(3)
		for i in 3: details.set_table_column_expand(i, true, 3 if i == 0 else 2)
		_cell("SHIP", false, true); _cell("PRICE", true, true); _cell("BUILD STOCK", false, true)
		for entry in station.get_ship_sale_catalog():
			_cell(entry["name"])
			_cell("$%d" % entry["price"], true)
			_cell("Ready" if entry["stocked"] else "Needs supplies")
		details.pop()
		for order in station.get_visible_ship_orders():
			details.add_text("\n%s — %s — %.1fs remaining" % [order.name, order.owner, order.remaining])
		if not station.get_manufacture_queue().is_empty(): details.add_text("\n\nConstruction dock busy. Stock status is independent of the active build.")
	details.get_v_scroll_bar().set_deferred("value", 0.0 if reset_scroll else scroll)
