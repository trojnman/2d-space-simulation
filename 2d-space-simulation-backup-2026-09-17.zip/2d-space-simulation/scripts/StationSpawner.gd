class_name StationSpawner
extends Node

## Attach to a StationInstance as a child.
## Seeds a finite starting fleet. Later ships must be manufactured.

const AIShipControllerScript = preload("res://scripts/AIShipController.gd")

const SPAWN_CHECK_INTERVAL : float = 10.0
const SPAWN_RADIUS         : float = 800.0

## Map ship id to scene path
const SHIP_SCENES : Dictionary = {
	&"fighter":            "res://scenes/Fighter.tscn",
	&"hauler":             "res://scenes/Hauler.tscn",
	&"miner":              "res://scenes/Miner.tscn",
	&"missile_boat":       "res://scenes/Missileboat.tscn",
	&"medium_fighter":     "res://scenes/Mediumfighter.tscn",
	&"medium_hauler":      "res://scenes/Mediumhauler.tscn",
	&"medium_miner":       "res://scenes/Mediumminer.tscn",
	&"medium_missile_boat":"res://scenes/Mediummissileboat.tscn",
	&"medium_logistics":   "res://scenes/Mediumlogistics.tscn",
	&"heavy_fighter":      "res://scenes/Heavyfighter.tscn",
	&"heavy_hauler":       "res://scenes/Heavyhauler.tscn",
	&"heavy_miner":        "res://scenes/Heavyminer.tscn",
	&"heavy_missile_boat": "res://scenes/Heavymissileboat.tscn",
	&"large_logistics":    "res://scenes/Largelogistics.tscn",
}

@export var max_ships      : int   = 5
@export var spawn_interval : float = 15.0

var _initial_ships_spawned: int = 0
var _replacement_requests: Array[StringName] = []

var _station       : StationInstance     = null
var _spawned_ships : Array[ShipInstance] = []
var _check_timer   : float = 0.0
var _spawn_timer   : float = 5.0
var _spawn_pool    : Array[StringName] = []


func _ready() -> void:
	_station = get_parent() as StationInstance
	if not _station:
		push_warning("StationSpawner: parent must be StationInstance")
		return
	await get_tree().process_frame
	_build_spawn_pool()
	print("StationSpawner: ready on '%s', pool=%s" % [_station.name, _spawn_pool])


func _build_spawn_pool() -> void:
	if not _station or not _station.station_data: return
	var sd    : StationData = _station.station_data
	var stype : String      = sd.station_type if sd.get("station_type") != null else "trade"
	_spawn_pool.clear()
	match stype:
		"military", "headquarters":
			_spawn_pool = [&"fighter", &"fighter", &"missile_boat", &"medium_fighter"]
		"trade":
			_spawn_pool = [&"hauler", &"hauler", &"medium_hauler", &"fighter"]
		"mining":
			_spawn_pool = [&"miner", &"miner", &"medium_miner", &"fighter"]
		"shipyard":
			_spawn_pool = [&"fighter", &"hauler"]
		"manufacturing":
			_spawn_pool = [&"hauler", &"miner"]
		_:
			_spawn_pool = [&"fighter", &"hauler"]


func _physics_process(delta: float) -> void:
	if _spawn_pool.is_empty(): return
	_check_timer += delta
	_spawn_timer += delta
	if _check_timer >= SPAWN_CHECK_INTERVAL:
		_check_timer = 0.0
		_clean_dead_ships()
		_request_replacement()
	if _spawn_timer >= spawn_interval:
		_spawn_timer = 0.0
		_try_spawn()


func _clean_dead_ships() -> void:
	_spawned_ships = _spawned_ships.filter(
		func(s): return is_instance_valid(s) and not s._is_destroyed
	)


func _try_spawn() -> void:
	if not is_instance_valid(_station) or _station._is_destroyed: return
	_clean_dead_ships()
	if _initial_ships_spawned >= max_ships: return
	if _spawn_pool.is_empty(): return
	var ship_id   : StringName = _spawn_pool[_initial_ships_spawned % _spawn_pool.size()]
	var ship_data : ShipData   = GameData.get_ship(ship_id)
	if not ship_data:
		push_warning("StationSpawner: ship data not found for '%s'" % ship_id)
		return
	if not FactionManager.can_add_npc_ship(_station.faction_id,ship_data):return
	if _spawn_ship(ship_id, ship_data):
		_initial_ships_spawned += 1


func build_completed_ship(ship_id: StringName) -> ShipInstance:
	if not GameData.ships.has(ship_id): return null
	return _spawn_ship(ship_id, GameData.ships[ship_id], false)


func _spawn_ship(ship_id: StringName, ship_data: ShipData, starting_equipment: bool = true) -> ShipInstance:
	## Load the correct ship scene
	var scene_path : String = SHIP_SCENES.get(ship_id, "")
	if scene_path == "":
		push_warning("StationSpawner: no scene for ship id '%s'" % ship_id)
		return null
	var ship_scene : PackedScene = load(scene_path)
	if ship_scene == null:
		push_warning("StationSpawner: could not load scene '%s'" % scene_path)
		return null

	var ship : ShipInstance = ship_scene.instantiate() as ShipInstance
	if not ship:
		push_warning("StationSpawner: scene root is not ShipInstance for '%s'" % ship_id)
		return null

	var angle : float = randf() * TAU
	ship.global_position = _station.global_position + Vector2(cos(angle), sin(angle)) * SPAWN_RADIUS
	ship.faction_id      = _station.faction_id

	## Add to scene first so initialize() works correctly
	var ship_parent: Node = _station.get_parent().get_parent()
	ship_parent.add_child(ship)
	ship.initialize(ship_data)
	if starting_equipment: _equip_ship(ship, ship_data)

	## Add AI controller
	var ai := AIShipControllerScript.new()
	ship.add_child(ai)

	_spawned_ships.append(ship)
	if not ship.is_inside_tree():
		ship.add_to_group("ships")
		FactionManager.register_ship(ship)
		ai.initialize_inactive(_station)
	ship.ship_destroyed.connect(_on_fleet_ship_destroyed)
	print("StationSpawner: spawned %s for %s" % [ship_data.display_name, _station.faction_id])

	return ship


func _equip_ship(ship: ShipInstance, sd: ShipData) -> void:
	for item_id in StationData.get_ship_loadout(sd.id):
		if GameData.weapons.has(item_id):
			for slot in sd.weapon_slots:
				if ship.equip_weapon(GameData.weapons[item_id], slot): break
		elif GameData.shields.has(item_id): ship.equip_shield(GameData.shields[item_id])
		elif GameData.missiles.has(item_id):
			ship.equip_missile(GameData.missiles[item_id], 0)
			ship.inventory.add_item(item_id, StationData.get_ship_loadout(sd.id)[item_id] - 1, GameData.items)
		else: ship.inventory.add_item(item_id, StationData.get_ship_loadout(sd.id)[item_id], GameData.items)



func get_ship_count() -> int:
	_clean_dead_ships()
	return _spawned_ships.size()


func _on_fleet_ship_destroyed(ship: ShipInstance, _killer: Node) -> void:
	if not is_instance_valid(_station) or _station._is_destroyed: return
	if not _spawned_ships.has(ship) or ship.is_in_group("player_fleet"): return
	_replacement_requests.append(ship.ship_data.id)
	_spawned_ships.erase(ship)

func _request_replacement() -> bool:
	if _replacement_requests.is_empty() or not is_instance_valid(_station) or _station._is_destroyed: return false
	# A request remains outstanding until delivery, so losing a yard allows retry.
	for station in SectorManager.get_sector_stations(_station.get_parent().get_parent()):
		if not station is StationInstance or station._is_destroyed: continue
		for job in station.get_manufacture_queue():
			if job.get("replacement_owner") == self: return false
	for station in SectorManager.get_sector_stations(_station.get_parent().get_parent()):
		if not station is StationInstance or station._is_destroyed or station.faction_id != _station.faction_id: continue
		if station.station_data.station_type != StationData.TYPE_SHIPYARD: continue
		# Player supply plans take priority over automatic fleet rebuilding.
		if station.requested_supply_ship != &"" or station.requested_station_blueprint != &"" or not station.get_manufacture_queue().is_empty(): continue
		var recipe: Dictionary = station.get_ship_recipe(_replacement_requests[0])
		if recipe.is_empty(): continue
		station.replacement_supply_ship = _replacement_requests[0]
		if not station.queue_manufacture(recipe): return false
		station.get_manufacture_queue().back()["replacement_owner"] = self
		station.replacement_supply_ship = &""
		return true
	return false

func accept_replacement(ship: ShipInstance, builder: StationSpawner) -> void:
	var index: int = _replacement_requests.find(ship.ship_data.id)
	if index >= 0: _replacement_requests.remove_at(index)
	if builder != self:
		builder._spawned_ships.erase(ship)
		if ship.ship_destroyed.is_connected(builder._on_fleet_ship_destroyed): ship.ship_destroyed.disconnect(builder._on_fleet_ship_destroyed)
		_spawned_ships.append(ship)
		ship.ship_destroyed.connect(_on_fleet_ship_destroyed)
	for child in ship.get_children():
		if child is AIShipController: child._home_station = _station
