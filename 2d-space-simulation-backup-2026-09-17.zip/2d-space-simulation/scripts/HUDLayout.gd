extends CanvasLayer
const FILE := "user://hud_layout.cfg"
const COLORS = {"Blue":Color("56dfeb"),"Red":Color("f06b76"),"Yellow":Color("edda62"),"Orange":Color("f5a45d"),"Purple":Color("bb86f4")}
var color_name := "Blue"
var previous_color := "Blue"
var color_picker:OptionButton
var layouts: Dictionary = {}
var before: Dictionary = {}
var editing := false
var was_paused := false
var was_map := false
var surface: Control
var toolbar: HBoxContainer
var selected := ""
var resize_axes := Vector2.ZERO
var guides: Array = []
var start_mouse := Vector2.ZERO
var start_rect := Rect2()
var message: Label

func _ready()->void:
 process_mode=Node.PROCESS_MODE_ALWAYS
 get_tree().node_added.connect(_register_input_surface)
 layer=150
 var config:=ConfigFile.new()
 if config.load(FILE)==OK:
  var saved=config.get_value("hud","panels",{})
  if saved is Dictionary:layouts=saved
  color_name=str(config.get_value("hud","color","Blue"))
  if not COLORS.has(color_name):color_name="Blue"
 surface=Control.new()
 surface.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 surface.mouse_filter=Control.MOUSE_FILTER_STOP
 add_child(surface)
 surface.draw.connect(_draw_editor)
 surface.gui_input.connect(_edit_input)
 toolbar=HBoxContainer.new()
 toolbar.position=Vector2(20,20)
 toolbar.add_theme_constant_override("separation",10)
 surface.add_child(toolbar)
 for label in ["Save layout","Cancel","Reset defaults"]:
  var button:=Button.new()
  button.text=label
  button.pressed.connect(_action.bind(label))
  toolbar.add_child(button)
 color_picker=OptionButton.new()
 for label in COLORS:color_picker.add_item(label)
 color_picker.select(COLORS.keys().find(color_name))
 color_picker.item_selected.connect(func(index):
  color_name=COLORS.keys()[index]
  repaint_ui())
 toolbar.add_child(color_picker)
 message=Label.new()
 message.text="Drag to move • Right/bottom handles resize X/Y • Alt bypasses snapping"
 toolbar.add_child(message)
 surface.hide()

func panels()->Dictionary:
 var result:Dictionary={}
 var target=get_tree().get_first_node_in_group("targeting_hud")
 if target:
  result["Your ship"]=target.own_card
  result["Target"]=target.target_card
 var weapons=get_tree().get_first_node_in_group("weapon_control_hud")
 if weapons:result["Weapons"]=weapons
 var fleet=get_tree().get_first_node_in_group("fleet_sidebar")
 if fleet:result["Fleet manager"]=fleet
 return result

func apply_layout(id:String,panel:Control)->void:
 paint_panel(panel)
 if not layouts.has(id):return
 var data=layouts[id]
 if not data is Dictionary:return
 var view:=get_viewport().get_visible_rect().size
 var old_scale=data.get("scale",1.0)
 var factors:Vector2=old_scale if old_scale is Vector2 else Vector2.ONE*float(old_scale)
 factors=factors.clamp(Vector2(.25,.25),Vector2(3,3))
 factors.x=minf(factors.x,view.x/maxf(1,panel.size.x))
 factors.y=minf(factors.y,view.y/maxf(1,panel.size.y))
 panel.scale=factors
 var fraction:Vector2=data.get("position",Vector2.ZERO)
 var position:Vector2=fraction*view
 var anchor:Vector2=data.get("screen_anchor",Vector2(-1,-1))
 for axis in 2:
  if anchor[axis]>=0:position[axis]=anchor[axis]*(view[axis]-panel.size[axis]*factors[axis])
 panel.position=position.clamp(Vector2.ZERO,(view-panel.size*factors).max(Vector2.ZERO))

func open_editor()->void:
 if editing:return
 before=layouts.duplicate(true)
 previous_color=color_name
 was_paused=get_tree().paused
 var cam=get_tree().get_first_node_in_group("free_camera")
 was_map=cam and cam.is_free_mode()
 if cam and not was_map:cam._enter_free_cam()
 var fleet=get_tree().get_first_node_in_group("fleet_sidebar")
 if fleet:fleet.show()
 get_tree().paused=true
 editing=true
 surface.show()

func _process(_delta:float)->void:
 if not editing:return
 for id in panels():apply_layout(id,panels()[id])
 surface.queue_redraw()

func _draw_editor()->void:
 for id in panels():
  var panel:Control=panels()[id]
  if not panel.is_visible_in_tree():continue
  var rect:=panel.get_global_rect()
  surface.draw_rect(rect,palette_color(Color("65ddea")),false,2)
  surface.draw_rect(Rect2(rect.end-Vector2(16,16),Vector2(16,16)),palette_color(Color("65ddea")))
  surface.draw_rect(Rect2(Vector2(rect.end.x-10,rect.get_center().y-12),Vector2(10,24)),palette_color(Color("65ddea")))
  surface.draw_rect(Rect2(Vector2(rect.get_center().x-12,rect.end.y-10),Vector2(24,10)),palette_color(Color("65ddea")))
  surface.draw_string(ThemeDB.fallback_font,rect.position+Vector2(8,18),id,HORIZONTAL_ALIGNMENT_LEFT,-1,14,Color("ffffff"))

 for guide in guides:
  var view:=get_viewport().get_visible_rect().size
  if guide.axis==0:surface.draw_line(Vector2(guide.at,0),Vector2(guide.at,view.y),Color("f0c16b"),1)
  else:surface.draw_line(Vector2(0,guide.at),Vector2(view.x,guide.at),Color("f0c16b"),1)

func snap_rect(rect:Rect2, resizing_axes:Vector2, exclude:String)->Rect2:
 guides.clear()
 var view:=get_viewport().get_visible_rect().size
 for axis in 2:
  var edges:Array=[0.0,view[axis]]
  for id in panels():
   var other:Control=panels()[id]
   if id==exclude or not other.is_visible_in_tree():continue
   var other_rect:=other.get_global_rect()
   edges.append(other_rect.position[axis])
   edges.append(other_rect.end[axis])
  var best:=13.0
  var adjustment:=0.0
  var aligned:=0.0
  if resizing_axes!=Vector2.ZERO and resizing_axes[axis]==0:continue
  var points:Array=[rect.end[axis]] if resizing_axes!=Vector2.ZERO else [rect.position[axis],rect.end[axis]]
  for edge in edges:
   for point in points:
    var distance:float=absf(edge-point)
    if distance<best:best=distance;adjustment=edge-point;aligned=edge
  if best<13:
   if resizing_axes==Vector2.ZERO:rect.position[axis]+=adjustment
   else:rect.size[axis]+=adjustment
   guides.append({"axis":axis,"at":aligned})
 return rect

func _edit_input(event:InputEvent)->void:
 if event is InputEventMouseButton and event.button_index==MOUSE_BUTTON_LEFT:
  selected=""
  guides.clear()
  if event.pressed:
   var entries=panels()
   var keys=entries.keys()
   keys.reverse()
   for id in keys:
    var panel:Control=entries[id]
    var rect:=panel.get_global_rect()
    if panel.is_visible_in_tree() and rect.has_point(event.position):
     selected=id
     start_mouse=event.position
     start_rect=rect
     resize_axes=Vector2(1 if event.position.x>rect.end.x-16 else 0,1 if event.position.y>rect.end.y-16 else 0)
     break
 elif event is InputEventMouseMotion and not selected.is_empty():
  var entries=panels()
  if not entries.has(selected):return
  var panel:Control=entries[selected]
  var view:=get_viewport().get_visible_rect().size
  var result:=start_rect
  var delta:Vector2=event.position-start_mouse
  if resize_axes!=Vector2.ZERO:result.size=(start_rect.size+delta*resize_axes).max(panel.size*.25)
  else:result.position+=delta
  if not event.alt_pressed:result=snap_rect(result,resize_axes,selected)
  else:guides.clear()
  var anchors:=Vector2(-1,-1)
  for axis in 2:
   if absf(result.position[axis])<1:anchors[axis]=0
   elif absf(result.end[axis]-view[axis])<1:anchors[axis]=1
  layouts[selected]={"position":result.position/view,"scale":result.size/panel.size,"screen_anchor":anchors}
  apply_layout(selected,panel)
 surface.accept_event()

func _action(action:String)->void:
 if action=="Reset defaults":
  layouts.clear()
  color_name="Blue"
  color_picker.select(0)
  repaint_ui()
  for panel in panels().values():panel.scale=Vector2.ONE
  # Default layout functions run while paused only when explicitly refreshed.
  var target=get_tree().get_first_node_in_group("targeting_hud")
  if target:
   target.own_card.place_at(get_viewport().get_visible_rect().size,false)
   target.target_card.place_at(get_viewport().get_visible_rect().size,true)
  var weapons=get_tree().get_first_node_in_group("weapon_control_hud")
  if weapons:weapons._process(0)
  var fleet=get_tree().get_first_node_in_group("fleet_sidebar")
  if fleet:fleet._process(0)
  return
 if action=="Save layout":
  var config:=ConfigFile.new()
  config.set_value("hud","panels",layouts)
  config.set_value("hud","color",color_name)
  if config.save(FILE)!=OK:
   message.text="Could not save layout. Try again."
   return
 else:
  layouts=before.duplicate(true)
  color_name=previous_color
  color_picker.select(COLORS.keys().find(color_name))
  repaint_ui()
 editing=false
 selected=""
 surface.hide()
 var cam=get_tree().get_first_node_in_group("free_camera")
 if cam and not was_map:cam._exit_free_cam()
 get_tree().paused=was_paused

func palette_color(source:Color)->Color:
 if color_name=="Blue" or source.s<.15 or source.h<.45 or source.h>.72:return source
 var accent:Color=COLORS.get(color_name,COLORS.Blue)
 return Color.from_hsv(accent.h,source.s,source.v,source.a)

func paint_panel(panel:Control)->void:
 if panel.get_meta("hud_palette","")==color_name:return
 for node in [panel]+panel.find_children("*","Control",true,false):paint_node(node)

func paint_node(node:Node)->void:
 if not is_instance_valid(node) or node.is_queued_for_deletion():return
 if not (node is Control or node is Window):return
 if node.get_meta("hud_palette","")==color_name:return
 node.set_meta("hud_palette",color_name)
 for property in node.get_property_list():
  var key:String=property.name
  if not key.begins_with("theme_override_colors/") and not key.begins_with("theme_override_styles/"):continue
  var value=node.get(key)
  if value==null:continue
  var baseline_key="palette_"+key.replace("/","_")
  if not node.has_meta(baseline_key):node.set_meta(baseline_key,value.duplicate() if value is Resource else value)
  var original=node.get_meta(baseline_key)
  if original is Color:node.set(key,palette_color(original))
  elif original is StyleBoxFlat:
   var style=original.duplicate()
   style.bg_color=palette_color(original.bg_color)
   style.border_color=palette_color(original.border_color)
   node.set(key,style)
 if node.theme:
  if not node.has_meta("palette_theme"):node.set_meta("palette_theme",node.theme)
  var themed:Theme=node.get_meta("palette_theme").duplicate(true)
  for type in themed.get_type_list():
   for key in themed.get_color_list(type):themed.set_color(key,type,palette_color(themed.get_color(key,type)))
   for key in themed.get_stylebox_list(type):
    var style=themed.get_stylebox(key,type)
    if style is StyleBoxFlat:
     style.bg_color=palette_color(style.bg_color)
     style.border_color=palette_color(style.border_color)
    elif style is StyleBoxLine:style.color=palette_color(style.color)
  node.theme=themed
 if node is CanvasItem:node.queue_redraw()

func repaint_ui()->void:
 for node in get_tree().get_nodes_in_group("palette_ui"):paint_node(node)
 for inspector in get_tree().get_nodes_in_group("station_inspection"):
  if inspector.has_method("_refresh_card"):inspector._refresh_card(true)
 surface.queue_redraw()

func _register_input_surface(node:Node)->void:
 if node is Control or node is Window:
  node.add_to_group("palette_ui")
  paint_node.call_deferred(node)
 if node is Window and node!=get_tree().root:node.add_to_group("ui_input_windows")
 if node is PanelContainer or node is ScrollContainer or node is Tree:
  node.mouse_force_pass_scroll_events=false
