extends ShipInstance

## Missile Boat — Small missile platform with triple pod launcher. 22px long, 8px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(11,0),Vector2(7,-3),Vector2(3,-4),Vector2(-10,-4),Vector2(-12,-2),Vector2(-12,2),Vector2(-10,4),Vector2(3,4),Vector2(7,3)])
	hull.color   = Color(0.2,0.25,0.45)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(8,-1),Vector2(8,1),Vector2(-10,1),Vector2(-10,-1)])
	detail0.color   = Color(0.15,0.2,0.35)
	add_child(detail0)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(9,0),Vector2(6,-2),Vector2(4,0),Vector2(6,2)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-12, -1.2),
		Vector2(-15.6, 0.0),
		Vector2(-12, 1.2),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(11,0),Vector2(3,-4),Vector2(-12,-2),Vector2(-12,2),Vector2(3,4)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(13,0),Vector2(9,-6),Vector2(0,-9),Vector2(-12,-6),Vector2(-15,0),Vector2(-12,6),Vector2(0,9),Vector2(9,6)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(8.0, -0.6),
		Vector2(13.0, -0.6),
		Vector2(13.0, 0.6),
		Vector2(8.0, 0.6),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(13.0, 0.0)
	add_child(m0)

	## Missile pod 0 — always visible
	var mpod0 := Polygon2D.new()
	mpod0.polygon = PackedVector2Array([
		Vector2(-8.0,       -5.2),
		Vector2(-2.0, -5.2),
		Vector2(-2.0, -2.8),
		Vector2(-8.0,       -2.8),
	])
	mpod0.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod0)
	missile_nodes.append(mpod0)

	var ml0 := Marker2D.new()
	ml0.name     = "MissileLaunch0"
	ml0.position = Vector2(-2.0, -4.0)
	add_child(ml0)

	## Missile pod 1 — always visible
	var mpod1 := Polygon2D.new()
	mpod1.polygon = PackedVector2Array([
		Vector2(-8.0,       -1.2),
		Vector2(-2.0, -1.2),
		Vector2(-2.0, 1.2),
		Vector2(-8.0,       1.2),
	])
	mpod1.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod1)
	missile_nodes.append(mpod1)

	var ml1 := Marker2D.new()
	ml1.name     = "MissileLaunch1"
	ml1.position = Vector2(-2.0, 0.0)
	add_child(ml1)

	## Missile pod 2 — always visible
	var mpod2 := Polygon2D.new()
	mpod2.polygon = PackedVector2Array([
		Vector2(-8.0,       2.8),
		Vector2(-2.0, 2.8),
		Vector2(-2.0, 5.2),
		Vector2(-8.0,       5.2),
	])
	mpod2.color   = Color(0.25, 0.28, 0.25, 0.7)
	add_child(mpod2)
	missile_nodes.append(mpod2)

	var ml2 := Marker2D.new()
	ml2.name     = "MissileLaunch2"
	ml2.position = Vector2(-2.0, 4.0)
	add_child(ml2)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"missile_boat", vc)
