extends ShipInstance

## Medium Miner — Medium mining vessel with extended drill array. 85px long, 36px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(30,-5),Vector2(42,0),Vector2(30,5),Vector2(24,18),Vector2(-36,18),Vector2(-42,12),Vector2(-42,-12),Vector2(-36,-18),Vector2(24,-18)])
	hull.color   = Color(0.3,0.35,0.28)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(30,-5),Vector2(50,-10),Vector2(50,-4),Vector2(30,-2)])
	detail0.color   = Color(0.38,0.35,0.28)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(30,5),Vector2(50,10),Vector2(50,4),Vector2(30,2)])
	detail1.color   = Color(0.38,0.35,0.28)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(20,-14),Vector2(20,14),Vector2(-34,14),Vector2(-34,-14)])
	detail2.color   = Color(0.2,0.24,0.2)
	add_child(detail2)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(36,0),Vector2(28,-4),Vector2(22,0),Vector2(28,4)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-42, -8.8),
		Vector2(-50.4, -6.0),
		Vector2(-42, -3.2),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	var eng1 := Polygon2D.new()
	eng1.polygon = PackedVector2Array([
		Vector2(-42, 3.2),
		Vector2(-50.4, 6.0),
		Vector2(-42, 8.8),
	])
	eng1.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng1)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(42,0),Vector2(24,-18),Vector2(-42,-12),Vector2(-42,12),Vector2(24,18)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(46,0),Vector2(32,-22),Vector2(0,-25),Vector2(-40,-18),Vector2(-46,0),Vector2(-40,18),Vector2(0,25),Vector2(32,22)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(28.0, -7.0),
		Vector2(50.0, -7.0),
		Vector2(50.0, -5.0),
		Vector2(28.0, -5.0),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(50.0, -6.0)
	add_child(m0)

	## Weapon barrel 1 — hidden when unequipped
	var wbarrel1 := Polygon2D.new()
	wbarrel1.polygon = PackedVector2Array([
		Vector2(28.0, 5.0),
		Vector2(50.0, 5.0),
		Vector2(50.0, 7.0),
		Vector2(28.0, 7.0),
	])
	wbarrel1.color   = Color(0.95, 0.95, 0.8)
	wbarrel1.visible = false
	add_child(wbarrel1)
	weapon_nodes.append(wbarrel1)

	var m1 := Marker2D.new()
	m1.name     = "Muzzle1"
	m1.position = Vector2(50.0, 6.0)
	add_child(m1)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"medium_miner", vc)
