class_name MissileHUD
extends CanvasLayer

## Small HUD indicator for missile arming state.
## Add to Player scene as a child alongside MissileSystem.
## Scene tree:
##   MissileHUD (CanvasLayer + MissileHUD.gd)
##     Panel (PanelContainer)
##       VBoxContainer
##         StateLabel (Label)   -- SELECTING / ARMING / ARMED
##         CountLabel (Label)   -- e.g. '2 / 4 missiles'
##         ProgressBar (ProgressBar)

@onready var state_label    : Label       = $Panel/VBoxContainer/StateLabel
@onready var count_label    : Label       = $Panel/VBoxContainer/CountLabel
@onready var progress_bar   : ProgressBar = $Panel/VBoxContainer/ProgressBar

var _missile_system : MissileSystem = null


func _ready() -> void:
	hide()
	## Find sibling MissileSystem
	await get_tree().process_frame
	var player := get_tree().get_first_node_in_group("player")
	if player:
		_missile_system = player.get_node_or_null("MissileSystem") as MissileSystem
		if _missile_system:
			_missile_system.state_changed.connect(_on_state_changed)
			_missile_system.armed_count_changed.connect(_on_count_changed)
			_missile_system.arm_progress_changed.connect(_on_progress_changed)
			_missile_system.missiles_fired.connect(_on_missiles_fired)


func _on_state_changed(state: MissileSystem.State) -> void:
	match state:
		MissileSystem.State.IDLE:
			hide()
		MissileSystem.State.SELECTING:
			state_label.text = "HOLD RIGHT + SCROLL: QUANTITY | RELEASE: ARM"
			state_label.add_theme_color_override("font_color", Color(0.8, 0.8, 0.2))
			progress_bar.value = 0.0
			progress_bar.hide()
			show()
		MissileSystem.State.ARMING:
			state_label.text = "ARMING"
			state_label.add_theme_color_override("font_color", Color(0.9, 0.5, 0.1))
			progress_bar.show()
			show()
		MissileSystem.State.ARMED:
			state_label.text = "ARMED — RIGHT CLICK TO FIRE"
			state_label.add_theme_color_override("font_color", Color(0.2, 1.0, 0.3))
			progress_bar.value = 1.0
			show()


func _on_count_changed(count: int, max_count: int) -> void:
	count_label.text = "%d / %d missiles" % [count, max_count]


func _on_progress_changed(progress: float) -> void:
	progress_bar.value = progress


func _on_missiles_fired(count: int) -> void:
	count_label.text = "Fired %d missile%s" % [count, "s" if count != 1 else ""]
