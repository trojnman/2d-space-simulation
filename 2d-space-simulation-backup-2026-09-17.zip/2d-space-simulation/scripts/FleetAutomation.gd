extends RefCounted
static func reachable(home:StringName,hops:int,blocked:Array)->Dictionary:
 var distances:Dictionary={}
 if home in blocked or not GameData.sectors.has(home):return distances
 distances[home]=0
 var queue:Array=[home]
 while not queue.is_empty():
  var id=queue.pop_front()
  if distances[id]>=hops:continue
  for next in GameData.sectors[id].connected_sectors:
   if next in blocked or distances.has(next):continue
   distances[next]=distances[id]+1;queue.append(next)
 return distances
static func path(start:StringName,finish:StringName,allowed:Dictionary)->Array:
 if not allowed.has(start) or not allowed.has(finish):return []
 var queue:Array=[start]
 var parents:Dictionary={start:null}
 while not queue.is_empty():
  var id=queue.pop_front()
  if id==finish:
   var result:Array=[]
   while id!=null:result.push_front(id);id=parents[id]
   return result
  for next in GameData.sectors[id].connected_sectors:
   if not allowed.has(next) or parents.has(next):continue
   parents[next]=id;queue.append(next)
 return []
static func allowed(ai:AIShipController)->Dictionary:
 return reachable(ai.automation_home,ai.automation_hops,ai.no_go_sectors)
static func navigate(ai:AIShipController,goal:Node,delta:float)->bool:
 var sector=preload("res://scripts/StationConstruction.gd").sector_of(ai._ship)
 var destination=preload("res://scripts/StationConstruction.gd").sector_of(goal)
 if not sector or not destination:return false
 var permitted=allowed(ai)
 if ai.fleet_job.get("automatic",false) and (not permitted.has(destination.sector_data.id) or not permitted.has(sector.sector_data.id)):
  ai.job_status="Blocked by sector policy";ai._ship.velocity=Vector2.ZERO;return true
 if sector==destination:return false
 var route=path(sector.sector_data.id,destination.sector_data.id,permitted)
 if route.size()<2:ai.job_status="Waiting: no permitted gate route";ai._ship.velocity=Vector2.ZERO;return true
 for gate in sector.get_node("JumpGates").get_children():
  if gate.destination_sector_id!=route[1]:continue
  ai.job_status="Travelling to "+GameData.sectors[route[1]].display_name
  if ai._ship.position.distance_to(gate.position)>200:ai._move_toward(gate.position,delta)
  elif not ai.fleet_job.get("jumping",false):
   ai.fleet_job.jumping=true
   SectorManager.transfer_job_ship.call_deferred(ai._ship,route[1])
  return true
 ai.job_status="Waiting: gate unavailable"
 return true
static func plan(ai:AIShipController)->void:
 if ai.automation_home==&"":
  var sector=preload("res://scripts/StationConstruction.gd").sector_of(ai._ship)
  if sector:ai.automation_home=sector.sector_data.id
 var sectors=allowed(ai)
 var stations:Array=[]
 var rocks:Array=[]
 var preparing:=false
 for id in sectors:
  var sector=SectorManager._visited_sectors.get(id)
  if not is_instance_valid(sector):
   preparing=true
   SectorManager._initialize_shared_sector.call_deferred(id)
   continue
  if sector.is_inside_tree() and sector!=SectorManager.current_sector:preparing=true;continue
  for station in SectorManager.get_sector_stations(sector):
   if not PlayerState.is_hostile_to_player(station.faction_id):stations.append(station)
  if ai.default_behavior=="auto_mine":
   for rock in sector.get_node("Asteroids").get_children():
    if rock is AsteroidInstance and not rock._is_destroyed and rock._remaining_yield!=0:rocks.append(rock)
 if preparing:ai.job_status="Preparing sector search";return
 var item:StringName=ai.automation_item
 var destination:StationInstance
 # Sell already-carried cargo before purchasing or mining more.
 var cargo=ai._ship.inventory.get_all_items()
 if ai.default_behavior=="auto_mine":
  var has_miner:bool=ai._ship.equipped_weapons.any(func(w):return w and w.weapon_type==GlobalEnums.WeaponType.MINING)
  if not has_miner:ai.job_status="Auto Mine needs a mining laser";return
  for rock in rocks:
   var mineral:StringName=AsteroidInstance.MATERIAL_IDS[rock.material_type]
   if item!=&"" and mineral!=item:continue
   for station in stations:
    if station.faction_id==&"player" or station._station_buys_item(mineral):
     destination=station
     ai.fleet_job={"kind":"mine","destination":destination,"mine_sector_id":preload("res://scripts/StationConstruction.gd").sector_of(rock).sector_data.id,"item":mineral,"amount":ai.automation_amount,"repeat":false,"automatic":true,"phase":"deliver" if ai._ship.inventory.get_amount(mineral)>=ai.automation_amount else "collect"}
     return
  ai.job_status="Waiting: no permitted mineral and buyer";return
 for id in cargo:
  if item!=&"" and id!=item:continue
  if not GameData.items[id].is_component and not GameData.items[id].is_raw_material:continue
  for station in stations:
   if station.faction_id!=&"player" and station._station_buys_item(id) and station.station_credits>=station.get_buy_price(id):
    ai.fleet_job={"kind":"trade","destination":station,"item":id,"amount":ai.automation_amount,"repeat":false,"automatic":true,"phase":"deliver"};return
 var best_profit:int=0
 var best:Dictionary={}
 for source in stations:
  for id in source.inventory.get_all_items():
   if item!=&"" and id!=item:continue
   if not GameData.items[id].is_component and not GameData.items[id].is_raw_material:continue
   if source.faction_id!=&"player" and not source._station_sells_item(id):continue
   if source.inventory.get_amount(id)<=source.get_export_reserve(id):continue
   var cost:int=0 if source.faction_id==&"player" else source.get_sell_price(id)
   if cost>PlayerState.credits:continue
   for buyer in stations:
    if buyer==source or buyer.faction_id==&"player" or not buyer._station_buys_item(id):continue
    var demand:int=maxi(0,buyer.get_supply_target(id)-buyer.inventory.get_amount(id))
    if demand<=0:continue
    var profit:int=buyer.get_buy_price(id)-cost
    if profit<=best_profit or buyer.station_credits<buyer.get_buy_price(id):continue
    best_profit=profit
    best={"kind":"trade","source":source,"destination":buyer,"item":id,"amount":mini(ai.automation_amount,demand),"repeat":false,"automatic":true,"phase":"collect"}
 if not best.is_empty():ai.fleet_job=best
 else:ai.job_status="Waiting: no profitable permitted trade"
