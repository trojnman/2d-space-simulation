class_name DockingManager
extends Node

## Attach to your Main scene node.
## Listens for nearby stations and handles the dock/undock flow.

signal docked(station: StationInstance)
signal undocked()

@export var station_ui_scene : PackedScene = null

var current_station  : StationInstance    = null
var _nearby_stations : Array[StationInstance] = []
var _player          : Player = null
var _station_ui      : Node   = null


func _ready() -> void:
	await get_tree().process_frame
	_player = get_tree().get_first_node_in_group("player") as Player
	print("DockingManager: player found = ", _player)

	for s in get_tree().get_nodes_in_group("stations"):
		print("DockingManager: found station = ", s.name)
		_connect_station(s as StationInstance)


func _input(event: InputEvent) -> void:
	_nearby_stations = _nearby_stations.filter(func(s): return is_instance_valid(s) and s.is_inside_tree() and not s._is_destroyed)
	if event.is_action_pressed("dock"):
		if current_station == null and _nearby_stations.size() > 0:
			_dock(_nearby_stations[0])
		elif current_station != null:
			_undock()


# ---------------------------------------------------------------------------
# Station connections
# ---------------------------------------------------------------------------

func _connect_station(station: StationInstance) -> void:
	if station == null:
		return
	if not station.player_in_range.is_connected(_on_player_in_range):
		station.player_in_range.connect(_on_player_in_range)
	if not station.player_out_of_range.is_connected(_on_player_out_of_range):
		station.player_out_of_range.connect(_on_player_out_of_range)


func _on_player_in_range(station: StationInstance) -> void:
	print("DockingManager: player entered range of ", station.name)
	if not _nearby_stations.has(station):
		_nearby_stations.append(station)


func _on_player_out_of_range(station: StationInstance) -> void:
	print("DockingManager: player left range of ", station.name)
	_nearby_stations.erase(station)


# ---------------------------------------------------------------------------
# Dock / undock
# ---------------------------------------------------------------------------

func _dock(station: StationInstance) -> void:
	if not is_instance_valid(station) or not station.is_inside_tree() or station._is_destroyed: return
	print("DockingManager: docking at ", station.name)
	if not station.can_dock():
		print("DockingManager: can_dock() returned false")
		return
	current_station = station
	if _player:
		_player.dock()
	# The economy continues while the player is docked.
	_open_station_ui(station)
	docked.emit(station)


func _undock() -> void:
	if current_station == null: return
	var spawn_pos := current_station.global_position + Vector2(
		current_station.get_docking_range() * 1.2, 0
	)
	_close_station_ui()
	get_tree().paused = false
	if _player:
		_player.undock(spawn_pos)
	current_station = null
	undocked.emit()


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------

func _open_station_ui(station: StationInstance) -> void:
	if station_ui_scene == null:
		push_warning("DockingManager: station_ui_scene not assigned")
		return
	if _station_ui:
		_station_ui.queue_free()
	_station_ui = station_ui_scene.instantiate()
	get_tree().current_scene.add_child(_station_ui)
	if _station_ui.has_method("open"):
		_station_ui.open(station, _player)


func _close_station_ui() -> void:
	if _station_ui:
		_station_ui.queue_free()
		_station_ui = null


func prepare_sector_change() -> void:
	if is_instance_valid(current_station): _undock()
	current_station = null
	_nearby_stations.clear()
