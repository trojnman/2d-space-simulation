extends RefCounted
static func mounts() -> Array[Dictionary]:
 var result:Array[Dictionary]=[]
 for i in 8:
  var arm:=i/2
  result.append({"id":&"laser_autocannon_s3","missile":false,"position":Vector2(80+(i%2)*24,0).rotated(arm*PI/2),"size":3})
 for i in 10:
  result.append({"id":&"laser_autocannon_s1","missile":false,"position":Vector2.from_angle(i*TAU/10)*28,"size":1})
 for tier in [3,1]:
  for i in 6:
   result.append({"id":StringName("missile_s%d" % tier),"missile":true,"position":Vector2(48+(i/4)*15,8 if tier==3 else -8).rotated((i%4)*PI/2),"size":tier})
 return result
static func tick(station:StationInstance,delta:float)->void:
 var layout:=mounts()
 if station.defense_cooldowns.size()!=layout.size():station.defense_cooldowns.resize(layout.size());station.defense_cooldowns.fill(0.0)
 station.defense_energy=minf(2000,station.defense_energy+800*delta)
 var sector=preload("res://scripts/StationConstruction.gd").sector_of(station)
 if not sector:return
 var candidates:Array=station.get_tree().get_nodes_in_group("ships") if station.is_inside_tree() else sector.find_children("*","",true,false)
 for i in layout.size():
  station.defense_cooldowns[i]=maxf(0,station.defense_cooldowns[i]-delta)
  if station.defense_cooldowns[i]>0:continue
  var mount:Dictionary=layout[i]
  var weapon=GameData.missiles[mount.id] if mount.missile else GameData.weapons[mount.id]
  if mount.missile and station.inventory.get_amount(mount.id)<1:continue
  if not mount.missile and station.defense_energy<weapon.energy_per_shot:continue
  var origin:Vector2=station.position+mount.position*StationInstance.STATION_SIZE_MULTIPLIER
  var distance:float=minf(weapon.lock_on_range,weapon.speed*weapon.lifetime) if mount.missile else weapon.max_range
  var target:ShipInstance
  for ship in candidates:
   if not ship is ShipInstance or ship._is_destroyed or ship.is_queued_for_deletion() or not ship.ship_data or ship.ship_data.id==&"escape_pod":continue
   var faction:StringName=&"player" if ship.is_in_group("player") or ship.is_in_group("player_fleet") else ship.faction_id
   if not FactionManager.are_at_war(station.faction_id,faction):continue
   var d:float=origin.distance_to(ship.position)
   if d<distance:distance=d;target=ship
  if not target:continue
  var direction:=origin.direction_to(target.position)
  if station.is_inside_tree():
   var shot=load("res://scenes/Missile.tscn" if mount.missile else "res://scenes/Bullet.tscn").instantiate()
   shot.position=origin+direction*(22 if mount.size==3 else 14)
   shot.rotation=direction.angle()
   if mount.missile:
    shot.launch(Vector2.ZERO,station,weapon)
    shot._target=target
    shot._target_acquired=true
   else:shot.launch(direction*weapon.projectile_speed,station,weapon)
   sector.add_child(shot)
   var visuals=station.get_node_or_null("StationVisuals")
   if visuals and visuals._turrets.size()>i:visuals._turrets[i].rotation=direction.angle()
  elif mount.missile:target.take_damage_from_missile(weapon,station)
  else:target.take_damage_from_weapon(weapon,station)
  if mount.missile:
   station.inventory.remove_item(mount.id,1)
   station.defense_cooldowns[i]=5.0
  else:
   station.defense_energy-=weapon.energy_per_shot
   station.defense_cooldowns[i]=60.0/maxf(1,weapon.fire_rate_rpm)
