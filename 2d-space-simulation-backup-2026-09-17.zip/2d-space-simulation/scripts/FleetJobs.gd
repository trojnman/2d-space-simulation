extends RefCounted
static func available(ai:AIShipController,node:Node)->bool:
 return is_instance_valid(node) and not node.is_queued_for_deletion() and not node.get("_is_destroyed")
static func station_ok(ai:AIShipController,node:Node)->bool:
 return available(ai,node) and node is StationInstance and not PlayerState.is_hostile_to_player(node.faction_id)
static func approach(ai:AIShipController,node:Node2D,range_limit:float,delta:float)->bool:
 ai._waypoint=node.global_position
 if ai._ship.global_position.distance_to(node.global_position)>range_limit:
  ai._move_toward(node.global_position,delta)
  return false
 ai._ship.velocity=Vector2.ZERO
 return true
static func room(inv:InventoryData,id:StringName)->int:
 var item=GameData.get_item(id)
 if not item:return 0
 if inv.capacity<=0:return 2147483647
 return maxi(0,int(inv.get_free_capacity(GameData.items)/maxf(.001,item.volume)))
static func tick(ai:AIShipController,delta:float)->bool:
 ai.hostile_alert_seconds=maxf(0,ai.hostile_alert_seconds-delta)
 if ai._is_fleet_ship and ai._state==AIShipController.State.GO_WAIT and ai._ship.global_position.distance_to(ai._waypoint)>100:
  if ai._ship.global_position.distance_to(ai.order_last_position)>25:ai.order_stall_seconds=0;ai.order_last_position=ai._ship.global_position
  else:ai.order_stall_seconds+=delta
  if ai.order_stall_seconds>45:ai.fail_order("Movement blocked: no progress");return true
 else:ai.order_stall_seconds=0
 if ai._is_fleet_ship and ai._state in [AIShipController.State.FOLLOW,AIShipController.State.DEFEND] and not is_instance_valid(ai._follow_target):
  ai.fail_order("Follow / defend target unavailable")
  return true
 var result=_tick(ai,delta)
 if result and (ai.job_status.begins_with("Waiting:") or ai.job_status.begins_with("Blocked") or ai.job_status.begins_with("Auto Mine needs")):
  ai.fail_order(ai.job_status)
 return result
static func _tick(ai:AIShipController,delta:float)->bool:
 if ai.fleet_job.is_empty():
  if ai.default_behavior in ["auto_mine","auto_trade","auto_resupply"] and not ai.default_suspended and ai._state in [AIShipController.State.IDLE,AIShipController.State.STAY]:
   ai.automation_retry-=delta
   if ai.automation_retry<=0:
    ai.automation_retry=3.0
    if ai.default_behavior=="auto_resupply":preload("res://scripts/FleetResupply.gd").plan(ai)
    else:preload("res://scripts/FleetAutomation.gd").plan(ai)
   return true
  return false
 var job=ai.fleet_job
 var ship=ai._ship
 if not ship.is_in_group("player_fleet"):return false
 var threat=ai._find_nearest_enemy(2500.0)
 if threat:
  ai.job_status="Evading threat; job retained"
  ai._target=threat
  preload("res://scripts/ShipTactics.gd").steer(ai,(ship.global_position-threat.global_position).normalized()*ship.ship_data.max_speed,ship.global_position-threat.global_position,delta)
  return true
 var id:StringName=job.item
 var destination=job.get("destination")
 var source=job.get("source")
 var kind:String=job.kind
 var phase:String=job.get("phase","collect")
 if job.has("fleet"):
  if not available(ai,destination) or destination.fleet_name!=job.fleet:
   ai.job_status="Waiting: resupply recipient left fleet or was destroyed";return true
  var needs=preload("res://scripts/FleetResupply.gd").needs(destination,ai.resupply_ammo,ai.resupply_volleys)
  if not needs.has(id) or destination.inventory.get_amount(id)>=int(needs.get(id,0)):complete(ai);return true
  job.amount=needs[id]
 var travel_goal=SectorManager._visited_sectors.get(job.get("mine_sector_id",&"")) if kind=="mine" and phase=="collect" else (source if phase=="collect" else destination)
 if is_instance_valid(travel_goal) and preload("res://scripts/FleetAutomation.gd").navigate(ai,travel_goal,delta):return true
 if kind=="mine" and phase=="collect":
  if not station_ok(ai,destination):ai.job_status="Waiting: home station unavailable";ship.velocity=Vector2.ZERO;return true
  if ship.inventory.get_amount(id)>=int(job.amount) or room(ship.inventory,id)==0:
   job.phase="deliver"
   return true
  var asteroid:AsteroidInstance
  var closest:float=INF
  for rock in preload("res://scripts/TurretOrders.gd").sector_nodes(ship,&"asteroids"):
   if not rock is AsteroidInstance or rock.is_queued_for_deletion() or rock._remaining_yield==0:continue
   if AsteroidInstance.MATERIAL_IDS[rock.material_type]!=id:continue
   var distance:float=ship.global_position.distance_to(rock.global_position)
   if distance<closest:closest=distance;asteroid=rock
  if not asteroid:
   if ship.inventory.get_amount(id)>0:job.phase="deliver"
   ai.job_status="Waiting: selected mineral unavailable"
   ship.velocity=Vector2.ZERO
   return true
  ai.job_status="Mining "+str(id)
  if not approach(ai,asteroid,300,delta):return true
  for slot in ship.equipped_weapons.size():
   var weapon=ship.equipped_weapons[slot]
   if weapon and weapon.weapon_type==GlobalEnums.WeaponType.MINING:
    var direction:Vector2=ship.global_position.direction_to(asteroid.global_position)
    ship.rotation=direction.angle()
    if ship.fire_weapon(slot,direction,false):asteroid.take_mining_damage(weapon.damage,ship)
  return true
 if phase=="collect":
  if not station_ok(ai,source):ai.job_status="Waiting: source unavailable";ship.velocity=Vector2.ZERO;return true
  if kind=="resupply" and (not available(ai,destination) or not destination.is_in_group("player_fleet")):
   ai.job_status="Waiting: recipient unavailable";ship.velocity=Vector2.ZERO;return true
  if kind=="trade" and not station_ok(ai,destination):ai.job_status="Waiting: destination unavailable";ship.velocity=Vector2.ZERO;return true
  var desired:int=int(job.amount)
  if job.get("automatic",false) and kind=="trade":
   var cost:int=0 if source.faction_id==&"player" else source.get_sell_price(id)
   if destination.get_buy_price(id)<=cost:ai.job_status="Waiting: trade is no longer profitable";return true
   desired=mini(desired,maxi(0,destination.get_supply_target(id)-destination.inventory.get_amount(id)))
   if desired<=0:complete(ai);return true
  if kind=="resupply":desired=maxi(0,desired-destination.inventory.get_amount(id))
  if desired<=0:ai.job_status="Recipient stocked";ship.velocity=Vector2.ZERO;return true
  if ship.inventory.get_amount(id)>=desired:job.phase="deliver";return true
  ai.job_status="Collecting "+str(id)
  if not approach(ai,source,source.get_docking_range(),delta):return true
  var stock:int=source.inventory.get_amount(id)
  if job.get("automatic",false) and kind=="trade":stock=maxi(0,stock-source.get_export_reserve(id))
  var amount=mini(desired-ship.inventory.get_amount(id),mini(room(ship.inventory,id),stock))
  if source.faction_id==&"player":
   if amount>0 and ship.inventory.add_item(id,amount,GameData.items):source.inventory.remove_item(id,amount)
  else:
   amount=mini(amount,PlayerState.credits/maxi(1,source.get_sell_price(id)))
   if amount>0:source.player_buy_item(id,amount,ship.inventory)
  if ship.inventory.get_amount(id)>0:job.phase="deliver"
  else:ai.job_status="Waiting: stock, credits or cargo space"
  return true
 if kind=="resupply":
  if not available(ai,destination) or not destination.is_in_group("player_fleet"):ai.job_status="Waiting: recipient unavailable";ship.velocity=Vector2.ZERO;return true
  ai.job_status="Resupplying "+destination.ship_data.display_name
  if not approach(ai,destination,500,delta):return true
  var amount=mini(ship.inventory.get_amount(id),mini(room(destination.inventory,id),maxi(0,int(job.amount)-destination.inventory.get_amount(id))))
  if amount>0 and destination.inventory.add_item(id,amount,GameData.items):ship.inventory.remove_item(id,amount)
  if destination.inventory.get_amount(id)>=int(job.amount) or ship.inventory.get_amount(id)==0:complete(ai)
  else:ai.job_status="Waiting: recipient cargo space"
  return true
 if not station_ok(ai,destination):ai.job_status="Waiting: destination unavailable";ship.velocity=Vector2.ZERO;return true
 ai.job_status="Delivering "+str(id)
 if not approach(ai,destination,destination.get_docking_range(),delta):return true
 var amount=mini(ship.inventory.get_amount(id),room(destination.inventory,id))
 if destination.faction_id==&"player":
  if amount>0 and destination.inventory.add_item(id,amount,GameData.items):ship.inventory.remove_item(id,amount)
 else:
  amount=mini(amount,destination.station_credits/maxi(1,destination.get_buy_price(id)))
  if amount>0:destination.player_sell_item(id,amount,ship.inventory,PlayerState.credits)
 if ship.inventory.get_amount(id)==0:complete(ai)
 else:ai.job_status="Waiting: buyer funds, demand or storage"
 return true
static func complete(ai:AIShipController)->void:
 if not ai._command_queue.is_empty():
  ai.fleet_job.clear()
  ai._execute_next_command()
  return
 if ai.fleet_job.get("repeat",true):ai.fleet_job.phase="collect";ai.job_status="Repeating job"
 else:ai.fleet_job.clear();ai.job_status="Job completed"
