class_name AIShipController
extends Node

## AI brain for any ship. Attach as a child of ShipInstance.
## Drives behavior via a state machine with command queue support.

enum State {
	IDLE,
	PATROL,
	ATTACK,
	PURSUE,
	ASSIST,
	FLEE,
	HAUL,
	MINE,
	RETURN,
	FOLLOW,
	STAY,
	DEFEND,
	PATROL_AREA,
	PATROL_ROUTE,
	GO_WAIT,
}

const THINK_INTERVAL  : float = 0.3
const ARRIVE_RADIUS   : float = 200.0
const SENSOR_RADIUS   : float = 8000.0
const PURSUE_TIMEOUT  : float = 15.0
const FLEE_THRESHOLD  : float = 0.4
const MINE_DURATION   : float = 60.0
const HAUL_WAIT       : float = 60.0

var _ship             : ShipInstance   = null
var _state            : State          = State.IDLE
var _target           : Node2D         = null
var _waypoint         : Vector2        = Vector2.ZERO
var _follow_target    : Node2D         = null
var _defend_target    : Node2D         = null
var _patrol_radius    : float          = 1000.0
var _patrol_center    : Vector2        = Vector2.ZERO
var _patrol_route     : Array[Vector2] = []
var _patrol_route_idx : int            = 0
var _home_station     : Node2D         = null
var _think_timer      : float          = 0.0
var _state_timer      : float          = 0.0
var _pursue_timer     : float          = 0.0
var _is_combat_ship   : bool           = false
var supply_station: StationInstance = null
var supply_scaffold: Node2D = null

var _is_fleet_ship    : bool           = false
var _patrol_points    : Array[Vector2] = []
var _patrol_idx       : int            = 0
var _haul_source: StationInstance = null
var _haul_destination: StationInstance = null
var _haul_item: StringName = &""
var _haul_loaded: bool = false
var _haul_manifest_amount: int = 0

var _command_queue    : Array          = []
var _missile_cooldown: float = 0.0
var _background_initialized := false


func _ready() -> void:
	name = "AIShipController"
	_ship = get_parent() as ShipInstance
	if not _ship:
		push_warning("AIShipController: parent is not ShipInstance")
		return
	if not _ship.ship_destroyed.is_connected(_on_ship_destroyed): _ship.ship_destroyed.connect(_on_ship_destroyed)
	if not _ship.hull_changed.is_connected(_on_hull_changed): _ship.hull_changed.connect(_on_hull_changed)
	_is_fleet_ship = _ship.is_in_group("player_fleet")
	FactionManager.register_ship(_ship)
	if _background_initialized:return
	await get_tree().process_frame
	_initialize()


func _initialize() -> void:
	if not _ship or not _ship.ship_data: return
	var id : StringName = _ship.ship_data.id
	_is_combat_ship = _ship.faction_id == &"rogue" or id.contains("fighter") or id.contains("missile_boat")
	if not is_instance_valid(_home_station): _home_station = _find_closest_friendly_station()
	_generate_patrol_points()
	if _is_fleet_ship:
		_set_state(State.IDLE)
	elif _is_combat_ship:
		_set_state(State.PATROL)
	elif id.contains("hauler") or id.contains("logistics"):
		_set_state(State.HAUL)
	elif id.contains("miner"):
		_set_state(State.MINE)
	else:
		_set_state(State.PATROL)


func _physics_process(delta: float) -> void:
	if not _is_fleet_ship and is_instance_valid(_target) and _target is ShipInstance and not _is_enemy(_target):
		_target=null
		_set_state(State.IDLE)
	if is_instance_valid(_target) and _target is ShipInstance and _target.ship_data and _target.ship_data.id == &"escape_pod":
		_target = null
		_set_state(State.IDLE)
	if not _ship or _ship._is_destroyed: return
	_ship.tick(delta)
	_missile_cooldown = maxf(0, _missile_cooldown - delta)
	if _resupply(delta): return
	_think_timer -= delta
	_state_timer  += delta
	if _think_timer <= 0.0:
		_think_timer = THINK_INTERVAL
		_think()
	_execute_state(delta)


# ---------------------------------------------------------------------------
# Command queue API
# ---------------------------------------------------------------------------

func queue_command(command: Dictionary) -> void:
	_command_queue.append(command)
	if _state == State.IDLE:
		_execute_next_command()


func set_command_queue(commands: Array) -> void:
	_command_queue = commands.duplicate()
	_execute_next_command()


func cancel_last_command() -> void:
	if _command_queue.size() > 0:
		_command_queue.pop_back()
	if _command_queue.is_empty():
		_set_state(State.IDLE)


func cancel_all_commands() -> void:
	supply_scaffold=null
	supply_station = null
	_command_queue.clear()
	_set_state(State.IDLE)


func get_command_queue() -> Array:
	return _command_queue.duplicate()


func _execute_next_command() -> void:
	if _command_queue.is_empty():
		_set_state(State.IDLE)
		return
	var command : Dictionary = _command_queue[0]
	_command_queue.remove_at(0)
	_apply_command(command)


func _apply_command(command: Dictionary) -> void:
	supply_scaffold=null
	supply_station = null
	match command.get("type", -1):
		GlobalEnums.FleetCommand.FOLLOW_SHIP:
			_follow_target = command.get("target", null)
			_set_state(State.FOLLOW)
		GlobalEnums.FleetCommand.DEFEND_SHIP:
			_defend_target = command.get("target", null)
			_follow_target = _defend_target
			_set_state(State.DEFEND)
		GlobalEnums.FleetCommand.GO_WAIT:
			_waypoint = command.get("position", _ship.global_position)
			_set_state(State.GO_WAIT)
		GlobalEnums.FleetCommand.PATROL_AREA:
			_patrol_center = command.get("position", _ship.global_position)
			_patrol_radius = command.get("radius", 1000.0)
			_set_state(State.PATROL_AREA)
		GlobalEnums.FleetCommand.PATROL_ROUTE:
			_patrol_route     = command.get("points", [])
			_patrol_route_idx = 0
			if _patrol_route.size() > 0:
				_waypoint = _patrol_route[0]
			_set_state(State.PATROL_ROUTE)
		GlobalEnums.FleetCommand.ATTACK_TARGET:
			_target = command.get("target", null)
			_set_state(State.ATTACK)


# ---------------------------------------------------------------------------
# Decision loop
# ---------------------------------------------------------------------------

func _think() -> void:
	match _state:
		State.PATROL:       _think_patrol()
		State.ATTACK:       _think_attack()
		State.PURSUE:       _think_pursue()
		State.ASSIST:       _think_assist()
		State.FLEE:         _think_flee()
		State.HAUL:         _think_haul()
		State.MINE:         _think_mine()
		State.RETURN:       _think_return()
		State.FOLLOW:       _think_follow()
		State.STAY:         _think_stay()
		State.DEFEND:       _think_defend()
		State.PATROL_AREA:  _think_patrol_area()
		State.PATROL_ROUTE: _think_patrol_route()
		State.GO_WAIT:      _think_go_wait()
		State.IDLE:
			if not _command_queue.is_empty():
				_execute_next_command()


func _think_patrol() -> void:
	var enemy := _find_nearest_enemy(SENSOR_RADIUS)
	if enemy:
		_target = enemy
		_set_state(State.ATTACK)
		return
	if _is_combat_ship:
		var distressed := _find_distressed_friendly(SENSOR_RADIUS * 1.5)
		if distressed:
			_target = distressed
			_set_state(State.ASSIST)
			return
	if _ship.global_position.distance_to(_waypoint) < ARRIVE_RADIUS:
		_next_patrol_point()


func _think_attack() -> void:
	if not is_instance_valid(_target) or _target._is_destroyed:
		_target = _find_nearest_enemy(SENSOR_RADIUS)
		if not _target:
			if _is_fleet_ship:
				_execute_next_command()
			else:
				_set_state(State.PATROL)
		return
	if not _is_combat_ship:
		_set_state(State.FLEE)
		return
	var dist : float = _ship.global_position.distance_to(_target.global_position)
	if dist > SENSOR_RADIUS * 2.0:
		_pursue_timer += THINK_INTERVAL
		if _pursue_timer >= PURSUE_TIMEOUT:
			_pursue_timer = 0.0
			_target = null
			if _is_fleet_ship:
				_execute_next_command()
			else:
				_set_state(State.PATROL)


func _think_pursue() -> void:
	if not is_instance_valid(_target) or _target._is_destroyed:
		_target = null
		_set_state(State.PATROL)
		return
	_pursue_timer += THINK_INTERVAL
	if _pursue_timer >= PURSUE_TIMEOUT:
		_pursue_timer = 0.0
		_set_state(State.PATROL)


func _think_assist() -> void:
	if not is_instance_valid(_target):
		_set_state(State.PATROL)
		return
	var enemy := _find_nearest_enemy(SENSOR_RADIUS)
	if enemy:
		_target = enemy
		_set_state(State.ATTACK)
		return
	if _state_timer > 10.0:
		_set_state(State.PATROL)


func _think_flee() -> void:
	if is_instance_valid(_home_station) and _ship.global_position.distance_to(_home_station.global_position) < 300.0:
		_set_state(_get_default_state())
		return
	if _ship.shield > _ship.max_shield * 0.8:
		_set_state(_get_default_state())


func _think_haul() -> void:
	if is_instance_valid(supply_scaffold):
		_think_scaffold_supply()
		return
	if _is_fleet_ship and (not is_instance_valid(supply_station) or supply_station._is_destroyed or supply_station.faction_id != &"player"):
		supply_station = null
		_set_state(State.IDLE)
		return
	if not is_instance_valid(_haul_source) or not is_instance_valid(_haul_destination) or _haul_source._is_destroyed or _haul_destination._is_destroyed or (not _haul_loaded and FactionManager.are_at_war(_haul_source.faction_id, _ship.faction_id)) or _haul_destination.faction_id != _ship.faction_id:
		_pick_haul_destination()
		return
	var service_station: StationInstance = _haul_destination if _haul_loaded else _haul_source
	if not _in_service_range(service_station): return
	if not _haul_loaded:
		var item: ItemData = GameData.items.get(_haul_item)
		if item == null or item.volume <= 0.0:
			_pick_haul_destination()
			return
		var available: int = _haul_source.inventory.get_amount(_haul_item) - _haul_source.get_supply_target(_haul_item)
		var amount: int = mini(available, _station_shortage(_haul_destination, _haul_item))
		amount = mini(amount, int(_ship.inventory.get_free_capacity(GameData.items) / item.volume))
		if _haul_source.faction_id != _ship.faction_id:
			var price: int = _haul_source.get_sell_price(_haul_item)
			amount = mini(amount, int(FactionManager.get_faction_credits(_ship.faction_id) / maxi(1, price)))
		if amount <= 0:
			_pick_haul_destination()
			return
		if _haul_source.faction_id == _ship.faction_id:
			if not _ship.inventory.add_item(_haul_item, amount, GameData.items): return
			_haul_source.inventory.remove_item(_haul_item, amount)
		else:
			if not FactionManager.purchase_cargo(_ship, _haul_source, _haul_item, amount):
				_pick_haul_destination()
				return
		_haul_manifest_amount = amount
		_haul_loaded = true
		_waypoint = _haul_destination.global_position
	else:
		var amount: int = _deliverable_cargo(_haul_item)
		if amount > 0:
			if not _haul_destination.inventory.add_item(_haul_item, amount, GameData.items): return
			_ship.inventory.remove_item(_haul_item, amount)
			print("Economy: delivered %d %s to %s" % [amount, _haul_item, _haul_destination.station_data.display_name])
		_haul_manifest_amount = 0
		_haul_loaded = false
		_pick_haul_destination()


func _think_mine() -> void:
	if _ship.inventory.get_free_capacity(GameData.items) < 1.0:
		_set_state(State.RETURN)
		return
	if _ship.global_position.distance_to(_waypoint) < ARRIVE_RADIUS:
		var asteroid := _find_nearest_asteroid()
		if not asteroid or _ship.global_position.distance_to(asteroid.global_position) > 400.0:
			_pick_mine_destination()
			return
		_try_mine_asteroid()
		if _state_timer >= MINE_DURATION and not _ship.inventory.get_all_items().is_empty():
			_set_state(State.RETURN)


func _think_return() -> void:
	if not is_instance_valid(_home_station) or (_home_station is StationInstance and (_home_station._is_destroyed or _home_station.faction_id != _ship.faction_id)):
		_home_station = _find_closest_friendly_station()
		return
	if _home_station is StationInstance and _in_service_range(_home_station):
		_deposit_cargo_to_station()
		_set_state(State.MINE)


func _think_follow() -> void:
	if not is_instance_valid(_follow_target):
		_follow_target = null
		_execute_next_command()
		return
	var enemy := _find_nearest_enemy(SENSOR_RADIUS * 0.5)
	if enemy and _is_combat_ship:
		_target = enemy
		_set_state(State.ATTACK)


func _think_stay() -> void:
	var enemy := _find_nearest_enemy(SENSOR_RADIUS * 0.3)
	if enemy and _is_combat_ship:
		_target = enemy
		_set_state(State.ATTACK)


func _think_defend() -> void:
	if not is_instance_valid(_defend_target):
		_defend_target = null
		_execute_next_command()


func _think_patrol_area() -> void:
	var enemy := _find_nearest_enemy(SENSOR_RADIUS)
	if enemy:
		_target = enemy
		_set_state(State.ATTACK)
		return
	if _ship.global_position.distance_to(_waypoint) < ARRIVE_RADIUS:
		_pick_patrol_area_waypoint()


func _think_patrol_route() -> void:
	var enemy := _find_nearest_enemy(SENSOR_RADIUS)
	if enemy:
		_target = enemy
		_set_state(State.ATTACK)
		return
	if _patrol_route.is_empty(): return
	if _ship.global_position.distance_to(_waypoint) < ARRIVE_RADIUS:
		_patrol_route_idx = (_patrol_route_idx + 1) % _patrol_route.size()
		_waypoint = _patrol_route[_patrol_route_idx]


func _think_go_wait() -> void:
	if _ship.global_position.distance_to(_waypoint) < ARRIVE_RADIUS:
		_set_state(State.STAY)


# ---------------------------------------------------------------------------
# Execution
# ---------------------------------------------------------------------------

func _execute_state(delta: float) -> void:
	match _state:
		State.PATROL, State.MINE, State.GO_WAIT, State.PATROL_ROUTE, State.PATROL_AREA:
			_move_toward(_waypoint, delta)
		State.HAUL:
			if is_instance_valid(supply_scaffold):
				var goal: Node2D=supply_scaffold if _haul_loaded else _haul_source
				if is_instance_valid(goal):
					if _ship.global_position.distance_to(goal.global_position)>250:_move_toward(goal.global_position,delta)
					else:_ship.velocity=Vector2.ZERO
				return
			_approach_station(_haul_destination if _haul_loaded else _haul_source, delta)
		State.ATTACK:
			if is_instance_valid(_target):
				_move_toward(_target.global_position, delta)
				_try_fire()
		State.PURSUE:
			if is_instance_valid(_target):
				_move_toward(_target.global_position, delta)
		State.ASSIST:
			if is_instance_valid(_target):
				_move_toward(_target.global_position, delta)
		State.FLEE:
			_move_toward(_get_flee_destination(), delta)
		State.RETURN:
			if _home_station is StationInstance:
				_approach_station(_home_station, delta)
		State.FOLLOW, State.DEFEND:
			if is_instance_valid(_follow_target):
				var offset_pos := _follow_target.global_position + Vector2(200, 0).rotated(_follow_target.rotation)
				_move_toward(offset_pos, delta)
		State.STAY, State.IDLE:
			if _ship and _ship.ship_data:
				_ship.velocity *= _ship.ship_data.drag
				_ship.move_and_slide()


func _move_toward(target_pos: Vector2, delta: float) -> void:
	if not _ship or not _ship.ship_data: return
	var dir  : Vector2  = _ship.global_position.direction_to(target_pos)
	var dist : float    = _ship.global_position.distance_to(target_pos)
	var sd   : ShipData = _ship.ship_data
	if dir != Vector2.ZERO:
		_ship.rotation = rotate_toward(_ship.rotation, dir.angle(), maxf(0.0, sd.rotation_speed * delta))
	if dist > ARRIVE_RADIUS * 0.5:
		_ship.velocity += dir * sd.thrust_force * delta * 60.0
	_ship.velocity  = _ship.velocity.limit_length(sd.max_speed)
	_ship.velocity *= sd.drag if is_inside_tree() else pow(sd.drag, delta * 60.0)
	if is_inside_tree(): _ship.move_and_slide()
	else: _ship.position += _ship.velocity * delta


func _pick_patrol_area_waypoint() -> void:
	var angle : float = randf() * TAU
	var dist  : float = randf_range(_patrol_radius * 0.3, _patrol_radius)
	_waypoint = _patrol_center + Vector2(cos(angle), sin(angle)) * dist


func _try_fire() -> void:
	if not is_inside_tree():
		_fire_background()
		return
	if not is_instance_valid(_target): return
	if _target is ShipInstance and _target.ship_data and _target.ship_data.id == &"escape_pod": return
	if not _ship: return
	var dir : Vector2 = _ship.global_position.direction_to(_target.global_position)
	for slot in _ship.equipped_weapons.size():
		if _ship.fire_weapon(slot, dir):
			_spawn_bullet(slot, dir)
	if _missile_cooldown <= 0:
		for missile in _ship.equipped_missiles:
			if missile and _ship.inventory.has_item(missile.id):
				var projectile: Node2D = load("res://scenes/Missile.tscn").instantiate()
				projectile.position = _ship.get_missile_launch_position(0)
				projectile.rotation = dir.angle()
				projectile.launch(_ship.velocity, _ship, missile)
				_ship.inventory.remove_item(missile.id, 1)
				SectorManager.add_sector_entity(projectile)
				_missile_cooldown = 5.0
				break


func _try_mine_asteroid() -> void:
	var nearest : Node2D = _find_nearest_asteroid()
	if not nearest: return
	if _ship.global_position.distance_to(nearest.global_position) > 400.0: return
	var dir : Vector2 = _ship.global_position.direction_to(nearest.global_position)
	for slot in _ship.equipped_weapons.size():
		var w : WeaponData = _ship.equipped_weapons[slot] if slot < _ship.equipped_weapons.size() else null
		if w == null: continue
		if w.weapon_type != GlobalEnums.WeaponType.MINING: continue
		if _ship.fire_weapon(slot, dir, is_inside_tree()):
			if is_inside_tree(): _spawn_bullet(slot, dir)
			else: nearest.take_mining_damage(w.damage, _ship)


func _deposit_cargo_to_station() -> void:
	if not is_instance_valid(_home_station) or not _home_station is StationInstance: return
	var station := _home_station as StationInstance
	if station._is_destroyed or station.faction_id != _ship.faction_id or not _in_service_range(station): return
	var items   := _ship.inventory.get_all_items()
	for item_id in items:
		if not AsteroidInstance.MATERIAL_IDS.values().has(item_id): continue
		var amount : int = items[item_id]
		if amount > 0:
			if not station.inventory.add_item(item_id, amount, GameData.items): continue
			print("Economy: mined cargo delivered %d %s to %s" % [amount, item_id, station.station_data.display_name])
			_ship.inventory.remove_item(item_id, amount)


func _spawn_bullet(slot: int, direction: Vector2) -> void:
	var w : WeaponData = _ship.equipped_weapons[slot] if slot < _ship.equipped_weapons.size() else null
	if w == null: return
	var scene_path : String = "res://scenes/Bullet.tscn"
	if w.weapon_type == GlobalEnums.WeaponType.ENERGY or w.weapon_type == GlobalEnums.WeaponType.MINING:
		scene_path = "res://scenes/LaserBeam.tscn"
	var bullet_scene : PackedScene = load(scene_path)
	if bullet_scene == null: return
	var b : Node2D = bullet_scene.instantiate()
	b.global_position = _ship._get_muzzle_position(slot)
	b.rotation        = direction.angle()
	if b.has_method("launch"):
		b.launch(_ship.velocity + direction * w.projectile_speed, _ship, w)
	SectorManager.add_sector_entity(b)


# ---------------------------------------------------------------------------
# Fleet commands (external API)
# ---------------------------------------------------------------------------

func command_follow(target: Node2D) -> void:
	set_command_queue([{"type": GlobalEnums.FleetCommand.FOLLOW_SHIP, "target": target}])

func command_stay() -> void:
	set_command_queue([{"type": GlobalEnums.FleetCommand.GO_WAIT, "position": _ship.global_position}])

func command_attack(target: Node2D) -> void:
	set_command_queue([{"type": GlobalEnums.FleetCommand.ATTACK_TARGET, "target": target}])

func command_move_to(pos: Vector2) -> void:
	set_command_queue([{"type": GlobalEnums.FleetCommand.GO_WAIT, "position": pos}])


# ---------------------------------------------------------------------------
# Defend — react when defended ship takes damage
# ---------------------------------------------------------------------------

func _on_defend_target_hull_changed(_current: float, _maximum: float) -> void:
	if _state == State.DEFEND:
		var enemy := _find_nearest_enemy(SENSOR_RADIUS)
		if enemy:
			_target = enemy
			_set_state(State.ATTACK)


# ---------------------------------------------------------------------------
# Sensors
# ---------------------------------------------------------------------------

func _find_nearest_enemy(radius: float) -> ShipInstance:
	var closest      : ShipInstance = null
	var closest_dist : float        = radius
	for ship in _local_nodes("ships"):
		if not ship is ShipInstance: continue
		if ship == _ship: continue
		if not is_instance_valid(ship) or ship._is_destroyed or ship.is_queued_for_deletion(): continue
		if not _is_enemy(ship): continue
		var dist : float = _ship.global_position.distance_to(ship.global_position)
		if dist < closest_dist:
			closest      = ship
			closest_dist = dist
	return closest


func _find_distressed_friendly(radius: float) -> ShipInstance:
	for ship in _local_nodes("ships"):
		if not ship is ShipInstance: continue
		if ship == _ship: continue
		if not is_instance_valid(ship): continue
		if not _is_friendly(ship): continue
		var dist : float = _ship.global_position.distance_to(ship.global_position)
		if dist > radius: continue
		if ship.hull < ship.max_hull * 0.8:
			return ship
	return null


func _find_closest_friendly_station() -> Node2D:
	var closest      : Node2D = null
	var closest_dist : float  = INF
	for station in _local_nodes("stations"):
		if not station is StationInstance: continue
		if not is_instance_valid(station): continue
		if station._is_destroyed: continue
		if not _is_friendly_faction(station.faction_id): continue
		if _ship.ship_data and _ship.ship_data.id.contains("miner") and station.faction_id != _ship.faction_id: continue
		var dist : float = _ship.global_position.distance_to(station.global_position)
		if _ship.ship_data and _ship.ship_data.id.contains("miner"):
			if station.faction_id == _ship.faction_id and station.station_data.station_type == StationData.TYPE_MANUFACTURING:
				dist -= 1000000.0
		if dist < closest_dist:
			closest      = station
			closest_dist = dist
	return closest


func _find_nearest_asteroid() -> Node2D:
	var closest: Node2D = null
	var closest_dist: float = INF
	var best_shortage: bool = false
	for asteroid in _local_nodes("asteroids"):
		if not is_instance_valid(asteroid) or asteroid._is_destroyed or asteroid.is_queued_for_deletion():continue
		var shortage := false
		if is_instance_valid(_home_station) and _home_station is StationInstance and not _home_station._is_destroyed:
			var material: StringName=AsteroidInstance.MATERIAL_IDS.get(asteroid.material_type,&"")
			shortage=_home_station.get_supply_target(material)>_home_station.inventory.get_amount(material)
		var distance: float=_ship.global_position.distance_to(asteroid.global_position)
		if closest==null or (shortage and not best_shortage) or (shortage==best_shortage and distance<closest_dist):
			closest=asteroid
			closest_dist=distance
			best_shortage=shortage
	return closest


func _is_enemy(ship: ShipInstance) -> bool:
	if ship.ship_data and ship.ship_data.id == &"escape_pod": return false
	if _ship.faction_id == &"rogue" or ship.faction_id == &"rogue": return ship != _ship
	if ship.is_in_group("player"):       return PlayerState.is_hostile_to_player(_ship.faction_id)
	if ship.is_in_group("player_fleet"): return not _is_fleet_ship and PlayerState.is_hostile_to_player(_ship.faction_id)
	if _is_fleet_ship: return PlayerState.is_hostile_to_player(ship.faction_id)
	return FactionManager.should_attack(_ship.faction_id, ship.faction_id)


func _is_friendly(ship: ShipInstance) -> bool:
	return _is_friendly_faction(ship.faction_id)


func _is_friendly_faction(faction_id: StringName) -> bool:
	if faction_id == _ship.faction_id: return true
	return FactionManager.are_allied(_ship.faction_id, faction_id)


# ---------------------------------------------------------------------------
# Navigation helpers
# ---------------------------------------------------------------------------

func _generate_patrol_points() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = hash(_ship.global_position)
	_patrol_points.clear()
	var count : int = 4 + rng.randi() % 4
	for i in count:
		var angle : float = float(i) / float(count) * TAU + rng.randf_range(-0.3, 0.3)
		var dist  : float = rng.randf_range(3000.0, 15000.0)
		_patrol_points.append(Vector2(cos(angle), sin(angle)) * dist + _ship.global_position)
	if _patrol_points.size() > 0:
		_waypoint = _patrol_points[0]


func _next_patrol_point() -> void:
	if _patrol_points.is_empty(): return
	_patrol_idx = (_patrol_idx + 1) % _patrol_points.size()
	_waypoint   = _patrol_points[_patrol_idx]


func _station_reserve(station: StationInstance, item_id: StringName) -> int:
	return station.get_input_reserve(item_id)


func _station_shortage(station: StationInstance, item_id: StringName) -> int:
	return maxi(0, station.get_supply_target(item_id) - station.inventory.get_amount(item_id))


func _pick_haul_destination() -> void:
	_waypoint = _ship.global_position
	var stations: Array[StationInstance] = []
	for station in _local_nodes("stations"):
		if station is StationInstance and not station._is_destroyed and station.station_data:
			if station.faction_id == _ship.faction_id and (not _is_fleet_ship or station == supply_station): stations.append(station)
	# Recover cargo when a destination disappears or a command interrupts a delivery.
	var cargo_ids: Array = _ship.inventory.get_all_items().keys()
	if _haul_loaded and cargo_ids.has(_haul_item):
		cargo_ids.erase(_haul_item)
		cargo_ids.push_front(_haul_item)
	for item_id in cargo_ids:
		var deliverable: int = _deliverable_cargo(item_id)
		if deliverable <= 0: continue
		for destination in stations:
			if _station_shortage(destination, item_id) > 0:
				_haul_source = destination
				_haul_destination = destination
				_haul_item = item_id
				_haul_manifest_amount = deliverable
				_haul_loaded = true
				_waypoint = destination.global_position
				return
	_haul_source = null
	_haul_destination = null
	# Retain an interrupted manifest and wait for demand instead of buying more.
	if _haul_loaded and _deliverable_cargo(_haul_item) > 0: return
	_haul_loaded = false
	_haul_manifest_amount = 0
	var best_distance: float = INF
	var sources: Array[StationInstance] = stations.duplicate()
	if _is_fleet_ship:
		for own in _local_nodes("stations"):
			if own is StationInstance and not own._is_destroyed and own.faction_id == &"player" and not sources.has(own): sources.append(own)
	for candidate in _local_nodes("stations"):
		if candidate is StationInstance and not candidate._is_destroyed and candidate.faction_id != _ship.faction_id and not FactionManager.are_at_war(candidate.faction_id, _ship.faction_id): sources.append(candidate)
	for source in sources:
		for item_id in source.inventory.get_all_items():
			if not GameData.items.has(item_id): continue
			if source.faction_id != _ship.faction_id:
				if not source.can_export_to_traders(item_id) or source.get_sell_price(item_id) <= 0 or FactionManager.get_faction_credits(_ship.faction_id) < source.get_sell_price(item_id): continue
			if GameData.items[item_id].volume > _ship.inventory.get_free_capacity(GameData.items): continue
			if source.inventory.get_amount(item_id) <= source.get_supply_target(item_id): continue
			for destination in stations:
				if destination == source or _station_shortage(destination, item_id) <= 0: continue
				var distance: float = _ship.global_position.distance_to(source.global_position) + source.global_position.distance_to(destination.global_position)
				if source.faction_id != _ship.faction_id: distance += 1000000.0 # Prefer internal surplus before imports.
				if distance >= best_distance: continue
				best_distance = distance
				_haul_source = source
				_haul_destination = destination
				_haul_item = item_id
	if _haul_source: _waypoint = _haul_source.global_position


func _pick_mine_destination() -> void:
	var asteroid := _find_nearest_asteroid()
	if asteroid:
		_waypoint = asteroid.global_position
	else:
		_waypoint = _ship.global_position + Vector2(randf_range(-8000, 8000), randf_range(-8000, 8000))
	_state_timer = 0.0


func _get_flee_destination() -> Vector2:
	if is_instance_valid(_home_station): return _home_station.global_position
	var enemy := _find_nearest_enemy(SENSOR_RADIUS * 2.0)
	if enemy:
		return _ship.global_position + _ship.global_position.direction_to(enemy.global_position) * -5000.0
	return _ship.global_position


func _get_default_state() -> State:
	if _is_fleet_ship: return State.IDLE
	if _is_combat_ship: return State.PATROL
	if _ship.ship_data and _ship.ship_data.id.contains("miner"): return State.MINE
	if _ship.ship_data and (_ship.ship_data.id.contains("hauler") or _ship.ship_data.id.contains("logistics")): return State.HAUL
	return State.PATROL


# ---------------------------------------------------------------------------
# Events
# ---------------------------------------------------------------------------

func _on_ship_destroyed(_ship_ref: ShipInstance, _killer: Node) -> void:
	FactionManager.unregister_ship(_ship)
	if FleetCommandSystem:
		FleetCommandSystem.selected_ships.erase(_ship)
		FleetCommandSystem.selection_changed.emit(FleetCommandSystem.selected_ships)
	queue_free()


func _on_hull_changed(current: float, maximum: float) -> void:
	if not _ship: return
	if not _is_combat_ship and _state != State.FLEE:
		_set_state(State.FLEE)
		return
	if current / maximum < FLEE_THRESHOLD and _state != State.FLEE:
		_home_station = _find_closest_friendly_station()
		_set_state(State.FLEE)


func _set_state(new_state: State) -> void:
	_state       = new_state
	_state_timer = 0.0
	match new_state:
		State.MINE:        _pick_mine_destination()
		State.HAUL:        _pick_haul_destination()
		State.PATROL:      _generate_patrol_points()
		State.PATROL_AREA: _pick_patrol_area_waypoint()
		State.DEFEND:
			if is_instance_valid(_defend_target) and _defend_target.has_signal("hull_changed"):
				if not _defend_target.hull_changed.is_connected(_on_defend_target_hull_changed):
					_defend_target.hull_changed.connect(_on_defend_target_hull_changed)


func setup(ship_data: ShipData, faction_id: StringName, _behavior: int) -> void:
	if _ship:
		_ship.faction_id = faction_id
		_ship.initialize(ship_data)
	_initialize()




func _resupply(delta: float) -> bool:
	if _is_fleet_ship or not _is_combat_ship: return false
	var needed: StringName = &""
	for weapon in _ship.equipped_weapons:
		if weapon and weapon.uses_ammo and _ship.inventory.get_amount(weapon.ammo_item_id) < 10:
			needed = weapon.ammo_item_id
	for missile in _ship.equipped_missiles:
		if missile and _ship.inventory.get_amount(missile.id) == 0: needed = missile.id
	if needed == &"": return false
	var closest: StationInstance
	var distance: float = INF
	for station in _local_nodes("stations"):
		if station is StationInstance and not station._is_destroyed and station.faction_id == _ship.faction_id and station.inventory.has_item(needed):
			var d: float = _ship.global_position.distance_to(station.global_position)
			if d < distance:
				closest = station
				distance = d
	if closest == null: return false
	if not _in_service_range(closest):
		_approach_station(closest, delta)
		return true
	var desired: int = 100 if needed == &"ballistic_ammo" else 4
	var amount: int = mini(desired - _ship.inventory.get_amount(needed), closest.inventory.get_amount(needed))
	amount = mini(amount, int(_ship.inventory.get_free_capacity(GameData.items) / GameData.items[needed].volume))
	if amount > 0 and _ship.inventory.add_item(needed, amount, GameData.items): closest.inventory.remove_item(needed, amount)
	return false


func _in_service_range(station: StationInstance) -> bool:
	return is_instance_valid(station) and not station._is_destroyed and _ship.global_position.distance_to(station.global_position) <= station.get_docking_range()

func _approach_station(station: StationInstance, delta: float) -> void:
	if not is_instance_valid(station) or station._is_destroyed: return
	if _in_service_range(station):
		# Hold outside the hull while the next AI think performs the transfer.
		_ship.velocity = Vector2.ZERO
		return
	_move_toward(station.global_position, delta)


func _deliverable_cargo(item_id: StringName) -> int:
	var carried: int = _ship.inventory.get_amount(item_id)
	if _haul_loaded and item_id == _haul_item and _haul_manifest_amount > 0:
		return mini(carried, _haul_manifest_amount)
	var reserve: int = 0
	for weapon in _ship.equipped_weapons:
		if weapon and weapon.uses_ammo and weapon.ammo_item_id == item_id: reserve = maxi(reserve, 100)
	for missile in _ship.equipped_missiles:
		if missile and missile.id == item_id: reserve = maxi(reserve, 4)
	return maxi(0, carried - reserve)


func _local_nodes(group: StringName) -> Array:
	if is_inside_tree(): return get_tree().get_nodes_in_group(group)
	var sector: Node = get_parent()
	while sector and not sector is SectorInstance: sector = sector.get_parent()
	if not sector: return []
	var result: Array = []
	for node in sector.find_children("*", "", true, false):
		if node.is_in_group(group): result.append(node)
	return result

func advance_background_transport(delta: float) -> void:
	if not is_instance_valid(_ship) or _ship._is_destroyed:return
	if is_instance_valid(_target):
		if _target.is_queued_for_deletion() or _target.get("_is_destroyed") or preload("res://scripts/StationConstruction.gd").sector_of(_target)!=preload("res://scripts/StationConstruction.gd").sector_of(_ship):_target=null
		elif not _is_fleet_ship and _target is ShipInstance and not _is_enemy(_target):_target=null
	_ship.tick(delta)
	_missile_cooldown=maxf(0,_missile_cooldown-delta)
	if _resupply(delta):return
	_think_timer-=delta
	_state_timer+=delta
	if _think_timer<=0:
		_think_timer=THINK_INTERVAL
		_think()
	_execute_state(delta)

func _fire_background() -> void:
	if not is_instance_valid(_target) or _target.get("_is_destroyed") or _target.is_queued_for_deletion():return
	if _target is ShipInstance and _target.ship_data and _target.ship_data.id==&"escape_pod":return
	var distance:=_ship.global_position.distance_to(_target.global_position)
	var direction:=_ship.global_position.direction_to(_target.global_position)
	for slot in _ship.equipped_weapons.size():
		if _target.get("_is_destroyed"):return
		var weapon: WeaponData=_ship.equipped_weapons[slot]
		if not weapon or distance>weapon.max_range:continue
		if _ship.fire_weapon(slot,direction,false):
			if _target is ShipInstance:_target.take_damage_from_weapon(weapon,_ship)
			elif _target is StationInstance:_target.take_damage(weapon.damage,_ship)
	if _missile_cooldown>0 or _target.get("_is_destroyed"):return
	for missile in _ship.equipped_missiles:
		if not missile or distance>minf(missile.lock_on_range,missile.speed*missile.lifetime) or not _ship.inventory.has_item(missile.id):continue
		_ship.inventory.remove_item(missile.id,1)
		_missile_cooldown=5.0
		if _target is ShipInstance:_target.take_damage_from_missile(missile,_ship)
		elif _target is StationInstance:_target.take_damage(missile.damage,_ship)
		break


func assign_station_supply(station: StationInstance) -> bool:
	if not _is_fleet_ship or not is_instance_valid(station) or station._is_destroyed or station.faction_id != &"player": return false
	if not _ship.ship_data or not ("hauler" in str(_ship.ship_data.id) or "logistics" in str(_ship.ship_data.id)): return false
	if not _local_nodes("stations").has(station): return false
	cancel_all_commands()
	_ship.faction_id = &"player"
	supply_station = station
	_set_state(State.HAUL)
	return true


func assign_scaffold_supply(scaffold: Node2D) -> bool:
	if not _is_fleet_ship or not is_instance_valid(scaffold) or scaffold.get_script()!=load("res://scripts/ConstructionScaffold.gd") or scaffold.completed or scaffold.remaining>=0:return false
	if not _ship.ship_data or not ("hauler" in str(_ship.ship_data.id) or "logistics" in str(_ship.ship_data.id)):return false
	if not _local_nodes("construction_scaffolds").has(scaffold):return false
	cancel_all_commands()
	_ship.faction_id=&"player"
	supply_scaffold=scaffold
	_state=State.HAUL
	_haul_source=null
	_haul_loaded=false
	return true

func _think_scaffold_supply() -> void:
	if supply_scaffold.completed or supply_scaffold.is_queued_for_deletion() or supply_scaffold.remaining>=0:
		cancel_all_commands()
		return
	var needs: Dictionary=supply_scaffold.requirements()
	for id in needs:
		var missing:=maxi(0,int(needs[id])-int(supply_scaffold.cargo.get(id,0)))
		var carried:=mini(missing,_deliverable_cargo(id))
		if carried>0:
			_haul_loaded=true
			if _ship.global_position.distance_to(supply_scaffold.global_position)<=350:
				_ship.inventory.remove_item(id,carried)
				supply_scaffold.cargo[id]=int(supply_scaffold.cargo.get(id,0))+carried
				_haul_manifest_amount=0
			return
	_haul_loaded=false
	_haul_source=null
	var best:=INF
	for source in _local_nodes("stations"):
		if not source is StationInstance or source._is_destroyed or FactionManager.are_at_war(&"player",source.faction_id):continue
		for id in needs:
			var missing:=maxi(0,int(needs[id])-int(supply_scaffold.cargo.get(id,0)))
			var item: ItemData=GameData.items.get(id)
			if missing<=0 or not item or item.volume<=0:continue
			var amount:=mini(missing,source.inventory.get_amount(id)-source.get_supply_target(id))
			amount=mini(amount,int(_ship.inventory.get_free_capacity(GameData.items)/item.volume))
			if source.faction_id!=&"player":
				if not source.can_export_to_traders(id):continue
				amount=mini(amount,int(PlayerState.credits/maxi(1,source.get_sell_price(id))))
			if amount<=0:continue
			var distance: float=_ship.global_position.distance_to(source.global_position)
			if source.faction_id!=&"player":distance+=1000000
			if distance>=best:continue
			best=distance
			_haul_source=source
			_haul_item=id
	if not is_instance_valid(_haul_source) or not _in_service_range(_haul_source):return
	var item: ItemData=GameData.items[_haul_item]
	var amount:=mini(int(needs[_haul_item])-int(supply_scaffold.cargo.get(_haul_item,0)),_haul_source.inventory.get_amount(_haul_item)-_haul_source.get_supply_target(_haul_item))
	amount=mini(amount,int(_ship.inventory.get_free_capacity(GameData.items)/item.volume))
	if _haul_source.faction_id==&"player":
		if not _ship.inventory.add_item(_haul_item,amount,GameData.items):return
		_haul_source.inventory.remove_item(_haul_item,amount)
	else:
		amount=mini(amount,int(PlayerState.credits/maxi(1,_haul_source.get_sell_price(_haul_item))))
		if not FactionManager.purchase_cargo(_ship,_haul_source,_haul_item,amount):return
	_haul_manifest_amount=amount
	_haul_loaded=true


func initialize_inactive(home: StationInstance) -> void:
	_ship=get_parent() as ShipInstance
	if not _ship:return
	name="AIShipController"
	_home_station=home
	_is_fleet_ship=_ship.is_in_group("player_fleet")
	if not _ship.ship_destroyed.is_connected(_on_ship_destroyed):_ship.ship_destroyed.connect(_on_ship_destroyed)
	if not _ship.hull_changed.is_connected(_on_hull_changed):_ship.hull_changed.connect(_on_hull_changed)
	_background_initialized=true
	_initialize()
