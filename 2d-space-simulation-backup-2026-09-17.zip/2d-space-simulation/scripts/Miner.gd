extends ShipInstance

## Miner — Small mining vessel with front drill assembly. 28px long, 12px wide.

func _ready() -> void:
	add_to_group("ships")
	_build_visuals()
	super()


func _build_visuals() -> void:
	var weapon_nodes  : Array[Node2D] = []
	var missile_nodes : Array[Node2D] = []

	## Hull
	var hull := Polygon2D.new()
	hull.polygon = PackedVector2Array([Vector2(14,-3),Vector2(18,0),Vector2(14,3),Vector2(8,6),Vector2(-12,6),Vector2(-14,3),Vector2(-14,-3),Vector2(-12,-6),Vector2(8,-6)])
	hull.color   = Color(0.32,0.38,0.32)
	add_child(hull)

	var detail0 := Polygon2D.new()
	detail0.polygon = PackedVector2Array([Vector2(14,-3),Vector2(22,-5),Vector2(22,-2),Vector2(14,-1)])
	detail0.color   = Color(0.4,0.38,0.3)
	add_child(detail0)

	var detail1 := Polygon2D.new()
	detail1.polygon = PackedVector2Array([Vector2(14,3),Vector2(22,5),Vector2(22,2),Vector2(14,1)])
	detail1.color   = Color(0.4,0.38,0.3)
	add_child(detail1)

	var detail2 := Polygon2D.new()
	detail2.polygon = PackedVector2Array([Vector2(6,-4),Vector2(6,4),Vector2(-10,4),Vector2(-10,-4)])
	detail2.color   = Color(0.2,0.25,0.22)
	add_child(detail2)

	var cockpit := Polygon2D.new()
	cockpit.polygon = PackedVector2Array([Vector2(12,0),Vector2(9,-3),Vector2(6,0),Vector2(9,3)])
	cockpit.color   = Color(0.5, 0.85, 1.0, 0.85)
	add_child(cockpit)

	var eng0 := Polygon2D.new()
	eng0.polygon = PackedVector2Array([
		Vector2(-14, -1.6),
		Vector2(-18.8, 0.0),
		Vector2(-14, 1.6),
	])
	eng0.color = Color(0.4, 0.65, 1.0, 0.8)
	add_child(eng0)

	## Collision
	var col := CollisionPolygon2D.new()
	col.polygon = PackedVector2Array([Vector2(18,0),Vector2(8,-6),Vector2(-14,-3),Vector2(-14,3),Vector2(8,6)])
	add_child(col)

	## Shield ring — always visible, color controlled by ShipVisualController
	var shield_ring := Polygon2D.new()
	shield_ring.polygon = PackedVector2Array([Vector2(20,0),Vector2(14,-8),Vector2(0,-11),Vector2(-14,-7),Vector2(-17,0),Vector2(-14,7),Vector2(0,11),Vector2(14,8)])
	shield_ring.color   = Color(0.25, 0.25, 0.3, 0.2)
	add_child(shield_ring)

	## Weapon barrel 0 — hidden when unequipped
	var wbarrel0 := Polygon2D.new()
	wbarrel0.polygon = PackedVector2Array([
		Vector2(14.0, -0.6),
		Vector2(22.0, -0.6),
		Vector2(22.0, 0.6),
		Vector2(14.0, 0.6),
	])
	wbarrel0.color   = Color(0.95, 0.95, 0.8)
	wbarrel0.visible = false
	add_child(wbarrel0)
	weapon_nodes.append(wbarrel0)

	var m0 := Marker2D.new()
	m0.name     = "Muzzle0"
	m0.position = Vector2(22.0, 0.0)
	add_child(m0)

	## Visual controller
	var vc := ShipVisualController.new()
	add_child(vc)
	vc.setup(weapon_nodes, shield_ring, missile_nodes)
	preload("res://scripts/ShipHullArt.gd").apply(self, &"miner", vc)
