class_name HUD
extends CanvasLayer

var _player        : Player    = null
var _boundary_dist : float     = -1.0
var _warn_visible  : bool      = false
var _warn_label    : Label     = null
var _vignette      : ColorRect = null
var _freecam_label : Label     = null
var _weapon_label  : Label     = null
var _missile_label : Label     = null

const LINE_H   : float = 33.0
const MARGIN_X : float = 16.0
const MARGIN_B : float = 16.0

func _ready() -> void:
	add_to_group("hud")
	layer = 10
	add_child(preload("res://scripts/TargetingHUD.gd").new())
	add_child(preload("res://scripts/EconomyPanel.gd").new())
	add_child(preload("res://scripts/PlaytestHelp.gd").new())
	add_child(preload("res://scripts/StationIdentification.gd").new())
	add_child(preload("res://scripts/SensorFogOverlay.gd").new())

	_vignette          = ColorRect.new()
	_vignette.color    = Color(0.8, 0.0, 0.0, 0.0)
	_vignette.position = Vector2.ZERO
	_vignette.size     = get_viewport().get_visible_rect().size
	_vignette.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(_vignette)

	_warn_label = Label.new()
	_warn_label.text = "⚠  LEAVING SECTOR  ⚠"
	_warn_label.add_theme_color_override("font_color", Color(1.0, 0.27, 0.0, 1.0))
	_warn_label.add_theme_font_size_override("font_size", 36)
	_warn_label.visible = false
	add_child(_warn_label)

	add_child(preload("res://scripts/WeaponsHUD.gd").new())

	_freecam_label = Label.new()
	_freecam_label.text = "[ FREE CAM ]"
	_freecam_label.add_theme_color_override("font_color", Color(0.3, 0.76, 0.93, 1.0))
	_freecam_label.add_theme_font_size_override("font_size", 24)
	_freecam_label.visible = false
	add_child(_freecam_label)

	await get_tree().process_frame
	_player = get_tree().get_first_node_in_group("player")
	if _player:
		_player.equipment_changed.connect(_update_labels)
	get_viewport().size_changed.connect(_on_viewport_resized)
	_on_viewport_resized()

func _on_viewport_resized() -> void:
	var sz := get_viewport().get_visible_rect().size
	_vignette.size          = sz
	_warn_label.position    = Vector2(sz.x / 2.0 - 220.0, 24.0)
	_freecam_label.position = Vector2(sz.x - 210.0, sz.y - 48.0)

func _process(_delta: float) -> void:
	_update_boundary_warning()
	_update_labels()

func show_boundary_warning(dist_outside: float) -> void:
	_boundary_dist = dist_outside
	_warn_visible  = true

func show_free_cam_mode(show_mode: bool) -> void:
	_freecam_label.visible = show_mode

func _update_boundary_warning() -> void:
	if _warn_visible:
		_warn_label.visible = true
		_vignette.color     = Color(0.8, 0.0, 0.0, clampf(_boundary_dist / 5000.0, 0.1, 0.5))
		_warn_visible       = false
	else:
		_warn_label.visible = false
		_vignette.color     = Color(0.8, 0.0, 0.0, 0.0)
	_boundary_dist = -1.0

func _update_labels() -> void:
	var sz := get_viewport().get_visible_rect().size
	_freecam_label.position = Vector2(sz.x - 210.0, sz.y - 48.0)
