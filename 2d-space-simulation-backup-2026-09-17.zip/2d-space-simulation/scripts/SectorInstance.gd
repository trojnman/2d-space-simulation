class_name SectorInstance
extends Node2D

## Represents a loaded sector in the game world.
## Spawns stations, asteroids, jump gates, derelicts, hazards and POIs.

signal jump_gate_activated(destination_sector_id: StringName)

const HALF_SIZE : float = 50000.0

const StationSpawnerScript = preload("res://scripts/StationSpawner.gd")

@export var sector_data : SectorData = null

var asteroid_respawns:Array = []
var restore_mode: bool = false
var layout_rng_state: int = 0

var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	if sector_data:
		_populate()


func _populate() -> void:
	if not sector_data: return
	_rng.seed = hash(sector_data.id)
	print("SectorInstance: populating '%s'" % sector_data.display_name)
	_spawn_hex_boundary()
	if not restore_mode:
		_spawn_stations()
		_spawn_asteroids()
	if restore_mode:
		_rng.state = SaveManager.restoring_layout.get(sector_data.id, _rng.state)
	layout_rng_state = _rng.state
	_spawn_jump_gates()
	_spawn_derelicts()
	_spawn_hazards()
	_spawn_points_of_interest()


func _spawn_hex_boundary() -> void:
	var hex := HexBoundary.new()
	hex.name = "HexBoundary"
	add_child(hex)


# ---------------------------------------------------------------------------
# Stations
# ---------------------------------------------------------------------------

func _spawn_stations() -> void:
	print("SectorInstance: starting_stations = ", sector_data.starting_stations)
	var container      := _get_or_create_container("Stations")
	var station_scene  : PackedScene = load("res://scenes/Station.tscn")
	if station_scene == null:
		push_warning("SectorInstance: Station.tscn not found at res://scenes/Station.tscn")
		return
	for station_id in sector_data.starting_stations:
		var sd : StationData = GameData.get_station(station_id)
		if not sd:
			push_warning("SectorInstance: station data not found for id '%s'" % station_id)
			continue
		var station : StationInstance = station_scene.instantiate() as StationInstance
		if not station: continue
		station.station_data    = sd
		station.faction_id      = sd.faction_id if sd.get("faction_id") != null else sector_data.controlling_faction_id
		station.global_position = _random_sector_position(0.05, 0.16)
		container.add_child(station)
		print("SectorInstance: spawned station '%s' at %s" % [sd.display_name, station.global_position])
		var spawner            = StationSpawnerScript.new()
		spawner.max_ships      = sd.max_ships if sd.get("max_ships") != null else 5
		spawner.spawn_interval = 30.0
		station.add_child(spawner)
		var dm := get_tree().get_first_node_in_group("docking_manager")
		if dm and dm.has_method("_connect_station"):
			dm._connect_station(station)


# ---------------------------------------------------------------------------
# Asteroids
# ---------------------------------------------------------------------------

func _spawn_asteroids() -> void:
	var container   := _get_or_create_container("Asteroids")
	var field_count : int = maxi(6,sector_data.asteroid_fields.size())
	for i in field_count:
		var field_center : Vector2 = Vector2.from_angle(i*TAU/field_count+_rng.randf_range(-0.2,0.2))*HALF_SIZE*_rng.randf_range(0.18,0.68)
		var field_def    : Dictionary = sector_data.asteroid_fields[i] if i < sector_data.asteroid_fields.size() else {}
		var count        : int        = field_def.get("count", _rng.randi_range(8, 14))
		for j in count:
			var asteroid:=_make_asteroid(field_center)
			var clear:=false
			for attempt in 30:
				clear=true
				for station in get_node("Stations").get_children():
					if asteroid.position.distance_to(station.position)<1200:clear=false
				for existing in container.get_children():
					if asteroid.position.distance_to(existing.position)<450:clear=false
				if clear:break
				asteroid.position=field_center+Vector2(_rng.randf_range(-5000,5000),_rng.randf_range(-5000,5000))
			if clear:container.add_child(asteroid)
			else:asteroid.free()


func _make_asteroid(field_center: Vector2) -> AsteroidInstance:
	var asteroid := AsteroidInstance.new()

	## Random size — weighted toward small/medium
	var size_roll : int = _rng.randi_range(0, 9)
	var size      : GlobalEnums.AsteroidSize
	if size_roll <= 4:
		size = GlobalEnums.AsteroidSize.SMALL
	elif size_roll <= 7:
		size = GlobalEnums.AsteroidSize.MEDIUM
	else:
		size = GlobalEnums.AsteroidSize.LARGE

	## Random material — gold is rare (1 in 10)
	var mat_roll : int = _rng.randi_range(0, 19)
	var mat      : GlobalEnums.AsteroidMaterial
	if mat_roll <= 5:
		mat = GlobalEnums.AsteroidMaterial.IRON
	elif mat_roll <= 10:
		mat = GlobalEnums.AsteroidMaterial.CARBON
	elif mat_roll <= 14:
		mat = GlobalEnums.AsteroidMaterial.SILICON
	elif mat_roll <= 17:
		mat = GlobalEnums.AsteroidMaterial.ICE
	else:
		mat = GlobalEnums.AsteroidMaterial.GOLD

	var offset : Vector2 = Vector2(
		_rng.randf_range(-4000.0, 4000.0),
		_rng.randf_range(-4000.0, 4000.0)
	)
	asteroid.global_position = field_center + offset
	asteroid.setup(mat, size, _rng.randi())
	return asteroid


# ---------------------------------------------------------------------------
# Jump gates
# ---------------------------------------------------------------------------

func _spawn_jump_gates() -> void:
	var container  := _get_or_create_container("JumpGates")
	var connected  : Array       = sector_data.connected_sectors
	var gate_scene : PackedScene = load("res://scenes/JumpGate.tscn")
	var hex        := get_node_or_null("HexBoundary") as HexBoundary
	var gate_positions : Array[Vector2] = []
	if hex:
		gate_positions = hex.get_gate_positions()
	else:
		for i in connected.size():
			var angle : float = float(i) / float(max(connected.size(), 1)) * TAU
			gate_positions.append(Vector2(cos(angle), sin(angle)) * HALF_SIZE * 0.85)
	for i in connected.size():
		var gate_pos : Vector2 = gate_positions[i % gate_positions.size()]
		if gate_scene:
			var gate = gate_scene.instantiate()
			gate.global_position = gate_pos
			if gate.has_method("set_destination"):
				gate.set_destination(connected[i])
			else:
				gate.set("destination_sector_id", connected[i])
			if gate.has_signal("activated"):
				gate.activated.connect(func(dest): jump_gate_activated.emit(dest))
			gate.add_to_group("jump_gates")
			container.add_child(gate)
		else:
			var marker := Node2D.new()
			marker.global_position = gate_pos
			marker.add_to_group("jump_gates")
			container.add_child(marker)


# ---------------------------------------------------------------------------
# Derelicts
# ---------------------------------------------------------------------------

func _spawn_derelicts() -> void:
	var container := _get_or_create_container("Derelicts")
	var count     : int = _rng.randi_range(0, 3)
	for i in count:
		var derelict := Node2D.new()
		derelict.add_to_group("derelicts")
		derelict.global_position = _random_sector_position(0.1, 0.9)
		var poly     := Polygon2D.new()
		poly.polygon = PackedVector2Array([
			Vector2(-40,-15), Vector2(40,-15),
			Vector2(40, 15),  Vector2(-40, 15),
		])
		poly.color = Color(0.25, 0.25, 0.3)
		derelict.add_child(poly)
		container.add_child(derelict)


# ---------------------------------------------------------------------------
# Hazards
# ---------------------------------------------------------------------------

func _spawn_hazards() -> void:
	var container := _get_or_create_container("Hazards")
	if not sector_data.get("has_nebula"): return
	var hazard := Node2D.new()
	hazard.add_to_group("hazards")
	hazard.global_position = _random_sector_position(0.2, 0.8)
	container.add_child(hazard)


# ---------------------------------------------------------------------------
# Points of interest
# ---------------------------------------------------------------------------

func _spawn_points_of_interest() -> void:
	var container := _get_or_create_container("PointsOfInterest")
	var poi_types := ["Anomaly", "Ancient Ruins", "Signal Source", "Abandoned Cache"]
	var count     : int = _rng.randi_range(1, 3)
	for i in count:
		var poi := Node2D.new()
		poi.add_to_group("points_of_interest")
		poi.set_meta("poi_type", poi_types[_rng.randi() % poi_types.size()])
		poi.global_position = _random_sector_position(0.1, 0.9)
		container.add_child(poi)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

func _random_sector_position(min_frac: float, max_frac: float) -> Vector2:
	var range_min : float = HALF_SIZE * min_frac
	var range_max : float = HALF_SIZE * max_frac
	var dist      : float = _rng.randf_range(range_min, range_max)
	var angle     : float = _rng.randf() * TAU
	return Vector2(cos(angle), sin(angle)) * dist


func _get_or_create_container(cname: String) -> Node:
	var existing := get_node_or_null(cname)
	if existing: return existing
	var node := Node2D.new()
	node.name = cname
	add_child(node)
	return node


func can_dock() -> bool:
	return false


func get_station_count() -> int:
	var container := get_node_or_null("Stations")
	if not container: return 0
	return container.get_child_count()

func advance_asteroid_respawns(delta:float)->void:
	for i in range(asteroid_respawns.size()-1,-1,-1):
		var entry:Dictionary=asteroid_respawns[i]
		entry.remaining-=delta
		if entry.remaining>0:continue
		var blocked:=false
		for node in find_children("*","",true,false):
			if (node is ShipInstance or node is StationInstance or node.is_in_group("construction_scaffolds")) and node.position.distance_to(entry.position)<600:blocked=true;break
		if self==SectorManager.current_sector and is_instance_valid(PlayerState.current_ship) and PlayerState.current_ship.position.distance_to(entry.position)<600:blocked=true
		if blocked:entry.remaining=5.0;continue
		var asteroid:=AsteroidInstance.new()
		asteroid.position=entry.position
		asteroid.setup(entry.material,entry.size,entry.seed)
		get_node("Asteroids").add_child(asteroid)
		asteroid_respawns.remove_at(i)
