class_name StationData
extends Resource

## Defines a station TYPE (template/blueprint).
## Station types: headquarters, military, trade, manufacturing, shipyard, defense_platform

## Station type constants
const TYPE_HEADQUARTERS    : StringName = &"headquarters"
const TYPE_MILITARY        : StringName = &"military"
const TYPE_TRADE           : StringName = &"trade"
const TYPE_MANUFACTURING   : StringName = &"manufacturing"
const TYPE_SHIPYARD        : StringName = &"shipyard"
const TYPE_DEFENSE_PLATFORM: StringName = &"defense_platform"

## Max stations of this type per sector
const SECTOR_CAPS : Dictionary = {
	&"headquarters":     1,
	&"military":         2,
	&"trade":            1,
	&"manufacturing":    3,
	&"shipyard":         2,
	&"defense_platform": 4,
}

## Build costs per station type — { item_id: amount }
const BUILD_COSTS : Dictionary = {
	&"claim_beacon": {&"hull_parts": 100, &"electronics": 100, &"reactor_parts": 50},
	&"headquarters": {
		&"hull_parts":   2000,
		&"weapon_parts": 1500,
		&"reactor_parts":1000,
		&"shield_parts": 2000,
		&"electronics":  1000,
	},
	&"military": {
		&"hull_parts":   2000,
		&"weapon_parts": 1500,
		&"reactor_parts":1000,
		&"shield_parts": 2000,
		&"electronics":  1000,
	},
	&"defense_platform": {
		&"hull_parts":    1000,
		&"weapon_parts":  3000,
		&"shield_parts":  3000,
		&"reactor_parts": 2000,
		&"electronics":   1500,
	},
	&"trade": {
		&"hull_parts":    2500,
		&"weapon_parts":  500,
		&"reactor_parts": 1000,
		&"shield_parts":  1500,
		&"electronics":   2000,
	},
	&"manufacturing": {
		&"hull_parts":    2000,
		&"weapon_parts":  500,
		&"reactor_parts": 3000,
		&"shield_parts":  1000,
		&"electronics":   3000,
	},
	&"shipyard": {
		&"hull_parts":    2000,
		&"weapon_parts":  500,
		&"reactor_parts": 3000,
		&"shield_parts":  1000,
		&"electronics":   3000,
	},
}

## What each station type buys and sells
## Manufacturing: raw materials in, processed materials out
## Trade: components in/out
## Military: weapons and equipment in/out
## Shipyard: ships in/out
const BUYS_CATEGORIES : Dictionary = {
	&"headquarters":     ["weapons", "equipment", "components"],
	&"military":         ["weapons", "equipment", "raw_materials"],
	&"trade":            ["components", "raw_materials"],
	&"manufacturing":    ["raw_materials"],
	&"shipyard":         ["components"],
	&"defense_platform": [],
}

const SELLS_CATEGORIES : Dictionary = {
	&"headquarters":     ["weapons", "equipment"],
	&"military":         ["weapons", "equipment"],
	&"trade":            ["components"],
	&"manufacturing":    ["components", "processed_materials"],
	&"shipyard":         ["ships"],
	&"defense_platform": [],
}

## Manufacturing recipes per station type
## Each recipe: { "inputs": {item_id: amount}, "output_id": StringName, "output_amount": int, "time": float }
const MANUFACTURING_RECIPES : Dictionary = {
	&"manufacturing": [
		## Processed fluids
		{ "inputs": { &"ice":      10  }, "output_id": &"water",         "output_amount": 10, "time": 30.0  },
		{ "inputs": { &"water":    10  }, "output_id": &"hydrogen",      "output_amount": 10, "time": 45.0  },
		{ "inputs": { &"hydrogen": 10  }, "output_id": &"plasma",        "output_amount": 10, "time": 60.0  },
		## Components
		{ "inputs": { &"iron": 5,  &"carbon": 5              }, "output_id": &"hull_parts",    "output_amount": 10, "time": 60.0  },
		{ "inputs": { &"iron": 5,  &"carbon": 5              }, "output_id": &"weapon_parts",  "output_amount": 10, "time": 60.0  },
		{ "inputs": { &"iron": 5,  &"carbon": 5              }, "output_id": &"shield_parts",  "output_amount": 10, "time": 60.0  },
		{ "inputs": { &"iron": 5,  &"carbon": 5              }, "output_id": &"missile_parts", "output_amount": 10, "time": 60.0  },
		{ "inputs": { &"silicon": 3, &"gold": 2              }, "output_id": &"electronics",   "output_amount": 10, "time": 90.0  },
		{ "inputs": { &"iron": 3, &"gold": 2, &"plasma": 2   }, "output_id": &"reactor_parts", "output_amount": 5,  "time": 120.0 },
		{ "inputs": { &"iron": 3, &"carbon": 3, &"electronics": 2 }, "output_id": &"thruster_parts","output_amount": 5,  "time": 120.0 },
	],
	&"shipyard": [
		## Small ships (60s)
		{ "inputs": { &"hull_parts": 60,  &"electronics": 70,  &"thruster_parts": 60, &"reactor_parts": 30 }, "output_id": &"fighter",      "output_amount": 1, "time": 60.0  },
		{ "inputs": { &"hull_parts": 100, &"electronics": 40,  &"thruster_parts": 60, &"reactor_parts": 30 }, "output_id": &"hauler",        "output_amount": 1, "time": 60.0  },
		{ "inputs": { &"hull_parts": 80,  &"electronics": 50,  &"thruster_parts": 50, &"reactor_parts": 50 }, "output_id": &"miner",         "output_amount": 1, "time": 60.0  },
		{ "inputs": { &"hull_parts": 80,  &"electronics": 80,  &"thruster_parts": 50, &"reactor_parts": 40 }, "output_id": &"missile_boat",  "output_amount": 1, "time": 60.0  },
		## Medium ships (180s)
		{ "inputs": { &"hull_parts": 120, &"electronics": 140, &"thruster_parts": 120, &"reactor_parts": 60  }, "output_id": &"medium_fighter",      "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"hull_parts": 200, &"electronics": 80, &"thruster_parts": 120, &"reactor_parts": 60  }, "output_id": &"medium_hauler",       "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"hull_parts": 160, &"electronics": 100, &"thruster_parts": 100, &"reactor_parts": 100 }, "output_id": &"medium_miner",        "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"hull_parts": 160, &"electronics": 160, &"thruster_parts": 100, &"reactor_parts": 80 }, "output_id": &"medium_missile_boat", "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"hull_parts": 300, &"electronics": 300, &"thruster_parts": 200, &"reactor_parts": 150 }, "output_id": &"medium_logistics",    "output_amount": 1, "time": 180.0 },
		## Large ships (540s)
		{ "inputs": { &"hull_parts": 180,  &"electronics": 210,  &"thruster_parts": 180, &"reactor_parts": 90 }, "output_id": &"heavy_fighter",      "output_amount": 1, "time": 540.0 },
		{ "inputs": { &"hull_parts": 300,  &"electronics": 120,  &"thruster_parts": 180, &"reactor_parts": 90 }, "output_id": &"heavy_hauler",       "output_amount": 1, "time": 540.0 },
		{ "inputs": { &"hull_parts": 240,  &"electronics": 150,  &"thruster_parts": 150, &"reactor_parts": 150 }, "output_id": &"heavy_miner",        "output_amount": 1, "time": 540.0 },
		{ "inputs": { &"hull_parts": 240,  &"electronics": 240,  &"thruster_parts": 150, &"reactor_parts": 120 }, "output_id": &"heavy_missile_boat", "output_amount": 1, "time": 540.0 },
		{ "inputs": { &"hull_parts": 600,  &"electronics": 600,  &"thruster_parts": 400, &"reactor_parts": 300 }, "output_id": &"large_logistics",    "output_amount": 1, "time": 540.0 },
		{ "inputs": { &"hull_parts": 780,  &"electronics": 780,  &"thruster_parts": 520, &"reactor_parts": 390 }, "output_id": &"construction_ship",  "output_amount": 1, "time": 540.0 },
	],
	&"military": [
		## Weapons S1
		{ "inputs": { &"weapon_parts": 40, &"electronics": 20 }, "output_id": &"ballistic_autocannon_s1", "output_amount": 1, "time": 60.0 },
		{ "inputs": { &"weapon_parts": 40, &"electronics": 10 }, "output_id": &"ballistic_cannon_s1",    "output_amount": 1, "time": 60.0 },
		{ "inputs": { &"weapon_parts": 40, &"electronics": 30 }, "output_id": &"ballistic_gatling_s1",   "output_amount": 1, "time": 60.0 },
		{ "inputs": { &"weapon_parts": 30, &"electronics": 60 }, "output_id": &"laser_autocannon_s1",    "output_amount": 1, "time": 60.0 },
		{ "inputs": { &"weapon_parts": 30, &"electronics": 70 }, "output_id": &"laser_cannon_s1",        "output_amount": 1, "time": 60.0 },
		{ "inputs": { &"weapon_parts": 30, &"electronics": 50 }, "output_id": &"laser_gatling_s1",       "output_amount": 1, "time": 60.0 },
		{ "inputs": { &"weapon_parts": 30, &"electronics": 40 }, "output_id": &"mining_laser_s1",        "output_amount": 1, "time": 60.0 },
		## Weapons S2 (×3)
		{ "inputs": { &"weapon_parts": 120, &"electronics": 60  }, "output_id": &"ballistic_autocannon_s2", "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"weapon_parts": 120, &"electronics": 30  }, "output_id": &"ballistic_cannon_s2",    "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"weapon_parts": 120, &"electronics": 90  }, "output_id": &"ballistic_gatling_s2",   "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"weapon_parts": 90,  &"electronics": 180 }, "output_id": &"laser_autocannon_s2",    "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"weapon_parts": 90,  &"electronics": 210 }, "output_id": &"laser_cannon_s2",        "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"weapon_parts": 90,  &"electronics": 150 }, "output_id": &"laser_gatling_s2",       "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"weapon_parts": 90,  &"electronics": 120 }, "output_id": &"mining_laser_s2",        "output_amount": 1, "time": 120.0 },
		## Weapons S3 (×6)
		{ "inputs": { &"weapon_parts": 240, &"electronics": 120 }, "output_id": &"ballistic_autocannon_s3", "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"weapon_parts": 240, &"electronics": 60  }, "output_id": &"ballistic_cannon_s3",    "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"weapon_parts": 240, &"electronics": 180 }, "output_id": &"ballistic_gatling_s3",   "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"weapon_parts": 180, &"electronics": 360 }, "output_id": &"laser_autocannon_s3",    "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"weapon_parts": 180, &"electronics": 420 }, "output_id": &"laser_cannon_s3",        "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"weapon_parts": 180, &"electronics": 300 }, "output_id": &"laser_gatling_s3",       "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"weapon_parts": 180, &"electronics": 240 }, "output_id": &"mining_laser_s3",        "output_amount": 1, "time": 180.0 },
		## Missiles (S1, S2×3, S3×6)
		{ "inputs": { &"missile_parts": 60,  &"electronics": 60,  &"hydrogen": 30  }, "output_id": &"missile_s1", "output_amount": 1, "time": 60.0  },
		{ "inputs": { &"missile_parts": 180, &"electronics": 180, &"hydrogen": 90  }, "output_id": &"missile_s2", "output_amount": 1, "time": 120.0 },
		{ "inputs": { &"missile_parts": 360, &"electronics": 360, &"hydrogen": 180 }, "output_id": &"missile_s3", "output_amount": 1, "time": 180.0 },
		## Shields (S1, S2×5, S3×10)
		{ "inputs": { &"shield_parts": 100, &"plasma": 100, &"electronics": 100 }, "output_id": &"shield_s1_average", "output_amount": 1, "time": 90.0  },
		{ "inputs": { &"shield_parts": 500, &"plasma": 500, &"electronics": 500 }, "output_id": &"shield_s2_average", "output_amount": 1, "time": 180.0 },
		{ "inputs": { &"shield_parts": 1000, &"plasma": 1000, &"electronics": 1000 }, "output_id": &"shield_s3_average", "output_amount": 1, "time": 360.0 },
	],
}

## Sell price multiplier — cost × this = sell price
const SELL_PRICE_MULTIPLIER : float = 3.0
## Player sell price — buy price × this
const PLAYER_SELL_MULTIPLIER : float = 0.667

@export_group("Identity")
@export var id           : StringName = &""
@export var display_name : String     = ""
@export var description  : String     = ""
@export_group("Type")
@export var station_type : StringName = &"military"
@export_group("Faction")
@export var faction_id   : StringName = &""
@export_group("Economy")
@export var sells_items  : Array[StringName] = []
@export var buys_items   : Array[StringName] = []
@export_group("Combat")
@export var max_hull     : float = 1000.0
@export var max_ships    : int   = 5
@export_group("Services")
@export var offers_repairs : bool = true
@export var docking_range  : float = 300.0
@export_group("Manufacture")
@export var capital_yard: bool = false
## Legacy field kept for compatibility — recipes now come from MANUFACTURING_RECIPES const
@export var manufacture_recipes : Array[Dictionary] = []

## Returns build cost for this station type
func get_build_cost() -> Dictionary:
	return BUILD_COSTS.get(station_type, {})

## Returns sector cap for this station type
func get_sector_cap() -> int:
	return SECTOR_CAPS.get(station_type, 2)

## Returns manufacturing recipes for this station type
func get_recipes() -> Array:
	var recipes: Array = MANUFACTURING_RECIPES.get(station_type, []).duplicate(true)
	if station_type == TYPE_MILITARY:
		recipes.push_front({"inputs": {&"iron": 1, &"carbon": 1}, "output_id": &"ballistic_ammo", "output_amount": 200, "time": 20.0})
	if station_type == TYPE_SHIPYARD:
		recipes = recipes.filter(func(recipe): return supports_ship(recipe["output_id"]))
		for recipe in recipes:
			var loadout: Dictionary = get_ship_loadout(recipe["output_id"])
			for item_id in loadout:
				recipe["inputs"][item_id] = loadout[item_id]
	return recipes

## Returns sell price for an item given its base cost
static func calc_sell_price(base_cost: int) -> int:
	return int(base_cost * SELL_PRICE_MULTIPLIER)

## Returns player sell price for an item given its buy price
static func calc_player_sell_price(buy_price: int) -> int:
	return int(buy_price * PLAYER_SELL_MULTIPLIER)


static func get_ship_loadout(ship_id: StringName) -> Dictionary:
	var sd: ShipData = GameData.ships.get(ship_id)
	if sd == null: return {}
	var tier: int = int(sd.ship_class) + 1
	var weapon_id: StringName
	if String(ship_id).contains("miner"):
		weapon_id = StringName("mining_laser_s%d" % tier)
	else:
		weapon_id = [&"ballistic_gatling_s1", &"ballistic_autocannon_s2", &"ballistic_cannon_s3"][int(sd.ship_class)]
	var result: Dictionary = {weapon_id: 1, StringName("shield_s%d_average" % tier): 1}
	if GameData.weapons[weapon_id].uses_ammo: result[&"ballistic_ammo"] = 100
	if String(ship_id).contains("missile_boat"):
		result[StringName("missile_s%d" % tier)] = 5
	return result


func supports_ship(ship_id: StringName) -> bool:
	if station_type != TYPE_SHIPYARD or not GameData.ships.has(ship_id): return false
	var large: bool = GameData.ships[ship_id].ship_class == GlobalEnums.ShipClass.LARGE
	return large if capital_yard else not large

func get_yard_class_name() -> String:
	return "Capital Shipyard" if capital_yard else "Small / Medium Shipyard"
