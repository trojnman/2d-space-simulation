class_name MissileData
extends Resource

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D = null
@export var scene: PackedScene = null

@export_group("Size")
## Missiles can be equipped by ships of this size OR LARGER
@export var equip_size: GlobalEnums.EquipSize = GlobalEnums.EquipSize.S1

@export_group("Stats")
@export var damage: float = 80.0
@export var damage_type: GlobalEnums.DamageType = GlobalEnums.DamageType.EXPLOSIVE
@export var blast_radius: float = 60.0      # 0 = no splash
@export var speed: float = 500.0
@export var turn_rate: float = 2.0          # radians/sec for homing
@export var is_homing: bool = true
@export var lifetime: float = 6.0           # seconds before self-destruct
@export var lock_on_range: float = 800.0
## Fraction of damage that hits hull directly, bypassing shields.
## All missiles: 0.50 (50% shield, 50% hull)
@export var hull_penetration_ratio: float = 0.50

@export_group("Economy")
@export var base_price: int = 200           # per missile
@export var manufacturer_faction_id: StringName = ""


## Returns [shield_damage, hull_damage] for a detonation
func calc_damage_split(raw: float) -> Array[float]:
	var hull_dmg  : float = raw * hull_penetration_ratio
	var shield_dmg: float = raw * (1.0 - hull_penetration_ratio)
	return [shield_dmg, hull_dmg]


## Small ships: S1 only. Medium: S1+S2. Large: S1+S2+S3.
func can_equip_on(ship_class: GlobalEnums.ShipClass) -> bool:
	match ship_class:
		GlobalEnums.ShipClass.SMALL:
			return equip_size == GlobalEnums.EquipSize.S1
		GlobalEnums.ShipClass.MEDIUM:
			return equip_size <= GlobalEnums.EquipSize.S2
		GlobalEnums.ShipClass.LARGE:
			return true
	return false
