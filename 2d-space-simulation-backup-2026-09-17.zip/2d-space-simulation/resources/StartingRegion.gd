extends RefCounted
const ID="four_faction_region_v1"
const ACTIVE:Array[StringName]=[&"terran_republic",&"free_traders_guild",&"ash_collective",&"iron_corsairs"]
const OWNERS={&"sol_prime":&"terran_republic",&"covenant_sanctuary":&"terran_republic",&"trade_nexus":&"free_traders_guild",&"axiom_corridor":&"free_traders_guild",&"ash_fringe":&"ash_collective",&"nova_frontier":&"ash_collective",&"corsair_expanse":&"iron_corsairs",&"frontier_reach":&"",&"reclaimer_belt":&"",&"void_hollow":&""}
static func station(data:Node,sector:StringName,template:StringName,suffix:String,title:String,type:StringName=&"")->void:
 var entry:StationData=data.stations[template].duplicate(true)
 entry.id=StringName(str(sector)+"_region_"+suffix)
 entry.display_name=title
 entry.faction_id=OWNERS[sector]
 if type!=&"":entry.station_type=type
 entry.max_ships=0 if entry.station_type==&"claim_beacon" else (4 if entry.station_type==&"headquarters" else 2)
 data.stations[entry.id]=entry
 data.sectors[sector].starting_stations.append(entry.id)
static func apply(data:Node)->void:
 # Retain source resources on disk; only this starting scenario is restricted.
 for id in data.factions.keys():
  if id not in ACTIVE:data.factions.erase(id)
 for id in ACTIVE:
  var faction: FactionData=data.factions[id].duplicate(true)
  faction.starting_reputation=300 if id in [&"terran_republic",&"free_traders_guild"] else (0 if id==&"ash_collective" else -400)
  faction.starting_sectors.clear()
  faction.base_relations.clear()
  for other in ACTIVE:
   if id==other:continue
   faction.base_relations[other]=.6 if id in [&"terran_republic",&"free_traders_guild"] and other in [&"terran_republic",&"free_traders_guild"] else -.8
  data.factions[id]=faction
 for id in OWNERS:
  var sector:SectorData=data.sectors[id].duplicate(true)
  sector.controlling_faction_id=OWNERS[id]
  sector.secondary_faction_id=&""
  sector.ambient_ships.clear()
  if id!=&"sol_prime":sector.starting_stations.clear()
  sector.description="Unclaimed frontier. Open to exploration and settlement." if OWNERS[id]==&"" else "Territory of "+data.factions[OWNERS[id]].display_name+"."
  data.sectors[id]=sector
  if OWNERS[id]!=&"":data.factions[OWNERS[id]].starting_sectors.append(id)
 for id in data.sectors[&"sol_prime"].starting_stations:
  var station_data:StationData=data.stations[id].duplicate(true)
  station_data.max_ships=4 if station_data.station_type==&"headquarters" else 2
  data.stations[id]=station_data
 # One headquarters per faction; owner-only military installations.
 station(data,&"trade_nexus",&"traders_hub","hq","Guild Headquarters")
 station(data,&"ash_fringe",&"ash_outpost","hq","Ash Collective Command")
 station(data,&"corsair_expanse",&"corsair_base","hq","Iron Corsair Stronghold",&"headquarters")
 for id in [&"trade_nexus",&"ash_fringe",&"corsair_expanse"]:
  var name:String=data.factions[OWNERS[id]].display_name
  station(data,id,&"sol_prime_trade","trade",name+" Exchange")
  station(data,id,&"sol_prime_manufacturing","factory",name+" Fabrication Works")
  station(data,id,&"sol_prime_shipyard","yard",name+" Shipyard")
  station(data,id,&"sol_prime_capital_shipyard","capital_yard",name+" Capital Shipyard")
 for id in [&"covenant_sanctuary",&"axiom_corridor",&"nova_frontier"]:
  var name:String=data.factions[OWNERS[id]].display_name
  station(data,id,&"claim_beacon","claim",name+" Claim Beacon")
  station(data,id,&"sol_prime_trade","trade",name+" Border Exchange")
  station(data,id,&"sol_prime_manufacturing","factory",name+" Frontier Works")
  station(data,id,&"ash_military","military",name+" Patrol Base")
