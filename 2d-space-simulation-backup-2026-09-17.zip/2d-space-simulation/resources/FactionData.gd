class_name FactionData
extends Resource

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""
@export var color: Color = Color.WHITE         # used on map and UI
@export var icon: Texture2D = null

@export_group("Relations")
## Keys are faction IDs (StringName), values are floats -1.0 (hostile) to 1.0 (allied)
@export var base_relations: Dictionary = {}

@export_group("Player Reputation")
## Starting rep the player has with this faction
@export var starting_reputation: float = 0.0  # -1000 to 1000

## Thresholds that determine FactionStance toward player
@export var hostile_threshold: float  = -200.0
@export var neutral_threshold: float  =    0.0
@export var friendly_threshold: float =  200.0
@export var allied_threshold: float   =  600.0

@export_group("Territory")
## Sector IDs this faction starts controlling
@export var starting_sectors: Array[StringName] = []

@export_group("Economy")
@export var preferred_goods: Array[StringName] = []   # item IDs they buy/sell most
@export var contraband_goods: Array[StringName] = []  # items illegal in their space


func get_stance_toward_faction(other_id: StringName) -> GlobalEnums.FactionStance:
	var rel: float = base_relations.get(other_id, 0.0)
	if rel <= -0.5:  return GlobalEnums.FactionStance.HOSTILE
	if rel >=  0.5:  return GlobalEnums.FactionStance.ALLIED
	if rel >=  0.1:  return GlobalEnums.FactionStance.FRIENDLY
	return GlobalEnums.FactionStance.NEUTRAL


func get_player_stance(player_rep: float) -> GlobalEnums.FactionStance:
	if player_rep <= hostile_threshold:  return GlobalEnums.FactionStance.HOSTILE
	if player_rep >= allied_threshold:   return GlobalEnums.FactionStance.ALLIED
	if player_rep >= friendly_threshold: return GlobalEnums.FactionStance.FRIENDLY
	return GlobalEnums.FactionStance.NEUTRAL
