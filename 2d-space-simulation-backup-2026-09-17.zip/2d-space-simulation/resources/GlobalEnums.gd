class_name GlobalEnums

enum EquipSize        { S1 = 1, S2 = 2, S3 = 3 }
enum ShipClass        { SMALL, MEDIUM, LARGE }
enum WeaponType       { BALLISTIC, ENERGY, MISSILE, MINING }
enum ShieldType       { KINETIC, ENERGY, OMNI }
enum MissionType      { COLLECT, ESCORT, KILL, DELIVER, PATROL }
enum MissionStatus    { AVAILABLE, ACTIVE, COMPLETED, FAILED }
enum AIBehavior       { IDLE, PATROL, ESCORT, ATTACK, FLEE, MINE, TRADE }
enum FleetFormation   { DELTA, LINE, WEDGE, SPREAD, ORBIT }
enum FleetOrder       { HOLD, FOLLOW, ATTACK_TARGET, DEFEND_AREA, GOTO }
enum FactionStance    { HOSTILE, NEUTRAL, FRIENDLY, ALLIED }
enum DamageType       { KINETIC, ENERGY, EXPLOSIVE }
enum AsteroidMaterial { IRON, CARBON, SILICON, ICE, GOLD }
enum AsteroidSize     { SMALL, MEDIUM, LARGE }

## Fleet command types for the RTS command queue
enum FleetCommand {
	FOLLOW_SHIP,      ## Follow a specific ship without engaging
	DEFEND_SHIP,      ## Follow a ship and attack anything that attacks it
	PATROL_AREA,      ## Patrol in a radius around a point, attack enemies
	PATROL_ROUTE,     ## Patrol between multiple waypoints, attack enemies
	GO_WAIT,          ## Move to position then idle
	ATTACK_TARGET,    ## Attack a specific target
}
