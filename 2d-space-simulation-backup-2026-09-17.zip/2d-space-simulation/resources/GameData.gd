extends Node

## GameData — Autoload singleton.
## Loads and holds every data resource.
## Add to Project -> Autoload as 'GameData'.

var items:    Dictionary = {}
var weapons:  Dictionary = {}
var shields:  Dictionary = {}
var missiles: Dictionary = {}
var ships:    Dictionary = {}
var stations: Dictionary = {}
var factions: Dictionary = {}
var missions: Dictionary = {}
var sectors:  Dictionary = {}

const PATHS := {
	"items":    "res://data/items/",
	"weapons":  "res://data/weapons/",
	"shields":  "res://data/shields/",
	"missiles": "res://data/missiles/",
	"ships":    "res://data/ships/",
	"stations": "res://data/stations/",
	"factions": "res://data/factions/",
	"missions": "res://data/missions/",
	"sectors":  "res://data/sectors/",
}


func _ready() -> void:
	_load_all()


func _load_all() -> void:
	_load_folder(PATHS["items"],    items,    "ItemData")
	_load_folder(PATHS["weapons"],  weapons,  "WeaponData")
	_load_folder(PATHS["shields"],  shields,  "ShieldData")
	_load_folder(PATHS["missiles"], missiles, "MissileData")
	_load_folder(PATHS["ships"],    ships,    "ShipData")
	_load_folder(PATHS["stations"], stations, "StationData")
	_load_folder(PATHS["factions"], factions, "FactionData")
	_load_folder(PATHS["missions"], missions, "MissionData")
	_load_folder(PATHS["sectors"],  sectors,  "SectorData")
	preload("res://resources/StartingRegion.gd").apply(self)
	_register_equipment_items()
	var ammo := ItemData.new()
	ammo.id = &"ballistic_ammo"
	ammo.display_name = "Ballistic ammunition"
	ammo.base_price = 1
	ammo.volume = 0.01
	ammo.is_consumable = true
	items[ammo.id] = ammo
	for weapon in weapons.values():
		if weapon.weapon_type == GlobalEnums.WeaponType.BALLISTIC:
			weapon.uses_ammo = true
			weapon.ammo_item_id = ammo.id
	print("GameData: loaded %d items, %d ships, %d factions, %d sectors" % [
		items.size(), ships.size(), factions.size(), sectors.size()
	])


func _load_folder(path: String, registry: Dictionary, type_name: String) -> void:
	if not DirAccess.dir_exists_absolute(path):
		push_warning("GameData: folder not found — " + path)
		return
	var dir := DirAccess.open(path)
	if dir == null: return
	dir.list_dir_begin()
	var filename := dir.get_next()
	while filename != "":
		if filename.ends_with(".tres") or filename.ends_with(".res"):
			var res = load(path + filename)
			if res != null:
				var script = res.get_script()
				if script != null and script.get_global_name() == type_name:
					var data_id: StringName = res.id
					if data_id == &"":
						push_warning("GameData: resource has no id — " + path + filename)
					else:
						registry[data_id] = res
		filename = dir.get_next()
	dir.list_dir_end()


## Safe getters — return null silently for empty ids, warn for unknown ids

func get_item(id: StringName) -> ItemData:
	if id == &"": return null
	var r = items.get(id)
	if r == null: push_warning("GameData: unknown item id '%s'" % id)
	return r

func get_weapon(id: StringName) -> WeaponData:
	if id == &"": return null
	var r = weapons.get(id)
	if r == null: push_warning("GameData: unknown weapon id '%s'" % id)
	return r

func get_shield(id: StringName) -> ShieldData:
	if id == &"": return null
	var r = shields.get(id)
	if r == null: push_warning("GameData: unknown shield id '%s'" % id)
	return r

func get_missile(id: StringName) -> MissileData:
	if id == &"": return null
	var r = missiles.get(id)
	if r == null: push_warning("GameData: unknown missile id '%s'" % id)
	return r

func get_ship(id: StringName) -> ShipData:
	if id == &"escape_pod": return preload("res://resources/EscapePod.tres")
	if id == &"": return null
	var r = ships.get(id)
	if r == null: push_warning("GameData: unknown ship id '%s'" % id)
	return r

func get_station(id: StringName) -> StationData:
	if id == &"": return null
	var r = stations.get(id)
	if r == null: push_warning("GameData: unknown station id '%s'" % id)
	return r

func get_faction(id: StringName) -> FactionData:
	if id == &"player": return preload("res://resources/PlayerFaction.tres")
	if id == &"": return null
	var r = factions.get(id)
	if r == null: push_warning("GameData: unknown faction id '%s'" % id)
	return r

func get_mission(id: StringName) -> MissionData:
	if id == &"": return null
	var r = missions.get(id)
	if r == null: push_warning("GameData: unknown mission id '%s'" % id)
	return r

func get_sector(id: StringName) -> SectorData:
	if id == &"": return null
	var r = sectors.get(id)
	if r == null: push_warning("GameData: unknown sector id '%s'" % id)
	return r


func _register_equipment_items() -> void:
	# Cargo metadata for equipment resources, which do not inherit ItemData.
	# Provisional volumes by size: small 5, medium 15, large 30.
	for registry in [weapons, shields, missiles]:
		for item_id in registry:
			if items.has(item_id): continue
			var equipment: Resource = registry[item_id]
			var item := ItemData.new()
			item.id = item_id
			item.display_name = equipment.display_name
			item.description = equipment.description
			item.icon = equipment.icon
			item.base_price = equipment.base_price
			item.volume = [5.0, 15.0, 30.0][int(equipment.equip_size) - 1]
			item.is_consumable = missiles.has(item_id)
			if item.is_consumable: item.volume = 0.1 * int(equipment.equip_size)
			items[item_id] = item
