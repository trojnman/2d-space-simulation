class_name MissionData
extends Resource

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""          # shown in mission board UI

@export_group("Type & Source")
@export var mission_type: GlobalEnums.MissionType = GlobalEnums.MissionType.COLLECT
@export var issuing_faction_id: StringName = ""
@export var issuing_station_id: StringName = "" # station where you pick this up

@export_group("Objectives")
## Flexible — content depends on mission_type:
##   COLLECT  → { "item_id": StringName, "amount": int, "deliver_to_station_id": StringName }
##   ESCORT   → { "ship_id": StringName, "destination_sector_id": StringName }
##   KILL     → { "target_faction_id": StringName, "kill_count": int }
##   DELIVER  → { "item_id": StringName, "amount": int, "deliver_to_station_id": StringName }
##   PATROL   → { "sector_ids": Array[StringName], "duration": float }
@export var objective: Dictionary = {}

@export_group("Rewards")
@export var credit_reward: int = 0
@export var reputation_reward: float = 50.0   # added to player rep with issuing faction
## Optional bonus item rewards: Array of { "item_id": StringName, "amount": int }
@export var item_rewards: Array[Dictionary] = []

@export_group("Requirements")
@export var min_reputation: float = -1000.0   # player must be at or above this
@export var time_limit: float = 0.0           # seconds; 0 = no limit
@export var required_cargo_space: float = 0.0 # player must have this free


func is_available_to_player(player_rep: float) -> bool:
	return player_rep >= min_reputation
