class_name ShipData
extends Resource

## Defines a ship TYPE (template/blueprint).
## Actual ship instances in the world reference this resource.

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D = null
@export var scene: PackedScene = null          # the scene to instantiate
@export var faction_id: StringName = ""        # which faction makes this ship

@export_group("Class")
@export var ship_class: GlobalEnums.ShipClass = GlobalEnums.ShipClass.SMALL

@export_group("Hull")
@export var max_hull: float = 100.0
@export var hull_repair_rate: float = 0.0      # HP/s passive regen (0 = none)

@export_group("Movement")
@export var thrust_force: float = 220.0
@export var strafe_force: float = 150.0
@export var max_speed: float = 600.0
@export var drag: float = 0.97
@export var rotation_speed: float = 3.0        # maximum hull turn rate for player and AI (rad/s)

@export_group("Energy")
@export var max_energy: float = 100.0
@export var energy_recharge_rate: float = 10.0 # per second

@export_group("Equipment Slots")
@export var weapon_slots: int = 2
@export var shield_slots: int = 1
@export var missile_slots: int = 1             # launcher hardpoints

@export_group("Cargo")
@export var cargo_capacity: float = 20.0       # total volume units

@export_group("Economy")
@export var base_price: int = 5000
@export var manufacture_time: float = 60.0     # seconds at station

@export_group("Manufacture Cost")
## Array of {id: StringName, amount: int} Dictionaries
@export var manufacture_materials: Array[Dictionary] = []
