class_name ShipData
extends Resource

## Defines a ship TYPE (template/blueprint).
## Actual ship instances in the world reference this resource.

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D = null
@export var scene: PackedScene = null          # the scene to instantiate
@export var faction_id: StringName = ""        # which faction makes this ship

@export_group("Class")
@export var ship_class: GlobalEnums.ShipClass = GlobalEnums.ShipClass.SMALL

@export_group("Hull")
@export var max_hull: float = 100.0
@export var hull_repair_rate: float = 0.0      # HP/s passive regen (0 = none)

@export_group("Movement")
@export var thrust_force: float = 220.0
@export var strafe_force: float = 150.0
@export var max_speed: float = 600.0
@export var drag: float = 0.97
@export var rotation_speed: float = 3.0        # maximum hull turn rate for player and AI (rad/s)

@export_group("Energy")
@export var max_energy: float = 100.0
@export var energy_recharge_rate: float = 10.0 # per second

@export_group("Equipment Slots")
@export var weapon_slots: int = 2
@export var shield_slots: int = 1
@export var missile_slots: int = 1             # launcher hardpoints

@export_group("Cargo")
@export var cargo_capacity: float = 20.0       # total volume units

@export_group("Economy")
@export var base_price: int = 5000
@export var manufacture_time: float = 60.0     # seconds at station

@export_group("Manufacture Cost")
## Array of {id: StringName, amount: int} Dictionaries
@export var manufacture_materials: Array[Dictionary] = []


@export var fixed_sizes: Array[int] = []
@export var turret_sizes: Array[int] = []
@export var rack_sizes: Array[int] = []
@export var mining_size: int = 0

func mount_size(slot: int) -> int:
	if slot < 0 or slot >= weapon_slots: return 0
	if slot < fixed_sizes.size(): return fixed_sizes[slot]
	if slot < fixed_sizes.size() + turret_sizes.size(): return turret_sizes[slot - fixed_sizes.size()]
	return mining_size

func mount_kind(slot: int) -> String:
	if slot < fixed_sizes.size(): return "Fixed"
	if slot < fixed_sizes.size() + turret_sizes.size(): return "Turret"
	return "Mining"

func mount_arc_center(slot: int) -> float:
	var turret: int = slot - fixed_sizes.size()
	# Paired side turrets; an odd final turret covers the stern.
	if turret_sizes.size() % 2 == 1 and turret == turret_sizes.size()-1: return PI
	return -2.0*PI/3.0 if turret % 2 == 0 else 2.0*PI/3.0

func accepts_weapon(slot: int, weapon: WeaponData) -> bool:
	if weapon == null or mount_size(slot) != int(weapon.equip_size): return false
	return (weapon.weapon_type == GlobalEnums.WeaponType.MINING) == (mount_kind(slot) == "Mining")

func mount_label(slot: int) -> String:
	return "%s S%d" % [mount_kind(slot), mount_size(slot)]


func inertia_seconds() -> float:
	var size_time:float=[0.4,1.2,3.0][clampi(int(ship_class),0,2)]
	var role:=1.0
	if "hauler" in str(id):role=2.0
	elif "miner" in str(id):role=1.65
	elif "logistics" in str(id):role=1.45
	elif "missile_boat" in str(id):role=1.2
	return size_time*role

func lateral_acceleration() -> float:
	return max_speed/inertia_seconds()

func forward_acceleration() -> float:
	return lateral_acceleration()*1.35

func coast_factor(delta:float)->float:
	return pow(0.5,maxf(0,delta)/(inertia_seconds()*.55))
