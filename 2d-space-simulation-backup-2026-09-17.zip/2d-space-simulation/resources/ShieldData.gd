class_name ShieldData
extends Resource

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D = null

@export_group("Size & Type")
@export var equip_size: GlobalEnums.EquipSize = GlobalEnums.EquipSize.S1
@export var shield_type: GlobalEnums.ShieldType = GlobalEnums.ShieldType.OMNI

@export_group("Stats")
@export var max_hp: float = 100.0
@export var recharge_rate: float = 5.0      # HP per second
@export var recharge_delay: float = 3.0     # seconds after last hit before recharge starts
@export var energy_per_second: float = 1.0  # passive energy drain while active

## Damage resistance multipliers (1.0 = full damage, 0.5 = half damage)
@export var kinetic_resist: float = 1.0
@export var energy_resist: float = 1.0
@export var explosive_resist: float = 1.0

@export_group("Economy")
@export var base_price: int = 400
@export var manufacturer_faction_id: StringName = ""


func can_equip_on(ship_class: GlobalEnums.ShipClass) -> bool:
	match ship_class:
		GlobalEnums.ShipClass.SMALL:
			return equip_size == GlobalEnums.EquipSize.S1
		GlobalEnums.ShipClass.MEDIUM:
			return equip_size == GlobalEnums.EquipSize.S2
		GlobalEnums.ShipClass.LARGE:
			return equip_size == GlobalEnums.EquipSize.S3
	return false


func get_resist(damage_type: GlobalEnums.DamageType) -> float:
	match damage_type:
		GlobalEnums.DamageType.KINETIC:   return kinetic_resist
		GlobalEnums.DamageType.ENERGY:    return energy_resist
		GlobalEnums.DamageType.EXPLOSIVE: return explosive_resist
	return 1.0
