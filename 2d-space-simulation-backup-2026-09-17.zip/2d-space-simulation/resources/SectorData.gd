class_name SectorData
extends Resource

@export_group("Identity")
@export var id           : StringName = &""
@export var display_name : String     = ""
@export var description  : String     = ""

@export_group("Map")
## Position on the galaxy map (not in-world position)
@export var map_position      : Vector2             = Vector2.ZERO
## Connected sector IDs (jump points / warp lanes)
@export var connected_sectors : Array[StringName]   = []

@export_group("Ownership")
@export var controlling_faction_id : StringName = &""  ## empty = unclaimed
@export var secondary_faction_id   : StringName = &""  ## contested presence, can be empty

@export_group("Contents")
## Station IDs present in this sector at world start
@export var starting_stations : Array[StringName]   = []
## Asteroid field definitions: Array of { resource_id, richness, count }
@export var asteroid_fields   : Array[Dictionary]   = []
## Ambient AI ship spawns: Array of { ship_data_id, faction_id, count, behavior }
@export var ambient_ships     : Array[Dictionary]   = []

@export_group("Hazards")
@export var has_nebula                : bool  = false
@export var nebula_sensor_penalty     : float = 0.5   ## multiplier on detection range
@export var has_radiation             : bool  = false
@export var radiation_damage_per_second : float = 0.0

@export_group("Economy")
## Local price modifiers for item categories (item_id -> multiplier)
@export var local_price_modifiers : Dictionary = {}
