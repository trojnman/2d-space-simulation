class_name InventoryData
extends Resource

## A general-purpose inventory.
## Ships, stations, and the player wallet all use this.
## Stacks items by id; each entry: { "item_id": StringName, "amount": int }

@export var capacity: float = 0.0   # 0 = unlimited (e.g. station warehouses)

## Internal storage — do not edit directly in the Inspector.
## Use the methods below so signals fire correctly.
var _items: Dictionary = {}         # item_id → amount

signal item_added(item_id: StringName, amount: int)
signal item_removed(item_id: StringName, amount: int)
signal capacity_changed()


# ---------------------------------------------------------------------------
# Queries
# ---------------------------------------------------------------------------

func get_amount(item_id: StringName) -> int:
	return _items.get(item_id, 0)


func has_item(item_id: StringName, amount: int = 1) -> bool:
	return amount > 0 and get_amount(item_id) >= amount


func get_all_items() -> Dictionary:
	return _items.duplicate()


func get_used_capacity(item_registry: Dictionary) -> float:
	## item_registry: item_id → ItemData (pass in from GameData singleton)
	var used := 0.0
	for item_id in _items:
		var data: ItemData = item_registry.get(item_id)
		if data:
			used += data.volume * _items[item_id]
	return used


func get_free_capacity(item_registry: Dictionary) -> float:
	if capacity <= 0.0:
		return INF
	return capacity - get_used_capacity(item_registry)


# ---------------------------------------------------------------------------
# Mutations
# ---------------------------------------------------------------------------

func add_item(item_id: StringName, amount: int, item_registry: Dictionary = {}) -> bool:
	if amount <= 0:
		return false
	## Check capacity if registry provided
	if capacity > 0.0 and not item_registry.is_empty():
		var data: ItemData = item_registry.get(item_id)
		if data:
			var needed_space := data.volume * amount
			if get_used_capacity(item_registry) + needed_space > capacity:
				return false

	_items[item_id] = get_amount(item_id) + amount
	item_added.emit(item_id, amount)
	return true


func remove_item(item_id: StringName, amount: int) -> bool:
	if not has_item(item_id, amount):
		return false
	_items[item_id] -= amount
	if _items[item_id] <= 0:
		_items.erase(item_id)
	item_removed.emit(item_id, amount)
	return true


func clear() -> void:
	_items.clear()


# ---------------------------------------------------------------------------
# Serialization
# ---------------------------------------------------------------------------

func serialize() -> Dictionary:
	return { "capacity": capacity, "items": _items.duplicate() }


func deserialize(data: Dictionary) -> void:
	capacity = data.get("capacity", 0.0)
	_items   = data.get("items", {})
