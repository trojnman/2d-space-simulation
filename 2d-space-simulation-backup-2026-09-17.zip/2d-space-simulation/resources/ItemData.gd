class_name ItemData
extends Resource

## Base resource for every item in the game.
## Materials, components, ammo, and finished goods all extend this.

@export_group("Identity")
@export var id: StringName = ""           # unique key e.g. "iron_ore"
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D = null

@export_group("Economy")
@export var base_price: int = 0           # credit value at neutral market
@export var volume: float = 1.0           # cargo units this item occupies

@export_group("Classification")
@export var is_raw_material: bool = false
@export var is_component: bool = false
@export var is_consumable: bool = false
@export var is_illegal: bool = false


func get_sell_price(market_modifier: float = 1.0) -> int:
	return int(base_price * market_modifier)
