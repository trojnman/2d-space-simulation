class_name WeaponData
extends Resource

@export_group("Identity")
@export var id: StringName = ""
@export var display_name: String = ""
@export var description: String = ""
@export var icon: Texture2D = null
@export var projectile_scene: PackedScene = null

@export_group("Size & Type")
@export var equip_size: GlobalEnums.EquipSize = GlobalEnums.EquipSize.S1
@export var weapon_type: GlobalEnums.WeaponType = GlobalEnums.WeaponType.BALLISTIC
@export var damage_type: GlobalEnums.DamageType = GlobalEnums.DamageType.KINETIC

@export_group("Stats")
@export var damage: float = 10.0
## Rounds per minute
@export var fire_rate_rpm: int = 120
@export var projectile_speed: float = 1200.0
@export var max_range: float = 1200.0
@export var spread: float = 0.0             # cone half-angle in radians

## Fraction of each shot that hits hull directly, bypassing shields.
## Ballistic gatling=0.10, autocannon=0.30, cannon=0.50
## Laser all types=0.0 (no penetration — higher raw DPS instead)
@export var hull_penetration_ratio: float = 0.0

@export_group("Ammo")
@export var uses_ammo: bool = false
@export var ammo_item_id: StringName = ""
@export var ammo_per_shot: int = 1

@export_group("Energy")
@export var energy_per_shot: float = 0.0

@export_group("Economy")
@export var base_price: int = 500
@export var manufacturer_faction_id: StringName = ""


func get_fire_interval() -> float:
	return 60.0 / float(fire_rate_rpm)


## Returns [shield_damage, hull_damage] for a single shot
func calc_damage_split(raw: float) -> Array[float]:
	var hull_dmg  : float = raw * hull_penetration_ratio
	var shield_dmg: float = raw * (1.0 - hull_penetration_ratio)
	return [shield_dmg, hull_dmg]


func can_equip_on(ship_class: GlobalEnums.ShipClass) -> bool:
	match ship_class:
		GlobalEnums.ShipClass.SMALL:  return equip_size == GlobalEnums.EquipSize.S1
		GlobalEnums.ShipClass.MEDIUM: return equip_size == GlobalEnums.EquipSize.S2
		GlobalEnums.ShipClass.LARGE:  return equip_size == GlobalEnums.EquipSize.S3
	return false
